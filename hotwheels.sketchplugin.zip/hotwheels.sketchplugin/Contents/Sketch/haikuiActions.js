var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

// TODO: async. Should probably be done with NSFileHandle and some notifications
// TODO: file descriptor. Needs to be done with NSFileHandle
var Buffer = __webpack_require__(7).Buffer;
var utils = __webpack_require__(11);
var parseStat = utils.parseStat;
var fsError = utils.fsError;
var fsErrorForPath = utils.fsErrorForPath;
var encodingFromOptions = utils.encodingFromOptions;
var NOT_IMPLEMENTED = utils.NOT_IMPLEMENTED;

module.exports.constants = {
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1,
};

module.exports.access = NOT_IMPLEMENTED("access");

module.exports.accessSync = function (path, mode) {
  mode = mode | 0;
  var fileManager = NSFileManager.defaultManager();

  switch (mode) {
    case 0:
      canAccess = module.exports.existsSync(path);
      break;
    case 1:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 2:
      canAccess = Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 3:
      canAccess =
        Boolean(Number(fileManager.isExecutableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 4:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path)));
      break;
    case 5:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 6:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 7:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
  }

  if (!canAccess) {
    throw new Error("Can't access " + String(path));
  }
};

module.exports.appendFile = NOT_IMPLEMENTED("appendFile");

module.exports.appendFileSync = function (file, data, options) {
  if (!module.exports.existsSync(file)) {
    return module.exports.writeFileSync(file, data, options);
  }

  var handle = NSFileHandle.fileHandleForWritingAtPath(file);
  handle.seekToEndOfFile();

  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  handle.writeData(nsdata);
};

module.exports.chmod = NOT_IMPLEMENTED("chmod");

module.exports.chmodSync = function (path, mode) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFilePosixPermissions: mode,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.chown = NOT_IMPLEMENTED("chown");
module.exports.chownSync = NOT_IMPLEMENTED("chownSync");

module.exports.close = NOT_IMPLEMENTED("close");
module.exports.closeSync = NOT_IMPLEMENTED("closeSync");

module.exports.copyFile = NOT_IMPLEMENTED("copyFile");

module.exports.copyFileSync = function (path, dest, flags) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.copyItemAtPath_toPath_error(path, dest, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.createReadStream = NOT_IMPLEMENTED("createReadStream");
module.exports.createWriteStream = NOT_IMPLEMENTED("createWriteStream");

module.exports.exists = NOT_IMPLEMENTED("exists");

module.exports.existsSync = function (path) {
  var fileManager = NSFileManager.defaultManager();
  return Boolean(Number(fileManager.fileExistsAtPath(path)));
};

module.exports.fchmod = NOT_IMPLEMENTED("fchmod");
module.exports.fchmodSync = NOT_IMPLEMENTED("fchmodSync");
module.exports.fchown = NOT_IMPLEMENTED("fchown");
module.exports.fchownSync = NOT_IMPLEMENTED("fchownSync");
module.exports.fdatasync = NOT_IMPLEMENTED("fdatasync");
module.exports.fdatasyncSync = NOT_IMPLEMENTED("fdatasyncSync");
module.exports.fstat = NOT_IMPLEMENTED("fstat");
module.exports.fstatSync = NOT_IMPLEMENTED("fstatSync");
module.exports.fsync = NOT_IMPLEMENTED("fsync");
module.exports.fsyncSync = NOT_IMPLEMENTED("fsyncSync");
module.exports.ftruncate = NOT_IMPLEMENTED("ftruncate");
module.exports.ftruncateSync = NOT_IMPLEMENTED("ftruncateSync");
module.exports.futimes = NOT_IMPLEMENTED("futimes");
module.exports.futimesSync = NOT_IMPLEMENTED("futimesSync");

module.exports.lchmod = NOT_IMPLEMENTED("lchmod");
module.exports.lchmodSync = NOT_IMPLEMENTED("lchmodSync");
module.exports.lchown = NOT_IMPLEMENTED("lchown");
module.exports.lchownSync = NOT_IMPLEMENTED("lchownSync");

module.exports.link = NOT_IMPLEMENTED("link");

module.exports.linkSync = function (existingPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.linkItemAtPath_toPath_error(existingPath, newPath, err);

  if (err.value() !== null) {
    throw fsErrorForPath(existingPath, undefined, err.value());
  }
};

module.exports.lstat = NOT_IMPLEMENTED("lstat");

module.exports.lstatSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.attributesOfItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return parseStat(result);
};

module.exports.mkdir = NOT_IMPLEMENTED("mkdir");

module.exports.mkdirSync = function (path, options) {
  var mode = 0o777;
  var recursive = false;
  if (options && options.mode) {
    mode = options.mode;
  }
  if (options && options.recursive) {
    recursive = options.recursive;
  }
  if (typeof options === "number") {
    mode = options;
  }
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(
    path,
    recursive,
    {
      NSFilePosixPermissions: mode,
    },
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.mkdtemp = NOT_IMPLEMENTED("mkdtemp");

module.exports.mkdtempSync = function (path) {
  function makeid() {
    var text = "";
    var possible =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 6; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  var tempPath = path + makeid();
  module.exports.mkdirSync(tempPath);
  return tempPath;
};

module.exports.open = NOT_IMPLEMENTED("open");
module.exports.openSync = NOT_IMPLEMENTED("openSync");

module.exports.read = NOT_IMPLEMENTED("read");

module.exports.readdir = NOT_IMPLEMENTED("readdir");

module.exports.readdirSync = function (path, options) {
  var encoding = encodingFromOptions(options, "utf8");
  var fileManager = NSFileManager.defaultManager();
  var paths = fileManager.subpathsAtPath(path);
  var arr = [];
  for (var i = 0; i < paths.length; i++) {
    var pathName = paths[i];
    arr.push(encoding === "buffer" ? Buffer.from(pathName) : String(pathName));
  }
  return arr;
};

module.exports.readFile = NOT_IMPLEMENTED("readFile");

module.exports.readFileSync = function (path, options) {
  var encoding = encodingFromOptions(options, "buffer");
  var fileManager = NSFileManager.defaultManager();
  var data = fileManager.contentsAtPath(path);
  if (!data) {
    throw fsErrorForPath(path, false);
  }

  var buffer = Buffer.from(data);

  if (encoding === "buffer") {
    return buffer;
  } else if (encoding === "NSData") {
    return buffer.toNSData();
  } else {
    return buffer.toString(encoding);
  }
};

module.exports.readlink = NOT_IMPLEMENTED("readlink");

module.exports.readlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.destinationOfSymbolicLinkAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return String(result);
};

module.exports.readSync = NOT_IMPLEMENTED("readSync");

module.exports.realpath = NOT_IMPLEMENTED("realpath");
module.exports.realpath.native = NOT_IMPLEMENTED("realpath.native");

module.exports.realpathSync = function (path) {
  return String(
    NSString.stringWithString(path).stringByResolvingSymlinksInPath()
  );
};

module.exports.realpathSync.native = NOT_IMPLEMENTED("realpathSync.native");

module.exports.rename = NOT_IMPLEMENTED("rename");

module.exports.renameSync = function (oldPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.moveItemAtPath_toPath_error(oldPath, newPath, err);

  var error = err.value();

  if (error !== null) {
    // if there is already a file, we need to overwrite it
    if (
      String(error.domain()) === "NSCocoaErrorDomain" &&
      Number(error.code()) === 516
    ) {
      var err2 = MOPointer.alloc().init();
      fileManager.replaceItemAtURL_withItemAtURL_backupItemName_options_resultingItemURL_error(
        NSURL.fileURLWithPath(newPath),
        NSURL.fileURLWithPath(oldPath),
        null,
        NSFileManagerItemReplacementUsingNewMetadataOnly,
        null,
        err2
      );
      if (err2.value() !== null) {
        throw fsErrorForPath(oldPath, undefined, err2.value());
      }
    } else {
      throw fsErrorForPath(oldPath, undefined, error);
    }
  }
};

module.exports.rmdir = NOT_IMPLEMENTED("rmdir");

module.exports.rmdirSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (!isDirectory) {
    throw fsError("ENOTDIR", {
      path: path,
      syscall: "rmdir",
    });
  }
  fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, true, err.value(), "rmdir");
  }
};

module.exports.stat = NOT_IMPLEMENTED("stat");

// the only difference with lstat is that we resolve symlinks
//
// > lstat() is identical to stat(), except that if pathname is a symbolic
// > link, then it returns information about the link itself, not the file
// > that it refers to.
// http://man7.org/linux/man-pages/man2/lstat.2.html
module.exports.statSync = function (path) {
  return module.exports.lstatSync(module.exports.realpathSync(path));
};

module.exports.symlink = NOT_IMPLEMENTED("symlink");

module.exports.symlinkSync = function (target, path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.createSymbolicLinkAtPath_withDestinationPath_error(
    path,
    target,
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.truncate = NOT_IMPLEMENTED("truncate");

module.exports.truncateSync = function (path, len) {
  var hFile = NSFileHandle.fileHandleForUpdatingAtPath(sFilePath);
  hFile.truncateFileAtOffset(len || 0);
  hFile.closeFile();
};

module.exports.unlink = NOT_IMPLEMENTED("unlink");

module.exports.unlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (isDirectory) {
    throw fsError("EPERM", {
      path: path,
      syscall: "unlink",
    });
  }
  var result = fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.unwatchFile = NOT_IMPLEMENTED("unwatchFile");

module.exports.utimes = NOT_IMPLEMENTED("utimes");

module.exports.utimesSync = function (path, aTime, mTime) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFileModificationDate: aTime,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.watch = NOT_IMPLEMENTED("watch");
module.exports.watchFile = NOT_IMPLEMENTED("watchFile");

module.exports.write = NOT_IMPLEMENTED("write");

module.exports.writeFile = NOT_IMPLEMENTED("writeFile");

module.exports.writeFileSync = function (path, data, options) {
  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  nsdata.writeToFile_atomically(path, true);
};

module.exports.writeSync = NOT_IMPLEMENTED("writeSync");


/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(Promise) {/* unused harmony export walkLayerTree */
/* unused harmony export arrayFromNSArray */
/* unused harmony export dictFromNSDict */
/* unused harmony export getAllLayersMatchingPredicate */
/* unused harmony export getFirstLayerMatchingPredicate */
/* unused harmony export getLayerById */
/* unused harmony export mkdirpSync */
/* unused harmony export loadDocFromSketchFile */
/* unused harmony export getLayerImage */
/* unused harmony export captureLayerImage */
/* unused harmony export nsImageToDataUri */
/* unused harmony export getPluginCachePath */
/* unused harmony export rmdirRecursive */
/* unused harmony export unpeg */
/* unused harmony export _profile */
/* unused harmony export getDocumentName */
/* unused harmony export connectedNetwork */
/* unused harmony export getUserRole */
/* unused harmony export handleFilePath */
/* unused harmony export isFileExist */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return writeFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return writeAndAppendFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return readFile; });
/* unused harmony export getPluginFolderPath */
/* unused harmony export isContainer */
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_skpm_path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4);
/* harmony import */ var sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8);
/*
 * Copyright 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */






/**
 * Performs a depth-first traversal of the layer tree, starting
 * at the provided root layer.
 */
function walkLayerTree(rootLayer, visitFunction) {
  var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
      reverse: false
    },
    reverse = _ref.reverse;
  var _visit_ = function visit_(layer) {
    // visit this layer
    visitFunction(layer);

    // visit children
    var subLayers;
    if ('layers' in layer) {
      subLayers = arrayFromNSArray(layer.layers());
    } else if ('artboards' in layer) {
      subLayers = arrayFromNSArray(layer.artboards());
    } else {
      return;
    }
    if (reverse) {
      subLayers.reverse();
    }
    subLayers.forEach(function (subLayer) {
      return _visit_(subLayer);
    });
  };
  _visit_(rootLayer);
}

/**
 * Converts an NSArray to a JS array
 */
function arrayFromNSArray(nsArray) {
  // TODO: this may no longer be needed... as of recent versions of sketch
  // NSArray seems to be array-like. or at least replace with Array.from(nsarray)
  var arr = [];
  var count = nsArray.count();
  for (var i = 0; i < count; i++) {
    arr.push(nsArray.objectAtIndex(i));
  }
  return arr;
}

/**
 * Convert an NSDictionary-type object to a JS dict.
 * As of Sketch 50.2, this is needed for some cases of symbol instance overrides
 */
function dictFromNSDict(nsDict) {
  var dict = {};

  /* eslint-disable */
  for (var key in nsDict) {
    dict[key] = nsDict[key];
  }
  /* eslint-disable */

  return dict;
}

/**
 * Returns the first layer matching the given NSPredicate
 *
 * @param {MSDocument|MSLayerGroup} parent The document or layer group to search.
 * @param {NSPredicate} predicate Search predicate
 */
function getAllLayersMatchingPredicate(parent, predicate) {
  if (parent instanceof MSDocument) {
    // MSDocument
    return parent.pages().reduce(function (acc, page) {
      return acc.concat(getAllLayersMatchingPredicate(page, predicate));
    }, []);
  }

  // assume MSLayerGroup
  return Array.from(parent.children().filteredArrayUsingPredicate(predicate));
}

/**
 * Returns the first layer matching the given NSPredicate
 *
 * @param {MSDocument|MSLayerGroup} parent The document or layer group to search.
 * @param {NSPredicate} predicate Search predicate
 */
function getFirstLayerMatchingPredicate(parent, predicate) {
  if (parent instanceof MSDocument) {
    // MSDocument
    var results;
    for (var _i = 0, _Array$from = Array.from(parent.pages()); _i < _Array$from.length; _i++) {
      page = _Array$from[_i];
      var firstInPage = getFirstLayerMatchingPredicate(page, predicate);
      if (firstInPage) {
        return firstInPage;
      }
    }
    return null;
  }

  // assume MSLayerGroup
  return getAllLayersMatchingPredicate(parent, predicate)[0] || null;
}

/**
 * Finds the layer with the given objectID in the given document.
 */
function getLayerById(document, layerId) {
  return getFirstLayerMatchingPredicate(document, NSPredicate.predicateWithFormat('objectID == %@', layerId));
}

/**
 * Copied from @skpm/fs with intermediate directories.
 */
function mkdirpSync(path, mode) {
  mode = mode || 511;
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(path, true, {
    NSFilePosixPermissions: mode
  }, err);
  if (err.value() !== null) {
    throw new Error(err.value());
  }
}

/**
 * Returns an MSDocument for the given .sketch file path. May take
 * a long time!
 */
function loadDocFromSketchFile(filePath) {
  var doc = MSDocument.new();
  doc.readDocumentFromURL_ofType_error_(NSURL.fileURLWithPath(filePath), 'com.bohemiancoding.sketch.drawing', null);
  return doc;
}

/**
 * Returns an NSImage for the given layer in the given document.
 */
function getLayerImage(document, layer) {
  var tempPath = NSTemporaryDirectory().stringByAppendingPathComponent("".concat(NSUUID.UUID().UUIDString(), ".png"));
  captureLayerImage(document, layer, tempPath);
  return NSImage.alloc().initWithContentsOfFile(tempPath);
}

/**
 * Saves the given layer in the given document to a PNG file at the given path.
 */
function captureLayerImage(document, layer, destPath) {
  var air = layer.absoluteInfluenceRect();
  var rect = NSMakeRect(air.origin.x, air.origin.y, air.size.width, air.size.height);
  var exportRequest = MSExportRequest.exportRequestsFromLayerAncestry_inRect_(MSImmutableLayerAncestry.ancestryWithMSLayer_(layer), rect // we pass this to avoid trimming
  ).firstObject();
  exportRequest.format = 'png';
  exportRequest.scale = 2;
  if (!(layer instanceof MSArtboardGroup || layer instanceof MSSymbolMaster)) {
    exportRequest.includeArtboardBackground = false;
  }

  // exportRequest.shouldTrim = false;
  document.saveArtboardOrSlice_toFile_(exportRequest, destPath);
}

/**
 * Converts an NSImage to a data URL string (png).
 */
function nsImageToDataUri(image) {
  var data = image.TIFFRepresentation();
  var bitmap = NSBitmapImageRep.imageRepWithData(data);
  data = bitmap.representationUsingType_properties_(NSPNGFileType, null);
  var base64 = "data:image/png;base64,".concat(data.base64EncodedStringWithOptions(0));
  return base64;
}

/**
 * Returns the system cache path for the plugin.
 */
function getPluginCachePath() {
  var cachePath = String(NSFileManager.defaultManager().URLsForDirectory_inDomains_(NSCachesDirectory, NSUserDomainMask)[0].path());

  // // console.log(cachePath);
  var pluginCacheKey = String(__command.pluginBundle().identifier()); // TODO: escape if needed

  // // console.log(pluginCacheKey);

  return _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.join(cachePath, pluginCacheKey);
}

/**
 * Deletes the given file or directory recursively (i.e. it and its
 * subfolders).
 */
function rmdirRecursive(path) {
  NSFileManager.defaultManager().removeItemAtPath_error_(path, null);
}

/**
 * Give the CPU some breathing room.
 */
function unpeg() {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      return resolve();
    }, 0);
  }).catch(function (err) {
    console.log('unpeg error:', err);
    throw err;
  });
}

/**
 * Profile the running time of a method
 */
function _profile(fnOrPromise) {
  var tag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  tag = tag ? " [".concat(tag, "]") : '';
  var t = Number(new Date());
  var finish = function finish() {
    t = Number(new Date()) - t;
    // log(`profile${tag}: ${t}ms`);
  };
  if (fnOrPromise instanceof Promise) {
    fnOrPromise.then(function () {
      return finish();
    });
    return fnOrPromise;
  }
  fnOrPromise();
  finish();
}

/**
 * Returns the name of the given document, if it has one.
 *
 * @param {MSDocument} document
 */
function getDocumentName(document) {
  var fileURL = document.fileURL();
  if (fileURL) {
    fileURL = String(fileURL.path());
    return _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.basename(fileURL).replace(/\.[^.]+$/, ''); // strip extension
  }
  return null;
}
var connectedNetwork = function connectedNetwork(successCallBack) {
  sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2___default()("https://img.58cdn.com.cn/lbg/picasso/picasso_6061.png?".concat(Number(new Date()))).then(function (res) {
    // // console.log('网络正常', res, res.status, res.url);

    successCallBack();
  }).catch(function (err) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('网络异常，请检测网络连接！');
    // console.log('qwert网络异常', err);
  });
};
var getUserRole = function getUserRole(userId, callBack) {
  var isIn = false;
  sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2___default()("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* host */ "a"], "/api/info/userrole?userId=").concat(userId)).then(function (res) {
    isIn = true;
    var data = res.json()._value.data;
    var role = data.userInfo && data.userInfo[0] && data.userInfo[0].role_id || '';
    callBack && callBack(role);
  }).catch(function (err) {
    if (!isIn) {
      sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('用户权限获取失败');
      // callBack && callBack('')
    }
  });
};

// 路径处理, 处理波浪号路径和中文路径
var handleFilePath = function handleFilePath(filePath) {
  if (!filePath) return null;

  // 展开波浪号路径
  var nsStringPath = NSString.stringWithString(filePath).stringByExpandingTildeInPath();

  // 只在确实需要时才解码
  // 检查是否包含百分号编码
  if (nsStringPath.includes('%')) {
    var decodedPath = nsStringPath.stringByRemovingPercentEncoding();
    // 解码成功则使用，失败则使用原路径
    return String(decodedPath || nsStringPath);
  }
  return String(nsStringPath);
};

/**
 * @desc 以下为文件读写相关操作，使用时文件名称必须完整，包括文件后缀
 * @param {*} context sketch内容
 * @param {*} fileName 文件名称
 */
function isFileExist(context, fileName) {
  var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  try {
    var isExist = _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.existsSync("".concat(pluginFolderPath, "/").concat(fileName));
    return isExist;
  } catch (e) {
    console.log('isFileExist Error: ', e);
    return false;
  }
}
function writeFile(context, fileName) {
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var path = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  try {
    _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(pluginFolderPath, "/").concat(fileName), JSON.stringify(data, null, 2), {
      encoding: 'utf8'
    });
  } catch (e) {
    console.log('writeFile Error: ', e);
    return false;
  }
}
function writeAndAppendFile(context, fileName) {
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var path = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  var isExist = isFileExist(context, fileName);
  try {
    if (isExist) {
      // 存在
      _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.appendFileSync("".concat(pluginFolderPath, "/").concat(fileName), ",".concat(JSON.stringify(data)), {
        encoding: 'utf8'
      });
    } else {
      // 不存在
      _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(pluginFolderPath, "/").concat(fileName), JSON.stringify(data), {
        encoding: 'utf8'
      });
    }
  } catch (e) {
    console.log('writeAndAppendFile Error: ', e);
    return false;
  }
}
function readFile(context, fileName) {
  var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  var isExist = isFileExist(context, fileName, path);
  try {
    if (isExist) {
      var data = _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.readFileSync("".concat(pluginFolderPath, "/").concat(fileName), {
        encoding: 'utf8'
      });
      return data;
    } else {
      return '{}';
    }
  } catch (e) {
    console.log('readFile Error: ', e);
    return '{}';
  }
}
function getPluginFolderPath(context) {
  // console.log('context.scriptPath', context.scriptPath);
  var split = context.scriptPath.split('/');
  // const split = context?.scriptPath ? context.scriptPath.split('/') : context?.path;

  split.splice(-3, 3);
  // 创建存储插件数据的文件夹
  var pluginDataPath = _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.join(split.join('/'), '../../hotwheels_data');
  if (!_skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.existsSync(pluginDataPath)) {
    _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.mkdirSync(pluginDataPath);
  }

  // console.log('资源存储路径pluginDataPath', pluginDataPath); // /Users/meiyuju/Library/Application\ Support/com.bohemiancoding.sketch3/hotwheels_data

  return pluginDataPath;
}

// 判断是否为容器
function isContainer(layer) {
  return layer.type === 'Artboard' || layer.isFrame || layer.isGraphicFrame;
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(6)))

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var sketchSpecifics = __webpack_require__(12)

// we only expose the posix implementation since Sketch only runs on macOS

var CHAR_FORWARD_SLASH = 47
var CHAR_DOT = 46

// Resolves . and .. elements in a path with directory names
function normalizeString(path, allowAboveRoot) {
  var res = ''
  var lastSegmentLength = 0
  var lastSlash = -1
  var dots = 0
  var code
  for (var i = 0; i <= path.length; i += 1) {
    if (i < path.length) code = path.charCodeAt(i)
    else if (code === CHAR_FORWARD_SLASH) break
    else code = CHAR_FORWARD_SLASH
    if (code === CHAR_FORWARD_SLASH) {
      if (lastSlash === i - 1 || dots === 1) {
        // NOOP
      } else if (lastSlash !== i - 1 && dots === 2) {
        if (
          res.length < 2 ||
          lastSegmentLength !== 2 ||
          res.charCodeAt(res.length - 1) !== CHAR_DOT ||
          res.charCodeAt(res.length - 2) !== CHAR_DOT
        ) {
          if (res.length > 2) {
            var lastSlashIndex = res.lastIndexOf('/')
            if (lastSlashIndex !== res.length - 1) {
              if (lastSlashIndex === -1) {
                res = ''
                lastSegmentLength = 0
              } else {
                res = res.slice(0, lastSlashIndex)
                lastSegmentLength = res.length - 1 - res.lastIndexOf('/')
              }
              lastSlash = i
              dots = 0
              continue
            }
          } else if (res.length === 2 || res.length === 1) {
            res = ''
            lastSegmentLength = 0
            lastSlash = i
            dots = 0
            continue
          }
        }
        if (allowAboveRoot) {
          if (res.length > 0) res += '/..'
          else res = '..'
          lastSegmentLength = 2
        }
      } else {
        if (res.length > 0) res += '/' + path.slice(lastSlash + 1, i)
        else res = path.slice(lastSlash + 1, i)
        lastSegmentLength = i - lastSlash - 1
      }
      lastSlash = i
      dots = 0
    } else if (code === CHAR_DOT && dots !== -1) {
      ++dots
    } else {
      dots = -1
    }
  }
  return res
}

function _format(sep, pathObject) {
  var dir = pathObject.dir || pathObject.root
  var base =
    pathObject.base || (pathObject.name || '') + (pathObject.ext || '')
  if (!dir) {
    return base
  }
  if (dir === pathObject.root) {
    return dir + base
  }
  return dir + sep + base
}

var posix = {
  // path.resolve([from ...], to)
  resolve: function resolve() {
    var resolvedPath = ''
    var resolvedAbsolute = false
    var cwd

    for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i -= 1) {
      var path
      if (i >= 0) {
        path = arguments[i]
      } else {
        if (cwd === undefined) {
          cwd = posix.dirname(sketchSpecifics.cwd())
        }
        path = cwd
      }

      path = sketchSpecifics.getString(path, 'path')

      // Skip empty entries
      if (path.length === 0) {
        continue
      }

      resolvedPath = path + '/' + resolvedPath
      resolvedAbsolute = path.charCodeAt(0) === CHAR_FORWARD_SLASH
    }

    // At this point the path should be resolved to a full absolute path, but
    // handle relative paths to be safe (might happen when process.cwd() fails)

    // Normalize the path
    resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute)

    if (resolvedAbsolute) {
      if (resolvedPath.length > 0) return '/' + resolvedPath
      else return '/'
    } else if (resolvedPath.length > 0) {
      return resolvedPath
    } else {
      return '.'
    }
  },

  normalize: function normalize(path) {
    path = sketchSpecifics.getString(path, 'path')

    if (path.length === 0) return '.'

    var isAbsolute = path.charCodeAt(0) === CHAR_FORWARD_SLASH
    var trailingSeparator =
      path.charCodeAt(path.length - 1) === CHAR_FORWARD_SLASH

    // Normalize the path
    path = normalizeString(path, !isAbsolute)

    if (path.length === 0 && !isAbsolute) path = '.'
    if (path.length > 0 && trailingSeparator) path += '/'

    if (isAbsolute) return '/' + path
    return path
  },

  isAbsolute: function isAbsolute(path) {
    path = sketchSpecifics.getString(path, 'path')
    return path.length > 0 && path.charCodeAt(0) === CHAR_FORWARD_SLASH
  },

  join: function join() {
    if (arguments.length === 0) return '.'
    var joined
    for (var i = 0; i < arguments.length; i += 1) {
      var arg = arguments[i]
      arg = sketchSpecifics.getString(arg, 'path')
      if (arg.length > 0) {
        if (joined === undefined) joined = arg
        else joined += '/' + arg
      }
    }
    if (joined === undefined) return '.'
    return posix.normalize(joined)
  },

  relative: function relative(from, to) {
    from = sketchSpecifics.getString(from, 'from path')
    to = sketchSpecifics.getString(to, 'to path')

    if (from === to) return ''

    from = posix.resolve(from)
    to = posix.resolve(to)

    if (from === to) return ''

    // Trim any leading backslashes
    var fromStart = 1
    for (; fromStart < from.length; fromStart += 1) {
      if (from.charCodeAt(fromStart) !== CHAR_FORWARD_SLASH) break
    }
    var fromEnd = from.length
    var fromLen = fromEnd - fromStart

    // Trim any leading backslashes
    var toStart = 1
    for (; toStart < to.length; toStart += 1) {
      if (to.charCodeAt(toStart) !== CHAR_FORWARD_SLASH) break
    }
    var toEnd = to.length
    var toLen = toEnd - toStart

    // Compare paths to find the longest common path from root
    var length = fromLen < toLen ? fromLen : toLen
    var lastCommonSep = -1
    var i = 0
    for (; i <= length; i += 1) {
      if (i === length) {
        if (toLen > length) {
          if (to.charCodeAt(toStart + i) === CHAR_FORWARD_SLASH) {
            // We get here if `from` is the exact base path for `to`.
            // For example: from='/foo/bar'; to='/foo/bar/baz'
            return to.slice(toStart + i + 1)
          } else if (i === 0) {
            // We get here if `from` is the root
            // For example: from='/'; to='/foo'
            return to.slice(toStart + i)
          }
        } else if (fromLen > length) {
          if (from.charCodeAt(fromStart + i) === CHAR_FORWARD_SLASH) {
            // We get here if `to` is the exact base path for `from`.
            // For example: from='/foo/bar/baz'; to='/foo/bar'
            lastCommonSep = i
          } else if (i === 0) {
            // We get here if `to` is the root.
            // For example: from='/foo'; to='/'
            lastCommonSep = 0
          }
        }
        break
      }
      var fromCode = from.charCodeAt(fromStart + i)
      var toCode = to.charCodeAt(toStart + i)
      if (fromCode !== toCode) break
      else if (fromCode === CHAR_FORWARD_SLASH) lastCommonSep = i
    }

    var out = ''
    // Generate the relative path based on the path difference between `to`
    // and `from`
    for (i = fromStart + lastCommonSep + 1; i <= fromEnd; i += 1) {
      if (i === fromEnd || from.charCodeAt(i) === CHAR_FORWARD_SLASH) {
        if (out.length === 0) out += '..'
        else out += '/..'
      }
    }

    // Lastly, append the rest of the destination (`to`) path that comes after
    // the common path parts
    if (out.length > 0) return out + to.slice(toStart + lastCommonSep)
    else {
      toStart += lastCommonSep
      if (to.charCodeAt(toStart) === CHAR_FORWARD_SLASH) toStart += 1
      return to.slice(toStart)
    }
  },

  toNamespacedPath: function toNamespacedPath(path) {
    // Non-op on posix systems
    return path
  },

  dirname: function dirname(path) {
    path = sketchSpecifics.getString(path, 'path')
    if (path.length === 0) return '.'
    var code = path.charCodeAt(0)
    var hasRoot = code === CHAR_FORWARD_SLASH
    var end = -1
    var matchedSlash = true
    for (var i = path.length - 1; i >= 1; i -= 1) {
      code = path.charCodeAt(i)
      if (code === CHAR_FORWARD_SLASH) {
        if (!matchedSlash) {
          end = i
          break
        }
      } else {
        // We saw the first non-path separator
        matchedSlash = false
      }
    }

    if (end === -1) return hasRoot ? '/' : '.'
    if (hasRoot && end === 1) return '//'
    return path.slice(0, end)
  },

  basename: function basename(path, ext) {
    if (ext !== undefined)
      ext = sketchSpecifics.getString(ext, 'ext')
    path = sketchSpecifics.getString(path, 'path')

    var start = 0
    var end = -1
    var matchedSlash = true
    var i

    if (ext !== undefined && ext.length > 0 && ext.length <= path.length) {
      if (ext.length === path.length && ext === path) return ''
      var extIdx = ext.length - 1
      var firstNonSlashEnd = -1
      for (i = path.length - 1; i >= 0; i -= 1) {
        var code = path.charCodeAt(i)
        if (code === CHAR_FORWARD_SLASH) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            start = i + 1
            break
          }
        } else {
          if (firstNonSlashEnd === -1) {
            // We saw the first non-path separator, remember this index in case
            // we need it if the extension ends up not matching
            matchedSlash = false
            firstNonSlashEnd = i + 1
          }
          if (extIdx >= 0) {
            // Try to match the explicit extension
            if (code === ext.charCodeAt(extIdx)) {
              if (--extIdx === -1) {
                // We matched the extension, so mark this as the end of our path
                // component
                end = i
              }
            } else {
              // Extension does not match, so our result is the entire path
              // component
              extIdx = -1
              end = firstNonSlashEnd
            }
          }
        }
      }

      if (start === end) end = firstNonSlashEnd
      else if (end === -1) end = path.length
      return path.slice(start, end)
    } else {
      for (i = path.length - 1; i >= 0; --i) {
        if (path.charCodeAt(i) === CHAR_FORWARD_SLASH) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            start = i + 1
            break
          }
        } else if (end === -1) {
          // We saw the first non-path separator, mark this as the end of our
          // path component
          matchedSlash = false
          end = i + 1
        }
      }

      if (end === -1) return ''
      return path.slice(start, end)
    }
  },

  extname: function extname(path) {
    path = sketchSpecifics.getString(path, 'path')
    var startDot = -1
    var startPart = 0
    var end = -1
    var matchedSlash = true
    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0
    for (var i = path.length - 1; i >= 0; --i) {
      var code = path.charCodeAt(i)
      if (code === CHAR_FORWARD_SLASH) {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          startPart = i + 1
          break
        }
        continue
      }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false
        end = i + 1
      }
      if (code === CHAR_DOT) {
        // If this is our first dot, mark it as the start of our extension
        if (startDot === -1) startDot = i
        else if (preDotState !== 1) preDotState = 1
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1
      }
    }

    if (
      startDot === -1 ||
      end === -1 ||
      // We saw a non-dot character immediately before the dot
      preDotState === 0 ||
      // The (right-most) trimmed path component is exactly '..'
      (preDotState === 1 && startDot === end - 1 && startDot === startPart + 1)
    ) {
      return ''
    }
    return path.slice(startDot, end)
  },

  format: function format(pathObject) {
    if (pathObject === null || typeof pathObject !== 'object') {
      throw new Error('pathObject should be an Object')
    }
    return _format('/', pathObject)
  },

  parse: function parse(path) {
    path = sketchSpecifics.getString(path, 'path')

    var ret = { root: '', dir: '', base: '', ext: '', name: '' }
    if (path.length === 0) return ret
    var code = path.charCodeAt(0)
    var isAbsolute = code === CHAR_FORWARD_SLASH
    var start
    if (isAbsolute) {
      ret.root = '/'
      start = 1
    } else {
      start = 0
    }
    var startDot = -1
    var startPart = 0
    var end = -1
    var matchedSlash = true
    var i = path.length - 1

    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0

    // Get non-dir info
    for (; i >= start; --i) {
      code = path.charCodeAt(i)
      if (code === CHAR_FORWARD_SLASH) {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          startPart = i + 1
          break
        }
        continue
      }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false
        end = i + 1
      }
      if (code === CHAR_DOT) {
        // If this is our first dot, mark it as the start of our extension
        if (startDot === -1) startDot = i
        else if (preDotState !== 1) preDotState = 1
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1
      }
    }

    if (
      startDot === -1 ||
      end === -1 ||
      // We saw a non-dot character immediately before the dot
      preDotState === 0 ||
      // The (right-most) trimmed path component is exactly '..'
      (preDotState === 1 && startDot === end - 1 && startDot === startPart + 1)
    ) {
      if (end !== -1) {
        if (startPart === 0 && isAbsolute)
          ret.base = ret.name = path.slice(1, end)
        else ret.base = ret.name = path.slice(startPart, end)
      }
    } else {
      if (startPart === 0 && isAbsolute) {
        ret.name = path.slice(1, startDot)
        ret.base = path.slice(1, end)
      } else {
        ret.name = path.slice(startPart, startDot)
        ret.base = path.slice(startPart, end)
      }
      ret.ext = path.slice(startDot, end)
    }

    if (startPart > 0) ret.dir = path.slice(0, startPart - 1)
    else if (isAbsolute) ret.dir = '/'

    return ret
  },

  sep: '/',
  delimiter: ':',
  win32: null,
  posix: null,

  resourcePath: sketchSpecifics.resourcePath,
}

module.exports = posix
module.exports.posix = posix


/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(7).Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var exception;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          exception
        );
        if (exception != null) {
          var error = new TypeError(
            String(
              typeof exception.localizedDescription === "function"
                ? exception.localizedDescription()
                : exception
            )
          );
          reject(error);
          return;
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
          break;
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, exception) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          finished = true;
          try {
            if (exception) {
              var error = new TypeError(
                String(
                  typeof exception.localizedDescription === "function"
                    ? exception.localizedDescription()
                    : exception
                )
              );
              reject(error);
              return;
            }
            resolve(response(res, data));
          } catch (err) {
            reject(err);
          }
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(6)))

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export context */
/* unused harmony export document */
/* unused harmony export version */
/* unused harmony export sketchVersion */
/* unused harmony export pluginFolderPath */
/* unused harmony export resourcesPath */
/* unused harmony export documentObjectID */
/* unused harmony export IdentifierPrefix */
/* unused harmony export SidePanelIdentifier */
/* unused harmony export WINDOW_MOVE_INSTANCE */
/* unused harmony export WINDOW_MOVE_SELECTOR */
/* unused harmony export Menus */
/* unused harmony export sieBarConfig */
/* unused harmony export newAbilitys */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return host; });
/* unused harmony export sideBarIdentifier */
/* eslint-disable */
var context;
var document;
var version;
var sketchVersion;
var pluginFolderPath;
var resourcesPath;
var documentObjectID;
var IdentifierPrefix;
var SidePanelIdentifier;
var WINDOW_MOVE_INSTANCE;
var WINDOW_MOVE_SELECTOR;
var Menus;
var sieBarConfig;
var newAbilitys;
/* eslint-disable */
// 正式包 和 开发包环境区分

var host =  true ? 'https://hotplugin.58.com' : undefined;
var sideBarIdentifier = 'newbar.icon';
console.log("production", 'process.env.NODE_ENV');
console.log(host, 'host');
function updateIdentifier(objectID) {
  IdentifierPrefix = objectID ? "hotwheels-".concat(objectID) : 'hotwheels';
  SidePanelIdentifier = "".concat(IdentifierPrefix, "-side-panel");
  WINDOW_MOVE_INSTANCE = "window-move-instance-".concat(objectID);
  WINDOW_MOVE_SELECTOR = "window-move-selector-".concat(objectID);
  sieBarConfig = {
    identifier: SidePanelIdentifier,
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.newbar"),
    url: "".concat(host, "/sideBar.html"),
    // web 页面url
    width: 100,
    // webview 宽度
    height: 500,
    // webview 高度
    x: -100,
    y: -100,
    alwaysOnTop: true,
    resizableBoolean: true,
    movable: true,
    title: '',
    inGravityType: 6
  };
  // 插件菜单配置
  Menus = [{
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'icon',
    activeIcon: 'icon-active',
    tooltip: 'icon',
    identifier: "".concat(IdentifierPrefix, "-menu.icon"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.icon"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/icon.html"),
    // web 页面url
    width: 380,
    // webview 宽度
    height: 700,
    // webview 高度
    isTop: true
    // title: '图标',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'fill',
    activeIcon: 'fill-active',
    tooltip: '填充',
    identifier: "".concat(IdentifierPrefix, "-menu.color"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.color"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/color.html"),
    width: 380,
    height: 730,
    isTop: true
    // title: '填充',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'component',
    activeIcon: 'component-active',
    tooltip: '组件',
    identifier: "".concat(IdentifierPrefix, "-menu.basecomp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.basecomp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/basecomp.html"),
    width: 380,
    height: 700,
    isTop: true
    // title: '组件库',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'scene',
    activeIcon: 'scene-active',
    tooltip: '场景',
    identifier: "".concat(IdentifierPrefix, "-menu.scenariocomp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.scenariocomp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/scenariocomp.html"),
    width: 380,
    height: 700,
    isTop: true
    // title: '长颈库',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'textcomp',
    activeIcon: 'text-active',
    tooltip: '文字',
    identifier: "".concat(IdentifierPrefix, "-menu.textcomp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.textcomp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/textcomp.html"),
    width: 380,
    height: 700,
    isTop: true
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'drawcomp',
    activeIcon: 'drawcomp-active',
    tooltip: '插画',
    identifier: "".concat(IdentifierPrefix, "-menu.drawComp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.drawComp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/drawComp.html"),
    // web 页面url
    width: 380,
    // webview 宽度
    height: 700,
    // webview 高度
    isTop: true
    // title: '插画库',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'oprationcomp',
    activeIcon: 'oprationcomp-active',
    tooltip: '运营',
    identifier: "".concat(IdentifierPrefix, "-menu.operationComp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.operationComp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/operationComp.html"),
    // web 页面url
    width: 380,
    // webview 宽度
    height: 700,
    // webview 高度
    isTop: true
    // title: '运营',
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'import',
    activeIcon: 'import-active',
    tooltip: '导入',
    identifier: "".concat(IdentifierPrefix, "-menu.localLibrary"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.localLibrary"),
    type: 2,
    inGravityType: 1,
    url: "".concat(host, "/localLibrary.html"),
    width: 380,
    height: 400,
    isTop: true,
    isDialog: true
    // title: '导入',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'upload',
    activeIcon: 'upload-active',
    tooltip: '上传',
    identifier: "".concat(IdentifierPrefix, "-menu.upload"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.upload"),
    type: 2,
    inGravityType: 1,
    url: "".concat(host, "/upload.html"),
    width: 380,
    height: 550,
    isTop: true,
    isDialog: true
    // title: '上传',
  },
  // {
  //   rect: NSMakeRect(0, 0, 40, 40),
  //   size: NSMakeSize(22, 22),
  //   icon: 'upload',
  //   activeIcon: 'upload-active',
  //   tooltip: '测试',
  //   identifier: `${IdentifierPrefix}-menu.popover`,
  //   wkIdentifier: `${IdentifierPrefix}-webview.popover`,
  //   type: 2,
  //   inGravityType: 1,
  //   url: `${host}/popover.html`,
  //   width: 380,
  //   height: 521,
  //   isTop: true,
  //   isDialog: true,
  //   isPopover: true
  // },
  {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'publicUpload',
    activeIcon: 'publicUpload',
    identifier: "".concat(IdentifierPrefix, "-menu.publicUpload"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.publicUpload"),
    type: 2,
    inGravityType: 3,
    url: "".concat(host, "/publicLibrary.html"),
    width: 380,
    height: 440,
    isDialog: true,
    permissions: [1, 2]
    // title: '上传',
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'help',
    activeIcon: 'help',
    // tooltip: '帮助',
    identifier: "".concat(IdentifierPrefix, "-menu.help"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.help"),
    type: 2,
    inGravityType: 3,
    // url: '`${host}/help.html`',
    url: 'https://hotwheel.58.com/help',
    width: 380,
    height: 450,
    toOpenUrl: true
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'designPlatform',
    activeIcon: 'designPlatform',
    // tooltip: '设计平台',
    identifier: "".concat(IdentifierPrefix, "-menu.help"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.help"),
    type: 2,
    inGravityType: 3,
    url: 'https://hotwheel.58.com',
    width: 380,
    height: 280,
    toOpenUrl: true
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'pluginClose',
    activeIcon: 'pluginClose',
    // tooltip: '关闭',
    identifier: "".concat(IdentifierPrefix, "-menu.help"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.help"),
    type: 2,
    inGravityType: 3,
    url: "".concat(host, "/help.html"),
    width: 380,
    height: 343,
    toClose: true
  }];
  newAbilitys = {
    imageFill: {
      name: 'imageFill',
      target: "".concat(IdentifierPrefix, "-menu.color"),
      image: 'https://wos.58cdn.com.cn/cDazYxWcDHJ/picasso/6vo7jcs5.png',
      title: '设计更好看更规范的秘密',
      description: '图片与颜色填充都整合在这里了'
    }
    // ,
    // oprationcomp: {
    //   name: 'oprationcomp',
    //   target: `${IdentifierPrefix}-menu.operationComp`,
    //   image: 'https://wos.58cdn.com.cn/cDazYxWcDHJ/picasso/6vo7jcs5.png',
    //   title: '新增运营库啦',
    //   description: '开发也不知道说些啥，找产品定义一下吧'
    // }
  };
}
function getPluginFolderPath(_context) {
  // Get absolute folder path of plugin
  var split = _context.scriptPath.split('/');
  split.splice(-3, 3);
  return split.join('/');
}
/* unused harmony default export */ var _unused_webpack_default_export = (function (ctx) {
  context = ctx;
  document = context.document || context.actionContext.document || MSDocument.currentDocument();
  documentObjectID = document.documentData().objectID();
  updateIdentifier(documentObjectID);
  // eslint-disable-next-line no-new-wrappers
  version = new String(context.plugin.version()).toString();
  try {
    sketchVersion = MSApplicationMetadata.metadata().appVersion;
  } catch (err) {
    sketchVersion = BCSketchInfo.shared().metadata().appVersion;
  }
  // eslint-disable-next-line no-new-wrappers
  pluginFolderPath = getPluginFolderPath(context);
  resourcesPath = "".concat(pluginFolderPath, "/Contents/Resources");
});

/***/ }),
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onConvertSymbolOrDetachInstances", function() { return onConvertSymbolOrDetachInstances; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(10);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1);




/**
 * @desc 监听解绑：海葵组件解绑操作时触发
 * @param {*} context
 */
function onConvertSymbolOrDetachInstances(context) {
  var action = context.action,
    actionContext = context.actionContext;
  var document = actionContext.document;
  var _sketchDom$fromNative = sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.fromNative(document),
    selectedLayers = _sketchDom$fromNative.selectedLayers,
    documentId = _sketchDom$fromNative.id;
  var symbolInstance = selectedLayers.layers[0];
  var actionName = String(action);
  if (actionName.includes('begin')) {
    if (symbolInstance.type !== 'SymbolInstance') return; // 解绑前必须是 组件SymbolInstance

    // 获取数据库中组件，用于匹配
    var comData = Object(_util__WEBPACK_IMPORTED_MODULE_2__[/* readFile */ "a"])(context, '.comData');
    comData = JSON.parse(comData);
    var SLayer = symbolInstance.sketchObject;
    var _sketchDom$fromNative2 = sketch_dom__WEBPACK_IMPORTED_MODULE_1___default.a.fromNative(SLayer.symbolMaster()),
      id = _sketchDom$fromNative2.id,
      name = _sketchDom$fromNative2.name;

    // 是库中的组件则暂存在开始解绑的文件中
    if (comData[id]) {
      var param = {
        id: '',
        compId: id,
        componentType: comData[id][0].component_type,
        uicomponentName: comData[id][0].uicomponent_name || name
      };
      Object(_util__WEBPACK_IMPORTED_MODULE_2__[/* writeFile */ "c"])(context, '.detachingInstances', param);
    }
  } else if (actionName.includes('finish')) {
    if (symbolInstance.type !== 'Group') return; // 解绑后必须是 文件夹Group

    var detachedComInfo = Object(_util__WEBPACK_IMPORTED_MODULE_2__[/* readFile */ "a"])(context, '.detachingInstances');
    detachedComInfo = JSON.parse(detachedComInfo);

    // 没有正在解绑的文件
    if (!detachedComInfo.compId) return;

    // 解绑完成
    detachedComInfo.id = symbolInstance.id;
    detachedComInfo.detached = true;
    Object(_util__WEBPACK_IMPORTED_MODULE_2__[/* writeAndAppendFile */ "b"])(context, "document_".concat(documentId, ".json"), detachedComInfo);

    // 操作结束还原数据
    Object(_util__WEBPACK_IMPORTED_MODULE_2__[/* writeFile */ "c"])(context, '.detachingInstances', {});
  }
}

/**
 * @desc 复制
 */
// export function onCopy(context) {
//     const { action, actionContext } = context;
//     const actionName = String(action);

//     const { document } = actionContext;
//     const { selectedLayers } = sketchDom.fromNative(document);
//     const symbolInstance = selectedLayers.layers[0];

//     // 只监控组件或组件解绑后的文件夹
//     if (symbolInstance.type !== 'SymbolInstance' && symbolInstance.type !== 'Group') return;

//     const SLayer = symbolInstance.sketchObject;
//     const { id } = sketchDom.fromNative(SLayer.symbolMaster());

//     if (actionName.includes('begin')) {
//         // console.log('onCopy begin selectedLayers', selectedLayers, id);
//     } else if (actionName.includes('finish')) {
//         // console.log('onCopy finish selectedLayers', selectedLayers, id);
//     }
// }

/**
 * @desc 粘贴
 */
// export function onPaste(context) {
//     const { action, actionContext } = context;
//     const actionName = String(action);

//     const { document } = actionContext;
//     const { selectedLayers } = sketchDom.fromNative(document);
//     const symbolInstance = selectedLayers.layers[0];

//     // 只监控组件或组件解绑后的文件夹
//     if (symbolInstance.type !== 'SymbolInstance' && symbolInstance.type !== 'Group') return;

//     const SLayer = symbolInstance.sketchObject;
//     const { id } = sketchDom.fromNative(SLayer.symbolMaster());

//     if (actionName.includes('begin')) {
//         // console.log('onPaste begin selectedLayers', selectedLayers, id);
//     } else if (actionName.includes('finish')) {
//         // console.log('onPaste finish selectedLayers', selectedLayers, id);
//     }
// }

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

module.exports.parseStat = function parseStat(result) {
  return {
    dev: String(result.NSFileDeviceIdentifier),
    // ino: 48064969, The file system specific "Inode" number for the file.
    mode: result.NSFileType | result.NSFilePosixPermissions,
    nlink: Number(result.NSFileReferenceCount),
    uid: String(result.NSFileOwnerAccountID),
    gid: String(result.NSFileGroupOwnerAccountID),
    // rdev: 0, A numeric device identifier if the file is considered "special".
    size: Number(result.NSFileSize),
    // blksize: 4096, The file system block size for i/o operations.
    // blocks: 8, The number of blocks allocated for this file.
    atimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    mtimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    ctimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    birthtimeMs:
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000,
    atime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ), // the 0.5 comes from the node source. Not sure why it's added but in doubt...
    mtime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    ctime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    birthtime: new Date(
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    isBlockDevice: function () {
      return result.NSFileType === NSFileTypeBlockSpecial;
    },
    isCharacterDevice: function () {
      return result.NSFileType === NSFileTypeCharacterSpecial;
    },
    isDirectory: function () {
      return result.NSFileType === NSFileTypeDirectory;
    },
    isFIFO: function () {
      return false;
    },
    isFile: function () {
      return result.NSFileType === NSFileTypeRegular;
    },
    isSocket: function () {
      return result.NSFileType === NSFileTypeSocket;
    },
    isSymbolicLink: function () {
      return result.NSFileType === NSFileTypeSymbolicLink;
    },
  };
};

var ERRORS = {
  EPERM: {
    message: "operation not permitted",
    errno: -1,
  },
  ENOENT: {
    message: "no such file or directory",
    errno: -2,
  },
  EACCES: {
    message: "permission denied",
    errno: -13,
  },
  ENOTDIR: {
    message: "not a directory",
    errno: -20,
  },
  EISDIR: {
    message: "illegal operation on a directory",
    errno: -21,
  },
};

function fsError(code, options) {
  var error = new Error(
    code +
      ": " +
      ERRORS[code].message +
      ", " +
      (options.syscall || "") +
      (options.path ? " '" + options.path + "'" : "")
  );

  Object.keys(options).forEach(function (k) {
    error[k] = options[k];
  });

  error.code = code;
  error.errno = ERRORS[code].errno;

  return error;
}

module.exports.fsError = fsError;

module.exports.fsErrorForPath = function fsErrorForPath(
  path,
  shouldBeDir,
  err,
  syscall
) {
  var fileManager = NSFileManager.defaultManager();
  var doesExist = fileManager.fileExistsAtPath(path);
  if (!doesExist) {
    return fsError("ENOENT", {
      path: path,
      syscall: syscall || "open",
    });
  }
  var isReadable = fileManager.isReadableFileAtPath(path);
  if (!isReadable) {
    return fsError("EACCES", {
      path: path,
      syscall: syscall || "open",
    });
  }
  if (typeof shouldBeDir !== "undefined") {
    var isDirectory = __webpack_require__(0).lstatSync(path).isDirectory();
    if (isDirectory && !shouldBeDir) {
      return fsError("EISDIR", {
        path: path,
        syscall: syscall || "read",
      });
    } else if (!isDirectory && shouldBeDir) {
      return fsError("ENOTDIR", {
        path: path,
        syscall: syscall || "read",
      });
    }
  }
  return new Error(err || "Unknown error while manipulating " + path);
};

module.exports.encodingFromOptions = function encodingFromOptions(
  options,
  defaultValue
) {
  return options && options.encoding
    ? String(options.encoding)
    : options
    ? String(options)
    : defaultValue;
};

module.exports.NOT_IMPLEMENTED = function NOT_IMPLEMENTED(name) {
  return function () {
    throw new Error(
      "fs." +
        name +
        " is not implemented yet. If you feel like implementing it, any contribution will be gladly accepted on https://github.com/skpm/fs"
    );
  };
};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

var util = __webpack_require__(13)

module.exports.getString = function getString(path, argumentName) {
  if (!util.isString(path)) {
    // let's make a special case for NSURL
    if (util.getNativeClass(path) === 'NSURL') {
      return String(path.path().copy())
    }
    throw new Error(argumentName + ' should be a string. Got ' + typeof path + ' instead.')
  }
  return String(path)
}

module.exports.cwd = function cwd() {
  if (typeof __command !== 'undefined' && __command.script() && __command.script().URL()) {
    return String(__command.script().URL().path().copy())
  }
  return String(MSPluginManager.defaultPluginURL().path().copy())
}

module.exports.resourcePath = function resourcePath(resourceName) {
  if (typeof __command === 'undefined' || !__command.pluginBundle()) {
    return undefined
  }
  var resource = __command.pluginBundle().urlForResourceNamed(resourceName)
  if (!resource) {
    return undefined
  }
  return String(resource.path())
}


/***/ }),
/* 13 */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })
/******/ ]);
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['onConvertSymbolOrDetachInstances'] = __skpm_run.bind(this, 'onConvertSymbolOrDetachInstances');
globalThis['onRun'] = __skpm_run.bind(this, 'default')
