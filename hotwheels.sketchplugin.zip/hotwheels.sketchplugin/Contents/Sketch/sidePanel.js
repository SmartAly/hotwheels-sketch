var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 18);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return context; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return document; });
/* unused harmony export version */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "m", function() { return sketchVersion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return pluginFolderPath; });
/* unused harmony export resourcesPath */
/* unused harmony export documentObjectID */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return IdentifierPrefix; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return SidePanelIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return WINDOW_MOVE_INSTANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return WINDOW_MOVE_SELECTOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return Menus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "l", function() { return sieBarConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return newAbilitys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return host; });
/* unused harmony export sideBarIdentifier */
/* eslint-disable */
var context;
var document;
var version;
var sketchVersion;
var pluginFolderPath;
var resourcesPath;
var documentObjectID;
var IdentifierPrefix;
var SidePanelIdentifier;
var WINDOW_MOVE_INSTANCE;
var WINDOW_MOVE_SELECTOR;
var Menus;
var sieBarConfig;
var newAbilitys;
/* eslint-disable */
// 正式包 和 开发包环境区分

var host =  true ? 'https://hotplugin.58.com' : undefined;
var sideBarIdentifier = 'newbar.icon';
console.log("production", 'process.env.NODE_ENV');
console.log(host, 'host');
function updateIdentifier(objectID) {
  IdentifierPrefix = objectID ? "hotwheels-".concat(objectID) : 'hotwheels';
  SidePanelIdentifier = "".concat(IdentifierPrefix, "-side-panel");
  WINDOW_MOVE_INSTANCE = "window-move-instance-".concat(objectID);
  WINDOW_MOVE_SELECTOR = "window-move-selector-".concat(objectID);
  sieBarConfig = {
    identifier: SidePanelIdentifier,
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.newbar"),
    url: "".concat(host, "/sideBar.html"),
    // web 页面url
    width: 100,
    // webview 宽度
    height: 500,
    // webview 高度
    x: -100,
    y: -100,
    alwaysOnTop: true,
    resizableBoolean: true,
    movable: true,
    title: '',
    inGravityType: 6
  };
  // 插件菜单配置
  Menus = [{
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'icon',
    activeIcon: 'icon-active',
    tooltip: 'icon',
    identifier: "".concat(IdentifierPrefix, "-menu.icon"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.icon"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/icon.html"),
    // web 页面url
    width: 380,
    // webview 宽度
    height: 700,
    // webview 高度
    isTop: true
    // title: '图标',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'fill',
    activeIcon: 'fill-active',
    tooltip: '填充',
    identifier: "".concat(IdentifierPrefix, "-menu.color"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.color"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/color.html"),
    width: 380,
    height: 730,
    isTop: true
    // title: '填充',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'component',
    activeIcon: 'component-active',
    tooltip: '组件',
    identifier: "".concat(IdentifierPrefix, "-menu.basecomp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.basecomp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/basecomp.html"),
    width: 380,
    height: 700,
    isTop: true
    // title: '组件库',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'scene',
    activeIcon: 'scene-active',
    tooltip: '场景',
    identifier: "".concat(IdentifierPrefix, "-menu.scenariocomp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.scenariocomp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/scenariocomp.html"),
    width: 380,
    height: 700,
    isTop: true
    // title: '长颈库',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'textcomp',
    activeIcon: 'text-active',
    tooltip: '文字',
    identifier: "".concat(IdentifierPrefix, "-menu.textcomp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.textcomp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/textcomp.html"),
    width: 380,
    height: 700,
    isTop: true
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'drawcomp',
    activeIcon: 'drawcomp-active',
    tooltip: '插画',
    identifier: "".concat(IdentifierPrefix, "-menu.drawComp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.drawComp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/drawComp.html"),
    // web 页面url
    width: 380,
    // webview 宽度
    height: 700,
    // webview 高度
    isTop: true
    // title: '插画库',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'oprationcomp',
    activeIcon: 'oprationcomp-active',
    tooltip: '运营',
    identifier: "".concat(IdentifierPrefix, "-menu.operationComp"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.operationComp"),
    type: 2,
    inGravityType: 7,
    url: "".concat(host, "/operationComp.html"),
    // web 页面url
    width: 380,
    // webview 宽度
    height: 700,
    // webview 高度
    isTop: true
    // title: '运营',
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'import',
    activeIcon: 'import-active',
    tooltip: '导入',
    identifier: "".concat(IdentifierPrefix, "-menu.localLibrary"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.localLibrary"),
    type: 2,
    inGravityType: 1,
    url: "".concat(host, "/localLibrary.html"),
    width: 380,
    height: 400,
    isTop: true,
    isDialog: true
    // title: '导入',
  }, {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'upload',
    activeIcon: 'upload-active',
    tooltip: '上传',
    identifier: "".concat(IdentifierPrefix, "-menu.upload"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.upload"),
    type: 2,
    inGravityType: 1,
    url: "".concat(host, "/upload.html"),
    width: 380,
    height: 550,
    isTop: true,
    isDialog: true
    // title: '上传',
  },
  // {
  //   rect: NSMakeRect(0, 0, 40, 40),
  //   size: NSMakeSize(22, 22),
  //   icon: 'upload',
  //   activeIcon: 'upload-active',
  //   tooltip: '测试',
  //   identifier: `${IdentifierPrefix}-menu.popover`,
  //   wkIdentifier: `${IdentifierPrefix}-webview.popover`,
  //   type: 2,
  //   inGravityType: 1,
  //   url: `${host}/popover.html`,
  //   width: 380,
  //   height: 521,
  //   isTop: true,
  //   isDialog: true,
  //   isPopover: true
  // },
  {
    rect: NSMakeRect(0, 0, 40, 40),
    size: NSMakeSize(22, 22),
    icon: 'publicUpload',
    activeIcon: 'publicUpload',
    identifier: "".concat(IdentifierPrefix, "-menu.publicUpload"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.publicUpload"),
    type: 2,
    inGravityType: 3,
    url: "".concat(host, "/publicLibrary.html"),
    width: 380,
    height: 440,
    isDialog: true,
    permissions: [1, 2]
    // title: '上传',
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'help',
    activeIcon: 'help',
    // tooltip: '帮助',
    identifier: "".concat(IdentifierPrefix, "-menu.help"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.help"),
    type: 2,
    inGravityType: 3,
    // url: '`${host}/help.html`',
    url: 'https://hotwheel.58.com/help',
    width: 380,
    height: 450,
    toOpenUrl: true
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'designPlatform',
    activeIcon: 'designPlatform',
    // tooltip: '设计平台',
    identifier: "".concat(IdentifierPrefix, "-menu.help"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.help"),
    type: 2,
    inGravityType: 3,
    url: 'https://hotwheel.58.com',
    width: 380,
    height: 280,
    toOpenUrl: true
  }, {
    rect: NSMakeRect(0, 0, 40, 160),
    size: NSMakeSize(22, 22),
    icon: 'pluginClose',
    activeIcon: 'pluginClose',
    // tooltip: '关闭',
    identifier: "".concat(IdentifierPrefix, "-menu.help"),
    wkIdentifier: "".concat(IdentifierPrefix, "-webview.help"),
    type: 2,
    inGravityType: 3,
    url: "".concat(host, "/help.html"),
    width: 380,
    height: 343,
    toClose: true
  }];
  newAbilitys = {
    imageFill: {
      name: 'imageFill',
      target: "".concat(IdentifierPrefix, "-menu.color"),
      image: 'https://wos.58cdn.com.cn/cDazYxWcDHJ/picasso/6vo7jcs5.png',
      title: '设计更好看更规范的秘密',
      description: '图片与颜色填充都整合在这里了'
    }
    // ,
    // oprationcomp: {
    //   name: 'oprationcomp',
    //   target: `${IdentifierPrefix}-menu.operationComp`,
    //   image: 'https://wos.58cdn.com.cn/cDazYxWcDHJ/picasso/6vo7jcs5.png',
    //   title: '新增运营库啦',
    //   description: '开发也不知道说些啥，找产品定义一下吧'
    // }
  };
}
function getPluginFolderPath(_context) {
  // Get absolute folder path of plugin
  var split = _context.scriptPath.split('/');
  split.splice(-3, 3);
  return split.join('/');
}
/* harmony default export */ __webpack_exports__["g"] = (function (ctx) {
  context = ctx;
  document = context.document || context.actionContext.document || MSDocument.currentDocument();
  documentObjectID = document.documentData().objectID();
  updateIdentifier(documentObjectID);
  // eslint-disable-next-line no-new-wrappers
  version = new String(context.plugin.version()).toString();
  try {
    sketchVersion = MSApplicationMetadata.metadata().appVersion;
  } catch (err) {
    sketchVersion = BCSketchInfo.shared().metadata().appVersion;
  }
  // eslint-disable-next-line no-new-wrappers
  pluginFolderPath = getPluginFolderPath(context);
  resourcesPath = "".concat(pluginFolderPath, "/Contents/Resources");
});

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

// TODO: async. Should probably be done with NSFileHandle and some notifications
// TODO: file descriptor. Needs to be done with NSFileHandle
var Buffer = __webpack_require__(30).Buffer;
var utils = __webpack_require__(63);
var parseStat = utils.parseStat;
var fsError = utils.fsError;
var fsErrorForPath = utils.fsErrorForPath;
var encodingFromOptions = utils.encodingFromOptions;
var NOT_IMPLEMENTED = utils.NOT_IMPLEMENTED;

module.exports.constants = {
  F_OK: 0,
  R_OK: 4,
  W_OK: 2,
  X_OK: 1,
};

module.exports.access = NOT_IMPLEMENTED("access");

module.exports.accessSync = function (path, mode) {
  mode = mode | 0;
  var fileManager = NSFileManager.defaultManager();

  switch (mode) {
    case 0:
      canAccess = module.exports.existsSync(path);
      break;
    case 1:
      canAccess = Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 2:
      canAccess = Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 3:
      canAccess =
        Boolean(Number(fileManager.isExecutableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 4:
      canAccess = Boolean(Number(fileManager.isReadableFileAtPath(path)));
      break;
    case 5:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
    case 6:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path)));
      break;
    case 7:
      canAccess =
        Boolean(Number(fileManager.isReadableFileAtPath(path))) &&
        Boolean(Number(fileManager.isWritableFileAtPath(path))) &&
        Boolean(Number(fileManager.isExecutableFileAtPath(path)));
      break;
  }

  if (!canAccess) {
    throw new Error("Can't access " + String(path));
  }
};

module.exports.appendFile = NOT_IMPLEMENTED("appendFile");

module.exports.appendFileSync = function (file, data, options) {
  if (!module.exports.existsSync(file)) {
    return module.exports.writeFileSync(file, data, options);
  }

  var handle = NSFileHandle.fileHandleForWritingAtPath(file);
  handle.seekToEndOfFile();

  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  handle.writeData(nsdata);
};

module.exports.chmod = NOT_IMPLEMENTED("chmod");

module.exports.chmodSync = function (path, mode) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFilePosixPermissions: mode,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.chown = NOT_IMPLEMENTED("chown");
module.exports.chownSync = NOT_IMPLEMENTED("chownSync");

module.exports.close = NOT_IMPLEMENTED("close");
module.exports.closeSync = NOT_IMPLEMENTED("closeSync");

module.exports.copyFile = NOT_IMPLEMENTED("copyFile");

module.exports.copyFileSync = function (path, dest, flags) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.copyItemAtPath_toPath_error(path, dest, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.createReadStream = NOT_IMPLEMENTED("createReadStream");
module.exports.createWriteStream = NOT_IMPLEMENTED("createWriteStream");

module.exports.exists = NOT_IMPLEMENTED("exists");

module.exports.existsSync = function (path) {
  var fileManager = NSFileManager.defaultManager();
  return Boolean(Number(fileManager.fileExistsAtPath(path)));
};

module.exports.fchmod = NOT_IMPLEMENTED("fchmod");
module.exports.fchmodSync = NOT_IMPLEMENTED("fchmodSync");
module.exports.fchown = NOT_IMPLEMENTED("fchown");
module.exports.fchownSync = NOT_IMPLEMENTED("fchownSync");
module.exports.fdatasync = NOT_IMPLEMENTED("fdatasync");
module.exports.fdatasyncSync = NOT_IMPLEMENTED("fdatasyncSync");
module.exports.fstat = NOT_IMPLEMENTED("fstat");
module.exports.fstatSync = NOT_IMPLEMENTED("fstatSync");
module.exports.fsync = NOT_IMPLEMENTED("fsync");
module.exports.fsyncSync = NOT_IMPLEMENTED("fsyncSync");
module.exports.ftruncate = NOT_IMPLEMENTED("ftruncate");
module.exports.ftruncateSync = NOT_IMPLEMENTED("ftruncateSync");
module.exports.futimes = NOT_IMPLEMENTED("futimes");
module.exports.futimesSync = NOT_IMPLEMENTED("futimesSync");

module.exports.lchmod = NOT_IMPLEMENTED("lchmod");
module.exports.lchmodSync = NOT_IMPLEMENTED("lchmodSync");
module.exports.lchown = NOT_IMPLEMENTED("lchown");
module.exports.lchownSync = NOT_IMPLEMENTED("lchownSync");

module.exports.link = NOT_IMPLEMENTED("link");

module.exports.linkSync = function (existingPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.linkItemAtPath_toPath_error(existingPath, newPath, err);

  if (err.value() !== null) {
    throw fsErrorForPath(existingPath, undefined, err.value());
  }
};

module.exports.lstat = NOT_IMPLEMENTED("lstat");

module.exports.lstatSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.attributesOfItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return parseStat(result);
};

module.exports.mkdir = NOT_IMPLEMENTED("mkdir");

module.exports.mkdirSync = function (path, options) {
  var mode = 0o777;
  var recursive = false;
  if (options && options.mode) {
    mode = options.mode;
  }
  if (options && options.recursive) {
    recursive = options.recursive;
  }
  if (typeof options === "number") {
    mode = options;
  }
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(
    path,
    recursive,
    {
      NSFilePosixPermissions: mode,
    },
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.mkdtemp = NOT_IMPLEMENTED("mkdtemp");

module.exports.mkdtempSync = function (path) {
  function makeid() {
    var text = "";
    var possible =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 6; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
  }
  var tempPath = path + makeid();
  module.exports.mkdirSync(tempPath);
  return tempPath;
};

module.exports.open = NOT_IMPLEMENTED("open");
module.exports.openSync = NOT_IMPLEMENTED("openSync");

module.exports.read = NOT_IMPLEMENTED("read");

module.exports.readdir = NOT_IMPLEMENTED("readdir");

module.exports.readdirSync = function (path, options) {
  var encoding = encodingFromOptions(options, "utf8");
  var fileManager = NSFileManager.defaultManager();
  var paths = fileManager.subpathsAtPath(path);
  var arr = [];
  for (var i = 0; i < paths.length; i++) {
    var pathName = paths[i];
    arr.push(encoding === "buffer" ? Buffer.from(pathName) : String(pathName));
  }
  return arr;
};

module.exports.readFile = NOT_IMPLEMENTED("readFile");

module.exports.readFileSync = function (path, options) {
  var encoding = encodingFromOptions(options, "buffer");
  var fileManager = NSFileManager.defaultManager();
  var data = fileManager.contentsAtPath(path);
  if (!data) {
    throw fsErrorForPath(path, false);
  }

  var buffer = Buffer.from(data);

  if (encoding === "buffer") {
    return buffer;
  } else if (encoding === "NSData") {
    return buffer.toNSData();
  } else {
    return buffer.toString(encoding);
  }
};

module.exports.readlink = NOT_IMPLEMENTED("readlink");

module.exports.readlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.destinationOfSymbolicLinkAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }

  return String(result);
};

module.exports.readSync = NOT_IMPLEMENTED("readSync");

module.exports.realpath = NOT_IMPLEMENTED("realpath");
module.exports.realpath.native = NOT_IMPLEMENTED("realpath.native");

module.exports.realpathSync = function (path) {
  return String(
    NSString.stringWithString(path).stringByResolvingSymlinksInPath()
  );
};

module.exports.realpathSync.native = NOT_IMPLEMENTED("realpathSync.native");

module.exports.rename = NOT_IMPLEMENTED("rename");

module.exports.renameSync = function (oldPath, newPath) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.moveItemAtPath_toPath_error(oldPath, newPath, err);

  var error = err.value();

  if (error !== null) {
    // if there is already a file, we need to overwrite it
    if (
      String(error.domain()) === "NSCocoaErrorDomain" &&
      Number(error.code()) === 516
    ) {
      var err2 = MOPointer.alloc().init();
      fileManager.replaceItemAtURL_withItemAtURL_backupItemName_options_resultingItemURL_error(
        NSURL.fileURLWithPath(newPath),
        NSURL.fileURLWithPath(oldPath),
        null,
        NSFileManagerItemReplacementUsingNewMetadataOnly,
        null,
        err2
      );
      if (err2.value() !== null) {
        throw fsErrorForPath(oldPath, undefined, err2.value());
      }
    } else {
      throw fsErrorForPath(oldPath, undefined, error);
    }
  }
};

module.exports.rmdir = NOT_IMPLEMENTED("rmdir");

module.exports.rmdirSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (!isDirectory) {
    throw fsError("ENOTDIR", {
      path: path,
      syscall: "rmdir",
    });
  }
  fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, true, err.value(), "rmdir");
  }
};

module.exports.stat = NOT_IMPLEMENTED("stat");

// the only difference with lstat is that we resolve symlinks
//
// > lstat() is identical to stat(), except that if pathname is a symbolic
// > link, then it returns information about the link itself, not the file
// > that it refers to.
// http://man7.org/linux/man-pages/man2/lstat.2.html
module.exports.statSync = function (path) {
  return module.exports.lstatSync(module.exports.realpathSync(path));
};

module.exports.symlink = NOT_IMPLEMENTED("symlink");

module.exports.symlinkSync = function (target, path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.createSymbolicLinkAtPath_withDestinationPath_error(
    path,
    target,
    err
  );

  if (err.value() !== null) {
    throw new Error(err.value());
  }
};

module.exports.truncate = NOT_IMPLEMENTED("truncate");

module.exports.truncateSync = function (path, len) {
  var hFile = NSFileHandle.fileHandleForUpdatingAtPath(sFilePath);
  hFile.truncateFileAtOffset(len || 0);
  hFile.closeFile();
};

module.exports.unlink = NOT_IMPLEMENTED("unlink");

module.exports.unlinkSync = function (path) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var isDirectory = module.exports.lstatSync(path).isDirectory();
  if (isDirectory) {
    throw fsError("EPERM", {
      path: path,
      syscall: "unlink",
    });
  }
  var result = fileManager.removeItemAtPath_error(path, err);

  if (err.value() !== null) {
    throw fsErrorForPath(path, false, err.value());
  }
};

module.exports.unwatchFile = NOT_IMPLEMENTED("unwatchFile");

module.exports.utimes = NOT_IMPLEMENTED("utimes");

module.exports.utimesSync = function (path, aTime, mTime) {
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  var result = fileManager.setAttributes_ofItemAtPath_error(
    {
      NSFileModificationDate: aTime,
    },
    path,
    err
  );

  if (err.value() !== null) {
    throw fsErrorForPath(path, undefined, err.value());
  }
};

module.exports.watch = NOT_IMPLEMENTED("watch");
module.exports.watchFile = NOT_IMPLEMENTED("watchFile");

module.exports.write = NOT_IMPLEMENTED("write");

module.exports.writeFile = NOT_IMPLEMENTED("writeFile");

module.exports.writeFileSync = function (path, data, options) {
  var encoding = encodingFromOptions(options, "utf8");

  var nsdata = Buffer.from(
    data,
    encoding === "NSData" || encoding === "buffer" ? undefined : encoding
  ).toNSData();

  nsdata.writeToFile_atomically(path, true);
};

module.exports.writeSync = NOT_IMPLEMENTED("writeSync");


/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "c", function() { return /* binding */ uniqueId; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ _Fetch; });
__webpack_require__.d(__webpack_exports__, "d", function() { return /* binding */ _upload; });
__webpack_require__.d(__webpack_exports__, "b", function() { return /* binding */ parseUpload_imageCompress; });

// UNUSED EXPORTS: uploadPreCheck, artboardPreCheck, artboardUpload, singleUpload, singlePreUpload, sliceUpload, sliceUploadIterator, sliceUploadFinish, slicePreUpload

// EXTERNAL MODULE: ./node_modules/sketch-polyfill-fetch/lib/form-data.js
var form_data = __webpack_require__(25);
var form_data_default = /*#__PURE__*/__webpack_require__.n(form_data);

// EXTERNAL MODULE: ./node_modules/sketch-polyfill-fetch/lib/index.js
var lib = __webpack_require__(14);
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// EXTERNAL MODULE: ./node_modules/@skpm/promise/index.js
var promise = __webpack_require__(4);
var promise_default = /*#__PURE__*/__webpack_require__.n(promise);

// CONCATENATED MODULE: ./src/parseUpload/url.js
var host = 'https://parseui.58.com/parse';

/**
 * 上传预检接口
 */
var UPLOAD_PRE_CHECK = '/uploadPreCheck';

// 简单上传接口
var UPLOAD = '/upload';

// 分片上传接口
var SLICE_UPLOAD = '/sliceUpload';

// 分片上传完成接口
var SLICE_UPLOAD_FINISH = '/sliceUploadFinish';

// 画板解析预检
var ARTBOARD_PRE_CHECK = '/artboardPreCheck';

// 画板结果上传
var ARTBOARD_UPLOAD = '/artboardUpload';

// 图片压缩接口
var IMAGE_COMPRESS = '/compress';
// CONCATENATED MODULE: ./src/parseUpload/index.js




var uniqueId = function uniqueId() {
  return new Date().valueOf() + Math.random().toString(32).substr(2, 8);
};
var _Fetch = function Fetch(urlString, options) {
  return new promise_default.a(function (resolve, reject) {
    if (_Fetch.isCancel) {
      _Fetch.isCancel = false;
      reject(new Error('取消请求'));
    }
    lib_default()(host + urlString, options).then(function (response) {
      return response.text();
    }).then(function (resString) {
      var _ref = JSON.parse(resString) || {},
        code = _ref.code,
        data = _ref.data;
      if (code === 0) {
        resolve(data);
      } else {
        reject(JSON.parse(resString));
      }
    }).catch(function (err) {
      reject(err);
    });
  }).catch(function (err) {
    console.log('Fetch error:', err);
    throw err;
  });
};

// 取消标识

_Fetch.isCancel = false;
// 取消请求
_Fetch.cancelFetch = function () {
  _Fetch.isCancel = true;
};

/**
 * 上传预检
 */
var parseUpload_uploadPreCheck = function uploadPreCheck(_ref2) {
  var fileName = _ref2.fileName,
    fileSize = _ref2.fileSize,
    sliceSize = _ref2.sliceSize,
    uploadparts = _ref2.uploadparts;
  var formData = new form_data_default.a();
  formData.append('fileName', fileName);
  formData.append('fileSize', fileSize);
  formData.append('sliceSize', sliceSize);
  formData.append('uploadparts', uploadparts);
  return _Fetch(UPLOAD_PRE_CHECK, {
    method: 'POST',
    body: formData
  });
};

/**
 * 画板解析预检
 */
var parseUpload_artboardPreCheck = function artboardPreCheck(artobardSha1) {
  return _Fetch("".concat(ARTBOARD_PRE_CHECK, "?sha1=").concat(artobardSha1));
};

/**
 * 画板解析结果上传
 */
var parseUpload_artboardUpload = function artboardUpload(_ref3) {
  var artboardSha1 = _ref3.artboardSha1,
    codeDSL = _ref3.codeDSL,
    measureDSL = _ref3.measureDSL;
  var formData = new form_data_default.a();
  formData.append('sha1', artboardSha1);
  formData.append('codeDSL', JSON.stringify(codeDSL));
  formData.append('measureDSL', JSON.stringify(measureDSL));
  return _Fetch(ARTBOARD_UPLOAD, {
    method: 'POST',
    body: formData
  });
};

/**
 * 简单文件上传
 */
var parseUpload_singleUpload = function singleUpload(_ref4) {
  var fileName = _ref4.fileName,
    fileData = _ref4.fileData;
  var formData = new form_data_default.a();
  formData.append('file', {
    fileName: fileName,
    data: fileData,
    mimeType: 'image/png'
  });
  return _Fetch(UPLOAD, {
    method: 'POST',
    body: formData
  });
};

/**
 * 简单文件上传带预检
 */
var parseUpload_singlePreUpload = function singlePreUpload(_ref5) {
  var fileData = _ref5.fileData,
    fileSize = _ref5.fileSize,
    fileSuffix = _ref5.fileSuffix;
  return new promise_default.a(function (resolve, reject) {
    // Objective-C => sha1
    var fileSha1 = fileData.toNSData().SHA1HexString().toLowerCase();
    var fileName = "".concat(fileSha1, ".").concat(fileSuffix);
    var uploadparts = JSON.stringify([{
      offset: 0,
      datalen: fileSize,
      datasha: fileSha1
    }]);

    // 秒传预检接口
    parseUpload_uploadPreCheck({
      fileSize: fileSize.toString(),
      fileName: fileName,
      sliceSize: '0',
      uploadparts: uploadparts
    }).then(function (res) {
      // 文件已存在，秒传完成
      if (res.allhit === 1) {
        resolve(res.url);
        // 文件不存在，秒传失败，走简单上传流程
      } else {
        parseUpload_singleUpload({
          fileName: fileName,
          fileData: fileData
        }).then(function (res2) {
          resolve(res2.url);
        }).catch(function (err) {
          reject(err);
        });
      }
    }).catch(function (err) {
      reject(err);
    });
  }).catch(function (err) {
    console.log('singlePreUpload error:', err);
    throw err;
  });
};

/**
 * 文件分片上传
 */
var parseUpload_sliceUpload = function sliceUpload(_ref6) {
  var fileName = _ref6.fileName,
    sliceFileData = _ref6.sliceFileData,
    session = _ref6.session,
    offset = _ref6.offset;
  var formData = new form_data_default.a();
  formData.append('file', {
    fileName: fileName,
    data: sliceFileData,
    mimeType: 'image/png'
  });
  return _Fetch("".concat(SLICE_UPLOAD, "?session=").concat(session, "&offset=").concat(offset), {
    method: 'POST',
    body: formData
  });
};

/**
 * 文件分片上传迭代器
 */
var parseUpload_sliceUploadIterator = function sliceUploadIterator(sliceUploadList, progressSlice, getProgress) {
  return new promise_default.a(function (resolve, reject) {
    var results = [];
    var _nextPromise2 = function _nextPromise(index, _sliceList) {
      if (index >= _sliceList.length) {
        resolve(results);
      } else {
        parseUpload_sliceUpload(_sliceList[index]).then(function (res) {
          results.push(res);
          _upload.artProgress += progressSlice / _sliceList.length;
          getProgress(_upload.artProgress);
          _nextPromise2(index + 1, _sliceList);
        }).catch(function (err) {
          reject(err);
        });
      }
    };
    _nextPromise2(0, sliceUploadList);
  }).catch(function (err) {
    console.log('sliceUploadIterator error:', err);
    throw err;
  });
};

/**
 * 分片上传完成接口
 */
var parseUpload_sliceUploadFinish = function sliceUploadFinish(_ref7) {
  var session = _ref7.session,
    fileName = _ref7.fileName,
    fileSize = _ref7.fileSize;
  return _Fetch("".concat(SLICE_UPLOAD_FINISH, "?session=").concat(session, "&fileName=").concat(fileName, "&fileSize=").concat(fileSize));
};
/**
 * 文件分片上传带预检
 */
var parseUpload_slicePreUpload = function slicePreUpload(_ref8) {
  var fileData = _ref8.fileData,
    fileSize = _ref8.fileSize,
    fileSuffix = _ref8.fileSuffix,
    sliceSize = _ref8.sliceSize,
    progressSlice = _ref8.progressSlice,
    getProgress = _ref8.getProgress;
  return new promise_default.a(function (resolve, reject) {
    var fileName = "".concat(uniqueId(), ".").concat(fileSuffix);

    // 分片数量
    var sliceNumber = Math.ceil(fileSize / sliceSize);
    // 分片数据
    var uploadpartsArr = [];
    for (var i = 0; i < sliceNumber; i++) {
      // 当前分片开始下标
      var sliceStart = i * sliceSize;
      // 当前分片结束下标
      var sliceEnd = Math.min(fileSize, sliceStart + sliceSize);
      // 分片二进制数据
      var sliceFileData = fileData.slice(sliceStart, sliceEnd);
      var sliceFileSha1 = sliceFileData.toNSData().SHA1HexString().toLowerCase();
      uploadpartsArr.push({
        offset: sliceStart,
        datalen: sliceEnd - sliceStart,
        datasha: sliceFileSha1
      });
    }
    var uploadparts = JSON.stringify(uploadpartsArr);
    _upload.artProgress += progressSlice * 0.1;
    getProgress(_upload.artProgress);
    parseUpload_uploadPreCheck({
      fileSize: fileSize.toString(),
      fileName: fileName,
      sliceSize: sliceSize.toString(),
      uploadparts: uploadparts
    }).then(function (res) {
      // 文件已存在，秒传完成
      if (res.allhit === 1) {
        _upload.artProgress += progressSlice * 0.9;
        getProgress(_upload.artProgress);
        resolve(res.url);
        // 文件不存在，秒传失败，走简单上传流程
      } else {
        var sliceUploadArr = [];
        for (var j = 0; j < res.uploadparts.length; j++) {
          var _res$uploadparts$j = res.uploadparts[j],
            offset = _res$uploadparts$j.offset,
            datalen = _res$uploadparts$j.datalen;
          sliceUploadArr.push({
            fileName: fileName,
            sliceFileData: fileData.slice(offset, offset + datalen),
            session: res.session,
            offset: offset
          });
        }

        // 切片批量上传
        parseUpload_sliceUploadIterator(sliceUploadArr, progressSlice * 0.85, getProgress).then(function () {
          // 分片上传完成，调用分片上传完成接口
          parseUpload_sliceUploadFinish({
            session: res.session,
            fileName: fileName,
            fileSize: fileSize
          }).then(function (res3) {
            _upload.artProgress += progressSlice * 0.05;
            getProgress(_upload.artProgress);
            resolve(res3.url);
          }).catch(function (err3) {
            reject(err3);
          });
        }).catch(function (err2) {
          reject(err2);
        });
      }
    }).catch(function (err) {
      reject(err);
    });
  }).catch(function (err) {
    console.log('slicePreUpload error:', err);
    throw err;
  });
};

/**
 * 文件上传
 */
var _upload = function upload(fileData, fileSuffix, currProgress, progressSlice, getProgress) {
  var sliceSize = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 1024 * 1024 * 2;
  var maxFileSize = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : 1024 * 1024 * 4;
  return new promise_default.a(function (resolve, reject) {
    var fileSize = fileData.length;
    _upload.artProgress = currProgress;
    // 文件 <= 4M, 进行简单上传
    if (fileSize <= maxFileSize) {
      parseUpload_singlePreUpload({
        fileData: fileData,
        fileSize: fileSize,
        fileSuffix: fileSuffix
      }).then(function (res) {
        _upload.artProgress += progressSlice;
        getProgress(_upload.artProgress);
        resolve({
          res: res,
          artProgress: _upload.artProgress
        });
      }).catch(function (err) {
        reject(err);
      });
      // 文件 > 4M, 分片上传
    } else {
      parseUpload_slicePreUpload({
        fileData: fileData,
        fileSize: fileSize,
        fileSuffix: fileSuffix,
        sliceSize: sliceSize,
        progressSlice: progressSlice,
        getProgress: getProgress
      }).then(function (res) {
        resolve({
          res: res,
          artProgress: _upload.artProgress
        });
      }).catch(function (err) {
        reject(err);
      });
    }
  }).catch(function (err) {
    console.log('upload error:', err);
    throw err;
  });
};

_upload.artProgress = 0;

/**
 * 图片压缩接口
 */
var parseUpload_imageCompress = function imageCompress(imageUrl) {
  return _Fetch("".concat(IMAGE_COMPRESS, "?imageUrl=").concat(imageUrl));
};

/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(Promise) {/* unused harmony export walkLayerTree */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return arrayFromNSArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return dictFromNSDict; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return getAllLayersMatchingPredicate; });
/* unused harmony export getFirstLayerMatchingPredicate */
/* unused harmony export getLayerById */
/* unused harmony export mkdirpSync */
/* unused harmony export loadDocFromSketchFile */
/* unused harmony export getLayerImage */
/* unused harmony export captureLayerImage */
/* unused harmony export nsImageToDataUri */
/* unused harmony export getPluginCachePath */
/* unused harmony export rmdirRecursive */
/* unused harmony export unpeg */
/* unused harmony export _profile */
/* unused harmony export getDocumentName */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return connectedNetwork; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return getUserRole; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return handleFilePath; });
/* unused harmony export isFileExist */
/* unused harmony export writeFile */
/* unused harmony export writeAndAppendFile */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return readFile; });
/* unused harmony export getPluginFolderPath */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return isContainer; });
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_skpm_path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(14);
/* harmony import */ var sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(0);
/*
 * Copyright 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */






/**
 * Performs a depth-first traversal of the layer tree, starting
 * at the provided root layer.
 */
function walkLayerTree(rootLayer, visitFunction) {
  var _ref = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {
      reverse: false
    },
    reverse = _ref.reverse;
  var _visit_ = function visit_(layer) {
    // visit this layer
    visitFunction(layer);

    // visit children
    var subLayers;
    if ('layers' in layer) {
      subLayers = arrayFromNSArray(layer.layers());
    } else if ('artboards' in layer) {
      subLayers = arrayFromNSArray(layer.artboards());
    } else {
      return;
    }
    if (reverse) {
      subLayers.reverse();
    }
    subLayers.forEach(function (subLayer) {
      return _visit_(subLayer);
    });
  };
  _visit_(rootLayer);
}

/**
 * Converts an NSArray to a JS array
 */
function arrayFromNSArray(nsArray) {
  // TODO: this may no longer be needed... as of recent versions of sketch
  // NSArray seems to be array-like. or at least replace with Array.from(nsarray)
  var arr = [];
  var count = nsArray.count();
  for (var i = 0; i < count; i++) {
    arr.push(nsArray.objectAtIndex(i));
  }
  return arr;
}

/**
 * Convert an NSDictionary-type object to a JS dict.
 * As of Sketch 50.2, this is needed for some cases of symbol instance overrides
 */
function dictFromNSDict(nsDict) {
  var dict = {};

  /* eslint-disable */
  for (var key in nsDict) {
    dict[key] = nsDict[key];
  }
  /* eslint-disable */

  return dict;
}

/**
 * Returns the first layer matching the given NSPredicate
 *
 * @param {MSDocument|MSLayerGroup} parent The document or layer group to search.
 * @param {NSPredicate} predicate Search predicate
 */
function getAllLayersMatchingPredicate(parent, predicate) {
  if (parent instanceof MSDocument) {
    // MSDocument
    return parent.pages().reduce(function (acc, page) {
      return acc.concat(getAllLayersMatchingPredicate(page, predicate));
    }, []);
  }

  // assume MSLayerGroup
  return Array.from(parent.children().filteredArrayUsingPredicate(predicate));
}

/**
 * Returns the first layer matching the given NSPredicate
 *
 * @param {MSDocument|MSLayerGroup} parent The document or layer group to search.
 * @param {NSPredicate} predicate Search predicate
 */
function getFirstLayerMatchingPredicate(parent, predicate) {
  if (parent instanceof MSDocument) {
    // MSDocument
    var results;
    for (var _i = 0, _Array$from = Array.from(parent.pages()); _i < _Array$from.length; _i++) {
      page = _Array$from[_i];
      var firstInPage = getFirstLayerMatchingPredicate(page, predicate);
      if (firstInPage) {
        return firstInPage;
      }
    }
    return null;
  }

  // assume MSLayerGroup
  return getAllLayersMatchingPredicate(parent, predicate)[0] || null;
}

/**
 * Finds the layer with the given objectID in the given document.
 */
function getLayerById(document, layerId) {
  return getFirstLayerMatchingPredicate(document, NSPredicate.predicateWithFormat('objectID == %@', layerId));
}

/**
 * Copied from @skpm/fs with intermediate directories.
 */
function mkdirpSync(path, mode) {
  mode = mode || 511;
  var err = MOPointer.alloc().init();
  var fileManager = NSFileManager.defaultManager();
  fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error(path, true, {
    NSFilePosixPermissions: mode
  }, err);
  if (err.value() !== null) {
    throw new Error(err.value());
  }
}

/**
 * Returns an MSDocument for the given .sketch file path. May take
 * a long time!
 */
function loadDocFromSketchFile(filePath) {
  var doc = MSDocument.new();
  doc.readDocumentFromURL_ofType_error_(NSURL.fileURLWithPath(filePath), 'com.bohemiancoding.sketch.drawing', null);
  return doc;
}

/**
 * Returns an NSImage for the given layer in the given document.
 */
function getLayerImage(document, layer) {
  var tempPath = NSTemporaryDirectory().stringByAppendingPathComponent("".concat(NSUUID.UUID().UUIDString(), ".png"));
  captureLayerImage(document, layer, tempPath);
  return NSImage.alloc().initWithContentsOfFile(tempPath);
}

/**
 * Saves the given layer in the given document to a PNG file at the given path.
 */
function captureLayerImage(document, layer, destPath) {
  var air = layer.absoluteInfluenceRect();
  var rect = NSMakeRect(air.origin.x, air.origin.y, air.size.width, air.size.height);
  var exportRequest = MSExportRequest.exportRequestsFromLayerAncestry_inRect_(MSImmutableLayerAncestry.ancestryWithMSLayer_(layer), rect // we pass this to avoid trimming
  ).firstObject();
  exportRequest.format = 'png';
  exportRequest.scale = 2;
  if (!(layer instanceof MSArtboardGroup || layer instanceof MSSymbolMaster)) {
    exportRequest.includeArtboardBackground = false;
  }

  // exportRequest.shouldTrim = false;
  document.saveArtboardOrSlice_toFile_(exportRequest, destPath);
}

/**
 * Converts an NSImage to a data URL string (png).
 */
function nsImageToDataUri(image) {
  var data = image.TIFFRepresentation();
  var bitmap = NSBitmapImageRep.imageRepWithData(data);
  data = bitmap.representationUsingType_properties_(NSPNGFileType, null);
  var base64 = "data:image/png;base64,".concat(data.base64EncodedStringWithOptions(0));
  return base64;
}

/**
 * Returns the system cache path for the plugin.
 */
function getPluginCachePath() {
  var cachePath = String(NSFileManager.defaultManager().URLsForDirectory_inDomains_(NSCachesDirectory, NSUserDomainMask)[0].path());

  // // console.log(cachePath);
  var pluginCacheKey = String(__command.pluginBundle().identifier()); // TODO: escape if needed

  // // console.log(pluginCacheKey);

  return _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.join(cachePath, pluginCacheKey);
}

/**
 * Deletes the given file or directory recursively (i.e. it and its
 * subfolders).
 */
function rmdirRecursive(path) {
  NSFileManager.defaultManager().removeItemAtPath_error_(path, null);
}

/**
 * Give the CPU some breathing room.
 */
function unpeg() {
  return new Promise(function (resolve, reject) {
    setTimeout(function () {
      return resolve();
    }, 0);
  }).catch(function (err) {
    console.log('unpeg error:', err);
    throw err;
  });
}

/**
 * Profile the running time of a method
 */
function _profile(fnOrPromise) {
  var tag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
  tag = tag ? " [".concat(tag, "]") : '';
  var t = Number(new Date());
  var finish = function finish() {
    t = Number(new Date()) - t;
    // log(`profile${tag}: ${t}ms`);
  };
  if (fnOrPromise instanceof Promise) {
    fnOrPromise.then(function () {
      return finish();
    });
    return fnOrPromise;
  }
  fnOrPromise();
  finish();
}

/**
 * Returns the name of the given document, if it has one.
 *
 * @param {MSDocument} document
 */
function getDocumentName(document) {
  var fileURL = document.fileURL();
  if (fileURL) {
    fileURL = String(fileURL.path());
    return _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.basename(fileURL).replace(/\.[^.]+$/, ''); // strip extension
  }
  return null;
}
var connectedNetwork = function connectedNetwork(successCallBack) {
  sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2___default()("https://img.58cdn.com.cn/lbg/picasso/picasso_6061.png?".concat(Number(new Date()))).then(function (res) {
    // // console.log('网络正常', res, res.status, res.url);

    successCallBack();
  }).catch(function (err) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('网络异常，请检测网络连接！');
    // console.log('qwert网络异常', err);
  });
};
var getUserRole = function getUserRole(userId, callBack) {
  var isIn = false;
  sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_2___default()("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* host */ "i"], "/api/info/userrole?userId=").concat(userId)).then(function (res) {
    isIn = true;
    var data = res.json()._value.data;
    var role = data.userInfo && data.userInfo[0] && data.userInfo[0].role_id || '';
    callBack && callBack(role);
  }).catch(function (err) {
    if (!isIn) {
      sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('用户权限获取失败');
      // callBack && callBack('')
    }
  });
};

// 路径处理, 处理波浪号路径和中文路径
var handleFilePath = function handleFilePath(filePath) {
  if (!filePath) return null;

  // 展开波浪号路径
  var nsStringPath = NSString.stringWithString(filePath).stringByExpandingTildeInPath();

  // 只在确实需要时才解码
  // 检查是否包含百分号编码
  if (nsStringPath.includes('%')) {
    var decodedPath = nsStringPath.stringByRemovingPercentEncoding();
    // 解码成功则使用，失败则使用原路径
    return String(decodedPath || nsStringPath);
  }
  return String(nsStringPath);
};

/**
 * @desc 以下为文件读写相关操作，使用时文件名称必须完整，包括文件后缀
 * @param {*} context sketch内容
 * @param {*} fileName 文件名称
 */
function isFileExist(context, fileName) {
  var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  try {
    var isExist = _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.existsSync("".concat(pluginFolderPath, "/").concat(fileName));
    return isExist;
  } catch (e) {
    console.log('isFileExist Error: ', e);
    return false;
  }
}
function writeFile(context, fileName) {
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var path = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  try {
    _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(pluginFolderPath, "/").concat(fileName), JSON.stringify(data, null, 2), {
      encoding: 'utf8'
    });
  } catch (e) {
    console.log('writeFile Error: ', e);
    return false;
  }
}
function writeAndAppendFile(context, fileName) {
  var data = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var path = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  var isExist = isFileExist(context, fileName);
  try {
    if (isExist) {
      // 存在
      _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.appendFileSync("".concat(pluginFolderPath, "/").concat(fileName), ",".concat(JSON.stringify(data)), {
        encoding: 'utf8'
      });
    } else {
      // 不存在
      _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(pluginFolderPath, "/").concat(fileName), JSON.stringify(data), {
        encoding: 'utf8'
      });
    }
  } catch (e) {
    console.log('writeAndAppendFile Error: ', e);
    return false;
  }
}
function readFile(context, fileName) {
  var path = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  var pluginFolderPath = context ? getPluginFolderPath(context) : path;
  var isExist = isFileExist(context, fileName, path);
  try {
    if (isExist) {
      var data = _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.readFileSync("".concat(pluginFolderPath, "/").concat(fileName), {
        encoding: 'utf8'
      });
      return data;
    } else {
      return '{}';
    }
  } catch (e) {
    console.log('readFile Error: ', e);
    return '{}';
  }
}
function getPluginFolderPath(context) {
  // console.log('context.scriptPath', context.scriptPath);
  var split = context.scriptPath.split('/');
  // const split = context?.scriptPath ? context.scriptPath.split('/') : context?.path;

  split.splice(-3, 3);
  // 创建存储插件数据的文件夹
  var pluginDataPath = _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.join(split.join('/'), '../../hotwheels_data');
  if (!_skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.existsSync(pluginDataPath)) {
    _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.mkdirSync(pluginDataPath);
  }

  // console.log('资源存储路径pluginDataPath', pluginDataPath); // /Users/meiyuju/Library/Application\ Support/com.bohemiancoding.sketch3/hotwheels_data

  return pluginDataPath;
}

// 判断是否为容器
function isContainer(layer) {
  return layer.type === 'Artboard' || layer.isFrame || layer.isGraphicFrame;
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 4 */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),
/* 5 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "e", function() { return /* binding */ parseArtboard_uploadSketch; });
__webpack_require__.d(__webpack_exports__, "d", function() { return /* binding */ _sliceExportIterator2; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ parseArtboard_cancelParse; });
__webpack_require__.d(__webpack_exports__, "c", function() { return /* binding */ parseArtboard_resetFetch; });
__webpack_require__.d(__webpack_exports__, "b", function() { return /* binding */ _parseDocument; });

// UNUSED EXPORTS: isCancelParse, is, toJSString, removeLayer, find, exportAndUploadArtboartImage, uploadImage, exportImage, exportSvgImage, uploadDSL, _sliceExportIterator, datachSymbolIterator, parseArtboard, parseArtboardIterator

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/toConsumableArray.js
var toConsumableArray = __webpack_require__(12);
var toConsumableArray_default = /*#__PURE__*/__webpack_require__.n(toConsumableArray);

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/defineProperty.js
var defineProperty = __webpack_require__(23);
var defineProperty_default = /*#__PURE__*/__webpack_require__.n(defineProperty);

// EXTERNAL MODULE: external "sketch"
var external_sketch_ = __webpack_require__(6);
var external_sketch_default = /*#__PURE__*/__webpack_require__.n(external_sketch_);

// EXTERNAL MODULE: external "sketch/dom"
var dom_ = __webpack_require__(8);
var dom_default = /*#__PURE__*/__webpack_require__.n(dom_);

// EXTERNAL MODULE: ./node_modules/sketch-polyfill-fetch/lib/index.js
var lib = __webpack_require__(14);
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// EXTERNAL MODULE: ./node_modules/@skpm/fs/index.js
var fs = __webpack_require__(1);
var fs_default = /*#__PURE__*/__webpack_require__.n(fs);

// EXTERNAL MODULE: ./node_modules/@skpm/promise/index.js
var promise = __webpack_require__(4);
var promise_default = /*#__PURE__*/__webpack_require__.n(promise);

// EXTERNAL MODULE: ./node_modules/@wubafe/picasso-parse/dist/picasso-parse/src/index.js
var src = __webpack_require__(29);

// EXTERNAL MODULE: ./src/parseUpload/index.js + 1 modules
var parseUpload = __webpack_require__(2);

// CONCATENATED MODULE: ./src/handleImage/handleJudge/isOval.js
// 判断是否是正圆
var isOval = function isOval(layer) {
  var points = layer.points;
  if (layer.points && layer.points.length !== 4) {
    return false;
  }
  for (var i = 0; i < points.length; i++) {
    var _points$i = points[i],
      pointType = _points$i.pointType,
      curveFrom = _points$i.curveFrom,
      curveTo = _points$i.curveTo,
      point = _points$i.point;

    // 非镜像属于不规则圆形
    if (pointType !== 'Mirrored') {
      return false;
    }
    if (i == 0 || i == 2) {
      if (curveFrom.y !== curveTo.y || curveTo.y !== point.y) {
        return false;
      }
    } else if (i == 1 || i == 3) {
      if (curveFrom.x !== curveTo.x || curveTo.x !== point.x) {
        return false;
      }
    }
  }

  // 判断是否是正圆
  if (Math.abs(layer.frame.width - layer.frame.height) >= 0.1) {
    // 表示是一个椭圆
    return false;
  }
  return true;
};
/* harmony default export */ var handleJudge_isOval = (isOval);
// CONCATENATED MODULE: ./src/handleImage/handleJudge/twoPointsAngle.js
/**
 * 依据两点坐标计算两点与原点之间连线的夹角
 *
 * @param {*} startX 第一个点X轴坐标
 * @param {*} startY 第一个点Y轴坐标
 * @param {*} endX 第二个点X轴坐标
 * @param {*} endY 第二个点Y轴坐标
 * @returns
 */

/* harmony default export */ var twoPointsAngle = (function (startX, startY, endX, endY) {
  var x = endX - startX;
  var y = endY - startY;
  if (x > 0 && y == 0) {
    return Math.PI * 0.5;
  }
  if (x < 0 && y == 0) {
    return Math.PI * 1.5;
  }
  if (y > 0 && x == 0) {
    return 0;
  }
  if (y < 0 && x == 0) {
    return Math.PI;
  }
  if (x >= 0 && y >= 0) {
    return Math.atan(x / y);
  }
  if (x >= 0 && y < 0) {
    return Math.PI + Math.atan(x / y);
  }
  if (x < 0 && y > 0) {
    return 2 * Math.PI + Math.atan(x / y);
  }
  if (x < 0 && y <= 0) {
    return Math.PI + Math.atan(x / y);
  }
});
// CONCATENATED MODULE: ./src/handleImage/handleJudge/isRect.js


/**
 * 获取夹角
 *
 * @param {Object} startPoint 起始点
 * @param {Object} midPoint 焦点
 * @param {Object} endPoint 结束点
 * @returns
 */

var isRect_getAngle = function getAngle(startPoint, midPoint, endPoint) {
  return twoPointsAngle(midPoint.x, midPoint.y, endPoint.x, endPoint.y) - twoPointsAngle(startPoint.x, startPoint.y, midPoint.x, midPoint.y);
};

/**
 * 判断是的为矩形
 *
 * @param {Array} pointArr 4个点数据组信息
 * @returns
 */
/* harmony default export */ var isRect = (function (pointArr) {
  /**
   * 四边形4个点顺时针依次为 A,B,C,D
   * {
   *   x:0,
   *   y:0
   * }
   */

  var pointA = pointArr[0].point;
  var pointB = pointArr[1].point;
  var pointC = pointArr[2].point;
  var pointD = pointArr[3].point;

  // 计算4个角度对应的点
  var anglePointArr = [[pointA, pointB, pointC], [pointB, pointC, pointD], [pointC, pointD, pointA], [pointD, pointA, pointB]];
  for (var i = 0; i < anglePointArr.length; i++) {
    if (Math.abs(Math.abs(isRect_getAngle(anglePointArr[i][0], anglePointArr[i][1], anglePointArr[i][2])) - Math.PI / 2) > 0.02 && Math.abs(Math.abs(isRect_getAngle(anglePointArr[i][0], anglePointArr[i][1], anglePointArr[i][2])) - Math.PI * 1.5) > 0.02) {
      return false;
    }
  }
  return true;
});
// CONCATENATED MODULE: ./src/handleImage/handleJudge/isRectangle.js

// 判断是否是正规的矩形
var isRectangle_isRectangle = function isRectangle(layer) {
  var points = layer.points;
  if (layer.points && layer.points.length != 4) {
    return false;
  }
  for (var i = 0; i < points.length; i++) {
    var pointType = points[i].pointType;

    // 非直点属于不规则矩形
    if (pointType !== 'Straight') {
      return false;
    }
  }
  return isRect(points);
};
/* harmony default export */ var handleJudge_isRectangle = (isRectangle_isRectangle);
// CONCATENATED MODULE: ./src/handleImage/handleJudge/isRegularShadow.js
/**
 * 判断是否为规则阴影
 * @param {*} layer
 */
var isRegularShadow = function isRegularShadow(layer) {
  var shadowList = [];
  if (layer.style && layer.style.shadows) {
    // 查找所有可用的阴影
    layer.style.shadows.map(function (item) {
      if (item.enabled) {
        shadowList.push(item);
      }
    });
  }
  if (layer.style && layer.style.innerShadows) {
    layer.style.innerShadows.map(function (item) {
      if (item.enabled) {
        shadowList.push(item);
      }
    });
  }
  if (layer.type === 'Text') {
    // 文本具有阴影则导出图片
    return shadowList.length === 0;
  }
  return true;
};
/* harmony default export */ var handleJudge_isRegularShadow = (isRegularShadow);
// CONCATENATED MODULE: ./src/handleImage/handleJudge/isRegularBorder.js
// 判断是否有边框
var isRegularBorder = function isRegularBorder(layer) {
  var _layer$style;
  if ((_layer$style = layer.style) !== null && _layer$style !== void 0 && _layer$style.borders && layer.style.borders.length) {
    // 获取激活的所有边框
    var borderList = layer.style.borders.filter(function (item) {
      return item.enabled;
    });

    // 多层边框
    if (borderList.length > 1) {
      return false;
    }

    // fillType: Color 纯色填充
    // fillType: Gradient 线性渐变填充|径向纯色填充|锥形渐变
    if (borderList.length === 1 && borderList[0].fillType !== 'Color') {
      // 单层边框
      return false;
    }
    return true;
  }
  return true;
};
/* harmony default export */ var handleJudge_isRegularBorder = (isRegularBorder);
// CONCATENATED MODULE: ./src/handleImage/handleJudge/isSupportedFill.js
// TBD 需要改造
var isSupportedFill = function isSupportedFill(layer) {
  var _layer$style, _layer$style2;
  if (!(layer.type === 'Artboard') && layer.style && Array.isArray((_layer$style = layer.style) === null || _layer$style === void 0 ? void 0 : _layer$style.fills) && (_layer$style2 = layer.style) !== null && _layer$style2 !== void 0 && (_layer$style2 = _layer$style2.fills) !== null && _layer$style2 !== void 0 && _layer$style2.length && layer.style.fills.filter(function (item) {
    return item.enabled;
  }).length > 0) {
    // 处理填充 fills,fills是数组，只支持单个情况,处理成背景色, 文本的背景另外设置
    // 填充类型
    // fillStyle.fillType
    //       Color  纯色
    //       Gradient 渐变色
    //       Pattern 填充图
    // fillStyle.fillType fillStyle.gradient.gradientType
    //        Gradient  Linear   线性渐变色  完全css解析
    //        Gradient  Radial   径向渐变色  1.圆形或者椭圆但是没有倾斜角度的 css解析 2.导出为图片
    //        Gradient  Angular  直角渐变色  css实验属性暂时不支持 ，导出为图片

    var fills = layer.style.fills.filter(function (item) {
      return item.enabled;
    });
    if (fills.length >= 2) {
      return false;
    }
    var fillStyle = fills[fills.length - 1];
    var fillType = fillStyle.fillType;
    if (layer.type === 'Text' && fillType != 'Color') {
      return false;
    }
    if (fillType == 'Pattern') {
      return false;
    }
    if (fillType == 'Gradient' && fillStyle.gradient) {
      var gradient = fillStyle.gradient;
      var frame = layer.frame;
      var gradientType = gradient.gradientType;
      if (gradientType === 'Radial') {
        // 径向渐变
        var startPoint = gradient.from;
        var startX = startPoint.x * frame.width;
        var startY = startPoint.y * frame.height;
        var endPoint = gradient.to;
        var endX = endPoint.x * frame.width;
        var endY = endPoint.y * frame.height;
        if (fillStyle.gradient.elipseLength > 0) {
          // 椭圆渐变
          if (!(Math.abs(endY - startY) < 1 || Math.abs(endX - startX) < 1)) {
            // 可解析
            // 如果倾斜则 导出该图层
            return false;
          }
        }
      } else if (gradientType === 'Angular') {
        // 直角渐变色
        // 导出该图层
        return false;
      }
    }
  }
  return true;
};
/* harmony default export */ var handleJudge_isSupportedFill = (isSupportedFill);
// CONCATENATED MODULE: ./src/handleImage/index.js






/**
 * 计算不规则图形
 *
 * 如果一个组中存在不规则的 mask则 这个组将会做成一张切片
 *
 */
/* harmony default export */ var handleImage = (function (layer) {
  var _layer$style, _layer$style2, _layer$style3;
  // 如果组上有阴影(内阴影或者外阴影)，则标记为导出的图形
  if (layer.type === 'Group' && (_layer$style = layer.style) !== null && _layer$style !== void 0 && _layer$style.shadows && [].concat(toConsumableArray_default()(layer.style.innerShadows), toConsumableArray_default()(layer.style.shadows)).find(function (item) {
    return item.enabled;
  })) {
    return true;
  }

  // 不支持的填充，导出为图片
  if (!handleJudge_isSupportedFill(layer)) {
    return true;
  }

  // 不规则边框则导出当前图层
  if (!handleJudge_isRegularBorder(layer)) {
    return true;
  }

  // 图片、矢量 则直接导出为图片
  if (['Image', 'Shape'].includes(layer.type)) {
    return true;
  }

  // 不规则图形、矢量图形 则将整个组导出为图片
  if (['Star', 'Triangle', 'ShapeGroup', 'Polygon'].includes(layer.shapeType)) {
    return true;
  }

  // Line&Array 线和箭头
  if (layer.type === 'ShapePath' && layer.shapeType === 'Custom' && Array.isArray(layer.points)) {
    // 大于4个点的，导出为图片
    if (layer.points.length > 4) {
      return true;
    }
    for (var i = 0; i < layer.points.length; i++) {
      var pointType = layer.points[i].pointType;

      // 非直点属于不规则矩形
      if (pointType !== 'Straight') {
        return true;
      }
    }
  }

  // 模糊效果直接导出
  if ((_layer$style2 = layer.style) !== null && _layer$style2 !== void 0 && (_layer$style2 = _layer$style2.blur) !== null && _layer$style2 !== void 0 && _layer$style2.enabled) {
    return true;
  }

  // 有矢量点的时候
  if (layer.style && layer.points) {
    // 排除 Mask 的情况
    if (layer.shapeType === 'Oval') {
      return !handleJudge_isOval(layer);
    }
    if (layer.shapeType === 'Rectangle') {
      return !handleJudge_isRectangle(layer);
    }
  }

  // 文本
  if (layer.type === 'Text' && (_layer$style3 = layer.style) !== null && _layer$style3 !== void 0 && _layer$style3.borders) {
    var _layer$style4;
    // 如果文本有可用的border也导出图片
    return (_layer$style4 = layer.style) === null || _layer$style4 === void 0 || (_layer$style4 = _layer$style4.borders) === null || _layer$style4 === void 0 ? void 0 : _layer$style4.find(function (border) {
      return border.enabled;
    });
  }

  // 不规则阴影，导出为图片
  if (!handleJudge_isRegularShadow(layer)) {
    return true;
  }
  return false;
});
// EXTERNAL MODULE: ./src/handleSketchFile.js
var handleSketchFile = __webpack_require__(62);

// EXTERNAL MODULE: ./src/util.js
var util = __webpack_require__(3);

// CONCATENATED MODULE: ./src/parseArtboard.js


function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { defineProperty_default()(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }










var comData;
var serverHost =  true ? 'https://hotplugin.58.com' : undefined;

// import sha1 from 'sha1';

var parseArtboard_isCancelParse = function isCancelParse() {
  return parseUpload["a" /* Fetch */].isCancel;
};
var is = function is(layer, theClass) {
  if (!layer) return false;
  var klass = layer.class();
  return klass === theClass;
};
var toJSString = function toJSString(str) {
  return str.toString();
};
var removeLayer = function removeLayer(layer) {
  var container = layer.parentGroup();
  if (container) container.removeLayer(layer);
};
var find = function find(format, container, returnArray) {
  if (!format || !format.key || !format.match) {
    return false;
  }
  var predicate = NSPredicate.predicateWithFormat(format.key, format.match);
  var items;
  if (container.pages) {
    items = container.pages();
  } else if (is(container, MSSharedStyleContainer) || is(container, MSSharedTextStyleContainer)) {
    items = container.objectsSortedByName();
  } else if (container.children) {
    items = container.children();
  } else {
    items = container;
  }
  var queryResult = items.filteredArrayUsingPredicate(predicate);
  if (returnArray) return queryResult;
  if (queryResult.count() == 1) {
    return queryResult[0];
  }
  if (queryResult.count() > 0) {
    return queryResult;
  }
  return false;
};

/**
 * 导出并上传图片
 * 画板直接导出两倍图
 */
var parseArtboard_exportAndUploadArtboartImage = function _exportAndUploadArtboartImage(layer, progressSlice, getProgress) {
  return new promise_default.a(function (resolve, reject) {
    var _layer$frame;
    var option = {
      scales: +((_layer$frame = layer.frame) === null || _layer$frame === void 0 ? void 0 : _layer$frame.width) === 375 ? 2 : 1,
      // 宽度375画板-2倍图，其他画板-1倍图
      formats: 'png',
      trimmed: false,
      'group-contents-only': true,
      'save-for-web': true,
      output: false
    };
    try {
      var buffer = external_sketch_default.a.export(layer, option);

      // 上传图片
      Object(parseUpload["d" /* upload */])(buffer, 'png', _parseDocument.artProgress, progressSlice, getProgress).then(function (_ref) {
        var res = _ref.res,
          _progress = _ref.artProgress;
        // // console.log(`图片上传成功url: ${res}`);
        _parseDocument.artProgress = _progress;
        resolve(res);
      }).catch(function () {
        // parseDocument.artProgress += progressSlice;
        // // console.log(`图片上传失败: ${err}`);
        resolve('');
      });
    } catch (err) {
      // // console.log('图片导出失败,图层信息：', layer.id, layer.type, err, layer.name);
      _parseDocument.artProgress += progressSlice;
      getProgress(_parseDocument.artProgress);
      // reject(err);
      // parseDocument.artProgress = _progress;
      resolve('');
    }
  }).catch(function (err) {
    console.log('_exportAndUploadArtboartImage error:', err);
    throw err;
  });
};

/**
 * 导出并上传图片
 */
var src_parseArtboard_exportAndUploadArtboartImage = function exportAndUploadArtboartImage(layer, progressSlice, getProgress, sliceSize, isSvg) {
  return new promise_default.a(function (resolve) {
    var scale = 1;

    // 根据选择尺寸导出最大的满足需求的图片尺寸
    if ([1, 1.5, 2, 3, 4].includes(+sliceSize)) {
      scale = Math.floor(4 / sliceSize);
    }
    // console.log('isSvg',isSvg)

    var option = isSvg ? {
      scales: scale,
      formats: 'svg',
      trimmed: false,
      'group-contents-only': true,
      'save-for-web': true,
      output: false
    } : {
      scales: scale,
      formats: 'png',
      trimmed: false,
      'group-contents-only': true,
      'save-for-web': true,
      output: false
    };
    try {
      if (isSvg) {
        var bufferPng = external_sketch_default.a.export(layer, {
          scales: scale,
          formats: 'png',
          trimmed: false,
          'group-contents-only': true,
          'save-for-web': true,
          output: false
        });
        var bufferSvg = external_sketch_default.a.export(layer, {
          scales: scale,
          formats: 'svg',
          trimmed: false,
          'group-contents-only': true,
          'save-for-web': true,
          output: false
        });

        // 上传图片
        Object(parseUpload["d" /* upload */])(bufferPng, 'png', _parseDocument.artProgress, progressSlice * 0.5, getProgress).then(function (_ref2) {
          var res = _ref2.res,
            _progress = _ref2.artProgress;
          // console.log(`图片上传成功url: ${res}`);
          _parseDocument.artProgress = _progress;
          // 上传图片
          Object(parseUpload["d" /* upload */])(bufferSvg, 'svg', _parseDocument.artProgress, progressSlice * 0.5, getProgress).then(function (_ref3) {
            var res2 = _ref3.res,
              _progress2 = _ref3.artProgress;
            // console.log(`图片上传成功url: ${res}`);
            _parseDocument.artProgress = _progress2;
            resolve("".concat(res, "|").concat(res2));
          }).catch(function () {
            // parseDocument.artProgress += progressSlice;
            // // console.log(`图片上传失败: ${err}`);
            resolve('');
          });
        }).catch(function () {
          // parseDocument.artProgress += progressSlice;
          // // console.log(`图片上传失败: ${err}`);
          resolve('');
        });
      } else {
        var buffer = external_sketch_default.a.export(layer, option);

        // 上传图片
        Object(parseUpload["d" /* upload */])(buffer, 'png', _parseDocument.artProgress, progressSlice, getProgress).then(function (_ref4) {
          var res = _ref4.res,
            _progress = _ref4.artProgress;
          // console.log(`图片上传成功url: ${res}`);
          _parseDocument.artProgress = _progress;
          resolve(res);
        }).catch(function () {
          // parseDocument.artProgress += progressSlice;
          // // console.log(`图片上传失败: ${err}`);
          resolve('');
        });
      }
    } catch (err) {
      // // console.log('图片导出失败,图层信息：', layer.id, layer.type, err, layer.name);
      _parseDocument.artProgress += progressSlice;
      getProgress(_parseDocument.artProgress);
      // reject(err);
      // parseDocument.artProgress = _progress;
      resolve('');
    }
  }).catch(function (err) {
    console.log('exportAndUploadArtboartImage error:', err);
    throw err;
  });
};

/**
 * 导出并上传图片
 */
var parseArtboard_uploadImage = function uploadImage(layer, progressSlice, getProgress) {
  return new promise_default.a(function (resolve) {
    try {
      // 上传图片
      Object(parseUpload["d" /* upload */])(layer.buffer, 'png', _parseDocument.artProgress, layer.svgBuffer ? progressSlice * 0.5 : progressSlice, getProgress).then(function (_ref5) {
        var res = _ref5.res,
          _progress = _ref5.artProgress;
        if (layer.svgBuffer) {
          _parseDocument.artProgress = _progress;
          // 上传图片
          Object(parseUpload["d" /* upload */])(layer.svgBuffer, 'svg', _parseDocument.artProgress, progressSlice * 0.5, getProgress).then(function (_ref6) {
            var resSvg = _ref6.res,
              _progressSvg = _ref6.artProgress;
            // // console.log(`图片上传成功url: ${res}`);
            _parseDocument.artProgress = _progressSvg;
            resolve("".concat(res, ",").concat(resSvg));
          }).catch(function (err) {
            console.log("\u56FE\u7247\u4E0A\u4F20\u5931\u8D251: ".concat(err));
            resolve('');
          });
        } else {
          // console.log(`图片上传成功url: ${res}`);
          _parseDocument.artProgress = _progress;
          resolve(res);
        }
      }).catch(function (err) {
        console.log("\u56FE\u7247\u4E0A\u4F20\u5931\u8D252: ".concat(err));
        resolve('');
      });
    } catch (err) {
      console.log('图片导出失败,图层信息：', layer.id, err);
      _parseDocument.artProgress += progressSlice;
      getProgress(_parseDocument.artProgress);
      // reject(err);
      // parseDocument.artProgress = _progress;
      resolve('');
    }
  }).catch(function (err) {
    console.log('uploadImage error:', err);
    throw err;
  });
};

/**
 * 仅导出图片
 */
var parseArtboard_exportImage = function exportImage(layer, sliceSize) {
  var trimmed = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  var groupContentsOnly = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
  var scale = 1;

  // 根据选择尺寸导出最大的满足需求的图片尺寸
  if ([1, 1.5, 2, 3, 4].includes(+sliceSize)) {
    scale = Math.floor(4 / sliceSize);
  }
  var option = {
    scales: scale,
    formats: 'png',
    trimmed: trimmed,
    // 剪切图片透明无效区域
    'group-contents-only': groupContentsOnly,
    'save-for-web': true,
    output: false
  };
  try {
    return external_sketch_default.a.export(layer, option);
  } catch (err) {
    // // console.log('图片导出失败,图层信息：', layer.id, layer.type, err, layer.name);
    // reject(err);
    // parseDocument.artProgress = _progress;

    return '';
  }
};

/**
 * 导出svg
 */
var parseArtboard_exportSvgImage = function exportSvgImage(layer) {
  var trimmed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  var groupContentsOnly = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
  var option = {
    scales: 1,
    formats: 'svg',
    trimmed: trimmed,
    // 剪切图片透明无效区域
    'group-contents-only': groupContentsOnly,
    'save-for-web': true,
    output: false
  };
  try {
    return external_sketch_default.a.export(layer, option);
  } catch (err) {
    console.log('图片导出失败,图层信息：', layer.id, layer.type, err, layer.name);
    // reject(err);
    // parseDocument.artProgress = _progress;

    return '';
  }
};

/**
 * 上传sketch设计稿
 */
var parseArtboard_uploadSketch = function uploadSketch(sketchPath, progressSlice, getProgress) {
  return new promise_default.a(function (resolve, reject) {
    console.log('sketch文件上传,文件路径：', sketchPath);
    console.log('handleFilePath(sketchPath)', Object(util["f" /* handleFilePath */])(sketchPath));
    var fileData = fs_default.a.readFileSync(Object(util["f" /* handleFilePath */])(sketchPath));
    var fileSuffix = sketchPath.split('.').pop();

    // 上传sketch源文件
    Object(parseUpload["d" /* upload */])(fileData, fileSuffix, _parseDocument.artProgress, progressSlice, getProgress).then(function (_ref7) {
      var res = _ref7.res,
        _progress = _ref7.artProgress;
      _parseDocument.artProgress = _progress;
      // // console.log(`sketch文件路径: ${sketchPath}, 上传成功url: ${res}`);
      resolve(res);
    }).catch(function (err) {
      reject(err);
    });
  }).catch(function (err) {
    console.log('uploadSketch error:', err);
    throw err;
  });
};

/**
 * 上传DSL
 */
var parseArtboard_uploadDSL = function uploadDSL(dslPath, progressSlice, getProgress) {
  return new promise_default.a(function (resolve, reject) {
    // 上传DSL
    var fileData = fs_default.a.readFileSync(Object(util["f" /* handleFilePath */])(dslPath));
    var fileSuffix = dslPath.split('.').pop();
    Object(parseUpload["d" /* upload */])(fileData, fileSuffix, _parseDocument.artProgress, progressSlice, getProgress).then(function (_ref8) {
      var res = _ref8.res,
        _progress = _ref8.artProgress;
      _parseDocument.artProgress = _progress;
      resolve(res);
    }).catch(function (err) {
      console.log('err', err);
      reject(err);
    });
  }).catch(function (err) {
    console.log('uploadDSL error:', err);
    throw err;
  });
};
var parseArtboard_sliceExportIterator = function _sliceExportIterator(sliceList, progressSlice, getProgress, sliceSize) {
  return new promise_default.a(function (resolve, reject) {
    var sliceObject = {};
    var _nextPromise2 = function _nextPromise(index, _sliceList) {
      if (_parseDocument.isCancel) {
        reject();
      }

      // 全部切片任务执行完成
      if (index >= _sliceList.length) {
        resolve(sliceObject);
      } else {
        var sliceId = _sliceList[index].id;

        // 如果切片不存在，则导出该切片
        if (!sliceObject[sliceId]) {
          parseArtboard_uploadImage(_sliceList[index], progressSlice / _sliceList.length, getProgress, sliceSize).then(function (imageUrl) {
            sliceObject[sliceId] = imageUrl;
            _nextPromise2(index + 1, _sliceList);
          }).catch(function (err) {
            reject(err);
          });
          // 如果切片已存在，则执行下一个任务
        } else {
          _nextPromise2(index + 1, _sliceList);
        }
      }
    };
    if (sliceList.length == 0) {
      _parseDocument.artProgress += progressSlice;
      getProgress(_parseDocument.artProgress);
      resolve(sliceObject);
    } else {
      _nextPromise2(0, sliceList);
    }
  }).catch(function (err) {
    console.log('_sliceExportIterator error:', err);
    throw err;
  });
};
var _sliceExportIterator2 = function sliceExportIterator(sliceList, progressSlice, getProgress, sliceSize, isSvg) {
  return new promise_default.a(function (resolve, reject) {
    var sliceObject = {};
    var _nextPromise3 = function _nextPromise(index, _sliceList) {
      // 全部切片任务执行完成
      if (index >= _sliceList.length) {
        resolve(sliceObject);
      } else {
        var sliceId = _sliceList[index].id;

        // 如果中止
        if (_sliceExportIterator2.isCancel) {
          reject();
        } else if (!sliceObject[sliceId]) {
          src_parseArtboard_exportAndUploadArtboartImage(_sliceList[index], progressSlice / _sliceList.length, getProgress, sliceSize, isSvg).then(function (imageUrl) {
            sliceObject[sliceId] = imageUrl;
            _nextPromise3(index + 1, _sliceList);
          }).catch(function (err) {
            reject(err);
          });
          // 如果切片已存在，则执行下一个任务
        } else {
          _nextPromise3(index + 1, _sliceList);
        }
      }
    };
    _nextPromise3(0, sliceList);
  }).catch(function (err) {
    console.log('sliceExportIterator error:', err);
    throw err;
  });
};

/**
 * @desc symbol 递归解绑
 */

var _datachSymbolIterator = function datachSymbolIterator(group) {
  var instancesList = external_sketch_default.a.find("[type='SymbolInstance']", group) || [];
  if (instancesList.length) {
    instancesList.forEach(function (layer) {
      layer.detach({
        recursively: false
      });
    });
    _datachSymbolIterator(group);
  }
  return group;
};

_sliceExportIterator2.isCancel = false;

/**
 * 画板解析
 * @param {*} type
 *
 */
var parseArtboard_parseArtboard = function parseArtboard(sharedLayerStyles, sharedTextStyles, _ref9, artboardItem, progressSlice, getProgress, sliceSize) {
  var isParseCode = _ref9.isParseCode,
    isExportSvg = _ref9.isExportSvg,
    pluginFolderPath = _ref9.pluginFolderPath;
  return new promise_default.a(function (resolve, reject) {
    // try {
    // 画板id暂时用随机值
    var artboardSha1 = Object(parseUpload["c" /* uniqueId */])();
    // 未解析，则走解析流程
    var symbolInstanceIds = [];
    // 字体存储
    var fontMap = {};
    var symbolGroups = [];
    // 代码解析图片处理存储
    var codeImageMap = {};
    var symbolMasterObject = comData;
    var symbolComponentObject = {};
    // 递归查找需求导出为图片的图层
    var _getImageLayers2 = function _getImageLayers(layers) {
      var _exportLayers = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
      for (var i = 0; i < layers.length; i++) {
        var _layer$exportFormats, _sketchDom$fromNative, _layer$exportFormats2;
        var layer = layers[i];
        var SLayer = layer.sketchObject;
        if (layer.type === 'SymbolInstance') {
          console.log('layer.name', layer.name);
          console.log('layer.type', layer.type);
        }

        // 组件关系记录=>存储
        if (layer.type === 'SymbolInstance' && SLayer.symbolMaster()
        // 从接口获取数据则记录组件关系
        && symbolMasterObject[dom_default.a.fromNative(SLayer.symbolMaster()).id]) {
          symbolComponentObject[layer.id] = symbolMasterObject[dom_default.a.fromNative(SLayer.symbolMaster()).id];
        }

        // 字体处理=>存储
        if (!fontMap[layer.id] && layer.type === 'Text') {
          var _layer$sketchObject;
          /* eslint-disable */
          fontMap[layer.id] = new String((_layer$sketchObject = layer.sketchObject) === null || _layer$sketchObject === void 0 ? void 0 : _layer$sketchObject.fontPostscriptName()).toString();
          /* eslint-disable */
        }

        /**
         * 切片条件
         * 必须条件：非隐藏图层
         * 可选条件：
         * 1. Slice图层
         * 2. SymbolInstance的SymbolMaster有导出项的图层
         * 3. 非Artboard且有导出项的图层
         *
         */
        if (!layer.hidden && (layer.type === 'Slice' || layer.type === 'SymbolInstance' && !(((_layer$exportFormats = layer.exportFormats) === null || _layer$exportFormats === void 0 ? void 0 : _layer$exportFormats.length) > 0) && SLayer.symbolMaster() && ((_sketchDom$fromNative = dom_default.a.fromNative(SLayer.symbolMaster()).exportFormats) === null || _sketchDom$fromNative === void 0 ? void 0 : _sketchDom$fromNative.length) > 0 || layer.type !== 'Artboard' && ((_layer$exportFormats2 = layer.exportFormats) === null || _layer$exportFormats2 === void 0 ? void 0 : _layer$exportFormats2.length) > 0)) {
          try {
            var _layer$exportFormats3, _sketchDom$fromNative2;
            var trimmed = true;
            var groupContentsOnly = true;
            var layerJson = external_sketch_default.a.export(layer, {
              formats: 'json',
              output: false
            });
            var symbolName = '';
            var buffer = '';
            var svgBuffer = '';

            // 处理组件
            if (layer.type === 'SymbolInstance' && !(((_layer$exportFormats3 = layer.exportFormats) === null || _layer$exportFormats3 === void 0 ? void 0 : _layer$exportFormats3.length) > 0) && SLayer.symbolMaster() && ((_sketchDom$fromNative2 = dom_default.a.fromNative(SLayer.symbolMaster()).exportFormats) === null || _sketchDom$fromNative2 === void 0 ? void 0 : _sketchDom$fromNative2.length) > 0) {
              symbolName = dom_default.a.fromNative(SLayer.symbolMaster()).name;
              buffer = parseArtboard_exportImage(SLayer.symbolMaster(), sliceSize, false, true);
              // 如何library的远程切图导出失败，则导出当前实例的切图（To Be Done 暂时还不够严谨）
              if (!buffer) {
                buffer = parseArtboard_exportImage(layer, sliceSize, false, true);
              }
            } else {
              var _layer$exportFormats4;
              if (layer.type === 'Slice') {
                var _layerJson$exportOpti = layerJson.exportOptions,
                  shouldTrim = _layerJson$exportOpti.shouldTrim,
                  layerOptions = _layerJson$exportOpti.layerOptions;
                trimmed = shouldTrim;
                groupContentsOnly = +layerOptions === 2;
              }
              // 非Artboard且有导出项的图层 是否进行剪切处理
              if (layer.type !== 'Artboard' && ((_layer$exportFormats4 = layer.exportFormats) === null || _layer$exportFormats4 === void 0 ? void 0 : _layer$exportFormats4.length) > 0) {
                var _shouldTrim = layerJson.exportOptions.shouldTrim;
                trimmed = _shouldTrim;
              }
              buffer = parseArtboard_exportImage(layer, sliceSize, trimmed, groupContentsOnly);

              // 需要导出svg的时候
              if (isExportSvg) {
                svgBuffer = parseArtboard_exportSvgImage(layer, trimmed, groupContentsOnly);
              }
            }
            _exportLayers.push({
              id: layer.id,
              buffer: buffer,
              svgBuffer: svgBuffer,
              symbolName: symbolName
            });
          } catch (error) {
            console.log('图片导出错误', layer.id, error);
          }
          // 代码模式导出图片
        } else if (!layer.hidden && isParseCode) {
          try {
            // 判断是否需要做切片处理
            if (handleImage(layer)) {
              // 进行切片
              var sliceLayer = MSSliceLayer.sliceLayerFromLayer(SLayer);
              // 获取切片尺寸
              var sliceFrame = sliceLayer.frame();
              // 注意：导出当前图层
              var _buffer = parseArtboard_exportImage(layer, sliceSize);

              // 存储切片信息
              codeImageMap[layer.id] = {
                x: sliceFrame.left ? sliceFrame.left() : sliceFrame.rect().origin.x,
                // 兼容v72
                y: sliceFrame.top ? sliceFrame.top() : sliceFrame.rect().origin.y,
                // 兼容v72
                width: sliceFrame.width ? sliceFrame.width() : sliceFrame.rect().size.width,
                // 兼容v72
                height: sliceFrame.height ? sliceFrame.height() : sliceFrame.rect().size.height // 兼容v72
              };
              _exportLayers.push({
                id: layer.id,
                buffer: _buffer
              });
              removeLayer(sliceLayer);
            }
          } catch (error) {
            console.log('_getImageLayers error:', error);
          }
        }
        var tempGroup = '';
        try {
          var _layer$exportFormats5, _sketchDom$fromNative3;
          // symbol
          if (!layer.hidden && layer.type === 'SymbolInstance' && !(((_layer$exportFormats5 = layer.exportFormats) === null || _layer$exportFormats5 === void 0 ? void 0 : _layer$exportFormats5.length) > 0) && SLayer.symbolMaster() && !(((_sketchDom$fromNative3 = dom_default.a.fromNative(SLayer.symbolMaster()).exportFormats) === null || _sketchDom$fromNative3 === void 0 ? void 0 : _sketchDom$fromNative3.length) > 0) && SLayer.symbolMaster().children && typeof SLayer.symbolMaster().children === 'function' && SLayer.symbolMaster().children().count() > 1) {
            var symbolChildren = SLayer.symbolMaster().children();
            var tempSymbol = SLayer.duplicate();
            if (tempSymbol.detachStylesAndReplaceWithGroup) {
              // 76.1以上版本
              tempGroup = tempSymbol.detachStylesAndReplaceWithGroup(); // detachStylesAndReplaceWithGroupRecursively(); // NSConcreteMapTable
              tempGroup = _datachSymbolIterator(tempGroup);
            } else {
              // 低版本
              tempGroup = dom_default.a.fromNative(tempSymbol).detach({
                recursively: false
              });
              tempGroup = _datachSymbolIterator(tempGroup);
              tempGroup = tempGroup.sketchObject;
            }
            var tempSymbolLayers = tempGroup.children().objectEnumerator();
            var overrides = SLayer.overrides();
            var idx = 0;
            var tempSymbolLayer = void 0;
            overrides = overrides ? overrides.objectForKey(0) : undefined;
            /* eslint-disable */
            while (tempSymbolLayer = tempSymbolLayers.nextObject()) {
              /* eslint-disable */
              if (is(tempSymbolLayer, MSSymbolInstance)) {
                var symbolMasterObjectID = toJSString(symbolChildren[idx].objectID());
                if (overrides && overrides[symbolMasterObjectID] && !!overrides[symbolMasterObjectID].symbolID) {
                  var changeSymbol = find({
                    key: '(symbolID != NULL) && (symbolID == %@)',
                    match: toJSString(overrides[symbolMasterObjectID].symbolID)
                  }, parseArtboard_document.documentData().allSymbols());
                  if (changeSymbol) {
                    tempSymbolLayer.changeInstanceToSymbol(changeSymbol);
                  } else {
                    tempSymbolLayer = undefined;
                  }
                }
              }
              idx++;
            }
            symbolInstanceIds.push(layer.id);
            symbolGroups.push(tempGroup);
            if (Array.isArray(dom_default.a.fromNative(tempGroup).layers)) {
              _getImageLayers2(dom_default.a.fromNative(tempGroup).layers, _exportLayers);
            }
            removeLayer(tempGroup);
          } else if (Array.isArray(layer.layers)) {
            _getImageLayers2(layer.layers, _exportLayers);
          }
        } catch (error) {
          console.log('error', error);
        }
      }
      return _exportLayers;
    };

    // 解绑组件
    var _detachAllSymbolInstances2 = function _detachAllSymbolInstances(container) {
      for (var i = container.layers.length - 1; i >= 0; i--) {
        var layer = container.layers[i];

        // 跳过切片图层，它们不需要解绑
        if (layer.type === 'SymbolInstance') {
          var detachedGroup = layer.detach();
          if (detachedGroup && detachedGroup.layers && detachedGroup.layers.length > 0) {
            _detachAllSymbolInstances2(detachedGroup);
          }
        } else if (layer.layers && layer.layers.length > 0) {
          _detachAllSymbolInstances2(layer);
        }
      }
    };
    // 创建画板的副本
    var artboardCopy = artboardItem.duplicate();
    // 对副本进行递归解绑操作
    _detachAllSymbolInstances2(artboardCopy);
    // console.log('画板导出开始：');
    var d1 = new Date().valueOf();
    var sliceList = _getImageLayers2(artboardCopy.layers);
    var d2 = new Date().valueOf();
    console.log('解析图片结束：', d2 - d1);
    // 更新进度
    _parseDocument.artProgress += progressSlice * 0.1;
    getProgress(_parseDocument.artProgress);
    // writeFile('', `${artboardItem.name}_sliceList.json`, sliceList, pluginFolderPath);
    // 导出处理后的画板
    var artboardJSON = external_sketch_default.a.export(artboardCopy, {
      formats: 'json',
      output: false
    });
    // writeFile('', `${artboardItem.name}_artboardItem_after.json`, artboardJSON, pluginFolderPath);

    // 删除临时副本
    artboardCopy.remove();
    var d3 = new Date().valueOf();
    console.log('画板导出结束：', d3 - d2);
    _parseDocument.artProgress += progressSlice * 0.1;
    getProgress(_parseDocument.artProgress);
    var symbolGroupsJSON = [];
    // console.log('symbol导出开始：');

    if (symbolGroups.length > 0) {
      symbolGroupsJSON = external_sketch_default.a.export(symbolGroups, {
        formats: 'json',
        output: false
      });
    }
    var d4 = new Date().valueOf();
    console.log('symbol导出结束：', d4 - d3);
    var _mergeLayer2 = function _mergeLayer(layers) {
      for (var i = 0; i < layers.length; i++) {
        var id = layers[i].do_objectID;
        if (symbolInstanceIds.indexOf(layers[i].do_objectID) > -1) {
          layers[i] = JSON.parse(JSON.stringify(symbolGroupsJSON[symbolInstanceIds.indexOf(layers[i].do_objectID)]));
          layers[i].do_objectID = id;
        }
        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _mergeLayer2(layers[i].layers);
        }
      }
      return layers;
    };
    artboardJSON.layers = _mergeLayer2(artboardJSON.layers);
    _parseDocument.artProgress += progressSlice * 0.1;
    getProgress(_parseDocument.artProgress);
    var _handleSlice2 = function _handleSlice(layers, sliceObject) {
      var _loop = function _loop(i) {
        if (sliceObject[layers[i].do_objectID]) {
          // 不是原始切片的图层以image的方式处理
          if (layers[i]._class !== 'slice') {
            layers[i]._class = 'image';
          }
          if (sliceList.findIndex(function (item) {
            return item.id === layers[i].do_objectID;
          }) > -1 && sliceList[sliceList.findIndex(function (item) {
            return item.id === layers[i].do_objectID;
          })] && sliceList[sliceList.findIndex(function (item) {
            return item.id === layers[i].do_objectID;
          })].symbolName) {
            layers[i].symbolName = sliceList[sliceList.findIndex(function (item) {
              return item.id === layers[i].do_objectID;
            })].symbolName;
          }
          layers[i].isFlippedHorizontal = false;
          layers[i].isFlippedVertical = false;
          layers[i].style = {
            _class: 'style',
            borderOptions: {
              _class: 'borderOptions',
              isEnabled: true,
              dashPattern: [],
              lineCapStyle: 0,
              lineJoinStyle: 0
            },
            borders: [],
            colorControls: {
              _class: 'colorControls',
              isEnabled: false,
              brightness: 0,
              contrast: 1,
              hue: 0,
              saturation: 1
            },
            contextSettings: {
              _class: 'graphicsContextSettings',
              blendMode: 0,
              opacity: 1
            },
            fills: [],
            innerShadows: [],
            shadows: []
          };
          layers[i].layers = [];
          if (/\,/.test(sliceObject[layers[i].do_objectID])) {
            layers[i].imageUrl = sliceObject[layers[i].do_objectID].split(',')[0];
            layers[i].imageSvgUrl = sliceObject[layers[i].do_objectID].split(',')[1];
          } else {
            layers[i].imageUrl = sliceObject[layers[i].do_objectID];
          }
        }
        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _handleSlice2(layers[i].layers, sliceObject);
        }
      };
      for (var i = 0; i < layers.length; i++) {
        _loop(i);
      }
      return layers;
    };

    // 字体补充
    var _handleFont2 = function _handleFont(layers, fontObject) {
      for (var i = 0; i < layers.length; i++) {
        var _layers$i$attributedS, _layers$i$attributedS2;
        // 仅限只有一段文本的情况，多段文本不处理
        if (fontObject[layers[i].do_objectID] && ((_layers$i$attributedS = layers[i].attributedString) === null || _layers$i$attributedS === void 0 || (_layers$i$attributedS = _layers$i$attributedS.attributes) === null || _layers$i$attributedS === void 0 ? void 0 : _layers$i$attributedS.length) === 1 && (_layers$i$attributedS2 = layers[i].attributedString) !== null && _layers$i$attributedS2 !== void 0 && (_layers$i$attributedS2 = _layers$i$attributedS2.attributes[0]) !== null && _layers$i$attributedS2 !== void 0 && (_layers$i$attributedS2 = _layers$i$attributedS2.attributes) !== null && _layers$i$attributedS2 !== void 0 && (_layers$i$attributedS2 = _layers$i$attributedS2.MSAttributedStringFontAttribute) !== null && _layers$i$attributedS2 !== void 0 && _layers$i$attributedS2.attributes) {
          layers[i].attributedString.attributes[0].attributes.MSAttributedStringFontAttribute.attributes.name = fontObject[layers[i].do_objectID];
        }
        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _handleFont2(layers[i].layers, fontObject);
        }
      }
      return layers;
    };

    // 组件关系
    var _handleSymbolComponent2 = function _handleSymbolComponent(layers) {
      var _loop2 = function _loop2() {
        var layer = layers[i];
        // 原始组件，没有解绑
        if (symbolComponentObject[layer.do_objectID]) {
          var _symbolComponentObjec = symbolComponentObject[layer.do_objectID][0],
            object_id = _symbolComponentObjec.object_id,
            component_type = _symbolComponentObjec.component_type,
            uicomponent_name = _symbolComponentObjec.uicomponent_name;
          layer.symbolComponentObject = symbolComponentObject[layer.do_objectID];
          layer.haikuiComponentInfo = {
            id: layer.do_objectID,
            compId: object_id,
            componentType: component_type,
            uicomponentName: uicomponent_name,
            detached: false
          };
        }

        // 组件已经解绑
        if (layer._class === 'group') {
          // 解绑之后只可能是组
          var datachedComList = JSON.parse("[".concat(datachedComData, "]"));
          var groupItem = datachedComList.find(function (item) {
            return item.id === layer.do_objectID;
          });
          if (groupItem && groupItem.id) {
            layer.haikuiComponentInfo = _objectSpread({}, groupItem);
          }
        }
        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _handleSymbolComponent2(layers[i].layers);
        }
      };
      for (var i = 0; i < layers.length; i++) {
        _loop2();
      }
      return layers;
    };
    var _handleSharedStyle2 = function _handleSharedStyle(layers) {
      for (var i = 0; i < layers.length; i++) {
        if (layers[i].sharedStyleID) {
          // 图层样式
          if (sharedLayerStyles[layers[i].sharedStyleID]) {
            layers[i].sharedLayerStyleName = sharedLayerStyles[layers[i].sharedStyleID];
            // 文本样式
          } else if (sharedTextStyles[layers[i].sharedStyleID]) {
            layers[i].sharedTextStyleName = sharedTextStyles[layers[i].sharedStyleID];
          }
        }
        if (Array.isArray(layers[i].layers)) {
          layers[i].layers = _handleSharedStyle2(layers[i].layers);
        }
      }
      return layers;
    };

    // 处理代码模式图片
    var _handleCodeImage2 = function _handleCodeImage(layers, codeImageMap) {
      for (var j = 0; j < layers.length; j++) {
        if (codeImageMap[layers[j].do_objectID]) {
          layers[j].frame = _objectSpread(_objectSpread({}, layers[j].frame), codeImageMap.frame);
        }
        if (Array.isArray(layers[j].layers)) {
          layers[j].layers = _handleCodeImage2(layers[j].layers, codeImageMap);
        }
      }
      return layers;
    };

    // 切片模式和代码模式公用的切片
    var commonSliceObject = {};
    // 代码模式私有切片
    var codeSliceObject = {};
    var sliceObject = {};
    sliceList.forEach(function (item) {
      if (!sliceObject[item.id]) {
        sliceObject[item.id] = 'imageUrl';
      }
    });
    // 公共切片和私有切片分开处理
    Object.keys(sliceObject).map(function (item) {
      if (codeImageMap[item]) {
        codeSliceObject[item] = sliceObject[item];
      } else {
        commonSliceObject[item] = sliceObject[item];
      }
    });
    artboardJSON.imageUrl = 'imageUrl';
    artboardJSON.layers = _handleSlice2(artboardJSON.layers, commonSliceObject);
    artboardJSON.layers = _handleFont2(artboardJSON.layers, fontMap);
    artboardJSON.layers = _handleSymbolComponent2(artboardJSON.layers);
    artboardJSON.layers = _handleSharedStyle2(artboardJSON.layers);
    // writeFile('', `${artboardItem.name}_dsl.json`, artboardJSON, pluginFolderPath);

    // 标注DSL
    var measureDSL = Object(src["picassoArtboardMeatureParse"])(JSON.parse(JSON.stringify(artboardJSON)));
    artboardJSON.layers = _handleSlice2(artboardJSON.layers, codeSliceObject);
    artboardJSON.layers = _handleCodeImage2(artboardJSON.layers, codeImageMap);
    // writeFile('', `${artboardItem.name}_measureDSL_dsl.json`, measureDSL, pluginFolderPath);

    // 代码DSL
    var codeDSL = [];
    var operationCodeDSL = [];
    if (isParseCode) {
      codeDSL = Object(src["picassoArtboardCodeParse"])(JSON.parse(JSON.stringify(artboardJSON)));
      operationCodeDSL = Object(src["picassoArtboardOperationCodeParse"])(JSON.parse(JSON.stringify(artboardJSON)));
    }

    // 图片map
    var imageMap = {};

    // 处理DSL图片
    var _handleDSLImageUrl2 = function _handleDSLImageUrl(layers) {
      for (var j = 0; j < layers.length; j++) {
        if (!imageMap[layers[j].id] && sliceObject[layers[j].id]) {
          imageMap[layers[j].id] = 'imageUrl';
        }
        if (Array.isArray(layers[j].children)) {
          _handleDSLImageUrl2(layers[j].children);
        }
      }
      return layers;
    };
    _handleDSLImageUrl2(measureDSL.children);
    if (isParseCode) {
      _handleDSLImageUrl2(codeDSL.children);
      _handleDSLImageUrl2(operationCodeDSL.children);
    }
    var realSliceList = [];
    sliceList.forEach(function (item) {
      if (imageMap[item.id] === 'imageUrl') {
        realSliceList.push(item);
      }
    });

    // 设置图片url
    var _setImageUrl2 = function _setImageUrl(layers, imgMap) {
      for (var j = 0; j < layers.length; j++) {
        if (imgMap[layers[j].id] && layers[j].value === 'imageUrl') {
          var _layers$j$style;
          // 1. 图片url进行替换
          if (/\,/.test(imgMap[layers[j].id])) {
            layers[j].value = imgMap[layers[j].id].split(',')[0];
            layers[j].imageSvgUrl = imgMap[layers[j].id].split(',')[1];
          } else {
            layers[j].value = imgMap[layers[j].id];
          }

          // 2. 如果是背景图，需要对背景图url进行替换
          if ((_layers$j$style = layers[j].style) !== null && _layers$j$style !== void 0 && (_layers$j$style = _layers$j$style.background) !== null && _layers$j$style !== void 0 && (_layers$j$style = _layers$j$style.image) !== null && _layers$j$style !== void 0 && _layers$j$style.url) {
            if (/\,/.test(imgMap[layers[j].id])) {
              layers[j].style.background.image.url = imgMap[layers[j].id].split(',')[0];
            } else {
              layers[j].style.background.image.url = imgMap[layers[j].id];
            }
          }
        }
        if (Array.isArray(layers[j].children)) {
          layers[j].children = _setImageUrl2(layers[j].children, imgMap);
        }
      }
      return layers;
    };
    // 切片处理
    parseArtboard_sliceExportIterator(realSliceList, progressSlice * 0.6, getProgress, sliceSize).then(function (sliceObject) {
      // 画板图片上传
      parseArtboard_exportAndUploadArtboartImage(artboardItem, progressSlice * 0.05, getProgress).then(function (imageUrl) {
        // 画板体积压缩
        Object(parseUpload["b" /* imageCompress */])(imageUrl).then(function (_ref0) {
          var url = _ref0.url;
          measureDSL.value = url;
          measureDSL.children = _setImageUrl2(measureDSL.children, sliceObject);
          if (isParseCode) {
            codeDSL.children = _setImageUrl2(codeDSL.children, sliceObject);
            operationCodeDSL.children = _setImageUrl2(operationCodeDSL.children, sliceObject);
          }
          var measurePath = "".concat(pluginFolderPath, "/").concat(artboardSha1, "_measure.json");
          var codePath = "".concat(pluginFolderPath, "/").concat(artboardSha1, "_code.json");
          var operationCodePath = "".concat(pluginFolderPath, "/").concat(artboardSha1, "_operation_code.json");
          // 先删除相关文件
          if (fs_default.a.existsSync(measurePath)) {
            fs_default.a.unlinkSync(measurePath);
          }
          if (fs_default.a.existsSync(codePath)) {
            fs_default.a.unlinkSync(codePath);
          }
          if (fs_default.a.existsSync(operationCodePath)) {
            fs_default.a.unlinkSync(operationCodePath);
          }
          fs_default.a.writeFileSync(measurePath, JSON.stringify([_objectSpread(_objectSpread({}, measureDSL), {}, {
            children: []
          })].concat(toConsumableArray_default()(Array.isArray(measureDSL.children) ? measureDSL.children : []))), {
            encoding: 'utf8'
          });
          fs_default.a.writeFileSync(codePath, JSON.stringify(codeDSL), {
            encoding: 'utf8'
          });
          fs_default.a.writeFileSync(operationCodePath, JSON.stringify(operationCodeDSL), {
            encoding: 'utf8'
          });
          parseArtboard_uploadDSL(measurePath, 0, getProgress).then(function (measureDSLUrl) {
            parseArtboard_uploadDSL(codePath, 0, getProgress).then(function (codeDSLUrl) {
              parseArtboard_uploadDSL(operationCodePath, 0, getProgress).then(function (operationCodeDSLUrl) {
                var id = artboardItem.id,
                  name = artboardItem.name,
                  frame = artboardItem.frame;
                var options = {
                  id: id,
                  name: name,
                  frame: JSON.stringify(frame),
                  sha1: artboardSha1,
                  md5: url,
                  measureDSLUrl: measureDSLUrl,
                  codeDSLUrl: codeDSLUrl,
                  operationCodeDSLUrl: operationCodeDSLUrl
                };
                _parseDocument.artProgress += progressSlice * 0.05;
                getProgress(_parseDocument.artProgress);
                // 上传成功，删除文件处理
                if (fs_default.a.existsSync(measurePath)) {
                  fs_default.a.unlinkSync(measurePath);
                }
                if (fs_default.a.existsSync(codePath)) {
                  fs_default.a.unlinkSync(codePath);
                }
                if (fs_default.a.existsSync(operationCodePath)) {
                  fs_default.a.unlinkSync(operationCodePath);
                }
                resolve(options);
              }).catch(function (err) {
                reject(err);
              });
            }).catch(function (err) {
              reject(err);
            });
          }).catch(function (err) {
            reject(err);
          });
        }).catch(function (err) {
          reject(err);
        });
      }).catch(function (err) {
        reject(err);
      });
    }).catch(function (err) {
      reject(err);
    });
    // } catch (error) {
    //     console.log('err',error);
    // }
  }).catch(function (err) {
    console.log('parseArtboard error:', err);
    throw err;
  });
};
var parseArtboard_parseArtboardIterator = function parseArtboardIterator(sharedLayerStyles, sharedTextStyles, parseInfo, progressSlice, getProgress, sliceSize) {
  return new promise_default.a(function (resolve, reject) {
    var results = [];
    var _nextPromise4 = function _nextPromise(index, _artboardList) {
      // console.log('第几个画板: ',index,_artboardList,parseDocument.artProgress,progressSlice/_artboardList.length,progressSlice);
      if (_parseDocument.isCancel) {
        reject();
      } else {
        // 全部画板解析任务完成
        if (index >= _artboardList.length) {
          resolve(results.reverse());
        } else {
          parseArtboard_parseArtboard(sharedLayerStyles, sharedTextStyles, parseInfo, _artboardList[index], progressSlice / _artboardList.length, getProgress, sliceSize).then(function (res) {
            results.push(res);
            _nextPromise4(index + 1, _artboardList);
          }).catch(function (err) {
            reject(err);
          });
        }
      }
    };
    _nextPromise4(0, parseInfo.artboards);
  }).catch(function (err) {
    console.log('parseArtboardIterator err', err);
    throw err;
  });
};

// 取消解析
var parseArtboard_cancelParse = function cancelParse() {
  // 解析过程中，才需要取消
  if (_parseDocument.artProgress > 0 && _parseDocument.artProgress < 1) {
    parseUpload["a" /* Fetch */].cancelFetch();
  }
};
var parseArtboard_resetFetch = function resetFetch() {
  return parseUpload["a" /* Fetch */].isCancel = false;
};
var parseArtboard_getCompData = function getCompData() {
  return new promise_default.a(function (resolve, reject) {
    try {
      if (!comData) {
        lib_default()("".concat(serverHost, "/api/code_component/search"), {
          method: 'GET'
        }).then(function (response) {
          return response.json();
        }).then(function (resultObj) {
          // console.log('上传结果------', text, typeof text);
          // const resultObj = JSON.parse(text);
          comData = resultObj.data ? resultObj.data : {};
          resolve();
        }).catch(function (err) {
          reject(err);
        });
      } else {
        resolve();
      }
      // resolve();
    } catch (error) {
      reject(error);
    }
  }).catch(function (err) {
    console.log('getCompData error:', err);
    throw err;
  });
};
var parseArtboard_document = '';
var documentId = '';
var datachedComData = {};
/**
 * 文档解析
 * @param {*} type 1 选中 2 all
 * @param { Boolean } isUploadSketch 是否上传sketch
 */
var _parseDocument = function parseDocument(parseInfo, type) {
  var getProgress = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : function () {};
  var isUploadSketch = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
  var sliceSize = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 1;
  return new promise_default.a(function (resolve, reject) {
    // 重置相关进度参数
    parseUpload["a" /* Fetch */].isCancel = false;
    _parseDocument.artProgress = 0;
    parseUpload["d" /* upload */].artProgress = 0;
    getProgress(_parseDocument.artProgress);
    var d01 = new Date().valueOf();
    // 获取当前文档
    // const document = sketch.getSelectedDocument();
    parseArtboard_document = external_sketch_default.a.getSelectedDocument();
    documentId = parseArtboard_document.id;
    datachedComData = Object(util["h" /* readFile */])('', "document_".concat(documentId, ".json"), parseInfo.pluginFolderPath);

    // 处理共享样式(图层样式和文本样式)
    // 图层样式Map
    var sharedLayerStyles = {};
    // 文本样式Map
    var sharedTextStyles = {};
    // 处理图层样式Map
    parseArtboard_document.sharedLayerStyles.forEach(function (_ref1) {
      var id = _ref1.id,
        name = _ref1.name;
      sharedLayerStyles[id] = name;
    });
    // 处理文本样式Map
    parseArtboard_document.sharedTextStyles.forEach(function (_ref10) {
      var id = _ref10.id,
        name = _ref10.name;
      sharedTextStyles[id] = name;
    });
    var artboards = [];

    // ====好像没有用到 开始====
    // 当前选中的画板;
    if (type === 1) {
      artboards = parseArtboard_document.selectedLayers.layers.filter(function (layer) {
        return Object(util["g" /* isContainer */])(layer);
      });
      if (artboards.length === 0) {
        parseArtboard_document.pages.forEach(function (page) {
          if (page.selected) {
            artboards = [].concat(toConsumableArray_default()(artboards), toConsumableArray_default()(page.layers.filter(function (item) {
              return Object(util["g" /* isContainer */])(item);
            })));
          }
        });
      }
    } else {
      parseArtboard_document.pages.forEach(function (page) {
        artboards = [].concat(toConsumableArray_default()(artboards), toConsumableArray_default()(page.layers.filter(function (item) {
          return Object(util["g" /* isContainer */])(item);
        })));
      });
    }
    // ====好像没有用到 结束 ====
    // console.log('获取画板时间:',d01, new Date().valueOf()-d01);
    _parseDocument.artProgress = 0.019;
    getProgress(_parseDocument.artProgress);
    // 画板解析进度分配
    var progressArtboardSlice = 0.98;
    if (isUploadSketch) {
      progressArtboardSlice = 0.78;
    }
    // 获取组件关系
    parseArtboard_getCompData().then(function () {
      parseArtboard_parseArtboardIterator(sharedLayerStyles, sharedTextStyles, parseInfo, progressArtboardSlice, getProgress, sliceSize).then(function (res) {
        if (isUploadSketch) {
          // sketch上传进度分配
          var progressSlice = 0.2;
          Object(handleSketchFile["a" /* default */])(type, parseInfo.pluginFolderPath).then(function (sketchFilePath) {
            // Sketch源文件上传
            parseArtboard_uploadSketch(sketchFilePath, progressSlice, getProgress).then(function (sketchUrl) {
              getProgress(1);
              // 部分选中的情况下，删除已有的sketch源文件
              if (type === 1 && fs_default.a.existsSync(sketchFilePath)) {
                fs_default.a.unlinkSync(sketchFilePath);
              }
              console.log('res:', res);
              resolve({
                sketchUrl: sketchUrl,
                artboardList: res
              });
            }).catch(function (err) {
              reject(err);
            });
          }).catch(function (err) {
            reject(err);
          });
        } else {
          getProgress(1);
          resolve({
            sketchUrl: '',
            artboardList: res
          });
        }
      }).catch(function (err) {
        reject(err);
      });
    }).catch(function (err) {
      reject(err);
    });
  }).catch(function (err) {
    console.log('parseDocument error:', err);
    throw err;
  });
};

_parseDocument.artProgress = 0;
_parseDocument.isCancel = false;

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "d", function() { return /* binding */ portal_onLogin; });
__webpack_require__.d(__webpack_exports__, "c", function() { return /* binding */ isLogin; });
__webpack_require__.d(__webpack_exports__, "b", function() { return /* binding */ getUserId; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ getPluginFolderPath; });

// UNUSED EXPORTS: onLogout

// EXTERNAL MODULE: ./node_modules/@skpm/fs/index.js
var fs = __webpack_require__(1);
var fs_default = /*#__PURE__*/__webpack_require__.n(fs);

// EXTERNAL MODULE: ./node_modules/@skpm/path/index.js
var path = __webpack_require__(9);
var path_default = /*#__PURE__*/__webpack_require__.n(path);

// EXTERNAL MODULE: ./src/webview/index.js
var webview = __webpack_require__(13);

// EXTERNAL MODULE: ./src/utils/index.js + 3 modules
var utils = __webpack_require__(10);

// CONCATENATED MODULE: ./src/action.js

var action_autoSidePanelCommand = function autoSidePanelCommand(context) {
  var objectID = (context.document || context.actionContext.document || MSDocument.currentDocument()).documentData().objectID();
  var IdentifierPrefix = objectID ? "hotwheels-".concat(objectID) : 'hotwheels';
  var SidePanelIdentifier = "".concat(IdentifierPrefix, "-side-panel");
  var isShow = Object(utils["c" /* getSettingForKey */])(SidePanelIdentifier);
  if (isShow) {
    var toggleSidePanelCommand = context.command.pluginBundle().commands()['hotwheels.toggle-side-panel'];
    context.command = toggleSidePanelCommand;
    AppController.sharedInstance().runPluginCommand_fromMenu_context(toggleSidePanelCommand, false, context);
  }
};
var handleCommand = function handleCommand(context, command) {
  var commandTarget = context.command.pluginBundle().commands()[command];
  context.command = commandTarget;
  console.info('自动执行');
  AppController.sharedInstance().runPluginCommand_fromMenu_context(commandTarget, false, context);
};

// library安装
// export const addLibrary = (context) => {
//     const libraryFiles = [
//         'test_library.sketch',
//     ];

//     libraryFiles.forEach((fileName) => {
//         const libraryUrl = context.plugin.urlForResourceNamed(fileName);

//         if (libraryUrl) {
//             const libraryPath = String(libraryUrl.path());
//             const library = Library.getLibraryForDocumentAtPath(libraryPath);

//             // 检测library更新
//             AppController.sharedInstance().checkForAssetLibraryUpdates();
//             if (context.action === 'Shutdown') {
//                 library.remove();
//             }
//         }
//     });
// };

var onOpenDocument = function onOpenDocument(context) {
  // addLibrary(context);
  setTimeout(action_autoSidePanelCommand.bind(null, context), 100);
};
var onSelectionChanged = function onSelectionChanged() {};
var onCloseDocument = function onCloseDocument() {
  COScript.currentCOScript().setShouldKeepAround(false);
};
// EXTERNAL MODULE: ./src/openUpload.js
var openUpload = __webpack_require__(17);

// EXTERNAL MODULE: ./src/sidePanel.js
var sidePanel = __webpack_require__(18);

// CONCATENATED MODULE: ./src/portal.js





/* eslint-disable */

/* eslint-disable */

var portal_onLogout = function onLogout(context) {
  clearToken(context);
  var baseUrl = getPluginFolderPath(context);
  Object(openUpload["b" /* clearOperation */])(baseUrl);
  // 判断panel状态，如果展开状态就关闭
  // autoSidePanelCommand(context);
  Object(sidePanel["onShutdown"])(context, true);
};
var portal_onLogin = function onLogin(context, cb) {
  // 命令唯一标识
  var commandIdentifier = context.command.identifier().toString();
  // 判断是否已经打开，如果打开取消重复打开
  var threadDictionary = NSThread.mainThread().threadDictionary();
  if (threadDictionary['hotwheels.login']) {
    return;
  }
  var win = new webview["a" /* Browser */]({
    width: 1100,
    height: 700,
    movable: false,
    resizable: false,
    alwaysOnTop: true,
    minimizable: false,
    transparent: false,
    frame: true,
    index: 100,
    isDialog: true
  }, true);
  // // console.log('win.browserWindow', win.browserWindow);
  win.browserWindow.on('closed', function () {
    threadDictionary['hotwheels.login'] = null;
    win = null;
  });

  // 进入登录页面，默认登录态已经失效
  // returnUrl默认回到home页面
  win.browserWindow.loadURL('https://hotplugin.58.com/logout');
  var contents = win.browserWindow.webContents;
  contents.on('login_success', function (str) {
    // 文件存储
    var oData = JSON.parse(str);

    // // console.log('登录成功返回数据', oData);
    storageToken(context, oData.token);
    // 关闭当前窗口
    // 交互需要确认
    setTimeout(function () {
      // 关闭窗口
      win.browserWindow.close();
      // 打开侧边栏或打开上传页面
      cb && cb();
      // 打开登录之前的命令
      handleCommand(context, commandIdentifier);
    });
  });
  contents.on('login_check', function () {
    var data = isLogin(context);

    // // console.log('login_check', data);
  });
  threadDictionary['hotwheels.login'] = win;
};
var isLogin = function isLogin(context) {
  var data = readToken(context);
  if (data && data.indexOf(authKey) === 0 && data.length > authKey.length + 1) {
    return true;
  }
  return false;
};

// 获取当前登录状态的UserId
var getUserId = function getUserId(context) {
  var data = readToken(context);
  if (data && data.indexOf(authKey) === 0 && data.length > authKey.length + 1) {
    return data.slice(authKey.length + 1);
  }
  return '';
};
var authKey = '_authToken';
function getPluginFolderPath(context) {
  // console.log('context.scriptPath', context.scriptPath);
  var split = context.scriptPath.split('/');
  split.splice(-3, 3);
  // 创建存储插件数据的文件夹
  var pluginDataPath = path_default.a.join(split.join('/'), '../../hotwheels_data');
  if (!fs_default.a.existsSync(pluginDataPath)) {
    fs_default.a.mkdirSync(pluginDataPath);
  }

  // console.log('资源存储路径pluginDataPath', pluginDataPath); // /Users/meiyuju/Library/Application\ Support/com.bohemiancoding.sketch3/hotwheels_data

  return pluginDataPath;
}
function storageToken(context, token) {
  var pluginFolderPath = getPluginFolderPath(context);

  // // console.log('pluginFolderPath', pluginFolderPath);
  fs_default.a.writeFileSync("".concat(pluginFolderPath, "/.hotwheels"), "".concat(authKey, "=").concat(token), {
    encoding: 'utf8'
  });
}
function clearToken(context) {
  var pluginFolderPath = getPluginFolderPath(context);

  // // console.log('pluginFolderPath', pluginFolderPath);
  fs_default.a.writeFileSync("".concat(pluginFolderPath, "/.hotwheels"), "".concat(authKey, "="), {
    encoding: 'utf8'
  });
}
function readToken(context) {
  var pluginFolderPath = getPluginFolderPath(context);

  // // console.log('pluginFolderPath', pluginFolderPath);
  try {
    var data = fs_default.a.readFileSync("".concat(pluginFolderPath, "/.hotwheels"), {
      encoding: 'utf8'
    });

    // // console.log('readToken', data);

    return data;
  } catch (e) {
    return '';
  }
}

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.

var sketchSpecifics = __webpack_require__(75)

// we only expose the posix implementation since Sketch only runs on macOS

var CHAR_FORWARD_SLASH = 47
var CHAR_DOT = 46

// Resolves . and .. elements in a path with directory names
function normalizeString(path, allowAboveRoot) {
  var res = ''
  var lastSegmentLength = 0
  var lastSlash = -1
  var dots = 0
  var code
  for (var i = 0; i <= path.length; i += 1) {
    if (i < path.length) code = path.charCodeAt(i)
    else if (code === CHAR_FORWARD_SLASH) break
    else code = CHAR_FORWARD_SLASH
    if (code === CHAR_FORWARD_SLASH) {
      if (lastSlash === i - 1 || dots === 1) {
        // NOOP
      } else if (lastSlash !== i - 1 && dots === 2) {
        if (
          res.length < 2 ||
          lastSegmentLength !== 2 ||
          res.charCodeAt(res.length - 1) !== CHAR_DOT ||
          res.charCodeAt(res.length - 2) !== CHAR_DOT
        ) {
          if (res.length > 2) {
            var lastSlashIndex = res.lastIndexOf('/')
            if (lastSlashIndex !== res.length - 1) {
              if (lastSlashIndex === -1) {
                res = ''
                lastSegmentLength = 0
              } else {
                res = res.slice(0, lastSlashIndex)
                lastSegmentLength = res.length - 1 - res.lastIndexOf('/')
              }
              lastSlash = i
              dots = 0
              continue
            }
          } else if (res.length === 2 || res.length === 1) {
            res = ''
            lastSegmentLength = 0
            lastSlash = i
            dots = 0
            continue
          }
        }
        if (allowAboveRoot) {
          if (res.length > 0) res += '/..'
          else res = '..'
          lastSegmentLength = 2
        }
      } else {
        if (res.length > 0) res += '/' + path.slice(lastSlash + 1, i)
        else res = path.slice(lastSlash + 1, i)
        lastSegmentLength = i - lastSlash - 1
      }
      lastSlash = i
      dots = 0
    } else if (code === CHAR_DOT && dots !== -1) {
      ++dots
    } else {
      dots = -1
    }
  }
  return res
}

function _format(sep, pathObject) {
  var dir = pathObject.dir || pathObject.root
  var base =
    pathObject.base || (pathObject.name || '') + (pathObject.ext || '')
  if (!dir) {
    return base
  }
  if (dir === pathObject.root) {
    return dir + base
  }
  return dir + sep + base
}

var posix = {
  // path.resolve([from ...], to)
  resolve: function resolve() {
    var resolvedPath = ''
    var resolvedAbsolute = false
    var cwd

    for (var i = arguments.length - 1; i >= -1 && !resolvedAbsolute; i -= 1) {
      var path
      if (i >= 0) {
        path = arguments[i]
      } else {
        if (cwd === undefined) {
          cwd = posix.dirname(sketchSpecifics.cwd())
        }
        path = cwd
      }

      path = sketchSpecifics.getString(path, 'path')

      // Skip empty entries
      if (path.length === 0) {
        continue
      }

      resolvedPath = path + '/' + resolvedPath
      resolvedAbsolute = path.charCodeAt(0) === CHAR_FORWARD_SLASH
    }

    // At this point the path should be resolved to a full absolute path, but
    // handle relative paths to be safe (might happen when process.cwd() fails)

    // Normalize the path
    resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute)

    if (resolvedAbsolute) {
      if (resolvedPath.length > 0) return '/' + resolvedPath
      else return '/'
    } else if (resolvedPath.length > 0) {
      return resolvedPath
    } else {
      return '.'
    }
  },

  normalize: function normalize(path) {
    path = sketchSpecifics.getString(path, 'path')

    if (path.length === 0) return '.'

    var isAbsolute = path.charCodeAt(0) === CHAR_FORWARD_SLASH
    var trailingSeparator =
      path.charCodeAt(path.length - 1) === CHAR_FORWARD_SLASH

    // Normalize the path
    path = normalizeString(path, !isAbsolute)

    if (path.length === 0 && !isAbsolute) path = '.'
    if (path.length > 0 && trailingSeparator) path += '/'

    if (isAbsolute) return '/' + path
    return path
  },

  isAbsolute: function isAbsolute(path) {
    path = sketchSpecifics.getString(path, 'path')
    return path.length > 0 && path.charCodeAt(0) === CHAR_FORWARD_SLASH
  },

  join: function join() {
    if (arguments.length === 0) return '.'
    var joined
    for (var i = 0; i < arguments.length; i += 1) {
      var arg = arguments[i]
      arg = sketchSpecifics.getString(arg, 'path')
      if (arg.length > 0) {
        if (joined === undefined) joined = arg
        else joined += '/' + arg
      }
    }
    if (joined === undefined) return '.'
    return posix.normalize(joined)
  },

  relative: function relative(from, to) {
    from = sketchSpecifics.getString(from, 'from path')
    to = sketchSpecifics.getString(to, 'to path')

    if (from === to) return ''

    from = posix.resolve(from)
    to = posix.resolve(to)

    if (from === to) return ''

    // Trim any leading backslashes
    var fromStart = 1
    for (; fromStart < from.length; fromStart += 1) {
      if (from.charCodeAt(fromStart) !== CHAR_FORWARD_SLASH) break
    }
    var fromEnd = from.length
    var fromLen = fromEnd - fromStart

    // Trim any leading backslashes
    var toStart = 1
    for (; toStart < to.length; toStart += 1) {
      if (to.charCodeAt(toStart) !== CHAR_FORWARD_SLASH) break
    }
    var toEnd = to.length
    var toLen = toEnd - toStart

    // Compare paths to find the longest common path from root
    var length = fromLen < toLen ? fromLen : toLen
    var lastCommonSep = -1
    var i = 0
    for (; i <= length; i += 1) {
      if (i === length) {
        if (toLen > length) {
          if (to.charCodeAt(toStart + i) === CHAR_FORWARD_SLASH) {
            // We get here if `from` is the exact base path for `to`.
            // For example: from='/foo/bar'; to='/foo/bar/baz'
            return to.slice(toStart + i + 1)
          } else if (i === 0) {
            // We get here if `from` is the root
            // For example: from='/'; to='/foo'
            return to.slice(toStart + i)
          }
        } else if (fromLen > length) {
          if (from.charCodeAt(fromStart + i) === CHAR_FORWARD_SLASH) {
            // We get here if `to` is the exact base path for `from`.
            // For example: from='/foo/bar/baz'; to='/foo/bar'
            lastCommonSep = i
          } else if (i === 0) {
            // We get here if `to` is the root.
            // For example: from='/foo'; to='/'
            lastCommonSep = 0
          }
        }
        break
      }
      var fromCode = from.charCodeAt(fromStart + i)
      var toCode = to.charCodeAt(toStart + i)
      if (fromCode !== toCode) break
      else if (fromCode === CHAR_FORWARD_SLASH) lastCommonSep = i
    }

    var out = ''
    // Generate the relative path based on the path difference between `to`
    // and `from`
    for (i = fromStart + lastCommonSep + 1; i <= fromEnd; i += 1) {
      if (i === fromEnd || from.charCodeAt(i) === CHAR_FORWARD_SLASH) {
        if (out.length === 0) out += '..'
        else out += '/..'
      }
    }

    // Lastly, append the rest of the destination (`to`) path that comes after
    // the common path parts
    if (out.length > 0) return out + to.slice(toStart + lastCommonSep)
    else {
      toStart += lastCommonSep
      if (to.charCodeAt(toStart) === CHAR_FORWARD_SLASH) toStart += 1
      return to.slice(toStart)
    }
  },

  toNamespacedPath: function toNamespacedPath(path) {
    // Non-op on posix systems
    return path
  },

  dirname: function dirname(path) {
    path = sketchSpecifics.getString(path, 'path')
    if (path.length === 0) return '.'
    var code = path.charCodeAt(0)
    var hasRoot = code === CHAR_FORWARD_SLASH
    var end = -1
    var matchedSlash = true
    for (var i = path.length - 1; i >= 1; i -= 1) {
      code = path.charCodeAt(i)
      if (code === CHAR_FORWARD_SLASH) {
        if (!matchedSlash) {
          end = i
          break
        }
      } else {
        // We saw the first non-path separator
        matchedSlash = false
      }
    }

    if (end === -1) return hasRoot ? '/' : '.'
    if (hasRoot && end === 1) return '//'
    return path.slice(0, end)
  },

  basename: function basename(path, ext) {
    if (ext !== undefined)
      ext = sketchSpecifics.getString(ext, 'ext')
    path = sketchSpecifics.getString(path, 'path')

    var start = 0
    var end = -1
    var matchedSlash = true
    var i

    if (ext !== undefined && ext.length > 0 && ext.length <= path.length) {
      if (ext.length === path.length && ext === path) return ''
      var extIdx = ext.length - 1
      var firstNonSlashEnd = -1
      for (i = path.length - 1; i >= 0; i -= 1) {
        var code = path.charCodeAt(i)
        if (code === CHAR_FORWARD_SLASH) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            start = i + 1
            break
          }
        } else {
          if (firstNonSlashEnd === -1) {
            // We saw the first non-path separator, remember this index in case
            // we need it if the extension ends up not matching
            matchedSlash = false
            firstNonSlashEnd = i + 1
          }
          if (extIdx >= 0) {
            // Try to match the explicit extension
            if (code === ext.charCodeAt(extIdx)) {
              if (--extIdx === -1) {
                // We matched the extension, so mark this as the end of our path
                // component
                end = i
              }
            } else {
              // Extension does not match, so our result is the entire path
              // component
              extIdx = -1
              end = firstNonSlashEnd
            }
          }
        }
      }

      if (start === end) end = firstNonSlashEnd
      else if (end === -1) end = path.length
      return path.slice(start, end)
    } else {
      for (i = path.length - 1; i >= 0; --i) {
        if (path.charCodeAt(i) === CHAR_FORWARD_SLASH) {
          // If we reached a path separator that was not part of a set of path
          // separators at the end of the string, stop now
          if (!matchedSlash) {
            start = i + 1
            break
          }
        } else if (end === -1) {
          // We saw the first non-path separator, mark this as the end of our
          // path component
          matchedSlash = false
          end = i + 1
        }
      }

      if (end === -1) return ''
      return path.slice(start, end)
    }
  },

  extname: function extname(path) {
    path = sketchSpecifics.getString(path, 'path')
    var startDot = -1
    var startPart = 0
    var end = -1
    var matchedSlash = true
    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0
    for (var i = path.length - 1; i >= 0; --i) {
      var code = path.charCodeAt(i)
      if (code === CHAR_FORWARD_SLASH) {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          startPart = i + 1
          break
        }
        continue
      }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false
        end = i + 1
      }
      if (code === CHAR_DOT) {
        // If this is our first dot, mark it as the start of our extension
        if (startDot === -1) startDot = i
        else if (preDotState !== 1) preDotState = 1
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1
      }
    }

    if (
      startDot === -1 ||
      end === -1 ||
      // We saw a non-dot character immediately before the dot
      preDotState === 0 ||
      // The (right-most) trimmed path component is exactly '..'
      (preDotState === 1 && startDot === end - 1 && startDot === startPart + 1)
    ) {
      return ''
    }
    return path.slice(startDot, end)
  },

  format: function format(pathObject) {
    if (pathObject === null || typeof pathObject !== 'object') {
      throw new Error('pathObject should be an Object')
    }
    return _format('/', pathObject)
  },

  parse: function parse(path) {
    path = sketchSpecifics.getString(path, 'path')

    var ret = { root: '', dir: '', base: '', ext: '', name: '' }
    if (path.length === 0) return ret
    var code = path.charCodeAt(0)
    var isAbsolute = code === CHAR_FORWARD_SLASH
    var start
    if (isAbsolute) {
      ret.root = '/'
      start = 1
    } else {
      start = 0
    }
    var startDot = -1
    var startPart = 0
    var end = -1
    var matchedSlash = true
    var i = path.length - 1

    // Track the state of characters (if any) we see before our first dot and
    // after any path separator we find
    var preDotState = 0

    // Get non-dir info
    for (; i >= start; --i) {
      code = path.charCodeAt(i)
      if (code === CHAR_FORWARD_SLASH) {
        // If we reached a path separator that was not part of a set of path
        // separators at the end of the string, stop now
        if (!matchedSlash) {
          startPart = i + 1
          break
        }
        continue
      }
      if (end === -1) {
        // We saw the first non-path separator, mark this as the end of our
        // extension
        matchedSlash = false
        end = i + 1
      }
      if (code === CHAR_DOT) {
        // If this is our first dot, mark it as the start of our extension
        if (startDot === -1) startDot = i
        else if (preDotState !== 1) preDotState = 1
      } else if (startDot !== -1) {
        // We saw a non-dot and non-path separator before our dot, so we should
        // have a good chance at having a non-empty extension
        preDotState = -1
      }
    }

    if (
      startDot === -1 ||
      end === -1 ||
      // We saw a non-dot character immediately before the dot
      preDotState === 0 ||
      // The (right-most) trimmed path component is exactly '..'
      (preDotState === 1 && startDot === end - 1 && startDot === startPart + 1)
    ) {
      if (end !== -1) {
        if (startPart === 0 && isAbsolute)
          ret.base = ret.name = path.slice(1, end)
        else ret.base = ret.name = path.slice(startPart, end)
      }
    } else {
      if (startPart === 0 && isAbsolute) {
        ret.name = path.slice(1, startDot)
        ret.base = path.slice(1, end)
      } else {
        ret.name = path.slice(startPart, startDot)
        ret.base = path.slice(startPart, end)
      }
      ret.ext = path.slice(startDot, end)
    }

    if (startPart > 0) ret.dir = path.slice(0, startPart - 1)
    else if (isAbsolute) ret.dir = '/'

    return ret
  },

  sep: '/',
  delimiter: ':',
  win32: null,
  posix: null,

  resourcePath: sketchSpecifics.resourcePath,
}

module.exports = posix
module.exports.posix = posix


/***/ }),
/* 10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "b", function() { return /* reexport */ createImageView; });
__webpack_require__.d(__webpack_exports__, "i", function() { return /* reexport */ setHighlight; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ addButton; });
__webpack_require__.d(__webpack_exports__, "d", function() { return /* reexport */ selector_getSketchSelected; });
__webpack_require__.d(__webpack_exports__, "f", function() { return /* reexport */ system["c" /* penUrlInBrowser */]; });
__webpack_require__.d(__webpack_exports__, "c", function() { return /* reexport */ system["a" /* getSettingForKey */]; });
__webpack_require__.d(__webpack_exports__, "j", function() { return /* reexport */ system["f" /* setSettingForKey */]; });
__webpack_require__.d(__webpack_exports__, "h", function() { return /* reexport */ system["e" /* removeSettingForKey */]; });
__webpack_require__.d(__webpack_exports__, "e", function() { return /* reexport */ system["b" /* observerWindowResizeNotification */]; });
__webpack_require__.d(__webpack_exports__, "g", function() { return /* reexport */ system["d" /* removeObserverWindowResizeNotification */]; });

// UNUSED EXPORTS: getImageURL, createImage, createBoxSeparator, createBounds, createPanel, createView, createBox, createTextField, getSelected, getScriptExecPath, getDocumentID, getDocumentPath, getDocumentName, dumpLayer, dumpSymbol, getNewUUID, getThreadDictForKey, setThreadDictForKey, removeThreadDictForKey, showPluginsPane, showLibrariesPane, getSystemVersion, getPluginVersion, reloadPlugins, getFileContentFromModal, getSavePathFromModal, File

// EXTERNAL MODULE: ./src/state.js
var state = __webpack_require__(0);

// CONCATENATED MODULE: ./src/utils/element.js


/**
 * getImageURL 获取 icon 路径
 * @param {*} name
 */
var element_getImageURL = function getImageURL(name) {
  var isRetinaDisplay = NSScreen.mainScreen().backingScaleFactor() > 1;
  // const suffix = isRetinaDisplay ? '@2x' : '';
  var suffix = '@2x';
  var pluginSketch = state["f" /* context */].plugin.url();
  var imageURL = pluginSketch.URLByAppendingPathComponent('Contents').URLByAppendingPathComponent('Resources').URLByAppendingPathComponent('icons').URLByAppendingPathComponent("".concat(name + suffix, ".png"));
  return imageURL;
};

/**
 * createImage 创建 NSImage
 * @param {*} imageURL
 * @param {*} size
 */
var createImage = function createImage(imageURL, size) {
  // NSImage.alloc().initWithSize([width, height])
  var Image = NSImage.alloc().initWithContentsOfURL(imageURL);
  size && Image.setSize(size);
  Image.setScalesWhenResized(true);
  return Image;
};

/**
 * createImageView 创建 NSImageView
 * @param {*} rect
 * @param {*} icon
 * @param {*} size
 */
var createImageView = function createImageView(rect, icon, size) {
  var imageView = NSImageView.alloc().initWithFrame(rect);
  var imageURL = element_getImageURL(icon);
  var image = createImage(imageURL, size);
  imageView.setImage(image);
  imageView.setAutoresizingMask(5);
  return imageView;
};

/**
 * createImageView 创建 NSBoxSeparator
 */
var createBoxSeparator = function createBoxSeparator() {
  // set to 0 in width and height
  var separtorBox = NSBox.alloc().initWithFrame(NSZeroRect);
  // Specifies that the box is a separator
  separtorBox.setBoxType(NSBoxSeparator);

  // separtorBox.setFillColor(NSColor.colorWithHex('#E40404'))
  separtorBox.setBorderColor(NSColor.colorWithHex('#E40404'));
  // separtorBox._updateSeparatorBackgroundView(NSColor.colorWithHex('#E40404'))

  // try {
  //   separtorBox.setBorderColor(NSColor.colorWithSRGBRed_green_blue_alpha(288/255, 4/255, 4/255, 1.0))
  // } catch (error) {
  //   console.error(error)
  // }

  // separtorBox.setTransparent(true)
  return separtorBox;
};
var setHighlight = function setHighlight(target, color, icon, size) {
  if (target.setABTextColor) {
    target.setABTextColor(NSColor.colorWithHex(color));
  } else {
    target.setContentTintColor(NSColor.colorWithHex(color));
  }
  var ImageURL = element_getImageURL(icon);
  var Image = createImage(ImageURL, size);
  target.setImage(Image);
};

/**
 * addButton 创建 NSButton
 * @param {*} param { rect, size, icon, activeIcon, tooltip = '', type = 5, callAction }
 */
var addButton = function addButton(_ref) {
  var rect = _ref.rect,
    size = _ref.size,
    icon = _ref.icon,
    activeIcon = _ref.activeIcon,
    _ref$tooltip = _ref.tooltip,
    tooltip = _ref$tooltip === void 0 ? '' : _ref$tooltip,
    _ref$type = _ref.type,
    type = _ref$type === void 0 ? 5 : _ref$type,
    toClose = _ref.toClose,
    callAction = _ref.callAction;
  var button = rect ? NSButton.alloc().initWithFrame(rect) : NSButton.alloc().init();
  // // console.log('button', button);
  // // console.log('rect', rect);
  // // console.log('size', size);
  // // console.log('type', type);
  var imageURL = element_getImageURL(icon);
  var image = createImage(imageURL, size);
  button.setImage(image);
  // 设置标题
  button.setTitle(tooltip);
  // 设置字体
  button.setFont(NSFont.systemFontOfSize(10));
  try {
    if (button.setABTextColor) {
      button.setABTextColor(NSColor.colorWithHex('#ffffff'));
    } else {
      button.setContentTintColor(NSColor.colorWithHex('#ffffff'));
    }
  } catch (error) {
    // // console.log('error', error);
  }
  if (activeIcon) {
    var activeImageURL = element_getImageURL(activeIcon);
    var activeImage = createImage(activeImageURL, size);
    button.setAlternateImage(activeImage);
  } else {
    button.setAlternateImage(image);
  }
  button.setBordered(false);
  // button.sizeToFit()
  button.setToolTip(tooltip);
  // 设置图文布局
  button.setImagePosition(5);
  // button.setButtonType(type || NSMomentaryChangeButton)
  button.setCOSJSTargetFunction(callAction);
  button.setAction('callAction:');
  button.removeBadge = function () {
    button.setImage(image);
    button.hasBadge = false;
  };
  button.icon = icon;
  return button;
};

/**
 * 创建 bounds
 * @param {*} x
 * @param {*} y
 * @param {*} width
 * @param {*} height
 */
var createBounds = function createBounds() {
  var x = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var y = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var width = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var height = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  return NSMakeRect(x, y, width, height);
};

/**
 * createView 创建 NSPanel
 * @param {*} frame  options
 */
var createPanel = function createPanel() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
    width: 800,
    height: 600,
    minWidth: 0,
    minHeight: 0,
    x: 0,
    y: 0,
    title: 'panel',
    identifier: 'sketch-panel',
    vibrancy: true
  };
  COScript.currentCOScript().setShouldKeepAround(true);
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var mainScreenRect = NSScreen.screens().firstObject().frame();
  var Bounds = NSMakeRect(options.x ? options.x : Math.round((NSWidth(mainScreenRect) - options.width) / 2), options.y ? NSHeight(mainScreenRect) - options.y : Math.round((NSHeight(mainScreenRect) - options.height) / 2), options.width, options.height);
  var panel = NSPanel.alloc().init();
  panel.setFrame_display(Bounds, true);
  panel.setOpaque(0);
  threadDictionary[options.identifier] = panel;

  // NSWindowStyleMaskDocModalWindow 直角
  panel.setStyleMask(NSWindowStyleMaskFullSizeContentView | NSBorderlessWindowMask | NSResizableWindowMask | NSTexturedBackgroundWindowMask | NSTitledWindowMask | NSClosableWindowMask | NSFullSizeContentViewWindowMask | NSWindowStyleMaskResizable);
  panel.setBackgroundColor(NSColor.whiteColor() || NSColor.windowBackgroundColor());
  panel.title = options.title;
  panel.movableByWindowBackground = true;
  panel.titlebarAppearsTransparent = true;
  panel.titleVisibility = NSWindowTitleHidden;
  panel.center();
  panel.makeKeyAndOrderFront(null);
  panel.setLevel(NSFloatingWindowLevel);
  panel.minSize = NSMakeSize(options.minWidth, options.minHeight);
  panel.standardWindowButton(NSWindowZoomButton).setHidden(true);
  panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true);
  panel.standardWindowButton(NSWindowCloseButton).setHidden(true);

  // Some third-party macOS utilities check the zoom button's enabled state to
  // determine whether to show custom UI on hover, so we disable it here to
  // prevent them from doing so in a frameless app window.
  panel.standardWindowButton(NSWindowZoomButton).setEnabled(false);

  // The fullscreen button should always be hidden for frameless window.
  if (panel.standardWindowButton(NSWindowFullScreenButton)) {
    panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true);
  }
  panel.showsToolbarButton = false;
  panel.movableByWindowBackground = true;
  if (options.vibrancy) {
    // Create the blurred background
    var effectView = NSVisualEffectView.alloc().initWithFrame(NSMakeRect(0, 0, options.width, options.height));
    effectView.setMaterial(NSVisualEffectMaterialPopover);
    effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable);
    effectView.setAppearance(NSAppearance.appearanceNamed(NSAppearanceNameVibrantLight));
    effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow);

    // Add it to the panel
    panel.contentView().addSubview(effectView);
  }
  var closeButton = panel.standardWindowButton(NSWindowCloseButton);
  closeButton.setCOSJSTargetFunction(function (sender) {
    // log(sender);

    panel.close();

    // Remove the reference to the panel
    threadDictionary.removeObjectForKey(options.identifier);

    // Stop this Long-running script
    COScript.currentCOScript().setShouldKeepAround(false);
  });
  return panel;
};

/**
 * createView 创建 NSView
 * @param {*} frame  NSMakeRect(0, 0, 40, 40)
 */
var createView = function createView(frame) {
  var view = NSView.alloc().initWithFrame(frame);
  view.setFlipped(1);
  return view;
};

/**
 * createBox 创建 NSBox
 * @param {*} frame  NSMakeRect(0, 0, 40, 40)
 */
var createBox = function createBox(frame) {
  var box = NSBox.alloc().initWithFrame(frame);
  box.setTitle('');
  return box;
};

/**
 * createBox 创建 createTextField
 * @param {*} string
 * @param {*} frame NSMakeRect(0, 0, 40, 40)
 */
var createTextField = function createTextField(string, frame) {
  var field = NSTextField.alloc().initWithFrame(frame);
  field.setStringValue(string);
  field.setFont(NSFont.systemFontOfSize(12));
  field.setTextColor(NSColor.colorWithCalibratedRed_green_blue_alpha(0, 0, 0, 0.7));
  field.setBezeled(0);
  field.setBackgroundColor(NSColor.windowBackgroundColor());
  field.setEditable(0);
  return field;
};
// EXTERNAL MODULE: external "sketch"
var external_sketch_ = __webpack_require__(6);
var external_sketch_default = /*#__PURE__*/__webpack_require__.n(external_sketch_);

// CONCATENATED MODULE: ./src/utils/selector.js



/**
 * getSketchSelected 获取当前选择的 document， page， selection
 */
var selector_getSketchSelected = function getSketchSelected() {
  var Document = external_sketch_default.a.Document;
  var document = Document.getSelectedDocument(); // 当前被选择的 document
  var page = document.selectedPage; // 当前被选择的 page
  var artboard = external_sketch_default.a.Artboard.fromNative(page._object.currentArtboard());
  var selection = document.selectedLayers; // 当前选择图层

  return {
    document: document,
    page: page,
    artboard: artboard,
    selection: selection
  };
};

/**
 * getSelected 获取当前 document、page、artboard、selection
 */
var selector_getSelected = function getSelected() {
  var document = state["f" /* context */].document; // 获取 sketch 当前 document
  var plugin = state["f" /* context */].plugin;
  var command = state["f" /* context */].command;
  var page = document.currentPage(); // 当前被选择的 page
  var artboards = page.artboards(); // 所有的画板
  var selectedArtboard = page.currentArtboard(); // 当前被选择的画板
  var selection = state["f" /* context */].selection; // 当前选择图层

  return {
    document: document,
    plugin: plugin,
    command: command,
    page: page,
    artboards: artboards,
    selectedArtboard: selectedArtboard,
    selection: selection
  };
};

/**
 * 获取当前脚本执行路径
 * @param {*} context
 */
var getScriptExecPath = function getScriptExecPath(_context) {
  return _context.scriptPath;
};

/**
 * document 获取所选择 document objectID
 */
var selector_getDocumentID = function getDocumentID() {
  return state["f" /* context */].document.documentData().objectID();
};

/**
 * getDocumentPath 获取所选择 document 路径
 */
var selector_getDocumentPath = function getDocumentPath() {
  var Document = state["f" /* context */].document;
  return Document.fileURL() ? Document.fileURL().path() : nil;
};

/**
 * getDocumentName 获取所选择 document name
 */
var selector_getDocumentName = function getDocumentName() {
  return selector_getDocumentPath(state["f" /* context */]) ? selector_getDocumentPath(state["f" /* context */]).lastPathComponent() : nil;
};

/**
 * dumpLayer 导出json数据
 * @param {*} sketchObject  如 context.document.currentPage()
 */
var dumpLayer = function dumpLayer(sketchObject) {
  // return NSDictionary
  var jsonData = sketchObject.treeAsDictionary();
  var nsData = NSJSONSerialization.dataWithJSONObject_options_error_(jsonData, 0, nil);
  return NSString.alloc().initWithData_encoding_(nsData, 4);
};

/**
 * dumpSymbol 导出json数据
 * @param {*} symbolInstance // context.selection[0]
 */
var dumpSymbol = function dumpSymbol(symbolInstance) {
  // return symbolInstance
  var immutableInstance = symbolInstance.immutableModelObject();
  return MSJSONDataArchiver.archiveStringWithRootObject_error(immutableInstance, nil);
};
// EXTERNAL MODULE: ./src/utils/system.js
var system = __webpack_require__(20);

// CONCATENATED MODULE: ./src/utils/file.js
/**
 * File 文件操作
 * NSString.stringWithFormat('%@', content)
 */

var File = {
  fileManager: NSFileManager.defaultManager(),
  _stringify: function _stringify(jsonData, opt) {
    opt = opt ? 1 : 0;
    var nsJson = NSJSONSerialization.dataWithJSONObject_options_error_(jsonData, opt, nil);
    return NSString.alloc().initWithData_encoding(nsJson, 4);
  },
  writeFile: function writeFile(content, path) {
    content = NSString.stringWithFormat('%@', content);
    path = NSString.stringWithFormat('%@', path);
    return content.writeToFile_atomically_encoding_error_(path, !0, 4, nil);
  },
  copyFile: function copyFile(path, dist) {
    return this.fileManager.fileExistsAtPath(path) ? this.fileManager.copyItemAtPath_toPath_error(path, dist, nil) : nil;
  },
  mkDir: function mkDir(path) {
    return !this.fileManager.fileExistsAtPath(path) && this.fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error_(path, !0, nil, nil);
  },
  readJSON: function readJSON(path, opt) {
    var src = NSData.dataWithContentsOfFile(path);
    var options = !0 === opt ? 1 : 0;
    return NSJSONSerialization.JSONObjectWithData_options_error(src, options, nil);
  },
  size: function size(patch) {
    var size = 0;
    try {
      size = this.fileManager.attributesOfItemAtPath_error(patch, nil).NSFileSize;
    } catch (e) {
      size = 0;
    }
    return size;
  },
  renameFile: function renameFile(from, to) {
    this.fileManager.fileExistsAtPath(from) && this.fileManager.moveItemAtPath_toPath_error(from, to, null);
  },
  exist: function exist(path) {
    return !!this.fileManager.fileExistsAtPath(path);
  },
  readDir: function readDir(path) {
    return !!this.fileManager.fileExistsAtPath(path) && this.fileManager.contentsOfDirectoryAtPath_error_(path, nil);
  },
  removeDir: function removeDir(path) {
    this.fileManager.removeItemAtPath_error(path, null);
  },
  getTempDirPath: function getTempDirPath() {
    var URL = this.fileManager.URLsForDirectory_inDomains(13, 1).lastObject();
    var hash = Date.now() / 1e3;
    var nsString = NSString.stringWithFormat('%@', hash);
    return URL.URLByAppendingPathComponent(nsString).path();
  },
  mkTempDir: function mkTempDir(path) {
    var URL = this.getTempDirPath(path);
    return this.mkDir(URL) || URL;
  },
  /**
  * @param {String} image
  * @param {MSImageData} image
  */
  saveImage: function saveImage(path, image) {
    var tiffData = image.TIFFRepresentation();
    var p = NSBitmapImageRep.imageRepWithData(tiffData);
    var data = p.representationUsingType_properties(NSPNGFileType, null);
    data.writeToFile_atomically(path, !0);
  },
  jsonFilePaths: function jsonFilePaths(path) {
    var filename;
    var ds = this.fileManager.enumeratorAtPath(path);
    var paths = [];

    // eslint-disable-next-line no-cond-assign
    while (filename = ds.nextObject()) {
      if (filename.pathExtension() == 'json') {
        paths.push(filename);
      }
    }
    return paths;
  }
};
// CONCATENATED MODULE: ./src/utils/index.js





/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transSketchColor = exports.precisionControl = exports.getEnabledFill = exports.calculateRGB = exports.isAlignCenter = void 0;
/**
 * @description 两个图层进行比较，判断图层layerB是否在layerA中间的位置
 * @param {Layer} layerA
 * @param {Layer} layerB
 * @returns {boolean}
 */
exports.isAlignCenter = (layerA, layerB) => {
    return Math.abs((layerA.frame.x + layerA.frame.width / 2) - (layerB.frame.x + layerB.frame.width / 2)) <= 5;
};
/**
 * @description 颜色值转换
 * @param {number} color 颜色
 * @returns {number}
 */
exports.calculateRGB = (color) => {
    return Math.round(color * 255);
};
// 判断是否包含可用的 fill
exports.getEnabledFill = (layer) => {
    var _a;
    if ((_a = layer.style) === null || _a === void 0 ? void 0 : _a.fills) {
        return layer.style.fills.filter((item) => item.isEnabled).pop();
    }
    return undefined;
};
/**
 * 精度控制
 * @param data 需要处理的数据
 * @param num 精度 eg. 0.1 0.01
 */
exports.precisionControl = (data, num = 1) => {
    const len = Math.round(1 / num).toString().length - 1;
    return +((Math.round(data / num) * num).toFixed(len));
};
/**
 * @description 转换sketch中的color => rgba值
 * @param {*} { red, green, blue, alpha }
 */
exports.transSketchColor = ({ red, green, blue, alpha }) => ({
    red: exports.calculateRGB(red),
    green: exports.calculateRGB(green),
    blue: exports.calculateRGB(blue),
    alpha: exports.precisionControl(alpha, 0.01),
});


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(76);

var iterableToArray = __webpack_require__(77);

var unsupportedIterableToArray = __webpack_require__(36);

var nonIterableSpread = __webpack_require__(78);

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 13 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return BrowserManage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return closeBrowser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Browser; });
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(21);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(22);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(59);
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(0);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3);






var BrowserManage = {
  list: [],
  add: function add(browser) {
    this.list.push(browser);
  },
  get: function get(identifier) {
    return this.list.find(function (d) {
      return d.identifier === identifier;
    });
  },
  getCurrent: function getCurrent() {
    return this.list.find(function (d) {
      return d.browserWindow.isVisible();
    });
  },
  empty: function empty() {
    this.list = [];
  }
};
var closeBrowser = function closeBrowser(identifier) {
  var targets = BrowserManage.list.filter(function (d) {
    return d.identifier !== _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"] && (!identifier || d.identifier === identifier);
  });
  var list = targets.length > 0 ? targets : BrowserManage.list.filter(function (d) {
    return d.identifier !== _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"];
  });
  list.forEach(function (d) {
    if (d.browserWindow) {
      d.hide();
    }
  });
};
var getAbsScreenOfTop = function getAbsScreenOfTop() {
  var contentView = _state__WEBPACK_IMPORTED_MODULE_4__[/* document */ "h"].documentWindow().contentView();
  var width = contentView.frame().size.width;
  var height = contentView.frame().size.height;
  var x = contentView.frame().origin.x;
  var y = contentView.frame().origin.y;
  var rect = _state__WEBPACK_IMPORTED_MODULE_4__[/* document */ "h"].window().convertRectToScreen(NSMakeRect(x, y, width, height));
  return rect;
};
var Browser = /*#__PURE__*/function () {
  function Browser(options, flag) {
    var _this = this;
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, Browser);
    this.options = Object.assign({
      width: 290,
      height: 550,
      minimizable: false,
      maximizable: false,
      resizable: false,
      transparent: false,
      closable: true,
      center: false,
      alwaysOnTop: true,
      // backgroundColor: '#212121',
      // titleBarStyle: 'hiddenInset',
      // titleBarStyle: 'hidden',
      movable: true,
      // frame: false,
      show: false,
      index: 0,
      isPopover: false
    }, options);
    this.identifier = options.identifier;
    BrowserManage.list.forEach(function (d) {
      if (d.identifier != _this.identifier && d.identifier !== _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]) {
        if (d.browserWindow.isVisible()) {
          d.hide();
        }
      }
    });
    var existBrowser = BrowserManage.get(options.identifier);
    if (existBrowser) {
      if (existBrowser.browserWindow.isVisible()) {
        existBrowser.hide();
      } else {
        existBrowser.show();
      }
      return existBrowser;
    }
    this.browserWindow = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_3___default.a(flag ? options : this.options);
    this.browserWindow.on('closed', function () {
      _this.closed();
    });
    options.url && this.browserWindow.loadURL(options.url);
    BrowserManage.add(this);
    this.show();
  }
  return _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default()(Browser, [{
    key: "show",
    value: function show() {
      var _this2 = this;
      // 网络处于连接状态
      Object(_util__WEBPACK_IMPORTED_MODULE_5__[/* connectedNetwork */ "b"])(function () {
        _this2.updatePosition();
        var documentWindow = _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"].document.documentWindow();
        documentWindow.addChildWindow_ordered(_this2.browserWindow._panel, true);
        _this2.browserWindow.show();
        _this2.browserWindow.webContents.executeJavaScript('reloadBusinessInTheWebview()').then(function () {});
      });
    }
  }, {
    key: "hide",
    value: function hide() {
      var panel = this.browserWindow ? this.browserWindow._panel : null;
      var documentWindow = _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"] && _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"].document && _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"].document.documentWindow ? _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"].document.documentWindow() : null;
      if (documentWindow && panel) {
        documentWindow.removeChildWindow(panel);
      }
      if (panel && panel.orderOut) {
        panel.orderOut(null);
      }
      this.browserWindow.hide();
    }
  }, {
    key: "closed",
    value: function closed() {
      // 关闭功能弹窗
      this.browserWindow.webContents.executeJavaScript("closeWebView(\"".concat(this.identifier, "\")")).then(function () {});
      // 关闭时，向侧边栏发送通知
      var sidebar = BrowserManage.get(_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]);
      sidebar && sidebar.browserWindow.webContents.executeJavaScript("webviewHasClosed(\"".concat(this.identifier, "\")")).then(function () {});
    }
  }, {
    key: "updatePosition",
    value: function updatePosition() {
      var _this$options = this.options,
        inGravityType = _this$options.inGravityType,
        isDialog = _this$options.isDialog;
      // const _sender = optionSender || sender;
      var _this$browserWindow$g = this.browserWindow.getSize(),
        _this$browserWindow$g2 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_this$browserWindow$g, 2),
        width = _this$browserWindow$g2[0],
        height = _this$browserWindow$g2[1];
      var winRect = getAbsScreenOfTop();
      // 整个sketch窗口中间的位置
      var middle = {
        x: (winRect.size.width - width) / 2 + winRect.origin.x,
        y: (winRect.size.height - height) / 2 + winRect.origin.y
      };
      if (isDialog) {
        var _x = middle.x;
        var _y = middle.y;
        this.browserWindow._panel.setFrame_display(NSMakeRect(_x, _y, width, height), true);
        return;
      }

      // 侧边栏的位置
      if (inGravityType === 6) {
        // x轴是左侧，y轴是底部为基点
        // 假设右边侧栏的宽度，后续调整位置调整这里
        var rightSpace = 240 + 10;
        var topSpace = 150;
        var _x2 = winRect.origin.x + winRect.size.width - width - rightSpace;
        var _y2 = winRect.origin.y + topSpace;

        //   console.log("winRect", winRect);
        this.browserWindow._panel.setFrame_display(NSMakeRect(_x2, _y2, width, height), true);
        return;
      }

      // 贴着侧边栏展示的webview
      if (inGravityType === 7) {
        var sideBarRect = BrowserManage.get(_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]).browserWindow.getBounds();
        var sideBarCenterX = sideBarRect.x + _state__WEBPACK_IMPORTED_MODULE_4__[/* sieBarConfig */ "l"].width / 2;
        var y = winRect.origin.y;
        var _x3;
        if (sideBarCenterX > middle.x) {
          _x3 = sideBarRect.x - width;
        } else {
          _x3 = sideBarRect.x + _state__WEBPACK_IMPORTED_MODULE_4__[/* sieBarConfig */ "l"].width;
        }
        this.browserWindow._panel.setFrame_display(NSMakeRect(_x3, y, width, height), true);
      }
    }
  }]);
}();

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(30).Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var exception;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          exception
        );
        if (exception != null) {
          var error = new TypeError(
            String(
              typeof exception.localizedDescription === "function"
                ? exception.localizedDescription()
                : exception
            )
          );
          reject(error);
          return;
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
          break;
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
          break;
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, exception) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          finished = true;
          try {
            if (exception) {
              var error = new TypeError(
                String(
                  typeof exception.localizedDescription === "function"
                    ? exception.localizedDescription()
                    : exception
                )
              );
              reject(error);
              return;
            }
            resolve(response(res, data));
          } catch (err) {
            reject(err);
          }
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 15 */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithHoles = __webpack_require__(64);

var iterableToArrayLimit = __webpack_require__(65);

var unsupportedIterableToArray = __webpack_require__(36);

var nonIterableRest = __webpack_require__(66);

function _slicedToArray(arr, i) {
  return arrayWithHoles(arr) || iterableToArrayLimit(arr, i) || unsupportedIterableToArray(arr, i) || nonIterableRest();
}

module.exports = _slicedToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 17 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export openUploadPageCurrent */
/* unused harmony export openUploadPageAll */
/* unused harmony export loginCheck */
/* unused harmony export webviewHandler */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return updateStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return cleanUploadWebview; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return storageOperation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return clearOperation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return readOperation; });
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_skpm_path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _portal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3);
/* harmony import */ var _utils_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(20);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(0);
/* harmony import */ var _webview__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(13);
/* harmony import */ var _stickers_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24);
/* harmony import */ var _upload_webview_function__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(27);
/* harmony import */ var _sidePanel__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(18);











var uploadType = null;
var uploadWebview = null;
var isHere = false;
var openUploadPage = function openUploadPage(_context) {
  _state__WEBPACK_IMPORTED_MODULE_5__[/* Menus */ "b"].forEach(function (item, index) {
    if (item.activeIcon != 'upload-active') {
      return;
    }
    var _item$rect = item.rect,
      rect = _item$rect === void 0 ? NSMakeRect(0, 0, 40, 40) : _item$rect,
      _item$size = item.size,
      size = _item$size === void 0 ? NSMakeSize(24, 24) : _item$size,
      icon = item.icon,
      activeIcon = item.activeIcon,
      tooltip = item.tooltip,
      identifier = item.identifier,
      wkIdentifier = item.wkIdentifier,
      _item$type = item.type,
      type = _item$type === void 0 ? 2 : _item$type,
      _item$inGravityType = item.inGravityType,
      inGravityType = _item$inGravityType === void 0 ? 1 : _item$inGravityType,
      url = item.url,
      width = item.width,
      height = item.height,
      isTop = item.isTop,
      toClose = item.toClose,
      toOpenUrl = item.toOpenUrl,
      isDialog = item.isDialog,
      permissions = item.permissions,
      isPopover = item.isPopover,
      title = item.title;
    // if(toClose){
    //   handlerClosePanel();
    //   return;
    // }
    if (permissions && (role === '' || !~permissions.indexOf(+role))) {
      return;
    }
    // const menuBtnRegExp = new RegExp(`${IdentifierPrefix}-menu*`);
    // const threadDictionary = NSThread.mainThread().threadDictionary();
    // for (const k in threadDictionary) {
    //   if (menuBtnRegExp.test(k) && k !== identifier) {
    //     threadDictionary[k].setState(NSOffState);
    //   }
    // }
    // const sender ='';
    var options = {
      // sender,
      identifier: wkIdentifier,
      // frame: false,
      show: false,
      width: width,
      height: height,
      inGravityType: inGravityType,
      url: url,
      index: index,
      isDialog: isDialog,
      isPopover: isPopover,
      title: title
    };
    var browser = new _webview__WEBPACK_IMPORTED_MODULE_6__[/* Browser */ "a"](options);
    var browserWindow = browser.browserWindow;
    var stickerUI = new _stickers_ui__WEBPACK_IMPORTED_MODULE_7__[/* StickersUI */ "a"](_context);
    stickerUI.setupWebAPI(browserWindow);
    var webView = browserWindow.webContents;
    if (identifier.indexOf('menu.upload')) {
      uploadWebview = webView;
      Object(_upload_webview_function__WEBPACK_IMPORTED_MODULE_8__[/* setListener */ "a"])(webView, browser, _context);
    }
  });
};
var openUploadPageCurrent = function openUploadPageCurrent(_context) {
  isHere = true;
  // panel没有打开先判断登录态
  Object(_state__WEBPACK_IMPORTED_MODULE_5__[/* default */ "g"])(_context);
  uploadType = 1;
  // 关闭侧栏
  // handlerClosePanel();
  loginCheck(_context);
};
var openUploadPageAll = function openUploadPageAll(_context) {
  isHere = true;
  Object(_state__WEBPACK_IMPORTED_MODULE_5__[/* default */ "g"])(_context);
  uploadType = 2;
  // 关闭侧栏
  // handlerClosePanel();
  // panel没有打开先判断登录态
  loginCheck(_context);
};
var loginCheck = function loginCheck(_context) {
  if (!Object(_portal__WEBPACK_IMPORTED_MODULE_2__[/* isLogin */ "c"])(_context)) {
    Object(_util__WEBPACK_IMPORTED_MODULE_3__[/* connectedNetwork */ "b"])(function () {
      Object(_portal__WEBPACK_IMPORTED_MODULE_2__[/* onLogin */ "d"])(_context);
    }, function () {
      webviewHandler(_context);
    });
    return;
  }
  webviewHandler(_context);
};
var webviewHandler = function webviewHandler(_context) {
  openUploadPage(_context);
  setUploadType(uploadType);
};
var updateStatus = function updateStatus() {
  if (isHere) {
    cleanUploadWebview();
  }
};
var cleanUploadWebview = function cleanUploadWebview() {
  var uploadWebViewPrefixRegExp = new RegExp("".concat(_state__WEBPACK_IMPORTED_MODULE_5__[/* IdentifierPrefix */ "a"], "-webview.upload*"));
  var threadDictionary = NSThread.mainThread().threadDictionary();
  for (var key in threadDictionary) {
    if (uploadWebViewPrefixRegExp.test(key)) {
      threadDictionary[key] && threadDictionary[key].close && threadDictionary[key].close();
      threadDictionary.removeObjectForKey(key);
    }
  }
};
var setUploadType = function setUploadType(type) {
  uploadWebview.executeJavaScript("onChangeUploadType(".concat(+type, ")"));
};
function storageOperation(payload) {
  var targetPath = getPluginFolderPath();
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(targetPath, "/.uploadOperation"), payload, {
    encoding: 'utf8'
  });
}
function clearOperation(baseUrl) {
  var targetPath = baseUrl || getPluginFolderPath();
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(targetPath, "/.uploadOperation"), '0', {
    encoding: 'utf8'
  });
}
function readOperation() {
  var targetPath = getPluginFolderPath();
  try {
    var data = _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.readFileSync("".concat(targetPath, "/.uploadOperation"), {
      encoding: 'utf8'
    });
    return !data || data === "0" ? null : data;
  } catch (e) {
    return null;
  }
}
function getPluginFolderPath(context) {
  // 创建存储插件数据的文件夹
  var pluginDataPath = _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.join(_state__WEBPACK_IMPORTED_MODULE_5__[/* pluginFolderPath */ "k"], '../../hotwheels_data');
  return pluginDataPath;
}

/***/ }),
/* 18 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "abilityNext", function() { return abilityNext; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onToggleSidePanel", function() { return onToggleSidePanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "handlerClosePanel", function() { return handlerClosePanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCompData", function() { return getCompData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onOpenDocument", function() { return onOpenDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCloseDocument", function() { return onCloseDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "closeBrowerAfter", function() { return closeBrowerAfter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "openOfficialWebsite", function() { return openOfficialWebsite; });
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14);
/* harmony import */ var sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(0);
/* harmony import */ var _webview_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13);
/* harmony import */ var _popover_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(10);
/* harmony import */ var _stickers_ui__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(24);
/* harmony import */ var _portal__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3);
/* harmony import */ var _upload_webview_function__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27);
/* harmony import */ var _utils_system__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(20);
/* harmony import */ var _openUpload__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(17);
/* harmony import */ var _logs__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(28);









/* eslint-disable */


/* eslint-disable */




var lastHandleObj = {};
var hasHighlight = false;
var newAbilitysPopover = null;

// NSPanel.contentView
/**
 * insertSidePanel 插入侧边栏
 * @param {*} toolbar
 * @param {*} identifier
 * @param {*} isInsert  默认插入，已插入删除
 */
var insertSidePanel = function insertSidePanel(_context, toolbar, identifier, _sketchVersion) {
  var isInsert = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : false;
  var context_copy = _context || _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"];
  var sketchVersion_copy = _sketchVersion || _state__WEBPACK_IMPORTED_MODULE_4__[/* sketchVersion */ "m"];
  var pushedWebView = false;
  if (sketchVersion_copy < 70) {
    var contentView = context_copy.document.documentWindow().contentView();
    var stageView = contentView.subviews().objectAtIndex(0);
    var views = stageView.subviews();
    var existId = isInsert || views.find(function (d) {
      return ''.concat(d.identifier()) === identifier;
    });
    var finalViews = [];
    for (var i = 0; i < views.count(); i++) {
      var view = views[i];
      if (existId) {
        if (''.concat(view.identifier()) !== identifier) finalViews.push(view);
      } else {
        finalViews.push(view);
        if (!pushedWebView && ''.concat(view.identifier()) === 'view_canvas') {
          finalViews.push(toolbar);
          pushedWebView = true;
        }
      }
    }
    stageView.subviews = finalViews;
    stageView.adjustSubviews();
  } else {
    var splitItems = context_copy.document.splitViewController().splitViewItems();
    var hasShow = false;
    var isVersion72 = false;
    if (sketchVersion_copy >= 72) {
      var threadDictionary = NSThread.mainThread().threadDictionary();
      var panalHash = threadDictionary[identifier + 'hash'];
      splitItems.forEach(function (item, index) {
        if (+item.hash() === +panalHash) {
          hasShow = true;
          context_copy.document.splitViewController().removeSplitViewItem(item);
        }
      });
    } else {
      splitItems.forEach(function (item, index) {
        if (item.identifier === identifier) {
          hasShow = true;
          context_copy.document.splitViewController().removeSplitViewItem(item);
        }
      });
    }
    if (!hasShow) {
      pushedWebView = true;
      var viewController = NSViewController.alloc().init();
      viewController.view = toolbar;
      var splitViewItem = NSSplitViewItem.splitViewItemWithViewController(viewController);
      splitViewItem.identifier = identifier;
      context_copy.document.splitViewController().insertSplitViewItem_atIndex(splitViewItem, 2);
      if (sketchVersion_copy >= 72) {
        var _threadDictionary = NSThread.mainThread().threadDictionary();
        _threadDictionary[identifier + 'hash'] = splitViewItem.hash();
      }
    }
  }
  if (pushedWebView) {
    Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* setSettingForKey */ "j"])(_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"], 'true');
  } else {
    Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* removeSettingForKey */ "h"])(_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]);
  }
};
var initPanelView = function initPanelView(_context, threadDictionary, role) {
  var toolbar = NSStackView.alloc().initWithFrame(NSMakeRect(0, 0, 50, 400));
  threadDictionary[_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]] = toolbar;
  var contextThreadId = _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"] + '-context';
  threadDictionary[contextThreadId] = _context;
  toolbar.hotwheelsTag = 'hotwheels_panel';
  toolbar.identifier = _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"];
  toolbar.setSpacing(18);
  toolbar.setFlipped(true);
  toolbar.setBackgroundColor(NSColor.colorWithHex('#1D2C3E'));
  if (_state__WEBPACK_IMPORTED_MODULE_4__[/* sketchVersion */ "m"] >= 70) {
    try {
      var window = _state__WEBPACK_IMPORTED_MODULE_4__[/* context */ "f"].document.documentWindow();
      var contentRect = window.contentRectForFrameRect(window.frame());
      var layoutRect = window.contentLayoutRect();
      var toolbarHeight = NSHeight(contentRect) - NSHeight(layoutRect);
      toolbar.translatesAutoResizingMaskIntoConstraints = false;
      toolbar.widthAnchor().constraintEqualToConstant(50).setActive(true);
      toolbar.edgeInsets = NSEdgeInsetsMake(toolbarHeight, 0, 10, 0);
    } catch (error) {
      _logs__WEBPACK_IMPORTED_MODULE_14__[/* logger */ "a"].error(error, 'toolbar');
    }
  }
  toolbar.orientation = 1;
  var contentTop = NSStackView.alloc().initWithFrame(NSMakeRect(0, 0, 50, 100));
  contentTop.orientation = 1;
  contentTop.setSpacing(18);
  var contentBottom = NSStackView.alloc().initWithFrame(NSMakeRect(0, 0, 50, 100));
  contentBottom.orientation = 1;
  contentBottom.setSpacing(8);
  var img = Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* createImageView */ "b"])(NSMakeRect(0, 0, 40, 40), 'logo', NSMakeSize(50, 60));
  toolbar.addView_inGravity(img, 1);
  _state__WEBPACK_IMPORTED_MODULE_4__[/* Menus */ "b"].map(function (item, index) {
    var _item$rect = item.rect,
      rect = _item$rect === void 0 ? NSMakeRect(0, 0, 40, 40) : _item$rect,
      _item$size = item.size,
      size = _item$size === void 0 ? NSMakeSize(24, 24) : _item$size,
      icon = item.icon,
      activeIcon = item.activeIcon,
      tooltip = item.tooltip,
      identifier = item.identifier,
      wkIdentifier = item.wkIdentifier,
      _item$type = item.type,
      type = _item$type === void 0 ? 2 : _item$type,
      _item$inGravityType = item.inGravityType,
      inGravityType = _item$inGravityType === void 0 ? 1 : _item$inGravityType,
      url = item.url,
      width = item.width,
      height = item.height,
      isTop = item.isTop,
      toClose = item.toClose,
      toOpenUrl = item.toOpenUrl,
      isDialog = item.isDialog,
      isPopover = item.isPopover,
      permissions = item.permissions;
    if (permissions && (role === '' || !~permissions.indexOf(+role))) {
      return;
    }
    var Button = Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* addButton */ "a"])({
      rect: rect,
      size: size,
      icon: icon,
      activeIcon: activeIcon,
      tooltip: tooltip,
      identifier: identifier,
      type: type,
      callAction: function callAction(sender) {
        console.log('%csender : ', 'color:#53DCFB', sender);
        if (toClose) {
          handlerClosePanel();
          return;
        }
        if (toOpenUrl) {
          Object(_utils_system__WEBPACK_IMPORTED_MODULE_12__[/* penUrlInBrowser */ "c"])(url);
          return;
        }
        var menuBtnRegExp = new RegExp("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* IdentifierPrefix */ "a"], "-menu*"));
        for (var k in threadDictionary) {
          if (menuBtnRegExp.test(k) && k !== identifier) {
            threadDictionary[k].setState(NSOffState);
          }
        }
        var options = {
          sender: sender,
          identifier: wkIdentifier,
          frame: false,
          show: false,
          width: width,
          height: height,
          inGravityType: inGravityType,
          url: url,
          index: index,
          isDialog: isDialog,
          isPopover: isPopover
        };

        // 非连续操作同一个button
        if (lastHandleObj.sender !== sender) {
          Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* setHighlight */ "i"])(sender, '#FF552E', activeIcon, size);
          // 初始化上一次高亮的icon
          if (lastHandleObj.sender) {
            Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* setHighlight */ "i"])(lastHandleObj.sender, '#FFFFFF', lastHandleObj.icon, lastHandleObj.size);
          }
          hasHighlight = true;
        } else {
          // 连续操作同一个button
          if (hasHighlight) {
            Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* setHighlight */ "i"])(sender, '#FFFFFF', icon, size);
          } else {
            Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* setHighlight */ "i"])(sender, '#FF552E', activeIcon, size);
          }
          hasHighlight = !hasHighlight;
        }
        lastHandleObj = {
          sender: sender,
          icon: icon,
          activeIcon: activeIcon,
          size: size
        };
        var browser = new _webview_index__WEBPACK_IMPORTED_MODULE_5__[/* Browser */ "a"](options);
        var browserWindow = browser.browserWindow;
        var stickerUI = new _stickers_ui__WEBPACK_IMPORTED_MODULE_8__[/* StickersUI */ "a"](_context);
        stickerUI.setupWebAPI(browserWindow);
        var webView = browserWindow.webContents;
        webView.on('nativeLog', function (s) {
          // console.error('s', s);
        });
        webView.on('did-start-loading', function () {
          // console.error('did-start-loading')
        });
        webView.on('did-finish-load', function () {
          // console.error('did-finish-load')
        });
        webView.on('openView', function (_options) {
          // console.error('openViewopenView');
          // console.error(_options);
        });
        if (identifier.indexOf('menu.upload')) {
          Object(_upload_webview_function__WEBPACK_IMPORTED_MODULE_11__[/* setListener */ "a"])(webView, browser, _context);
        }
      }
    });
    threadDictionary[identifier] = Button;
    toolbar.addView_inGravity(Button, inGravityType);
    // if (isTop) {
    //     contentTop.addView_inGravity(Button, inGravityType);
    // } else {
    //     contentBottom.addView_inGravity(Button, inGravityType);
    // }
  });

  // toolbar.addView_inGravity(contentTop, 1);
  // toolbar.addView_inGravity(contentBottom, 3);

  insertSidePanel(null, toolbar, _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"], null);

  //
  // initAbilitysTooltip(_context)
  getReadingAbilitys(_context);
};
function initAbilitysTooltip(_context, newAbilitysList) {
  if (newAbilitysList) {
    newAbilitysPopover = new _popover_index__WEBPACK_IMPORTED_MODULE_6__[/* Popover */ "a"](_context, newAbilitysList);
  }
}
function getReadingAbilitys(_context) {
  var userId = Object(_portal__WEBPACK_IMPORTED_MODULE_9__[/* getUserId */ "b"])(_context);
  sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_1___default()("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* host */ "i"], "/api/notice/getReading?id=").concat(userId)).then(function (res) {
    return res.json();
  }).then(function (json) {
    var data = json.data;
    if (!data) {
      data = {
        abilitys: ''
      };
    }
    var newAbilitysList = data.abilitys.split(',');
    initAbilitysTooltip(_context, newAbilitysList);
  });
}
var abilityNext = function abilityNext() {
  newAbilitysPopover.abilityNext();
};
var onToggleSidePanel = function onToggleSidePanel(_context) {
  // register context
  Object(_state__WEBPACK_IMPORTED_MODULE_4__[/* default */ "g"])(_context);
  Object(_openUpload__WEBPACK_IMPORTED_MODULE_13__[/* cleanUploadWebview */ "a"])();
  var threadDictionary = NSThread.mainThread().threadDictionary();
  if (threadDictionary[_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]]) {
    insertSidePanel(null, threadDictionary[_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]], _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"], null, true);
    onShutdown();
    return;
  }

  // panel没有打开先判断登录态
  if (!Object(_portal__WEBPACK_IMPORTED_MODULE_9__[/* isLogin */ "c"])(_context)) {
    Object(_util__WEBPACK_IMPORTED_MODULE_10__[/* connectedNetwork */ "b"])(function () {
      Object(_portal__WEBPACK_IMPORTED_MODULE_9__[/* onLogin */ "d"])(_context);
    });
    return;
  }
  var userId = Object(_portal__WEBPACK_IMPORTED_MODULE_9__[/* getUserId */ "b"])(_context);

  // Long-running script
  COScript.currentCOScript().setShouldKeepAround(true);
  Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* observerWindowResizeNotification */ "e"])(function () {
    var curWebView = _webview_index__WEBPACK_IMPORTED_MODULE_5__[/* BrowserManage */ "b"].getCurrent();
    if (curWebView) {
      curWebView.updatePosition();
    }
  });
  Object(_util__WEBPACK_IMPORTED_MODULE_10__[/* getUserRole */ "e"])(userId, function (role) {
    initPanelView(_context, threadDictionary, role);
  });
  // const userId = getUserId(_context)
};
var handlerClosePanel = function handlerClosePanel() {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  if (threadDictionary[_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]]) {
    insertSidePanel(null, threadDictionary[_state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"]], _state__WEBPACK_IMPORTED_MODULE_4__[/* SidePanelIdentifier */ "c"], null, true);
    onShutdown();
    return;
  }
};
var oldViewDetection = function oldViewDetection(_document, callback) {
  var appVersion = 70;
  try {
    appVersion = MSApplicationMetadata.metadata().appVersion;
  } catch (error) {
    appVersion = BCSketchInfo.shared().metadata().appVersion;
  }
  try {
    var hasOldPanal = false;
    //暂时屏蔽70版本
    if (appVersion < 70) {
      var contentView = _document.documentWindow().contentView();
      var stageView = contentView.subviews().objectAtIndex(0);
      var views = stageView.subviews();
      views.find(function (item) {
        if (item.hotwheelsTag === 'hotwheels_panel') {
          hasOldPanal = true;
        }
      });
    } else {
      var splitItems = _document.splitViewController().splitViewItems();
      splitItems.forEach(function (item, index) {
        if (item.viewController().view().hotwheelsTag === 'hotwheels_panel') {
          hasOldPanal = true;
        }
      });
    }
    if (!hasOldPanal) {
      callback && callback();
    }
  } catch (error) {
    // console.log('222', error);
  }
};
function storageComData(context, data) {
  var pluginFolderPath = Object(_portal__WEBPACK_IMPORTED_MODULE_9__[/* getPluginFolderPath */ "a"])(context);
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.writeFileSync("".concat(pluginFolderPath, "/.comData"), JSON.stringify(data), {
    encoding: 'utf8'
  });
}
var getCompData = function getCompData(payload) {
  return new Promise(function (resolve, reject) {
    sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('正在更新组件，请稍后....');
    try {
      sketch_polyfill_fetch__WEBPACK_IMPORTED_MODULE_1___default()("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* host */ "i"], "/api/code_component/search"), {
        method: 'GET'
      }).then(function (response) {
        return response.json();
      }).then(function (resultObj) {
        var comData = resultObj.data ? resultObj.data : {};
        storageComData(payload, comData);

        // toast
        sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('组件更新成功！');
        resolve();
      }).catch(function (err) {
        sketch_ui__WEBPACK_IMPORTED_MODULE_3___default.a.message('组件更新成功！');
        reject(err);
      });
    } catch (error) {
      reject(error);
    }
  }).catch(function (err) {
    console.log('getCompData error:', err);
    throw err;
  });
};
var onOpenDocument = function onOpenDocument(payload) {
  try {
    // 需要拿 sketch 原生视图，不做延时拿不到
    setTimeout(function () {
      oldViewDetection(payload.actionContext.document, function () {
        payload.document = payload.actionContext.document;
        payload.selection = payload.actionContext.selection;
        onToggleSidePanel(payload);
      });
      getCompData(payload);
    }, 2000);
  } catch (error) {}
};
var onCloseDocument = function onCloseDocument(_context) {
  Object(_state__WEBPACK_IMPORTED_MODULE_4__[/* default */ "g"])(_context);
  onShutdown();
};

// handler cleanly Long-running script
function onShutdown(content, cleanAll) {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var prefixRegExp = new RegExp("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* IdentifierPrefix */ "a"], "*"));
  var webViewPrefixRegExp = new RegExp("".concat(_state__WEBPACK_IMPORTED_MODULE_4__[/* IdentifierPrefix */ "a"], "-webview*"));
  var aLlPrefixRegExp = /^hotwheels-[0-9a-zA-Z\u4e00-\u9fa5-]+-side-panel$/;
  var removeKeepAround = true;
  if (content || cleanAll) {
    var _sketchVersion = null;
    try {
      _sketchVersion = MSApplicationMetadata.metadata().appVersion;
    } catch (err) {
      _sketchVersion = BCSketchInfo.shared().metadata().appVersion;
    }
    var panelPrefixList = [];
    for (var key in threadDictionary) {
      if (aLlPrefixRegExp.test(key)) {
        panelPrefixList.push(key);
      }
    }
    panelPrefixList.forEach(function (panelPrefix) {
      var prefix = panelPrefix.replace('-side-panel', '');
      var _prefixRegExp = new RegExp("".concat(prefix, "*"));
      var _webViewPrefixRegExp = new RegExp("".concat(prefix, "-webview*"));
      var _context = threadDictionary["".concat(panelPrefix, "-context")];
      var panel = threadDictionary[panelPrefix];
      if (_context) {
        insertSidePanel(_context, panel, panelPrefix, _sketchVersion);
      }
      for (var _key in threadDictionary) {
        if (_prefixRegExp.test(_key)) {
          if (_webViewPrefixRegExp.test(_key)) {
            threadDictionary[_key] && threadDictionary[_key].close && threadDictionary[_key].close();
          }
          threadDictionary.removeObjectForKey(_key);
        }
      }
    });
    if (!cleanAll) {
      removeKeepAround = false;
    }
  } else {
    _webview_index__WEBPACK_IMPORTED_MODULE_5__[/* BrowserManage */ "b"].empty();

    // clear MSClass
    for (var _key2 in threadDictionary) {
      if (prefixRegExp.test(_key2)) {
        if (webViewPrefixRegExp.test(_key2)) {
          threadDictionary[_key2] && threadDictionary[_key2].close && threadDictionary[_key2].close();
        }
        threadDictionary.removeObjectForKey(_key2);
      } else if (aLlPrefixRegExp.test(_key2)) {
        removeKeepAround = false;
      }
    }
  }

  // clear WindowResizeNotification
  Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* removeObserverWindowResizeNotification */ "g"])();
  // if(removeKeepAround){
  // COScript.currentCOScript().setShouldKeepAround(false);
  // }
}
function closeBrowerAfter() {
  if (lastHandleObj && lastHandleObj.sender) {
    Object(_utils__WEBPACK_IMPORTED_MODULE_7__[/* setHighlight */ "i"])(lastHandleObj.sender, '#FFFFFF', lastHandleObj.icon, lastHandleObj.size);
    hasHighlight = false;
  }
}
function openOfficialWebsite() {
  Object(_utils_system__WEBPACK_IMPORTED_MODULE_12__[/* penUrlInBrowser */ "c"])('https://hotwheel.58.com');
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
// 类型导出
__exportStar(__webpack_require__(170), exports);
__exportStar(__webpack_require__(171), exports);
__exportStar(__webpack_require__(172), exports);
__exportStar(__webpack_require__(173), exports);
__exportStar(__webpack_require__(179), exports);
__exportStar(__webpack_require__(180), exports);
__exportStar(__webpack_require__(181), exports);
__exportStar(__webpack_require__(182), exports);


/***/ }),
/* 20 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return penUrlInBrowser; });
/* unused harmony export getNewUUID */
/* unused harmony export getThreadDictForKey */
/* unused harmony export setThreadDictForKey */
/* unused harmony export removeThreadDictForKey */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return getSettingForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return setSettingForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return removeSettingForKey; });
/* unused harmony export showPluginsPane */
/* unused harmony export showLibrariesPane */
/* unused harmony export getSystemVersion */
/* unused harmony export getPluginVersion */
/* unused harmony export reloadPlugins */
/* unused harmony export getFileContentFromModal */
/* unused harmony export getSavePathFromModal */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return observerWindowResizeNotification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return removeObserverWindowResizeNotification; });
/* harmony import */ var mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(35);
/* harmony import */ var mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(0);



/**
 * openUrlInBrowser 浏览器打开链接
 * @param {string} url
 */
var penUrlInBrowser = function penUrlInBrowser(url) {
  NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
};

/**
 * getNewUUID 获取唯一 ID
 */
var getNewUUID = function getNewUUID() {
  return NSUUID.UUID().UUIDString();
};

/**
 * getThreadDictForKey 获取挂载 mainThread 的键值
 * @param {string} key
 */
var getThreadDictForKey = function getThreadDictForKey(key) {
  return NSThread.mainThread().threadDictionary()[key];
};

/**
 * setThreadDictForKey 挂载到 mainThread 的键值
 * @param {string} key
 * @param {string} value
 */
var setThreadDictForKey = function setThreadDictForKey(key, value) {
  return NSThread.mainThread().threadDictionary()[key] = value;
};

/**
 * removeThreadDictForKey 移除挂载到 mainThread 的键值
 * @param { string } key
 */
var removeThreadDictForKey = function removeThreadDictForKey(key) {
  if (NSThread.mainThread().threadDictionary()[key]) NSThread.mainThread().threadDictionary().removeObjectForKey(key);
};

/**
 * getSettingForKey 获取挂载 NSUserDefaults 的键值
 * @param { string } key
 */
var getSettingForKey = function getSettingForKey(key) {
  return NSUserDefaults.standardUserDefaults().objectForKey(key);
};

/**
 * setSettingForKey 挂载到 NSUserDefaults 的键值
 * @param {string} key
 * @param {string} value
 */
var setSettingForKey = function setSettingForKey(key, value) {
  return NSUserDefaults.standardUserDefaults().setObject_forKey(value, key);
};

/**
 * removeSettingForKey 移除挂载到 NSUserDefaults 的键值
 * @param { string } key
 */
var removeSettingForKey = function removeSettingForKey(key) {
  setSettingForKey(key, nil);
};

/**
 * showPluginsPane 显示 plugin window
 */
var showPluginsPane = function showPluginsPane() {
  var identifier = MSPluginsPreferencePane.identifier();
  var preferencesController = MSPreferencesController.sharedController();
  preferencesController.switchToPaneWithIdentifier(identifier);
  preferencesController.currentPreferencePane().tableView().reloadData();
};

/**
 * showLibrariesPane 显示 libraries window
 */
var showLibrariesPane = function showLibrariesPane() {
  var identifier = MSAssetLibrariesPreferencePane.identifier();
  var preferencesController = MSPreferencesController.sharedController();
  preferencesController.switchToPaneWithIdentifier(identifier);
  preferencesController.currentPreferencePane().tableView().reloadData();
};

/**
 * getSystemVersion 获取系统版本
 */
var getSystemVersion = function getSystemVersion() {
  try {
    var systemVersion = NSProcessInfo.processInfo().operatingSystemVersionString().match(/\d*\.\d*(\.\d*)?/);
    if (systemVersion && systemVersion[0]) {
      var versions = systemVersion[0];
      return versions.split('.').length === 2 ? ''.concat(versions, '.0') : versions;
    }
    return '0.0.0';
  } catch (e) {
    return '0.0.0';
  }
};

/**
 * getPluginVersion 获取插件版本
 */
var getPluginVersion = function getPluginVersion() {
  return _state__WEBPACK_IMPORTED_MODULE_1__[/* context */ "f"].plugin.version();
};

/**
 * reloadPlugins 重载插件
 */
var reloadPlugins = function reloadPlugins() {
  AppController.sharedInstance().pluginManager().reloadPlugins();
};

/**
 * getFileContentFromModal 打开文件选择器，获取文件的文本内容
 * @param {Array<string>} fileTypes 文件类型
 */
var getFileContentFromModal = function getFileContentFromModal() {
  var fileTypes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var openPanel = NSOpenPanel.openPanel();
  openPanel.setTitle('Choose a JSON File');
  openPanel.canCreateDirectories = false;
  openPanel.canChooseFiles = true;
  openPanel.allowedFileTypes = fileTypes;
  var openPanelButtonPressed = openPanel.runModal();
  if (openPanelButtonPressed === NSModalResponseOK) {
    var filePath = openPanel.URL().path();
    return NSString.stringWithContentsOfFile_encoding_error(filePath, NSUTF8StringEncoding, nil);
  }
  return '';
};

/**
 * getSavePathFromModal 获取文件的存储路径
 * @param {String} fileName 文件名
 * @param {Array<string>} fileTypes 文件类型
 */
var getSavePathFromModal = function getSavePathFromModal(fileName) {
  var fileTypes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ['json'];
  if (!fileName) return;
  var savePanel = NSSavePanel.savePanel();
  savePanel.canCreateDirectories = true;
  savePanel.nameFieldStringValue = fileName;
  savePanel.allowedFileTypes = fileTypes;
  var savePanelActionStatus = savePanel.runModal();
  if (savePanelActionStatus === NSModalResponseOK) {
    var filePath = savePanel.URL().path();
    return {
      filePath: filePath,
      fileName: savePanel.nameFieldStringValue()
    };
  }
  return false;
};

/**
 * observerWindowResizeNotification 监听窗口resize
 * @param {*} fn
 */
var observerWindowResizeNotification = function observerWindowResizeNotification(fn) {
  // Keep script around, otherwise everything will be dumped once its run
  // COScript.currentCOScript().setShouldKeepAround(true)

  if (!getThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__[/* WINDOW_MOVE_INSTANCE */ "d"])) {
    // Create a selector
    var Selector = NSSelectorFromString('onWindowMove:');
    var delegate = new mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0___default.a({
      'onWindowMove:': function onWindowMove(notification) {
        // const bounds = NSScreen.mainScreen().frame()
        fn(notification);
        // log(notification)
        // NSNotificationCenter.defaultCenter().removeObserver_name_object(delegateInstance, NSWindowDidResizeNotification, nil)
      }
    });

    // Don't forget to create a class instance of the delegate
    var delegateInstance = delegate.getClassInstance();
    NSNotificationCenter.defaultCenter().addObserver_selector_name_object(delegateInstance, Selector, NSWindowDidResizeNotification, nil);
    setThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__[/* WINDOW_MOVE_INSTANCE */ "d"], delegateInstance);
    setThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__[/* WINDOW_MOVE_SELECTOR */ "e"], Selector);
  }
};

/**
 * removeObserverWindowResizeNotification 清除监听窗口resize
 * @param {*} fn
 */
var removeObserverWindowResizeNotification = function removeObserverWindowResizeNotification() {
  var delegateInstance = getThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__[/* WINDOW_MOVE_INSTANCE */ "d"]);
  if (delegateInstance) {
    NSNotificationCenter.defaultCenter().removeObserver_name_object(delegateInstance, NSWindowDidResizeNotification, nil);
    removeThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__[/* WINDOW_MOVE_INSTANCE */ "d"]);
    removeThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__[/* WINDOW_MOVE_SELECTOR */ "e"]);
  }
};

/***/ }),
/* 21 */
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 22 */
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}

module.exports = _createClass, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 23 */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 24 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ stickers_ui_StickersUI; });

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/defineProperty.js
var defineProperty = __webpack_require__(23);
var defineProperty_default = /*#__PURE__*/__webpack_require__.n(defineProperty);

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/slicedToArray.js
var slicedToArray = __webpack_require__(16);
var slicedToArray_default = /*#__PURE__*/__webpack_require__.n(slicedToArray);

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/classCallCheck.js
var classCallCheck = __webpack_require__(21);
var classCallCheck_default = /*#__PURE__*/__webpack_require__.n(classCallCheck);

// EXTERNAL MODULE: ../node_modules/@babel/runtime/helpers/createClass.js
var createClass = __webpack_require__(22);
var createClass_default = /*#__PURE__*/__webpack_require__.n(createClass);

// EXTERNAL MODULE: ./node_modules/@skpm/dialog/lib/index.js
var lib = __webpack_require__(61);
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// EXTERNAL MODULE: external "sketch"
var external_sketch_ = __webpack_require__(6);
var external_sketch_default = /*#__PURE__*/__webpack_require__.n(external_sketch_);

// EXTERNAL MODULE: external "sketch/ui"
var ui_ = __webpack_require__(15);
var ui_default = /*#__PURE__*/__webpack_require__.n(ui_);

// EXTERNAL MODULE: external "sketch/dom"
var dom_ = __webpack_require__(8);

// EXTERNAL MODULE: ./node_modules/sketch-polyfill-fetch/lib/form-data.js
var form_data = __webpack_require__(25);

// EXTERNAL MODULE: ./node_modules/sketch-polyfill-fetch/lib/index.js
var sketch_polyfill_fetch_lib = __webpack_require__(14);

// EXTERNAL MODULE: ./node_modules/@skpm/fs/index.js
var fs = __webpack_require__(1);
var fs_default = /*#__PURE__*/__webpack_require__.n(fs);

// EXTERNAL MODULE: ./node_modules/@skpm/path/index.js
var path = __webpack_require__(9);
var path_default = /*#__PURE__*/__webpack_require__.n(path);

// EXTERNAL MODULE: ./src/webview/index.js
var webview = __webpack_require__(13);

// EXTERNAL MODULE: ./src/portal.js + 1 modules
var portal = __webpack_require__(7);

// EXTERNAL MODULE: ./src/util.js
var util = __webpack_require__(3);

// CONCATENATED MODULE: ./src/util-libraries.js
/*
 * Copyright 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



/**
 * Returns the MSAssetLibrary / MSUserAssetLibrary with the given library ID
 * (which is a UUID)
 */
function getLibraryById(libraryId) {
  var _getLibrariesControll, _getLibrariesControll2, _getLibrariesControll3;
  var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
    _ref$onlyEnabled = _ref.onlyEnabled,
    onlyEnabled = _ref$onlyEnabled === void 0 ? false : _ref$onlyEnabled;
  return util["a" /* arrayFromNSArray */]((_getLibrariesControll = getLibrariesController()) !== null && _getLibrariesControll !== void 0 && _getLibrariesControll.libraries ? (_getLibrariesControll2 = getLibrariesController()) === null || _getLibrariesControll2 === void 0 ? void 0 : _getLibrariesControll2.libraries() : (_getLibrariesControll3 = getLibrariesController()) === null || _getLibrariesControll3 === void 0 ? void 0 : _getLibrariesControll3.appLibraries()).filter(function (lib) {
    return onlyEnabled ? !!lib.enabled() : true;
  }).find(function (lib) {
    return String(lib.libraryID()) == String(libraryId);
  });
}

/**
 * Adds the given .sketch file as a library in Sketch.
 */
function addLibrary(context, librarySketchFilePath) {
  getLibrariesController().addAssetLibraryAtURL(NSURL.fileURLWithPath(librarySketchFilePath));
  getLibrariesController().notifyLibraryChange(getLibrariesController().userLibraries().firstObject()); // notify change on any lib
}

/**
 * Replaces all symbol instances and shared styles under (and including) the given parent layer with
 * those found in the given MSAssetLibrary.
 */
function replaceSymbolsAndSharedStylesInLayerWithLibrary(parentDocument, parentLayer, library) {
  if (parentLayer.children) {
    var maybeImportForeignObjectWithId = function maybeImportForeignObjectWithId(objectId) {
      // TODO: is this valid/useful?
      // let existing = parentDocument.documentData().foreignSymbols()
      //     .find(fs => String(fs.symbolMaster().symbolID()) == String(symbolId));
      // if (existing) {
      //   return existing;
      // }

      var objectInLibrary = library.document().symbolWithID(objectId) || library.document().textStyleWithID(objectId) || library.document().layerStyleWithID(objectId);
      if (objectInLibrary) {
        var foreignObject = objectInLibrary.foreignObject();
        if (foreignObject) {
          // the shared obj in the target library is a foreign obj from yet
          // another library, try to import it from the other library, and if
          // unavailable, grab the MSForeignObject and add it to the target
          // document directly
          var nestedLibrary = getLibraryById(foreignObject.libraryID(), {
            onlyEnabled: true
          });
          if (nestedLibrary) {
            var objectInNestedLibrary = nestedLibrary.document().symbolWithID(foreignObject.remoteShareID()) || nestedLibrary.document().textStyleWithID(foreignObject.remoteShareID()) || nestedLibrary.document().layerStyleWithID(foreignObject.remoteShareID()) || objectInLibrary; /* worst case, just try to import the object in the outer lib */

            return importObjectFromLibrary(objectInNestedLibrary, nestedLibrary, parentDocument.documentData());
          }
          if (objectInLibrary instanceof MSSymbolMaster) {
            // TODO: investigate what other dependencies we may need to bring in
            // when calling addForeignXX() on a foreign object from another doc.
            // likely we need to add other foreign objects that this one relies on
            parentDocument.documentData().addForeignSymbol(foreignObject);
            return foreignObject;
          }
          /* else if (objectInLibrary instanceof MSTextStyle) {
                           parentDocument.documentData().addForeignTextStyle(foreignObject);
                         } else if (objectInLibrary instanceof MSLayerStyle) {
                           parentDocument.documentData().addForeignLayerStyle(foreignObject);
                         } */
        }

        // the symbol in the target library is local to the library, import it
        // from the library
        return importObjectFromLibrary(objectInLibrary, library, parentDocument.documentData());
      }
      return null;
    };

    // Deep import is necessary when importing override symbols that themselves have overrides
    // This method returns a mapping from local to foreign ID
    var _deepImportOverrides = function deepImportOverrides(overridesDict) {
      var localToForeignIdMap = {};
      for (var k in overridesDict) {
        var foreignObject = maybeImportForeignObjectWithId(overridesDict[k]);
        if (foreignObject) {
          // swap out the symbol ID that's local to the library for the symbol ID
          // for the foreign symbol in the new document linked to the library
          localToForeignIdMap[String(overridesDict[k])] = String(foreignObject.localShareID());
        }
        localToForeignIdMap = Object.assign(localToForeignIdMap, _deepImportOverrides(overridesDict[k]));
      }
      return localToForeignIdMap;
    };
    var allSymbolInstances = util["d" /* getAllLayersMatchingPredicate */](parentLayer, NSPredicate.predicateWithFormat('className == %@', 'MSSymbolInstance'));
    allSymbolInstances.forEach(function (symbolInstance) {
      var symbolId = symbolInstance.symbolID();
      var foreignSymbol = maybeImportForeignObjectWithId(symbolId);
      if (foreignSymbol) {
        symbolInstance.changeInstanceToSymbol(foreignSymbol.symbolMaster());
        replaceSymbolsAndSharedStylesInLayerWithLibrary(parentDocument, foreignSymbol.symbolMaster(), library);
      }
      var overrides = util["c" /* dictFromNSDict */](symbolInstance.overrides());
      var localToForeignSharedObjectIdMap = _deepImportOverrides(overrides);
      symbolInstance.updateOverridesWithObjectIDMap(localToForeignSharedObjectIdMap);
    });
    var allLayersWithSharedStyle = util["d" /* getAllLayersMatchingPredicate */](parentLayer, NSPredicate.predicateWithFormat('sharedStyleID != nil'));
    allLayersWithSharedStyle.forEach(function (layerWithSharedStyle) {
      var styleId = layerWithSharedStyle.sharedStyleID();
      var foreignSharedStyle = maybeImportForeignObjectWithId(styleId);
      if (foreignSharedStyle) {
        if (layerWithSharedStyle instanceof MSTextLayer) {
          // preserve formatted string value before setting shared style (which resets
          // character-level formatting)
          var aStr = layerWithSharedStyle.attributedStringValue();
          layerWithSharedStyle.setSharedStyle(foreignSharedStyle.localSharedStyle());
          layerWithSharedStyle.setAttributedStringValue(aStr);
        } else {
          // inherits MSStyledLayer
          var style = layerWithSharedStyle.style().copy();
          layerWithSharedStyle.setSharedStyle(foreignSharedStyle.localSharedStyle());
          layerWithSharedStyle.setStyle(style);
        }
      }
    });
  }
}

/**
 * Compatibility layer for importForeignSymbol_fromLibrary_intoDocument,
 * removed in Sketch 50.
 *
 * @param {MSModelObject} libraryObject The object (e.g. symbol master, style) in library to import
 * @param {MSAssetLibrary} library The library to import from
 * @param {MSDocumentData} parentDocumentData The document data to import into
 * @returns {MSForeignObject}
 */
function importObjectFromLibrary(libraryObject, library, parentDocumentData) {
  var librariesController = getLibrariesController();
  var shareableObjectReference = MSShareableObjectReference.referenceForShareableObject_inLibrary(libraryObject, library);
  return librariesController.importShareableObjectReference_intoDocument(shareableObjectReference, parentDocumentData);
}

/**
 * Returns an MSDocument for the library with the given ID (cached).
 * Note: this operation may take a while.
 */
function docForLibraryId(libraryId) {
  docForLibraryId.__cache__ = docForLibraryId.__cache__ || {};
  if (!(libraryId in docForLibraryId.__cache__)) {
    var library = Array.from(getLibrariesController().libraries()).find(function (lib) {
      return String(lib.libraryID()) == libraryId;
    });
    if (!library) {
      return null;
    }
    docForLibraryId.__cache__[libraryId] = utils.loadDocFromSketchFile(String(library.locationOnDisk().path()));
  }
  return docForLibraryId.__cache__[libraryId];
}

/**
 * Gets the app instance's MSAssetLibraryController
 */
function getLibrariesController() {
  return AppController.sharedInstance().librariesController();
}
// EXTERNAL MODULE: ./src/parseUpload/index.js + 1 modules
var parseUpload = __webpack_require__(2);

// EXTERNAL MODULE: ./src/utils/index.js + 3 modules
var src_utils = __webpack_require__(10);

// EXTERNAL MODULE: ./src/state.js
var state = __webpack_require__(0);

// EXTERNAL MODULE: ./src/sidePanel.js
var sidePanel = __webpack_require__(18);

// EXTERNAL MODULE: ./src/openUpload.js
var openUpload = __webpack_require__(17);

// EXTERNAL MODULE: ./src/logs.js
var logs = __webpack_require__(28);

// EXTERNAL MODULE: ./src/parseArtboard.js + 8 modules
var parseArtboard = __webpack_require__(5);

// CONCATENATED MODULE: ./src/parseSketch.js


/**
 * 校验是否符合色彩库的数据格式
 * @param layer
 */
var checkIsColor = function checkIsColor(layer) {
  var _layer$layers, _layer$layers2;
  if ((layer === null || layer === void 0 || (_layer$layers = layer.layers) === null || _layer$layers === void 0 ? void 0 : _layer$layers.length) == 1 && (layer === null || layer === void 0 || (_layer$layers2 = layer.layers) === null || _layer$layers2 === void 0 || (_layer$layers2 = _layer$layers2[0]) === null || _layer$layers2 === void 0 ? void 0 : _layer$layers2._class) == 'rectangle') {
    return true;
  }
  return false;
};

/**
 * 校验是否符合icon库的数据格式
 * @param layer
 */
var checkIsIcon = function checkIsIcon(layer) {
  var _layer$layers3;
  if ((layer === null || layer === void 0 || (_layer$layers3 = layer.layers) === null || _layer$layers3 === void 0 || (_layer$layers3 = _layer$layers3[0]) === null || _layer$layers3 === void 0 ? void 0 : _layer$layers3._class) == 'shapeGroup') {
    return true;
  }
  return false;
};

/**
 * @description 根据类型编码进行分类
 * @param {string}
 */
var parseCategory = function parseCategory(parseType) {
  switch (parseType) {
    case 'A':
    case 'E':
      return 'IconGroup';
    case 'B':
      return 'ColorGroup';
    case 'C':
      return 'ComponentGroup';
    case 'D':
      return 'SceneGroup';
    case 'T':
      return 'TextGroup';
    default:
      return '';
  }
};

/**
 * @description 对初始数据进行修饰
 * @param {Object} layer
 * @param {number} parseLevel
 * @param {string} parseType
 * @param {list} array
 */
var parseSketch_initdataToList = function initdataToList(layer, parseLevel, parseType, list) {
  var do_objectID = layer.do_objectID,
    name = layer.name,
    frame = layer.frame;
  var height = frame.height,
    width = frame.width;
  var nameSplitAry = name.split('/');
  var containType = nameSplitAry[0] == 'A' || nameSplitAry[0] == 'B' || nameSplitAry[0] == 'C' || nameSplitAry[0] == 'D' || nameSplitAry[0] == 'E';
  if (containType) nameSplitAry.shift();
  if (nameSplitAry.length == 0) return;

  // 如果有标签的话，取出并剔除
  var labels = [];
  var labelStr;
  if (nameSplitAry[nameSplitAry.length - 1].indexOf('(') !== -1) {
    labelStr = nameSplitAry.pop();
    // 有标签
    labels = labelStr.slice(1, labelStr.length - 1).split('·'); // 标签
  }

  // 将解析目标层级之后的合并在一起处理
  if (nameSplitAry.length > parseLevel) {
    nameSplitAry = nameSplitAry.slice(0, parseLevel).concat(nameSplitAry.slice(parseLevel, nameSplitAry.length).join('/'));
  }

  // 只有一级的话，默认copy增加一级
  if (nameSplitAry.length == 1) {
    nameSplitAry.push(nameSplitAry[0]);
  }
  var reg = /(\d*)([a-z]*)/g;
  var first_name = nameSplitAry[0];
  for (var i = 0; i < nameSplitAry.length; i++) {
    var parent_name = '';
    if (i == 0 && first_name.match(reg)[0]) {
      // nameSplitAry[i] = nameSplitAry[i].replace(first_name.match(reg)[0], '')
    } else if (i != 0) {
      parent_name = "".concat(parseType, "/").concat(nameSplitAry.slice(0, i).join('/'));
    }
    var tempObj = {
      name: nameSplitAry[i],
      uniKey: "".concat(parseType, "/").concat(nameSplitAry.slice(0, i + 1).join('/')),
      parent_name: parent_name,
      type: parseCategory(parseType)
    };
    tempObj.numOrder = nameSplitAry[i].match(reg)[0]; // 第一层级添加numOrder参数，用于排序
    if (nameSplitAry[i + 1]) {
      // 除最底层外手动添加唯一的id
      tempObj.id = Object(parseUpload["c" /* uniqueId */])();
    } else {
      // 最底层一级添加一些属性
      tempObj.fullName = name;
      tempObj.type = parseCategory(parseType).slice(0, -5);
      tempObj.id = Object(parseUpload["c" /* uniqueId */])(); // 最底层的id
      tempObj.objectId = do_objectID;
      if (parseType != 'B') {
        // 色彩库无须缩略图 和 宽高
        tempObj.imgUrl = '';
        tempObj.frame = {
          width: width,
          height: height
        };
      } else {
        var _layer$layers4;
        var objColor = layer === null || layer === void 0 || (_layer$layers4 = layer.layers) === null || _layer$layers4 === void 0 || (_layer$layers4 = _layer$layers4[0]) === null || _layer$layers4 === void 0 || (_layer$layers4 = _layer$layers4.style) === null || _layer$layers4 === void 0 || (_layer$layers4 = _layer$layers4.fills) === null || _layer$layers4 === void 0 || (_layer$layers4 = _layer$layers4[0]) === null || _layer$layers4 === void 0 ? void 0 : _layer$layers4.color;
        if (objColor) {
          var _layer$layers5;
          var _layer$layers$0$style = layer === null || layer === void 0 || (_layer$layers5 = layer.layers) === null || _layer$layers5 === void 0 || (_layer$layers5 = _layer$layers5[0]) === null || _layer$layers5 === void 0 || (_layer$layers5 = _layer$layers5.style) === null || _layer$layers5 === void 0 || (_layer$layers5 = _layer$layers5.fills) === null || _layer$layers5 === void 0 || (_layer$layers5 = _layer$layers5[0]) === null || _layer$layers5 === void 0 ? void 0 : _layer$layers5.color,
            red = _layer$layers$0$style.red,
            green = _layer$layers$0$style.green,
            blue = _layer$layers$0$style.blue,
            alpha = _layer$layers$0$style.alpha;
          tempObj.value = {
            // 颜色色彩值
            red: red,
            green: green,
            blue: blue,
            alpha: alpha
          };
        }
      }
      tempObj.labels = labels;
      if (parseType == 'A') {
        tempObj.isLocked = 0; // icon 可编辑(可改变字体图标颜色和选择大小)
      } else if (parseType == 'E') {
        tempObj.isLocked = 1; // icon 不可编辑
      }
    }
    list.push(tempObj);
  }
};

/**
 * @description 将扁平数据转化为层级数据
 * @param {any[]} list
 */
var listToTree = function listToTree(list) {
  var temp = {};
  var tree = {};
  for (var i in list) {
    temp[list[i].uniKey] = list[i];
  }
  for (var _i in temp) {
    if (temp[_i].parent_name) {
      if (!temp[temp[_i].parent_name].children) {
        temp[temp[_i].parent_name].children = new Array();
      }
      var parent_name = temp[_i].parent_name;
      delete temp[_i].parent_name;
      delete temp[_i].uniKey;
      temp[parent_name].children.push(temp[_i]);
    } else {
      var finalKey = "".concat(temp[_i].uniKey, "/").concat(temp[_i].numOrder);
      delete temp[_i].parent_name;
      delete temp[_i].uniKey;
      tree[finalKey] = temp[_i];
    }
  }
  return tree;
};

/**
 * @description 将数据进行最后的处理：1）将扁平数据转化为层级数据 2）排序
 */
var parseSketch_handleParseData = function handleParseData(parseType, list) {
  // 用于存储icon库数据
  var IconGroupChildren = [];
  // 用于存储色彩库数据
  var ColorGroupChildren = [];
  // 用于存储组件库数据
  var ComponentGroupChildren = [];
  // 用于存储场景库数据
  var SceneGroupChildren = [];
  // 用于存储文字库数据
  var TextGroupChildren = [];

  /* 获取排序标识数据 */
  function getNumOrder(str) {
    // 获取最后一个/的位置
    var site = str.lastIndexOf('\/');
    // 截取最后一个/后的值
    var order = str.substring(site + 1, str.length);
    if (order) {
      // 有序号时，根据序号的大小进行排列
      return order;
    }

    // 否则放在最后
    return Number.POSITIVE_INFINITY;
  }
  function childrenSort(dataAry) {
    dataAry.forEach(function (item) {
      var _item$children;
      if ((item === null || item === void 0 || (_item$children = item.children) === null || _item$children === void 0 ? void 0 : _item$children.length) > 0) {
        item.children = item.children.sort(function (a, b) {
          a.numOrder = a.numOrder || Number.POSITIVE_INFINITY;
          b.numOrder = b.numOrder || Number.POSITIVE_INFINITY;
          return a.numOrder - b.numOrder;
        });
      }
    });
    var res = dataAry.sort(function (a, b) {
      a.numOrder = a.numOrder || Number.POSITIVE_INFINITY;
      b.numOrder = b.numOrder || Number.POSITIVE_INFINITY;
      return a.numOrder - b.numOrder;
    });
    return res;
  }

  /* 根据排序标识进行排序 */
  function sortByNumOrder(treeData) {
    for (var key in treeData) {
      var _treeData$key;
      if (((_treeData$key = treeData[key]) === null || _treeData$key === void 0 || (_treeData$key = _treeData$key.children) === null || _treeData$key === void 0 ? void 0 : _treeData$key.length) > 0) {
        treeData[key].children = childrenSort(treeData[key].children);
      }
    }

    /* 对第一层进行排序 */
    var resData = Object.keys(treeData).sort(function (a, b) {
      return getNumOrder(a) - getNumOrder(b);
    });
    return resData;
  }
  switch (parseType) {
    case 'A':
    case 'E':
      // 将扁平数据变更为树形结构数据
      var iconTree = listToTree(list);
      // 对icon库进行排序
      var iconKey = sortByNumOrder(iconTree);
      iconKey.forEach(function (item) {
        return IconGroupChildren.push(iconTree[item]);
      });
      break;
    case 'B':
      // 将扁平数据变更为树形结构数据
      var colorTree = listToTree(list);
      // 将色彩库的key根据序号进行排序
      var colorKey = sortByNumOrder(colorTree);

      // 按照排序结果塞到数据结构中
      colorKey.forEach(function (item) {
        return ColorGroupChildren.push(colorTree[item]);
      });
      break;
    case 'C':
      // 将扁平数据变更为树形结构数据
      var componentTree = listToTree(list);
      // 对组件库进行排序
      var componentKey = sortByNumOrder(componentTree);
      componentKey.forEach(function (item) {
        return ComponentGroupChildren.push(componentTree[item]);
      });
      break;
    case 'D':
      // 将扁平数据变更为树形结构数据
      var sceneTree = listToTree(list);
      // 对场景库进行排序
      var sceneKey = sortByNumOrder(sceneTree);
      sceneKey.forEach(function (item) {
        return SceneGroupChildren.push(sceneTree[item]);
      });
      break;
    case 'T':
      // 将扁平数据变更为树形结构数据
      var textTree = listToTree(list);
      // 对场景库进行排序
      var textKey = sortByNumOrder(textTree);
      textKey.forEach(function (item) {
        return TextGroupChildren.push(textTree[item]);
      });
      break;
  }
  var IconGroup = {
    name: 'Icon库',
    type: 'IconGroup',
    id: Object(parseUpload["c" /* uniqueId */])(),
    children: IconGroupChildren
  };
  var ColorGroup = {
    name: '色彩库',
    type: 'ColorGroup',
    id: Object(parseUpload["c" /* uniqueId */])(),
    children: ColorGroupChildren
  };
  var ComponentGroup = {
    name: '基础库',
    type: 'ComponentGroup',
    id: Object(parseUpload["c" /* uniqueId */])(),
    children: ComponentGroupChildren
  };
  var SceneGroup = {
    name: '场景库',
    type: 'SceneGroup',
    id: Object(parseUpload["c" /* uniqueId */])(),
    children: SceneGroupChildren
  };
  var TextGroup = {
    name: '文字库',
    type: 'TextGroup',
    id: Object(parseUpload["c" /* uniqueId */])(),
    children: TextGroupChildren
  };
  return {
    name: 'name',
    type: 'Library',
    children: [IconGroup, ColorGroup, ComponentGroup, SceneGroup, TextGroup]
  };
};

/**
 * @description 将缩略图上传后的结果插入到数据中
 * @param resultData 不含imgUrl的解析数据
 * @param sliceObject 缩略图上传完成后的返回结果
 */
var handleSliceImg = function handleSliceImg(resultData, sliceObject) {
  var symbolIds = {};
  function _dfs(o) {
    if (o.objectId && o.type !== 'Color') {
      symbolIds[o.objectId] = o;
    }
    if (o.children && o.children.length) {
      o.children.forEach(function (item) {
        _dfs(item);
      });
    }
  }
  _dfs(resultData);
  for (var key in symbolIds) {
    symbolIds[key].imgUrl = sliceObject[key];
  }
  return resultData;
};
var parseSketch_handleInitData = function handleInitData(layer, parseLevel, parseType, list) {
  var do_objectID = layer.do_objectID,
    name = layer.name,
    frame = layer.frame;
  var height = frame.height,
    width = frame.width;
  var nameSplitAry = name.split('/');
  if (nameSplitAry.length == 0) return;

  // 将解析目标层级之后的合并在一起做平铺 如 ['1','2','3','4','5','6'] parseLevel为4时，处理成['1','2','3','4/5/6']
  if (nameSplitAry.length > parseLevel) {
    nameSplitAry = nameSplitAry.slice(0, parseLevel).concat(nameSplitAry.slice(parseLevel, nameSplitAry.length).join('/'));
  }

  // 只有一级的话，默认copy增加一级
  if (nameSplitAry.length == 1) {
    nameSplitAry.push(nameSplitAry[0]);
  }

  /* 匹配字符串开头的数字 */
  var reg = /^[0-9]+/g;
  for (var i = 0; i < nameSplitAry.length; i++) {
    var parent_name = ''; // 增加parent_name字段，是为了将扁平数据转化为层级数据
    var numOrder = nameSplitAry[i].match(reg) ? nameSplitAry[i].match(reg)[0] : ''; // 添加numOrder参数，用于排序

    nameSplitAry[i] = nameSplitAry[i].replace(numOrder, ''); // 将匹配到每一级用于排序的数字剔除，不做展示
    if (i != 0) {
      parent_name = nameSplitAry.slice(0, i).join('/');
    }
    var tempObj = {
      name: nameSplitAry[i],
      uniKey: nameSplitAry.slice(0, i + 1).join('/'),
      parent_name: parent_name,
      type: parseCategory(parseType),
      numOrder: numOrder
    };
    if (nameSplitAry[i + 1]) {
      // 除最底层外手动添加唯一的id
      tempObj.id = Object(parseUpload["c" /* uniqueId */])();
    } else {
      // 最底层一级添加一些属性
      tempObj.fullName = name;
      tempObj.type = parseCategory(parseType).slice(0, -5);
      tempObj.id = Object(parseUpload["c" /* uniqueId */])(); // 最底层的id
      tempObj.objectId = do_objectID;
      if (parseType == 'B') {
        var _layer$layers6;
        // 色彩库无须增加imgUrl字段
        var objColor = layer === null || layer === void 0 || (_layer$layers6 = layer.layers) === null || _layer$layers6 === void 0 || (_layer$layers6 = _layer$layers6[0]) === null || _layer$layers6 === void 0 || (_layer$layers6 = _layer$layers6.style) === null || _layer$layers6 === void 0 || (_layer$layers6 = _layer$layers6.fills) === null || _layer$layers6 === void 0 || (_layer$layers6 = _layer$layers6[0]) === null || _layer$layers6 === void 0 ? void 0 : _layer$layers6.color;
        if (objColor) {
          var _layer$layers7;
          var _layer$layers$0$style2 = layer === null || layer === void 0 || (_layer$layers7 = layer.layers) === null || _layer$layers7 === void 0 || (_layer$layers7 = _layer$layers7[0]) === null || _layer$layers7 === void 0 || (_layer$layers7 = _layer$layers7.style) === null || _layer$layers7 === void 0 || (_layer$layers7 = _layer$layers7.fills) === null || _layer$layers7 === void 0 || (_layer$layers7 = _layer$layers7[0]) === null || _layer$layers7 === void 0 ? void 0 : _layer$layers7.color,
            red = _layer$layers$0$style2.red,
            green = _layer$layers$0$style2.green,
            blue = _layer$layers$0$style2.blue,
            alpha = _layer$layers$0$style2.alpha;
          tempObj.value = {
            // 颜色色彩值
            red: red,
            green: green,
            blue: blue,
            alpha: alpha
          };
        }
      } else {
        // 其他库增加frame以及imgUrl字段
        tempObj.imgUrl = '';
        tempObj.frame = {
          width: width,
          height: height
        };
      }
      if (parseType == 'A') {
        // 通用icon库,可编辑更改
        tempObj.isLocked = 0;
      } else if (parseType == 'E') {
        // 平台icon库,不可编辑更改
        tempObj.isLocked = 1;
      }
    }
    list.push(tempObj);
  }
};
// CONCATENATED MODULE: ./src/stickers-ui.js




function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { defineProperty_default()(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
/*
 * Copyright 2018 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */




















var UI_MODE = 'cover';
var symbolReferences;
var stickers_ui_StickersUI = /*#__PURE__*/function () {
  function StickersUI(context) {
    classCallCheck_default()(this, StickersUI);
    this.context = context;
    // userId 挂载到this上
    this.userId = Object(portal["b" /* getUserId */])(context);
  }
  return createClass_default()(StickersUI, [{
    key: "setupWebAPI",
    value: function setupWebAPI(browserWindow) {
      var _this = this;
      // toast
      browserWindow.webContents.on('SKToast', function (params) {
        ui_default.a.message(params);
      });
      // 设置webviewBounds
      browserWindow.webContents.on('setWebViewBounds', function (params) {
        var _params$split = params.split(','),
          _params$split2 = slicedToArray_default()(_params$split, 2),
          width = _params$split2[0],
          height = _params$split2[1];
        var bounds = {};
        if (width) {
          bounds.width = +width;
        }
        if (height) {
          bounds.height = +height;
        }
        browserWindow.setBounds(bounds);
      });
      // 获取用户id方法
      browserWindow.webContents.on('getUserId', function (params) {
        try {
          // // console.log('params', params);
          browserWindow.webContents
          // 上传成功，将消息传给webview
          .executeJavaScript("getUserIdCallBack('".concat(_this.userId, "')")).then(function (_res) {
            // // console.log(_res);
          });
        } catch (error) {
          browserWindow.webContents
          // 上传成功，将消息传给webview
          .executeJavaScript('getUserIdCallBack(\'\')').then(function (_res) {
            // // console.log(_res);
          });
        }
      });
      browserWindow.webContents.on('handleLibrarySelectFile', function () {
        try {
          // 弹窗
          var fileList = lib_default.a.showOpenDialogSync({
            properties: ['openFile', 'openDirectory'],
            filters: [{
              name: 'Sketch',
              extensions: ['sketch']
            }]
          });

          // 选择完成
          if (Array.isArray(fileList) && fileList.length > 0) {
            var sketchFilePath = fileList[0];

            //   // console.log('当前选择的文件路径:', sketchFilePath);
            browserWindow.webContents
            // 上传成功，将消息传给webview
            .executeJavaScript("librarySelectFileCallBack('".concat(sketchFilePath, "')")).then(function () {});
            // 取消弹窗
          } else {
            //   // console.log('取消文件选择');
          }
        } catch (e) {
          console.log('handleLibrarySelectFile error', e);
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
        }
        // if (UI_MODE == 'cover') {
        //     browserWindow.close();
        // }
      });

      // 缓存 上传页面的操作记录
      browserWindow.webContents.on('cacheOperation', function (payload) {
        Object(openUpload["d" /* storageOperation */])(payload);
      });

      // 获取 上传页面的操作记录
      browserWindow.webContents.on('getOperation', function () {
        // storageOperation(payload)
        var res = Object(openUpload["c" /* readOperation */])();
        if (res) {
          browserWindow.webContents.executeJavaScript("uploadOperation(".concat(res, ")"));
        }
      });

      // 终止解析library
      browserWindow.webContents.on('cancelParseLibrary', function () {
        //   // console.log('---------')
        //   // console.log('cancelFetch sliceExportIterator')
        parseArtboard["d" /* sliceExportIterator */].isCancel = true;
      });

      // 公共library解析及上传
      browserWindow.webContents.on('handlePublicLibraryParse', function (params) {
        try {
          // sketchFilePath 为原文件路径
          // parseTypeName 为库类型，可为 'icon库', '色彩库', '组件库', '场景库', '插画库', '运营库', '文字库'
          var _params$split3 = params.split(','),
            _params$split4 = slicedToArray_default()(_params$split3, 2),
            sketchFilePath = _params$split4[0],
            parseTypeName = _params$split4[1];

          // 获取插件路径
          var _pluginFolderPath = Object(portal["a" /* getPluginFolderPath */])(_this.context);

          // 将sketch原文件复制到插件路径下，并重命名
          var libraryPath = path_default.a.join(_pluginFolderPath, "".concat(Object(parseUpload["c" /* uniqueId */])(), ".sketch"));
          fs_default.a.copyFileSync(sketchFilePath, libraryPath);

          /* 通过API 获取上传的sketch文件数据 */
          var library = dom_["Library"].getLibraryForDocumentAtPath(sketchFilePath);

          // 根据libraryData导出切片并上传
          var libraryData = library.getDocument();

          // 根据libraryJSON进行数据解析
          var libraryJSON = external_sketch_default.a.export(libraryData, {
            formats: 'json',
            output: false
          });
          switch (parseTypeName) {
            case '组件库':
              _this.componentParse(libraryData, libraryJSON, browserWindow, libraryPath, 0.8, _this.parseCallBack);
              break;
            case '色彩库':
              _this.colorParse(libraryData, libraryJSON, browserWindow, libraryPath, 0, _this.parseCallBack);
              break;
            case '场景库':
              _this.sceneParse(libraryData, libraryJSON, browserWindow, libraryPath, 0.8, _this.parseCallBack);
              break;
            case '插画库':
              _this.drawParse(libraryData, libraryJSON, browserWindow, libraryPath, 0.8, _this.parseCallBack, 'DrawGroup');
              break;
            case '运营库':
              _this.drawParse(libraryData, libraryJSON, browserWindow, libraryPath, 0.8, _this.parseCallBack, 'OperationGroup');
              break;
            case 'icon库':
              _this.iconParse(libraryData, libraryJSON, browserWindow, libraryPath, 0.8, _this.parseCallBack);
              break;
            case '文字库':
              _this.textParse(libraryData, libraryJSON, browserWindow, libraryPath, 1, _this.parseCallBack);
              break;
            default:
              break;
          }
        } catch (e) {
          browserWindow.webContents.executeJavaScript('onUploadFail()');
        }
      });
      browserWindow.webContents.on('deleteLibrary', function (libraryName) {
        var libraryController = AppController.sharedInstance().librariesController();
        var _libraryName$split = libraryName.split('_'),
          _libraryName$split2 = slicedToArray_default()(_libraryName$split, 3),
          prefix = _libraryName$split2[0],
          libraryId = _libraryName$split2[1],
          libraryVersion = _libraryName$split2[2];
        var allLib = libraryController.libraries ? libraryController.libraries() : libraryController.appLibraries();
        allLib.forEach(function (library) {
          // 判断是否是风火轮，并且libraryid一致
          if (library.name().indexOf("".concat(prefix, "_").concat(libraryId)) > -1) {
            // 卸载
            libraryController.removeAssetLibrary(library);
            // 如果library源文件存在删除
            // 获取插件路径
            var _pluginFolderPath2 = Object(portal["a" /* getPluginFolderPath */])(_this.context);
            // library本地路径
            var libraryPath = path_default.a.join(_pluginFolderPath2, "".concat(libraryName, ".sketch"));
            if (fs_default.a.existsSync(libraryPath)) {
              // 删除library源文件
              fs_default.a.unlinkSync(libraryPath);
            }
          }
        });
        libraryController.notifyLibraryChange(null);
      });
      // 本地library解析+缩略图上传
      browserWindow.webContents.on('handleLibraryUpload', function (params) {
        try {
          // 获取插件路径
          var _pluginFolderPath3 = Object(portal["a" /* getPluginFolderPath */])(_this.context);

          // sketchFilePath原文件路径 , parseTypeName为library库类型 , newFileName重新命名的目标nane
          var _params$split5 = params.split(','),
            _params$split6 = slicedToArray_default()(_params$split5, 3),
            sketchFilePath = _params$split6[0],
            parseTypeName = _params$split6[1],
            newFileName = _params$split6[2];

          // 将sketch原文件复制到插件路径下，并重命名
          var libraryPath = path_default.a.join(_pluginFolderPath3, "".concat(newFileName, ".sketch"));
          if (fs_default.a.existsSync(libraryPath)) {
            // 更新->终止 导致本地已有同名文件，且数据库未更新，因此再一次会存在插件中已含重名文件的情况，此时先进行删除
            fs_default.a.unlinkSync(libraryPath);
          }
          fs_default.a.copyFileSync(sketchFilePath, libraryPath);

          /* 通过API 获取上传的sketch文件数据 libraryData数据可以用于缩略图切片上传 */
          var library = dom_["Library"].getLibraryForDocumentAtPath(libraryPath);
          var libraryData = library.getDocument();
          // libraryJSON数据用于解析library
          var libraryJSON = external_sketch_default.a.export(libraryData, {
            formats: 'json',
            output: false
          });

          // 重置fetch
          Object(parseArtboard["c" /* resetFetch */])();
          parseArtboard["b" /* parseDocument */].artProgress = 0;
          switch (parseTypeName) {
            case '组件库':
              _this.componentParse(libraryData, libraryJSON, browserWindow, libraryPath, 1, _this.localParseCB.bind(_this));
              break;
            case '色彩库':
              _this.colorParse(libraryData, libraryJSON, browserWindow, libraryPath, 0, _this.localParseCB.bind(_this));
              break;
            case '场景库':
              _this.sceneParse(libraryData, libraryJSON, browserWindow, libraryPath, 1, _this.localParseCB.bind(_this));
              break;
            case '插画库':
              _this.drawParse(libraryData, libraryJSON, browserWindow, libraryPath, 1, _this.localParseCB.bind(_this), 'DrawGroup');
              break;
            case '运营库':
              _this.drawParse(libraryData, libraryJSON, browserWindow, libraryPath, 0.8, _this.localParseCB.bind(_this), 'OperationGroup');
              break;
            case 'icon库':
              _this.iconParse(libraryData, libraryJSON, browserWindow, libraryPath, 1, _this.localParseCB.bind(_this));
              break;
            case '文字库':
              _this.textParse(libraryData, libraryJSON, browserWindow, libraryPath, 1, _this.localParseCB.bind(_this));
              break;
            default:
              break;
          }
        } catch (e) {
          browserWindow.webContents.executeJavaScript('onUploadFail()');
        }
      });

      // 重置进度
      browserWindow.webContents.on('resetProgress', function () {
        // console.log('--res reset progress----')
        parseArtboard["b" /* parseDocument */].artProgress = 0;
      });

      // 取消进度
      browserWindow.webContents.on('cancelSliceExportIterator', function () {
        // console.log('--res isCancel----')
        parseArtboard["d" /* sliceExportIterator */].isCancel = true;
      });

      // add a handler for a call from web content's javascript
      browserWindow.webContents.on('startDragging', function (payload) {
        try {
          var _payload = _objectSpread({}, payload),
            stickerId = _payload.stickerId,
            frame = _payload.frame;
          var _stickerId$split = stickerId.split(/\|/),
            _stickerId$split2 = slicedToArray_default()(_stickerId$split, 6),
            type = _stickerId$split2[0],
            libraryName = _stickerId$split2[1],
            name = _stickerId$split2[2],
            fullName = _stickerId$split2[3],
            imgUrl = _stickerId$split2[4],
            size = _stickerId$split2[5];

          // console.log('stickerId', stickerId);
          // console.log(`${type}, ${libraryName}, ${name}, ${fullName}, ${imgUrl}, ${size}, ${JSON.stringify(frame)}`);

          // console.log('type, libraryName, fullName, name, imgUrl, size, frame', type, libraryName, name, fullName, imgUrl, size, frame);

          _this.startDragging(type, libraryName, name, fullName, imgUrl, size, frame, browserWindow._webview);
        } catch (e) {
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
          console.log('startDragging error', e);
        }

        // 拖拽成功，将消息传给webview
        browserWindow.webContents.executeJavaScript('draggingCallBack()').then(function (_res) {
          //   // console.log(_res);
        });
        // if (UI_MODE == 'cover') {
        //     browserWindow.close();
        // }
      });
      browserWindow.webContents.on('startFill', function (payload) {
        var _payload2 = _objectSpread({}, payload),
          type = _payload2.type,
          color = _payload2.color;
        console.log('type', type);
        console.log('color', color);
        try {
          _this.startFill(type, color);
        } catch (e) {
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
          console.log('startFill error', e);
        }
      });
      browserWindow.webContents.on('fillImage', function (payload) {
        var pageIndex = payload.pageIndex,
          url = payload.url;
        try {
          console.log('payload-image', payload);
          _this.image2Fill(url);
          browserWindow.webContents.executeJavaScript("onImageFillEnd('success',".concat(pageIndex, ")"));
        } catch (e) {
          browserWindow.webContents.executeJavaScript("onImageFillEnd('fail',".concat(pageIndex, ")"));
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
          console.log('fillImage error', e);
        }
      });
      browserWindow.webContents.on('newAbilityRead', function () {
        sidePanel["abilityNext"] && Object(sidePanel["abilityNext"])();
      });
      browserWindow.webContents.on('closeOpenedBrowser', function (type, color) {
        // console.log('closeOpenedBrowser1')
        try {
          Object(webview["c" /* closeBrowser */])(type);
          // closeBrowerAfter();
          Object(openUpload["e" /* updateStatus */])();
        } catch (e) {
          console.log('closeOpenedBrowser error', e);
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
        }
      });
      // 下载并安装Library;
      browserWindow.webContents.on('handleLibrary', function (paramsString) {
        try {
          var _paramsString$split = paramsString.split(/\|/),
            _paramsString$split2 = slicedToArray_default()(_paramsString$split, 2),
            libraryUrl = _paramsString$split2[0],
            libraryName = _paramsString$split2[1];

          // log('尝试下载安装')
          _this.downloadAndaddLibrary(libraryUrl, libraryName, browserWindow);
        } catch (e) {
          console.log('handleLibrary error', e);
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
        }
      });
      browserWindow.webContents.on('openUrl', function (url) {
        try {
          Object(src_utils["f" /* penUrlInBrowser */])(url);
        } catch (e) {
          console.log('openUrl error', e);
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
        }
      });
      browserWindow.webContents.on('log', function (name, data) {
        try {
          // // console.log(name, data)
        } catch (e) {
          // TODO: do this everywhere somehow
          // log(e.message);
          // log(e);
        }
      });
    }

    /**
    * Triggers the beginning of a drag operation on the given sticker ID
    */
  }, {
    key: "startDragging",
    value: function startDragging(type, libraryName, name, fullName, imgUrl, size, frame, srcView) {
      try {
        // 解析Library
        var librariesAll = dom_["Library"].getLibraries();
        var currLibrary = librariesAll.find(function (_ref) {
          var _name = _ref.name;
          return _name === libraryName;
        });
        var libraryId = currLibrary.id;
        var document = external_sketch_default.a.getSelectedDocument();
        if (currLibrary) {
          var layer = null;
          if (type === 'icon' && size.indexOf('_') !== -1) {
            // 可编辑的icon拖拽 生成svg
            var imageBuffer = NSData.alloc().initWithContentsOfURL(NSURL.alloc().initWithString(imgUrl.split(',')[1]));

            // 使用svg导出图层
            layer = external_sketch_default.a.createLayerFromData(imageBuffer, 'svg').sketchObject;
            // 设置图层名称
            layer.name = name;
            // 设置图层尺寸宽_高
            var _frame = size.split('_');
            layer.rect = NSMakeRect(0, 0, +_frame[0], +_frame[1]);
            // 组件拖拽
          } else if (type === 'component' || type === 'icon' || type === 'text') {
            // 不可编辑的icon和组件拖拽 生成symbol
            // 高版本此句报错，待查todo
            var _symbolReferences = currLibrary.getImportableSymbolReferencesForDocument(document);
            // 获取symbolReference
            var symbolReference = _symbolReferences.find(function (_ref2) {
              var _name = _ref2.name;
              return _name === fullName;
            });
            // 获取symbolMaster
            var symbolMaster = symbolReference.import();
            // 获取symbol实例
            var instance = symbolMaster.createNewInstance().sketchObject.immutableModelObject();
            layer = instance.newMutableCounterpart();
            // 设置图层名称
            layer.name = fullName;
          } else if (type === 'scenario' || type === 'drawgroup' || type === 'operationgroup') {
            // 场景组件拖拽  生成画板
            var libraryData = currLibrary.getDocument();

            // const name = fullName.split('/').pop();
            layer = libraryData.getLayersNamed(name)[0].sketchObject;
            layer.name = name;
          }

          // 通用icon和场景组件不需要解析内部图层
          if (!(type === 'icon' && [40, 50].includes(+size)) && type !== 'scenario' && type !== 'drawgroup' && type !== 'operationgroup' && type !== 'text') {
            // 获取当前library
            var library = getLibraryById(libraryId, {
              onlyEnabled: true
            });
            // // create a dummy document and import the layer into it, so that
            // foreign symbols can be created in it and sent along with the layer
            // to the pasteboard

            var dummyDocData = MSDocumentData.alloc().init();
            dummyDocData.addBlankPage().addLayer(layer);

            // // import any symbols and shared styles used in library (either from the library itself or
            // // other libraries referenced from the library... i.e. nested libraries)
            replaceSymbolsAndSharedStylesInLayerWithLibrary(dummyDocData, layer, library);
          }

          // initiate cocoa drag operation
          // let pbItem = NSPasteboardItem.new();
          // pbItem.setData_forType_(
          //     image.TIFFRepresentation(),
          //     NSPasteboardTypePNG);
          // 获取当前拖拽的图层图片
          var image = NSImage.alloc().initWithContentsOfURL(NSURL.alloc().initWithString(imgUrl.split(',')[0]));
          var dragItem = NSDraggingItem.alloc().initWithPasteboardWriter(image);

          // pbItem.release();
          dragItem.setDraggingFrame_contents_(NSMakeRect(frame.x, frame.y, frame.width, frame.height), image);
          var mouse = NSEvent.mouseLocation();
          var event = NSEvent.eventWithCGEvent(CGEventCreateMouseEvent(null, kCGEventLeftMouseDown, CGPointMake(mouse.x - srcView.window().frame().origin.x, NSHeight(NSScreen.screens().firstObject().frame()) - mouse.y + srcView.window().frame().origin.y), kCGMouseButtonLeft));
          var draggingSession = srcView.beginDraggingSessionWithItems_event_source_(NSArray.arrayWithObject(dragItem.autorelease()), event, srcView);
          if (draggingSession) {
            draggingSession.setAnimatesToStartingPositionsOnCancelOrFail(false);
            draggingSession.setDraggingFormation(NSDraggingFormationNone);
            // copy to pasteboard
            var dpb = NSPasteboard.pasteboardWithName(NSDragPboard);
            dpb.clearContents();
            var newPbLayers = MSPasteboardLayers.pasteboardLayersWithLayers([layer]);
            MSPasteboardManager.writePasteboardLayers_toPasteboard(newPbLayers, dpb);
          }
        }
      } catch (err) {
        console.log('startDragging error', err);
      }
    }
  }, {
    key: "startFill",
    value: function startFill(type, color) {
      var red = color.red,
        green = color.green,
        blue = color.blue,
        alpha = color.alpha;
      // 获取当前文档
      var document = external_sketch_default.a.getSelectedDocument();
      var layers = document.selectedLayers.layers;
      var currColor = MSColor.alloc().initWithRed_green_blue_alpha(red / 255, green / 255, blue / 255, alpha);
      layers.forEach(function (item) {
        var layer = item.sketchObject;
        if (type === 'fill') {
          // 填充颜色 参考: https://github.com/colesperks/QuickColor
          var fills = layer.style().enabledFills();
          if (fills.count() > 0 && fills.lastObject().fillType() === 0) {
            fills.lastObject().setColor(currColor);
          } else {
            var fill = layer.style().addStylePartOfType(0);
            fill.setFillType(0);
            fill.setColor(currColor);
          }
          // 描边
        } else if (type === 'border') {
          // 填充颜色 参考: https://github.com/colesperks/QuickColor
          var borders = layer.style().enabledBorders();
          // 定义颜色值

          if (borders.count() > 0 && borders.lastObject().fillType() === 0) {
            borders.lastObject().setColor(currColor);
          } else {
            var border = layer.style().addStylePartOfType(1);
            border.setFillType(0);
            border.setColor(currColor);
          }
        }
      });
    }

    /**
    *
    * 调用webview侧暴露的方法，目前只有如下3种
    * @param {('updating' | 'updateComplete' | 'updateError')} functionName
    * @param {string} [text]
    * @memberof StickersUI
    */
  }, {
    key: "updateHandle",
    value: function updateHandle(browserWindow, functionName) {
      var text = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
      // console.log('browserWindow', browserWindow);
      console.log('functionName', functionName);
      console.log('text', text);
      browserWindow.webContents.executeJavaScript("".concat(functionName, "(\"").concat(text, "\")")).then(function (res) {
        console.log('res', res);
      });
      console.log('执行结束了');
    }

    /**
    * 检查现有的，删除以前的旧版本
    */
  }, {
    key: "deletePreviousLibrary",
    value: function deletePreviousLibrary(libraryName) {
      var _this2 = this;
      var libraryController = AppController.sharedInstance().librariesController();
      var allLib = libraryController.libraries ? libraryController.libraries() : libraryController.appLibraries();
      var _libraryName$split3 = libraryName.split('_'),
        _libraryName$split4 = slicedToArray_default()(_libraryName$split3, 3),
        prefix = _libraryName$split4[0],
        libraryId = _libraryName$split4[1],
        libraryVersion = _libraryName$split4[2];
      allLib.forEach(function (library) {
        // 判断是否是风火轮，并且libraryid一致
        if (library.name().indexOf("".concat(prefix, "_").concat(libraryId)) > -1) {
          // 前面一致的情况下，判断版本号，不一样的全都删除
          if (library.name() != libraryName) {
            libraryController.removeAssetLibrary(library);
            // 删除之前版本的library源文件
            // 获取插件路径
            var _pluginFolderPath4 = Object(portal["a" /* getPluginFolderPath */])(_this2.context);
            // library本地路径
            var libraryPath = path_default.a.join(_pluginFolderPath4, "".concat(library.name(), ".sketch"));
            if (fs_default.a.existsSync(libraryPath)) {
              // 删除library源文件
              fs_default.a.unlinkSync(libraryPath);
            }
          }
        }
      });
      libraryController.notifyLibraryChange(null);
    }

    /**
    * 下载并安装
    */
  }, {
    key: "downloadAndaddLibrary",
    value: function downloadAndaddLibrary(libraryUrl, libraryName, browserWindow) {
      var _this3 = this;
      // libraryUrl = 'https://parse.58.com/preview/sketch/SketchDownLoad?sketchMd5Id=d79a0c1e233f8dd95944477de5e17913&sketchName=hotwheel_v2_test_library';
      //   // console.log('libraryUrl, libraryName', libraryUrl, libraryName);
      // 下载测试 start
      var session = NSURLSession.sharedSession();
      //   // console.log('session', session);
      var url1 = NSURL.URLWithString(NSString.stringWithString(libraryUrl));
      // 获取插件路径
      var pluginFolderPath = Object(portal["a" /* getPluginFolderPath */])(this.context);
      // library本地路径
      var libraryPath = path_default.a.join(pluginFolderPath, "".concat(libraryName, ".sketch"));

      // log(`libraryPath${libraryPath} pluginFolderPath${pluginFolderPath}`);
      // 如果已存在，则不需要二次安装
      if (fs_default.a.existsSync(libraryPath)) {
        //   log(`${libraryName}已安装，无需下载`);
        dom_["Library"].getLibraryForDocumentAtPath(NSURL.fileURLWithPath(libraryPath));
        this.deletePreviousLibrary(libraryName);
        // log(`${libraryName}NSURL.fileURLWithPath(libraryPath)`)
        // 如果不存在，则需要下载组件库并安装
      } else {
        this.updateHandle(browserWindow, 'updating');
        //   log('updating');

        var task = session.downloadTaskWithRequest_completionHandler(NSURLRequest.requestWithURL(url1), __mocha__.createBlock_function('v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24', function (location, response, error) {
          try {
            //   // console.log('location,response,error', location, location.filePathURL(), response, response.suggestedFilename(), error);
            // const f0 = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, true);
            // const f1 = f0.lastObject();
            // const fullPath = f1.stringByAppendingPathComponent(response.suggestedFilename());

            // 将缓存文件存储为本地文件
            NSFileManager.defaultManager().moveItemAtURL_toURL_error(location, NSURL.fileURLWithPath(libraryPath), nil);
            // 安装Library
            if (libraryPath) {
              //   // console.log('fullPath, libraryPath',fullPath, libraryPath);
              //   fs.copyFileSync(fullPath, libraryPath);

              //   fs.unlinkSync(fullPath);
              dom_["Library"].getLibraryForDocumentAtPath(NSURL.fileURLWithPath(libraryPath));
              _this3.updateHandle(browserWindow, 'updateComplete');
              _this3.deletePreviousLibrary(libraryName);
            }
          } catch (err) {
            //   // console.log(err);
            _this3.updateHandle(browserWindow, 'updateError');
            _this3.deletePreviousLibrary(libraryName);
          }
        }));
        task.resume();
      }
    }

    /**
    * 色彩库解析
    */
  }, {
    key: "colorParse",
    value: function colorParse(libraryData, libraryJSON, browserWindow, libraryPath, progressSlice, parseCB) {
      var colorList = []; // 存放色彩库json文件加工的初始数据
      var parseLevel = 3; // 解析层级。代表1,2,3为层级结构，剩下的平铺展示
      var parseType = 'B'; // 解析类型，B代表色彩库

      // step1: 通过handleInitData方法拿到 json文件里的有用数据，存放在colorList中
      libraryJSON.pages.forEach(function (item) {
        item.layers.forEach(function (layer) {
          parseSketch_handleInitData(layer, parseLevel, parseType, colorList);
        });
      });

      // step2: 通过handleParseData方法 将扁平数据转化为层级数据 并排序 得到最后的解析数据
      var resultData = parseSketch_handleParseData(parseType, colorList);
      parseCB(libraryPath, resultData, browserWindow, 1 - progressSlice);
    }

    /**
    * 组件库解析
    */
  }, {
    key: "componentParse",
    value: function componentParse(libraryData, libraryJSON, browserWindow, libraryPath, progressSlice, parseCB) {
      var componentList = [];
      var parseLevel = 3; // 解析层级。代表1,2,3为层级结构，剩下的平铺展示
      var parseType = 'C'; // 解析类型，C代表组件库

      // step1: 通过handleInitData方法拿到 json文件里的有用数据，存放在componentList中
      libraryJSON.pages.forEach(function (item) {
        if (item.name !== '控件') {
          item.layers.forEach(function (layer) {
            parseSketch_handleInitData(layer, parseLevel, parseType, componentList);
          });
        }
      });

      // step2: 通过handleParseData方法 将扁平数据转化为层级数据 并排序 得到最后的解析数据
      var resultData = parseSketch_handleParseData(parseType, componentList);

      // 用于存储缩略图数据
      var sliceList = [];

      // 获取切片列表
      libraryData.pages.forEach(function (item) {
        if (item.type === 'Page' && item.name !== '控件') {
          item.layers.forEach(function (item2) {
            if (item2.type === 'SymbolMaster') {
              // 这里存储的是SymbolMaster这一级
              sliceList.push(item2);
            }
          });
        }
      });

      // 导出并上传切片
      parseArtboard["d" /* sliceExportIterator */].isCancel = false;
      Object(parseArtboard["d" /* sliceExportIterator */])(sliceList, progressSlice, function (res) {
        // 将进度实时告知给webview
        browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
      }).then(function (sliceObject) {
        // 切片map表 key: 切片id ,value: 切片ur

        // 将上传后的缩略图拼接到解析数据中
        resultData = handleSliceImg(resultData, sliceObject);
        parseCB(libraryPath, resultData, browserWindow, 1 - progressSlice);
      });
    }

    /**
    * icon库解析
    */
  }, {
    key: "iconParse",
    value: function iconParse(libraryData, libraryJSON, browserWindow, libraryPath, progressSlice, parseCB) {
      var iconList = [];
      var parseLevel = 3; // 解析层级。代表1,2,3为层级结构，剩下的平铺展示
      var parseType = ''; // 解析类型
      var resultData = {}; // 平台icon库数据
      var resultDataBase = {}; // 通用icon库数据

      // step1: 通过handleInitData方法拿到 json文件里的有用数据，存放在iconList中
      libraryJSON.pages.forEach(function (item) {
        if (item.name !== '控件') {
          item.layers.forEach(function (layer) {
            if (layer._class === 'symbolMaster') {
              // 代表为平台icon库,不可编辑更改
              parseType = 'E';
              // 平台icon的解析逻辑
              parseSketch_handleInitData(layer, parseLevel, parseType, iconList);
            } else if (layer._class === 'artboard') {
              // 通用icon库的解析逻辑
              var _setD = function _setD(options) {
                return {
                  name: options.name,
                  fullName: options.name,
                  type: 'IconGroup',
                  id: Object(parseUpload["c" /* uniqueId */])(),
                  isLocked: 0,
                  children: []
                };
              };
              // 代表为通用icon库,可编辑更改
              parseType = 'A';
              resultDataBase = _setD(layer);
              // 通用icon库的解析逻辑
              layer.layers && layer.layers.forEach(function (layer1) {
                if (layer1._class === 'group') {
                  var o = _setD(layer1);
                  o.fullName = "".concat(layer.name, "/").concat(layer1.name);
                  resultDataBase.children.push(o);
                  layer1.layers && layer1.layers.forEach(function (layer2) {
                    if (layer2._class === 'group') {
                      var o1 = _setD(layer2);
                      o1.fullName = "".concat(layer.name, "/").concat(layer1.name, "/").concat(layer2.name);
                      o.children.push(o1);
                      layer2.layers && layer2.layers.forEach(function (layer3) {
                        if (layer3._class === 'group') {
                          var o2 = _setD(layer3);
                          o2.fullName = "".concat(layer.name, "/").concat(layer1.name, "/").concat(layer2.name, "/").concat(layer3.name);
                          o2.type = 'Icon';
                          o2.objectId = layer3.do_objectID;
                          o2.frame = {
                            width: layer3.frame.width,
                            height: layer3.frame.height
                          };
                          o1.children.push(o2);
                        }
                      });
                    }
                  });
                }
              });
            }
          });
        }
      });
      resultData = parseSketch_handleParseData(parseType, iconList);

      // 用于存储缩略图数据
      var sliceList = [];
      var sliceListBase = [];

      // 获取切片列表
      libraryData.pages.forEach(function (item) {
        if (item.type === 'Page' && item.name !== '控件') {
          item.layers.forEach(function (item2) {
            if (item2.type === 'SymbolMaster') {
              // 代表为平台icon库,这里导出的是SymbolMaster这一级的切片
              sliceList.push(item2);
            } else if (item2.type === 'Artboard') {
              // 代表为通用icon库,这里需要导出svg上传
              // 代表为通用icon库,这里需要导出svg上传
              var _2 = function _(l) {
                if (l.layers && l.layers.length) {
                  if (l.layers[0].type === 'ShapePath' || l.layers[0].type === 'Shape') {
                    sliceListBase.push(l);
                  } else {
                    l.layers.forEach(function (i) {
                      _2(i);
                    });
                  }
                }
              };
              _2(item2);
            }
          });
        }
      });

      // 导出并上传切片
      parseArtboard["d" /* sliceExportIterator */].isCancel = false;

      // 组装 通用icon数据
      Object(parseArtboard["d" /* sliceExportIterator */])(sliceListBase, progressSlice / 2, function (res) {
        // console.log('--res  1--', res)
        browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
      }, 1, true).then(function (sliceObject) {
        resultDataBase = handleSliceImg(resultDataBase, sliceObject);
        // 组装 平台icon数据
        Object(parseArtboard["d" /* sliceExportIterator */])(sliceList, progressSlice / 2, function (res) {
          // console.log('--res  2--', res)
          // 将进度实时告知给webview
          browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
        }).then(function (sliceObject) {
          var _resultData;
          // 切片map表 key: 切片id ,value: 切片url
          // console.log('缩略图上传结果')
          // console.log(sliceObject);

          // 将上传后的缩略图拼接到解析数据中
          resultData = handleSliceImg(resultData, sliceObject);
          (_resultData = resultData) === null || _resultData === void 0 || (_resultData = _resultData.children) === null || _resultData === void 0 || _resultData.forEach(function (item) {
            if (item.type === 'IconGroup' && Object.keys(resultDataBase).length) {
              item.children.push(resultDataBase);
            }
          });
          parseCB(libraryPath, resultData, browserWindow, 1 - progressSlice);
        });
      });
    }

    /**
     * 文字库解析
     */
  }, {
    key: "textParse",
    value: function textParse(libraryData, libraryJSON, browserWindow, libraryPath, progressSlice, parseCB) {
      var textList = [];
      var parseLevel = 3; // 解析层级。代表1,2,3为层级结构，剩下的平铺展示
      var parseType = 'T'; // 解析类型，T代表文字库

      // step1: 通过handleInitData方法拿到 json文件里的有用数据，存放在textList中
      libraryJSON.pages.forEach(function (item) {
        if (item.name !== '控件') {
          item.layers.forEach(function (layer) {
            parseSketch_handleInitData(layer, parseLevel, parseType, textList);
          });
        }
      });

      // step2: 通过handleParseData方法 将扁平数据转化为层级数据 并排序 得到最后的解析数据
      var resultData = parseSketch_handleParseData(parseType, textList);

      // 用于存储缩略图数据
      var sliceList = [];

      // 获取切片列表
      libraryData.pages.forEach(function (item) {
        if (item.type === 'Page' && item.name !== '控件') {
          item.layers.forEach(function (item2) {
            if (item2.type === 'SymbolMaster') {
              // 这里存储的是SymbolMaster这一级
              sliceList.push(item2);
            }
          });
        }
      });

      // 导出并上传切片
      parseArtboard["d" /* sliceExportIterator */].isCancel = false;
      Object(parseArtboard["d" /* sliceExportIterator */])(sliceList, progressSlice, function (res) {
        // 将进度实时告知给webview
        browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
      }).then(function (sliceObject) {
        // 切片map表 key: 切片id ,value: 切片ur
        // 将上传后的缩略图拼接到解析数据中
        resultData = handleSliceImg(resultData, sliceObject);
        parseCB(libraryPath, resultData, browserWindow, 1 - progressSlice);
      });
    }

    /**
    * 场景库解析
    */
  }, {
    key: "sceneParse",
    value: function sceneParse(libraryData, libraryJSON, browserWindow, libraryPath, progressSlice, parseCB) {
      var page = libraryJSON.pages[0]; // 规定只有一个页面
      var pageImgs = [];
      function _setD(options) {
        return {
          name: options.name,
          fullName: options.name,
          type: 'SceneGroup',
          id: Object(parseUpload["c" /* uniqueId */])(),
          isLocked: 0,
          children: []
        };
      }
      var data = _setD(page);
      page.layers && page.layers.forEach(function (layer) {
        if (layer._class === 'artboard') {
          var rd = _setD(layer);
          rd.fullName = "".concat(data.name, "/").concat(layer.name);
          data.children.push(rd);
          layer.layers && layer.layers.forEach(function (layer1) {
            if (layer1._class === 'group') {
              var rd1 = _setD(layer1);
              rd1.fullName = "".concat(data.name, "/").concat(layer.name, "/").concat(layer1.name);
              rd.children.push(rd1);
              layer1.layers && layer1.layers.forEach(function (layer2) {
                if (layer2._class === 'group') {
                  var rd2 = _setD(layer2);
                  rd2.fullName = "".concat(data.name, "/").concat(layer.name, "/").concat(layer1.name, "/").concat(layer2.name);
                  rd2.type = 'Scene';
                  rd2.objectId = layer2.do_objectID;
                  rd2.frame = {
                    width: layer2.frame.width,
                    height: layer2.frame.height
                  };
                  rd1.children.push(rd2);
                }
              });
            }
          });
        }
      });

      // 获取切片列表
      libraryData.pages.forEach(function (page) {
        if (page.type === 'Page') {
          page.layers && page.layers.forEach(function (layer) {
            if (layer.type === 'Artboard') {
              layer.layers && layer.layers.forEach(function (layer1) {
                if (layer1.type === 'Group') {
                  layer1.layers && layer1.layers.forEach(function (layer2) {
                    pageImgs.push(layer2);
                  });
                }
              });
            }
          });
        }
      });

      // 导出并上传切片
      parseArtboard["d" /* sliceExportIterator */].isCancel = false;

      // 组装 场景库数据
      Object(parseArtboard["d" /* sliceExportIterator */])(pageImgs, progressSlice, function (res) {
        // console.log('--res 1--', res)
        browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
      }).then(function (sliceObject) {
        data = handleSliceImg(data, sliceObject);
        data = {
          name: 'name',
          type: 'Library',
          children: [{
            name: 'Icon库',
            type: 'IconGroup',
            id: Object(parseUpload["c" /* uniqueId */])(),
            children: []
          }, {
            name: '色彩库',
            type: 'ColorGroup',
            id: Object(parseUpload["c" /* uniqueId */])(),
            children: []
          }, {
            name: '基础库',
            type: 'ComponentGroup',
            id: Object(parseUpload["c" /* uniqueId */])(),
            children: []
          }, data]
        };
        parseCB(libraryPath, data, browserWindow, 1 - progressSlice);
      }).catch(function (err) {
        browserWindow.webContents.executeJavaScript('onUploadFail()');
      });
    }

    /**
    * 插画库、运营库解析
    */
  }, {
    key: "drawParse",
    value: function drawParse(libraryData, libraryJSON, browserWindow, libraryPath, progressSlice, parseCB, type) {
      var page = libraryJSON.pages[0]; // 规定只有一个页面
      var pageImgs = [];
      function _setD(options) {
        return {
          name: options.name,
          fullName: options.name,
          type: type,
          id: Object(parseUpload["c" /* uniqueId */])(),
          isLocked: 0,
          children: []
        };
      }
      var data = _setD(page);
      page.layers && page.layers.forEach(function (layer) {
        if (layer._class === 'artboard') {
          var rd = _setD(layer);
          rd.fullName = "".concat(data.name, "/").concat(layer.name);
          data.children.push(rd);
          layer.layers && layer.layers.forEach(function (layer1) {
            if (layer1._class === 'group') {
              var rd1 = _setD(layer1);
              rd1.fullName = "".concat(data.name, "/").concat(layer.name, "/").concat(layer1.name);
              rd.children.push(rd1);
              layer1.layers && layer1.layers.forEach(function (layer2) {
                if (layer2._class === 'group') {
                  var rd2 = _setD(layer2);
                  rd2.fullName = "".concat(data.name, "/").concat(layer.name, "/").concat(layer1.name, "/").concat(layer2.name);
                  rd2.type = type.replace(/Group/g, ''), rd2.objectId = layer2.do_objectID;
                  rd2.frame = {
                    width: layer2.frame.width,
                    height: layer2.frame.height
                  };
                  rd1.children.push(rd2);
                }
              });
            }
          });
        }
      });

      // 获取切片列表
      libraryData.pages.forEach(function (page) {
        if (page.type === 'Page') {
          page.layers && page.layers.forEach(function (layer) {
            if (layer.type === 'Artboard') {
              layer.layers && layer.layers.forEach(function (layer1) {
                if (layer1.type === 'Group') {
                  layer1.layers && layer1.layers.forEach(function (layer2) {
                    pageImgs.push(layer2);
                  });
                }
              });
            }
          });
        }
      });

      // 导出并上传切片
      parseArtboard["d" /* sliceExportIterator */].isCancel = false;

      // 组装 场景库数据
      Object(parseArtboard["d" /* sliceExportIterator */])(pageImgs, progressSlice, function (res) {
        // console.log('--res 1--', res)
        browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
      }).then(function (sliceObject) {
        data = handleSliceImg(data, sliceObject);
        data = {
          name: 'name',
          type: 'Library',
          children: [{
            name: 'Icon库',
            type: 'IconGroup',
            id: Object(parseUpload["c" /* uniqueId */])(),
            children: []
          }, {
            name: '色彩库',
            type: 'ColorGroup',
            id: Object(parseUpload["c" /* uniqueId */])(),
            children: []
          }, {
            name: '基础库',
            type: 'ComponentGroup',
            id: Object(parseUpload["c" /* uniqueId */])(),
            children: []
          }, data]
        };
        parseCB(libraryPath, data, browserWindow, 1 - progressSlice);
      }).catch(function (err) {
        browserWindow.webContents.executeJavaScript('onUploadFail()');
      });
    }

    /**
    *公共库解析后的回调
    */
  }, {
    key: "parseCallBack",
    value: function parseCallBack(libraryPath, resultData, browserWindow, resSlice) {
      // 上传sketch文件
      Object(parseArtboard["e" /* uploadSketch */])(libraryPath, resSlice, function (res) {
        // console.log('--res 2--', res)
        browserWindow.webContents.executeJavaScript("progessUpdate(".concat(res, ")"));
      }).then(function (sketchUrl) {
        if (fs_default.a.existsSync(libraryPath)) {
          // 删除sketch临时文件
          fs_default.a.unlinkSync(libraryPath);
        }

        // fs.writeFileSync('/Users/zhangjun/workspace/hotwheels_plugin_node_docker/download/result.json', JSON.stringify(resultData))
        // 将解析数据，传给webview
        browserWindow.webContents.executeJavaScript("publicParseCallBack(".concat(JSON.stringify({
          resultData: resultData,
          sketchUrl: sketchUrl
        }), ")")).then(function (_res) {
          console.log('parseCallBack1 error', err);
          // console.log(_res)
        });
      }).catch(function (err) {
        console.log('parseCallBack2 error', err);
        // console.log(err)
        browserWindow.webContents.executeJavaScript('onUploadFail()');
      });
    }

    /**
    *本地库解析后的回调
    */
  }, {
    key: "localParseCB",
    value: function localParseCB(libraryPath, resultData, browserWindow) {
      /* 根据命名规则查询以前的版本，进行卸载，并删除源文件 */
      var newFileName = libraryPath.split('/').pop().replace('.sketch', '');

      // console.log(newFileName)
      this.deletePreviousLibrary(newFileName);
      browserWindow.webContents
      // 上传成功，将消息传给webviewz
      .executeJavaScript("uploadCallBack(".concat(JSON.stringify(resultData), ")")).then(function (_res) {});
    }

    /**
    * 填充图层
    */
  }, {
    key: "image2Fill",
    value: function image2Fill(imgUrl) {
      if (!~imgUrl.indexOf('https://')) {
        logs["a" /* logger */].error('图片填充不能用 http 的路径', 'imageFill');
        // 不允许用 http 的图片
        imgUrl = 'https://wos2.58cdn.com.cn/KlMhGfEdKlMK/cbplatform/1432602619947311104';
        ui_default.a.message('当前填充图片链接为http协议，禁用http协议，请联系管理人员');
      }
      var _getSketchSelected = Object(src_utils["d" /* getSketchSelected */])(),
        document = _getSketchSelected.document,
        page = _getSketchSelected.page,
        artboard = _getSketchSelected.artboard,
        layers = _getSketchSelected.selection.layers;
      var imageurl_nsurl = NSURL.alloc().initWithString(imgUrl);
      // var imageData = NSImage.alloc().initByReferencingURL(imageurl_nsurl);
      var imageData = NSImage.alloc().initWithContentsOfURL(imageurl_nsurl);
      layers.forEach(function (item) {
        var layer = item.sketchObject;
        var fills = layer.style().enabledFills();
        var currImage = MSImageData.alloc().initWithImage(imageData);

        // fillType 0 颜色 1渐变 4图像
        if (fills.count() > 0 && fills.lastObject().fillType() === 4) {
          // 替换
          fills.lastObject().setImage(currImage);
        } else {
          // 新增
          var fill = layer.style().addStylePartOfType(0);
          fill.setFillType(4);
          fill.setImage(currImage);
        }
      });
    }
  }]);
}();

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

var Buffer;
try {
  Buffer = __webpack_require__(30).Buffer;
} catch (err) {}
var util;
try {
  util = __webpack_require__(40);
} catch (err) {}

var boundary = "Boundary-" + NSUUID.UUID().UUIDString();

module.exports = function FormData() {
  var data = NSMutableData.data();
  return {
    _boundary: boundary,
    _isFormData: true,
    _data: data,
    append: function(field, value) {
      data.appendData(
        NSString.alloc()
          .initWithString("--" + boundary + "\r\n")
          .dataUsingEncoding(NSUTF8StringEncoding)
      );
      data.appendData(
        NSString.alloc()
          .initWithString(
            'Content-Disposition: form-data; name="' + field + '"'
          )
          .dataUsingEncoding(NSUTF8StringEncoding)
      );
      if (util ? util.isString(value) : typeof value === "string") {
        data.appendData(
          NSString.alloc()
            .initWithString("\r\n\r\n" + value)
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
      } else if (value && value.fileName && value.data && value.mimeType) {
        var nsdata;
        if (Buffer && Buffer.isBuffer(value.data)) {
          nsdata = value.data.toNSData();
        } else if (
          value.data.isKindOfClass &&
          value.data.isKindOfClass(NSData) == 1
        ) {
          nsdata = value.data;
        } else {
          throw new Error("unknown data type");
        }
        data.appendData(
          NSString.alloc()
            .initWithString(
              '; filename="' +
                value.fileName +
                '"\r\nContent-Type: ' +
                value.mimeType +
                "\r\n\r\n"
            )
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        data.appendData(nsdata);
      } else {
        throw new Error("unknown value type");
      }
      data.appendData(
        NSString.alloc()
          .initWithString("\r\n")
          .dataUsingEncoding(NSUTF8StringEncoding)
      );
    }
  };
};


/***/ }),
/* 26 */
/***/ (function(module, exports) {

module.exports = {
  JS_BRIDGE: '__skpm_sketchBridge',
  JS_BRIDGE_RESULT_SUCCESS: '__skpm_sketchBridge_success',
  JS_BRIDGE_RESULT_ERROR: '__skpm_sketchBridge_error',
  START_MOVING_WINDOW: '__skpm_startMovingWindow',
  EXECUTE_JAVASCRIPT: '__skpm_executeJS',
  EXECUTE_JAVASCRIPT_SUCCESS: '__skpm_executeJS_success_',
  EXECUTE_JAVASCRIPT_ERROR: '__skpm_executeJS_error_',
}


/***/ }),
/* 27 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return setListener; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(12);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _parseArtboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5);
/* harmony import */ var _portal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3);


function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }

// import UI from 'sketch/ui';
// import fetch from 'sketch-polyfill-fetch';
// import fs from '@skpm/fs';
// import FormData from 'sketch-polyfill-fetch/lib/form-data';

/* eslint-disable */

/* eslint-disable */

var SELECTED_ARTBOARD_TYPE = {
  selected: 1,
  all: 2
};
// const APP_KEY = '70d52042-60cc-33f7-d388-bda400e931a9';

var setListener = function setListener(webView, browser, context) {
  // webview上传页面，打开项目链接
  webView.on('uploadWebviewOpenLink', function (url) {
    NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
  });

  // webview获取userId，现在没有使用
  webView.on('uploadWebviewGetUserId', function () {
    var userId = Object(_portal__WEBPACK_IMPORTED_MODULE_4__[/* getUserId */ "b"])(context);

    // // console.log('on get user id----', userId);

    return userId;
  });

  // 关闭webview容器
  webView.on('uploadWebviewClose', function () {
    // 取消解析
    Object(_parseArtboard__WEBPACK_IMPORTED_MODULE_3__[/* cancelParse */ "a"])();
    _parseArtboard__WEBPACK_IMPORTED_MODULE_3__[/* parseDocument */ "b"].isCancel = true;
    browser.hide();
    webView.reload();
  });
  // 取消解析
  webView.on('cancelParse', function () {
    Object(_parseArtboard__WEBPACK_IMPORTED_MODULE_3__[/* cancelParse */ "a"])();
    _parseArtboard__WEBPACK_IMPORTED_MODULE_3__[/* parseDocument */ "b"].isCancel = true;
  });

  // webview点击上传时，通过sketch上传文件
  webView.on('uploadWebviewSubmit', function (data) {
    try {
      var document = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Document"].getSelectedDocument();
      if (!document.path) {
        return webView.executeJavaScript("onUploadNotArtboard('\u8BF7\u4FDD\u5B58\u6587\u4EF6\u540E\u518D\u6B21\u4E0A\u4F20')");
      }
      // // 路径处理,不处理中文路径会报错
      // const sketchFilePath = NSURL.URLWithString(
      //     String(
      //         NSString.stringWithString(document.path).stringByExpandingTildeInPath(),
      //     ).replace(/ /g, '%20'),
      // );

      // // console.log('sketchFilePath', sketchFilePath);
      // let artboardIds = 'all';
      console.log('执行到uploadWebviewSubmit');
      var artboards = [];
      // 当前选中的画板;
      if (data.selectedArtBoardType === SELECTED_ARTBOARD_TYPE.selected) {
        artboards = document.selectedLayers.layers.filter(function (layer) {
          return Object(_util__WEBPACK_IMPORTED_MODULE_5__[/* isContainer */ "g"])(layer);
        });
        if (artboards.length === 0) {
          document.pages.forEach(function (page) {
            if (page.selected) {
              artboards = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1___default()(artboards), _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1___default()(page.layers.filter(function (item) {
                return Object(_util__WEBPACK_IMPORTED_MODULE_5__[/* isContainer */ "g"])(item);
              })));
            }
          });
        }
      } else {
        document.pages.forEach(function (page) {
          artboards = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1___default()(artboards), _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_1___default()(page.layers.filter(function (item) {
            return Object(_util__WEBPACK_IMPORTED_MODULE_5__[/* isContainer */ "g"])(item);
          })));
        });
      }

      // console.log(getPluginFolderPath(context), 'getPluginFolderPath(context)');
      // writeFile('', 'artboards.json', artboards, getPluginFolderPath(context));

      var artboardsLength = artboards.length;
      if (artboardsLength === 0) {
        if (+data.selectedArtBoardType === SELECTED_ARTBOARD_TYPE.selected) {
          webView.executeJavaScript("onUploadNotArtboard('\u8BF7\u9009\u62E9\u753B\u677F')");
        } else {
          webView.executeJavaScript("onUploadNotArtboard('\u6587\u6863\u4E2D\u6CA1\u6709\u753B\u677F')");
        }
      } else {
        _parseArtboard__WEBPACK_IMPORTED_MODULE_3__[/* parseDocument */ "b"].isCancel = false;
        webView.executeJavaScript('onUploadStart()');
        var userId = Object(_portal__WEBPACK_IMPORTED_MODULE_4__[/* getUserId */ "b"])(context);
        var pluginFolderPath = Object(_portal__WEBPACK_IMPORTED_MODULE_4__[/* getPluginFolderPath */ "a"])(context);
        Object(_parseArtboard__WEBPACK_IMPORTED_MODULE_3__[/* parseDocument */ "b"])(_objectSpread(_objectSpread({}, data), {}, {
          userId: userId,
          pluginFolderPath: pluginFolderPath,
          artboards: artboards
        }), data.selectedArtBoardType, function (artProgress) {
          // console.log('解析进度artProgress', artProgress);
          // To Be Done 如果超出0.99999,则值不能超出1
          if (artProgress >= 1) {
            artProgress = 1;
          }
          webView
          // 上传成功，将消息传给webview
          .executeJavaScript("onParseProcess('".concat(artProgress, "')")).then(function (_res) {
            // // console.log(_res);
          });
        }, data.isUploadRawResource, data.size).then(function (res) {
          res.artboardsLength = artboardsLength;
          // console.log('解析完成', res);
          webView
          // 上传成功，将消息传给webview
          .executeJavaScript("onParseSuccess(".concat(JSON.stringify(res), ")")).then(function (_res) {
            // // console.log(_res);
          });
        }).catch(function (err) {
          // // console.log('解析失败', err);
          webView.executeJavaScript("onUploadFail(".concat(err, ")"));
        });
      }
    } catch (error) {
      // // console.log(error);
    }

    // const formData = new FormData();

    // try {
    //     formData.append('file', {
    //         fileName: `${document.id}.sketch`,
    //         data: fs.readFileSync(sketchFilePath),
    //         mimeType: 'image/png',
    //     });
    // } catch (error) {
    //     // console.log(error);
    // }

    // const url = `https://parse.58.com/parse/sketch?appKey=${APP_KEY}&artboardIds=${artboardIds}`;

    // fetch(url, {
    //     method: 'POST',
    //     body: formData,
    // }).then(response => response.text())
    //     .then((text) => {
    //         // console.log('上传结果------', text, typeof text);
    //         const resultObj = JSON.parse(text);

    //         resultObj.data = { ...resultObj.data, artboardIds };
    //         webView.executeJavaScript(`onUploadSuccess(${JSON.stringify(resultObj)})`);
    //     })
    //     .catch((err) => {
    //         console.error(err);
    //         webView.executeJavaScript(`onUploadFail(${err})`);
    //     });
  });
};

/***/ }),
/* 28 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export writerLogs */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return logger; });
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_skpm_path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(0);




/**
 * @调用方式
 *      import { logger } from './logs';
 *      logger.info(desc, [mark])
 * @type info | trace | warn | error | fatal | debug
 * @param desc 日志字符串 —— 必填 String
 * @param mark 标记 —— 选填 String
 * @warning 目前只能在主线程写日志，避免循环大量输出日志！避免循环大量输出日志！避免循环大量输出日志！
 */

// 用纽约时间格式 +8个时区 直接拿到北京时间的理想格式 "2021-04-28 15:27:59.620"
function timeStamp() {
  var beijingTime = new Date().getTime();
  var date = new Date(beijingTime + 8 * 3600 * 1000);
  return date.toJSON().substr(0, 23).replace('T', ' ');
}
function writerLogs(payload) {
  var targetPath = getPluginFolderPath();
  _skpm_fs__WEBPACK_IMPORTED_MODULE_0___default.a.appendFileSync("".concat(targetPath, "/.logs"), payload, {
    encoding: 'utf8'
  });
}
function getPluginFolderPath(context) {
  // 创建存储插件数据的文件夹
  var pluginDataPath = _skpm_path__WEBPACK_IMPORTED_MODULE_1___default.a.join(_state__WEBPACK_IMPORTED_MODULE_2__[/* pluginFolderPath */ "k"], '../../hotwheels_data');
  return pluginDataPath;
}
function LogsCreater(mark) {
  this.mark = mark || 'default';
}
LogsCreater.prototype.info = function (desc, mark) {
  this.options2text('INFO', desc, mark);
};
LogsCreater.prototype.trace = function (desc, mark) {
  this.options2text('TRACE', desc, mark);
};
LogsCreater.prototype.warn = function (desc, mark) {
  this.options2text('WARN', desc, mark);
};
LogsCreater.prototype.error = function (desc, mark) {
  this.options2text('ERROR', desc, mark);
};
LogsCreater.prototype.fatal = function (desc, mark) {
  this.options2text('FATAL', desc, mark);
};
LogsCreater.prototype.debug = function (desc, mark) {
  this.options2text('DEBUG', desc, mark);
};
LogsCreater.prototype.options2text = function (type, desc, mark) {
  if (!type || !desc) return;
  var _mark = mark || this.mark;
  if (typeof type !== 'string') type += '';
  if (typeof desc !== 'string') desc += '';
  if (typeof _mark !== 'string') _mark += '';
  var time = timeStamp();
  var printLog = "[".concat(time, "] [").concat(type, "] [").concat(_mark, "] - ").concat(desc, "\r");
  this.ptrintLog(printLog);
};
LogsCreater.prototype.ptrintLog = function (log) {
  if (!process && process.env && "production" === 'development') {
    console.log(log);
  } else {
    writerLogs(log);
  }
};
var logger = new LogsCreater();

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoArtboardLowcodeParse = exports.picassoArtboardOperationCodeParse = exports.picassoArtboardCodeParse = exports.picassoArtboardMeatureParse = void 0;
const parseDSL_1 = __webpack_require__(79);
const parseArtboard_1 = __webpack_require__(104);
const handleClassName_1 = __webpack_require__(120);
const operationLayout_1 = __webpack_require__(122);
const src_1 = __webpack_require__(123);
const src_2 = __webpack_require__(138);
// import * as fs from 'fs';
/**
 * @description Picasso 画板标注解析方法
 * @param { SKLayer } layer 当前图层
 * @returns { Promise<DSL> }
 *
 */
exports.picassoArtboardMeatureParse = (layer) => {
    // 画板处理
    layer = parseArtboard_1.default(layer, 'measure');
    // DSL处理
    const DSL = parseDSL_1.default([layer], 'measure');
    // fs.writeFileSync('./meature_dsl_result.json',JSON.stringify(DSL,null,2));
    return DSL[0];
};
/**
 * @description Picasso 画板代码解析方法
 * @param { SKLayer } layer 当前图层
 * @returns { Promise<DSL> }
 *
 */
exports.picassoArtboardCodeParse = (layer) => {
    // fs.writeFileSync('./code_dsl_1.json',JSON.stringify(layer,null,2));
    // 画板处理
    layer = parseArtboard_1.default(layer, 'code');
    // fs.writeFileSync('./code_dsl_2.json',JSON.stringify(layer,null,2));
    // 1.DSL处理
    let DSL = parseDSL_1.default([layer], 'code');
    // fs.writeFileSync('./code_dsl_3.json',JSON.stringify(DSL,null,2));
    // 2. 特征分组
    DSL = src_1.default(DSL);
    // fs.writeFileSync('./code_dsl_4.json',JSON.stringify(DSL,null,2));
    // 3. 布局处理
    DSL = src_2.default(DSL);
    // fs.writeFileSync('./code_dsl_5.json',JSON.stringify(DSL,null,2));
    // 4. 添加className
    DSL = handleClassName_1.default(DSL);
    // fs.writeFileSync('./code_dsl_6.json',JSON.stringify(DSL,null,2));
    return DSL[0];
};
/**
 *
 * @description Picasso运营版代码生成
 * @param { SKLayer } layer 当前图层
 * @returns { Promise<DSL> }
 *
 */
exports.picassoArtboardOperationCodeParse = (layer) => {
    // 画板处理
    layer = parseArtboard_1.default(layer, 'code');
    // 1.DSL处理
    let DSL = parseDSL_1.default([layer], 'code');
    // 2. 运营版布局
    DSL = operationLayout_1.default(DSL);
    // 3. 添加className
    DSL = handleClassName_1.default(DSL);
    return DSL[0];
};
/**
 * @description Picasso Lowcode-海葵组件
 * @param { SKLayer } layer 当前图层
 * @returns { Promise<DSL> }
 */
exports.picassoArtboardLowcodeParse = (layer) => {
    // 画板处理
    layer = parseArtboard_1.default(layer, 'lowcode');
    // 1.DSL处理
    let DSL = parseDSL_1.default([layer], 'lowcode');
    // 2. 特征分组
    DSL = src_1.default(DSL);
    // 3. 布局处理
    DSL = src_2.default(DSL);
    // fs.writeFileSync('./lowcode_dsl.json',JSON.stringify(DSL,null,2));
    return DSL[0];
};
// 代码生成
__exportStar(__webpack_require__(155), exports);
// sketch DSL
__exportStar(__webpack_require__(19), exports);


/***/ }),
/* 30 */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {module.exports.getURL = function getURL(path) {
  return NSURL.URLWithString(
    String(
      NSString.stringWithString(path).stringByExpandingTildeInPath()
    ).replace(/ /g, '%20')
  )
}

module.exports.runDialog = function runDialog(dialog, getResult, document) {
  if (!document) {
    var returnCode = dialog.runModal()
    return Promise.resolve(getResult(dialog, returnCode))
  }

  var fiber = coscript.createFiber()

  var window = (document.sketchObject || document).documentWindow()

  return new Promise(function p(resolve, reject) {
    dialog.beginSheetModalForWindow_completionHandler(
      window,
      __mocha__.createBlock_function('v16@?0q8', function onCompletion(
        _returnCode
      ) {
        try {
          resolve(getResult(dialog, _returnCode))
        } catch (err) {
          reject(err)
        }
        NSApp.endSheet(dialog)
        if (fiber) {
          fiber.cleanup()
        } else {
          coscript.shouldKeepAround = false
        }
      })
    )
  })
}

module.exports.runDialogSync = function runDialog(dialog, getResult, document) {
  var returnCode

  if (!document) {
    returnCode = dialog.runModal()
    return getResult(dialog, returnCode)
  }

  var window = (document.sketchObject || document).documentWindow()

  dialog.beginSheetModalForWindow_completionHandler(
    window,
    __mocha__.createBlock_function('v16@?0q8', function onCompletion(
      _returnCode
    ) {
      NSApp.stopModalWithCode(_returnCode)
    })
  )

  returnCode = NSApp.runModalForWindow(window)
  NSApp.endSheet(dialog)
  return getResult(dialog, returnCode)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.uniqueId = void 0;
exports.uniqueId = () => {
    return Math.random().toString(32).substr(2, 8);
};


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(144), exports);
__exportStar(__webpack_require__(145), exports);
__exportStar(__webpack_require__(146), exports);
__exportStar(__webpack_require__(147), exports);
__exportStar(__webpack_require__(48), exports);
__exportStar(__webpack_require__(148), exports);
__exportStar(__webpack_require__(149), exports);
__exportStar(__webpack_require__(150), exports);
__exportStar(__webpack_require__(47), exports);


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoTrans = void 0;
// import * as fs from 'fs'
const formateDslStyle_1 = __webpack_require__(160);
const transRNStyle_1 = __webpack_require__(163);
const transAndroidCode_1 = __webpack_require__(164);
const transIOSCode_1 = __webpack_require__(165);
const transWebCode_1 = __webpack_require__(166);
const transPanel_1 = __webpack_require__(167);
const transScale_1 = __webpack_require__(168);
const types_1 = __webpack_require__(169);
__exportStar(__webpack_require__(203), exports);
__exportStar(__webpack_require__(54), exports);
/**
 *
 * @param {Array} data DSL
 * @param {Number} remScale rem换算参数
 * @returns 处理后的DSL样式
 */
exports.picassoTrans = (data, { scale = types_1.WebScale.Points, unit = types_1.Unit.WebPx, colorFormat = types_1.ColorFormat.RGBA, codeType = types_1.CodeType.WebPx, }) => {
    // 属性面板处理
    data = transPanel_1.transPanel(data, { scale, unit, colorFormat, codeType });
    // fs.writeFileSync('./test/transPanel_code_dsl.json', JSON.stringify(data, null,2));
    // 画板宽度
    // const artboardWidth = data[0].structure.width * scale;
    const scaleData = transScale_1.transScale(data, { scale, unit, colorFormat, codeType });
    // fs.writeFileSync('./test/scaleData_code_dsl.json', JSON.stringify(scaleData, null,2));
    switch (codeType) {
        case types_1.CodeType.WebPx:
            const codeData = formateDslStyle_1.formateDslStyle(scaleData);
            // fs.writeFileSync('./test/web_code_dsl_10.json', JSON.stringify(codeData, null,2));
            const webCodeData = transWebCode_1.transWebCode(data, codeData);
            // fs.writeFileSync('./test/web_code_dsl_11.json', JSON.stringify(webCodeData, null,2));
            return webCodeData;
        // return transWebCode(data, codeData)
        case types_1.CodeType.WebRem:
            // 样式转换px
            const dataPx = formateDslStyle_1.formateDslStyle(scaleData);
            // fs.writeFileSync('./test/web_code_dsl_12.json', JSON.stringify(dataPx, null,2));
            // 样式转换rem
            const dataRem = formateDslStyle_1.formateDslRemStyle(dataPx, 1);
            // fs.writeFileSync('./test/web_code_dsl_13.json', JSON.stringify(dataRem, null,2));
            const remCodeData = transWebCode_1.transWebCode(data, dataRem);
            // fs.writeFileSync('./test/web_code_dsl_14.json', JSON.stringify(remCodeData, null,2));
            return remCodeData;
        case types_1.CodeType.Weapp:
            // 样式转换px
            const dataweappPx = formateDslStyle_1.formateDslStyle(scaleData);
            // 样式转换rpx
            const dataRpx = formateDslStyle_1.formatDslRpxStyle(dataweappPx, 1);
            return transWebCode_1.transWebCode(data, dataRpx);
        case types_1.CodeType.ReactNative:
            const codeRNData = transRNStyle_1.transRNStyle(scaleData);
            return transWebCode_1.transWebCode(data, codeRNData);
        case types_1.CodeType.IOS:
            return transIOSCode_1.transIOSCode(data);
        case types_1.CodeType.Android:
            return transAndroidCode_1.transAndroidCode(data);
        default:
            break;
    }
};


/***/ }),
/* 35 */
/***/ (function(module, exports) {

/* globals MOClassDescription, NSObject, NSSelectorFromString, NSClassFromString, MOPropertyDescription */

module.exports = function MochaDelegate(definition, superclass) {
  var uniqueClassName =
    'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
    uniqueClassName,
    superclass || NSObject
  )

  // Storage
  var handlers = {}
  var ivars = {}

  // Define an instance method
  function setHandlerForSelector(selectorString, func) {
    var handlerHasBeenSet = selectorString in handlers
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      // eslint-disable-next-line no-eval
      var dynamicFunction = eval(
        '(function (' +
          args.join(', ') +
          ') { return handlers[selectorString].apply(this, arguments); })'
      )

      delegateClassDesc.addInstanceMethodWithSelector_function(
        selector,
        dynamicFunction
      )
    }
  }

  // define a property
  function setIvar(key, value) {
    var ivarHasBeenSet = key in handlers

    ivars[key] = value

    if (!ivarHasBeenSet) {
      delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, '@')
      var description = MOPropertyDescription.new()
      description.name = key
      description.typeEncoding = '@'
      description.weak = true
      description.ivarName = key
      delegateClassDesc.addProperty(description)
    }
  }

  this.getClass = function() {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function(instanceVariables) {
    var instance = NSClassFromString(uniqueClassName).new()
    Object.keys(ivars).forEach(function(key) {
      instance[key] = ivars[key]
    })
    Object.keys(instanceVariables || {}).forEach(function(key) {
      instance[key] = instanceVariables[key]
    })
    return instance
  }
  // alias
  this.new = this.getClassInstance

  // Convenience
  if (typeof definition === 'object') {
    Object.keys(definition).forEach(
      function(key) {
        if (typeof definition[key] === 'function') {
          setHandlerForSelector(key, definition[key])
        } else {
          setIvar(key, definition[key])
        }
      }
    )
  }

  delegateClassDesc.registerClass()
}


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(37);

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 37 */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 38 */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var CONSTANTS = __webpack_require__(26)

module.exports = function (webview, browserWindow) {
  function executeJavaScript(script, userGesture, callback) {
    if (typeof userGesture === 'function') {
      callback = userGesture
      userGesture = false
    }
    var fiber = coscript.createFiber()

    // if the webview is not ready yet, defer the execution until it is
    if (
      webview.navigationDelegate().state &&
      webview.navigationDelegate().state.wasReady == 0
    ) {
      return new Promise(function (resolve, reject) {
        browserWindow.once('ready-to-show', function () {
          executeJavaScript(script, userGesture, callback)
            .then(resolve)
            .catch(reject)
          fiber.cleanup()
        })
      })
    }

    return new Promise(function (resolve, reject) {
      var requestId = Math.random()

      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
        function (res) {
          try {
            if (callback) {
              callback(null, res)
            }
            resolve(res)
          } catch (err) {
            reject(err)
          }
          fiber.cleanup()
        }
      )
      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
        function (err) {
          try {
            if (callback) {
              callback(err)
              resolve()
            } else {
              reject(err)
            }
          } catch (err2) {
            reject(err2)
          }
          fiber.cleanup()
        }
      )

      webview.evaluateJavaScript_completionHandler(
        module.exports.wrapScript(script, requestId),
        null
      )
    })
  }

  return executeJavaScript
}

module.exports.wrapScript = function (script, requestId) {
  return (
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    '(' +
    requestId +
    ', ' +
    JSON.stringify(script) +
    ')'
  )
}

module.exports.injectScript = function (webView) {
  var source =
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    ' = function(id, script) {' +
    '  try {' +
    '    var res = eval(script);' +
    '    if (res && typeof res.then === "function" && typeof res.catch === "function") {' +
    '      res.then(function (res2) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res2);' +
    '      })' +
    '      .catch(function (err) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '      })' +
    '    } else {' +
    '      window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res);' +
    '    }' +
    '  } catch (err) {' +
    '    window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '  }' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 40 */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(31)

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSOpenPanel.openPanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    dialog.allowedFileTypes = exts
  }

  var hasProperty =
    Array.isArray(options.properties) && options.properties.length > 0
  dialog.canChooseFiles =
    hasProperty && options.properties.indexOf('openFile') !== -1
  dialog.canChooseDirectories =
    hasProperty && options.properties.indexOf('openDirectory') !== -1
  dialog.allowsMultipleSelection =
    hasProperty && options.properties.indexOf('multiSelections') !== -1
  dialog.showsHiddenFiles =
    hasProperty && options.properties.indexOf('showHiddenFiles') !== -1
  dialog.canCreateDirectories =
    hasProperty && options.properties.indexOf('createDirectory') !== -1
  dialog.resolvesAliases =
    !hasProperty || options.properties.indexOf('noResolveAliases') === -1
  dialog.treatsFilePackagesAsDirectories =
    hasProperty && options.properties.indexOf('treatPackageAsDirectory') !== -1

  if (options.message) {
    dialog.message = options.message
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogbrowserwindow-options
module.exports.openDialog = function openDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return {
          canceled: true,
          filePaths: [],
        }
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return {
        canceled: false,
        filePaths: result,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowopendialogsyncbrowserwindow-options
module.exports.openDialogSync = function openDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      if (returnCode != NSOKButton) {
        return []
      }
      var result = []
      var urls = _dialog.URLs()
      for (var k = 0; k < urls.length; k += 1) {
        result.push(String(urls[k].path()))
      }
      return result
    },
    setup.document
  )
}


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(31)

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  }
  if (!options) {
    options = {}
  }

  var dialog = NSSavePanel.savePanel()

  if (options.title) {
    dialog.title = options.title
  }

  if (options.defaultPath) {
    // that's a path
    dialog.setDirectoryURL(utils.getURL(options.defaultPath))

    if (
      options.defaultPath[0] === '.' ||
      options.defaultPath[0] === '~' ||
      options.defaultPath[0] === '/'
    ) {
      var parts = options.defaultPath.split('/')
      if (parts.length > 1 && parts[parts.length - 1]) {
        dialog.setNameFieldStringValue(parts[parts.length - 1])
      }
    } else {
      dialog.setNameFieldStringValue(options.defaultPath)
    }
  }

  if (options.buttonLabel) {
    dialog.prompt = options.buttonLabel
  }

  if (options.filters && options.filters.length) {
    var exts = []
    options.filters.forEach(function setFilter(filter) {
      filter.extensions.forEach(function setExtension(ext) {
        exts.push(ext)
      })
    })

    if (dialog.allowedContentTypes) {
      // Big Sur and newer.
      dialog.allowedContentTypes = exts.map((ext) => UTType.typeWithFilenameExtension(ext))
    } else {
      // Catalina and older.
      dialog.allowedFileTypes = exts
    }
  }

  if (options.message) {
    dialog.message = options.message
  }

  if (options.nameFieldLabel) {
    dialog.nameFieldLabel = options.nameFieldLabel
  }

  if (options.showsTagField) {
    dialog.showsTagField = options.showsTagField
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogbrowserwindow-options
module.exports.saveDialog = function saveDialog(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        canceled: returnCode != NSOKButton,
        filePath:
          returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowsavedialogsyncbrowserwindow-options
module.exports.saveDialogSync = function saveDialogSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return returnCode == NSOKButton ? String(_dialog.URL().path()) : undefined
    },
    setup.document
  )
}


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

/* eslint-disable no-not-accumulator-reassign/no-not-accumulator-reassign */
var utils = __webpack_require__(31)

var typeMap = {
  none: 0,
  info: 1,
  error: 2,
  question: 1,
  warning: 2,
}

function setupOptions(document, options) {
  if (
    !document ||
    (typeof document.isKindOfClass !== 'function' && !document.sketchObject)
  ) {
    options = document
    document = undefined
  } else if (document.sketchObject) {
    document = document.sketchObject
  }
  if (!options) {
    options = {}
  }

  var dialog = NSAlert.alloc().init()

  if (options.type) {
    dialog.alertStyle = typeMap[options.type] || 0
  }

  if (options.buttons && options.buttons.length) {
    options.buttons.forEach(function addButton(button) {
      dialog.addButtonWithTitle(
        options.normalizeAccessKeys ? button.replace(/&/g, '') : button
      )
      // TODO: add keyboard shortcut if options.normalizeAccessKeys
    })
  }

  if (typeof options.defaultId !== 'undefined') {
    var buttons = dialog.buttons()
    if (options.defaultId < buttons.length) {
      // Focus the button at defaultId if the user opted to do so.
      // The first button added gets set as the default selected.
      // So remove that default, and make the requested button the default.
      buttons[0].setKeyEquivalent('')
      buttons[options.defaultId].setKeyEquivalent('\r')
    }
  }

  if (options.title) {
    // not shown on macOS
  }

  if (options.message) {
    dialog.messageText = options.message
  }

  if (options.detail) {
    dialog.informativeText = options.detail
  }

  if (options.checkboxLabel) {
    dialog.showsSuppressionButton = true
    dialog.suppressionButton().title = options.checkboxLabel

    if (typeof options.checkboxChecked !== 'undefined') {
      dialog.suppressionButton().state = options.checkboxChecked
        ? NSOnState
        : NSOffState
    }
  }

  if (options.icon) {
    if (typeof options.icon === 'string') {
      options.icon = NSImage.alloc().initWithContentsOfFile(options.icon)
    }
    dialog.icon = options.icon
  } else if (
    typeof __command !== 'undefined' &&
    __command.pluginBundle() &&
    __command.pluginBundle().icon()
  ) {
    dialog.icon = __command.pluginBundle().icon()
  } else {
    var icon = NSImage.imageNamed('plugins')
    if (icon) {
      dialog.icon = icon
    }
  }

  return {
    document: document,
    options: options,
    dialog: dialog,
  }
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxbrowserwindow-options
module.exports.messageBox = function messageBox(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialog(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return {
        response:
          setup.options.buttons && setup.options.buttons.length
            ? Number(returnCode) - 1000
            : Number(returnCode),
        checkboxChecked: _dialog.suppressionButton().state() == NSOnState,
      }
    },
    setup.document
  )
}

// https://github.com/electron/electron/blob/master/docs/api/dialog.md#dialogshowmessageboxsyncbrowserwindow-options
module.exports.messageBoxSync = function messageBoxSync(document, options) {
  var setup = setupOptions(document, options)

  return utils.runDialogSync(
    setup.dialog,
    function getResult(_dialog, returnCode) {
      return setup.options.buttons && setup.options.buttons.length
        ? Number(returnCode) - 1000
        : Number(returnCode)
    },
    setup.document
  )
}


/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.fontSizeLineHeightMap = exports.fontWeightTypes = void 0;
/**
 * 字体类型
 */
exports.fontWeightTypes = ["black", "heavy", "ultrabold", "extrabold", "bold", "boldmt", "psboldmt", "semibold", "demibold", "medium", "roman", "regular", "normal", "book", "light", "extralight", "ultralight", "thin"];
/**
 * 0-60 字体行高映射表
 * fontSize => lineHeight
 */
exports.fontSizeLineHeightMap = [0, 1, 3, 4, 5, 7, 8, 9, 11, 13, 14, 16, 17, 18, 20, 21, 22, 24, 25, 26, 28, 29, 30, 32, 33, 36, 37, 38, 40, 41, 42, 44, 45, 46, 48, 49, 50, 52, 53, 54, 56, 57, 59, 61, 62, 63, 65, 66, 67, 59, 70, 71, 73, 74, 75, 77, 78, 79, 81, 83, 84];


/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(11);
exports.default = (fillStyle, layer) => {
    let { alpha, red, green, blue } = fillStyle.color;
    // 如果设置了 Opacity 属性，则 fills border 需要乘于这个数值
    if (layer.style && layer.style.contextSettings) {
        alpha = layer.style.contextSettings.opacity * alpha;
    }
    if (alpha > 0) {
        return {
            color: utils_1.transSketchColor({ red, green, blue, alpha }),
        };
    }
    return {};
};


/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 计算两点之间的距离
 * 根据X轴方向判断正负
 *
 * @param {*} startX
 * @param {*} startY
 * @param {*} endX
 * @param {*} endY
 * @returns
 */
exports.default = (startX, startY, endX, endY) => {
    let x = endX - startX;
    let y = endY - startY;
    if (x >= 0) {
        return Math.sqrt(x * x + y * y);
    }
    else {
        return -Math.sqrt(x * x + y * y);
    }
};


/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.utils = void 0;
// 公用方法
exports.utils = {
    // 判断是否等宽
    isEqualWidth(data) {
        // 判断所有的元素是否等宽
        let setList = new Set();
        for (let item of data) {
            setList.add(item.structure.width);
        }
        let ary = [...new Set(setList)];
        return ary.length == 1 ? true : false;
    },
    // 判断所有的子元素是否中线对齐
    isAlignMiddle(data, parent) {
        let middlePos = parent.structure.y + parent.structure.height / 2;
        let isAlignMiddle = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if (Math.abs(item.structure.y + item.structure.height / 2 - middlePos) > 2) {
                // 允许 2px 误差
                isAlignMiddle = false;
                break;
            }
        }
        return isAlignMiddle;
    },
    isEqualHeight(data) {
        // 判断所有的元素是否等宽
        let setList = new Set();
        for (let item of data) {
            setList.add(item.structure.height);
        }
        let ary = [...new Set(setList)];
        return ary.length == 1 ? true : false;
    },
    // 第一层级只包含一个文本节点
    hasTextType(data) {
        if (data.type == "Text")
            return true; // 自身是文本的情况返回 true
        if (data.children) {
            let textList = [];
            for (let item of data.children) {
                if (item.type == "Text") {
                    textList.push(item);
                }
            }
            return textList.length == 1;
        }
        return false;
    },
    // 多行之间判断是否是否相同间距
    isSameSpacing(data) {
        let flag = true;
        let space = data[1].structure.x - data[0].structure.x - data[0].structure.width;
        for (let i = 1; i < data.length; i++) {
            if (data[i].structure.y == data[i - 1].structure.y &&
                Math.abs(data[i].structure.x - data[i - 1].structure.x - data[i - 1].structure.width - space) > 4 ||
                (!data[i].structure.x && data[i].structure.x !== 0)) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 是否有边框
    hasBorder(data) {
        var _a;
        let flag = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if (!((_a = item.structure) === null || _a === void 0 ? void 0 : _a.border)) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 是否有背景
    hasBackground(data) {
        var _a;
        let flag = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if ((_a = item.style) === null || _a === void 0 ? void 0 : _a.background) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 判断所有的子元素和父元素的高度是否一致
    isSameParentHeight(data, parent) {
        let flag = true;
        for (let i = 0; i < data.length; i++) {
            let item = data[i];
            if (item.structure.height != parent.structure.height) {
                flag = false;
                break;
            }
        }
        return flag;
    },
    // 判断水平方向子元素贴近父元素
    isHorizontalCloseParent(data, parent) {
        if (data.length < 2)
            return false;
        // 两个元素组合位于父元素中间
        return (data[0].structure.x == parent.structure.x &&
            Math.abs(data[data.length - 1].structure.x +
                data[data.length - 1].structure.width -
                parent.structure.x -
                parent.structure.width) < 2);
    },
    // 判断垂直方向子元素贴近父元素
    isVerticalCloseParent(data, parent) {
        if (data.length < 2)
            return false;
        // 两个元素组合位于父元素中间
        return (data[0].structure.y == parent.structure.y &&
            Math.abs(data[data.length - 1].structure.y +
                data[data.length - 1].structure.height -
                parent.structure.y -
                parent.structure.height) < 2);
    }
};


/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isLine = void 0;
/**
 * 判断同层元素是否都在同一行
 *
 * @param {Array} data 同层元素数组
 */
exports.isLine = (data) => {
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        for (let j = i; j < data.length; j++) {
            const itemJ = data[j];
            if (itemJ.structure.y >= item.structure.y + item.structure.height || item.structure.y >= itemJ.structure.y + itemJ.structure.height) {
                return false;
            }
        }
    }
    return true;
};


/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CLASS_TYPE = void 0;
exports.CLASS_TYPE = {
    "NORMAL": 1,
    "RELY_ON_PARENT": 2,
    "RELY_ON_CHILD_AND_PARENT": 3,
};


/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoWebCode = void 0;
const generateScss_1 = __webpack_require__(156);
const generateCSS_1 = __webpack_require__(158);
const generateBody_1 = __webpack_require__(159);
const src_1 = __webpack_require__(34);
const src_2 = __webpack_require__(19);
/**
 * 生成局部代码
 * @description Picasso生成代码
 * @param {Layer[]} data
 * @param {string} outputPath 生成代码存放路径
 */
exports.picassoWebCode = (data, size) => {
    try {
        const platform = [375, 750].includes(Math.round(size)) ? 2 : 1;
        // 4. 样式处理
        data = src_1.picassoTrans(data, {
            scale: src_2.WebScale.Points,
            unit: src_2.Unit.WebPx,
            colorFormat: src_2.ColorFormat.RGBA,
            codeType: src_2.CodeType.WebPx,
        });
        // 生成 body
        const body = generateBody_1.default(data, '');
        let scss = '';
        // 生成scss
        scss += generateScss_1.default(data, size);
        // 生成css
        const css = generateCSS_1.default(data, size, platform);
        return {
            scss,
            css,
            html: body,
            vueHtml: body,
            reactHtml: body.replace(/class=/ig, 'className='),
        };
    }
    catch (error) {
        console.log(error);
    }
};


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const cssOrder_1 = __webpack_require__(157);
/**
 * margin合并
 * @param {Object} styleOrderObj 样式
 */
const mergeMargin = (styleOrderObj) => {
    let marginTop = 0, marginRight = 0, marginBottom = 0, marginLeft = 0;
    let num = 0;
    if (styleOrderObj['margin-top']) {
        num++;
        marginTop = styleOrderObj['margin-top'];
    }
    if (styleOrderObj['margin-right']) {
        num++;
        marginRight = styleOrderObj['margin-right'];
    }
    if (styleOrderObj['margin-bottom']) {
        num++;
        marginBottom = styleOrderObj['margin-bottom'];
    }
    if (styleOrderObj['margin-left']) {
        num++;
        marginLeft = styleOrderObj['margin-left'];
    }
    if (num >= 2) {
        if (marginBottom == marginLeft && marginLeft == marginRight && marginRight == marginTop) {
            styleOrderObj['margin'] = `${marginTop}`;
        }
        else if (marginBottom == marginTop && marginLeft == marginRight) {
            styleOrderObj['margin'] = `${marginTop} ${marginRight}`;
        }
        else if (marginLeft == marginRight) {
            styleOrderObj['margin'] = `${marginTop} ${marginRight} ${marginBottom}`;
        }
        else {
            styleOrderObj['margin'] = `${marginTop} ${marginRight} ${marginBottom} ${marginLeft}`;
        }
        delete styleOrderObj['margin-top'];
        delete styleOrderObj['margin-right'];
        delete styleOrderObj['margin-bottom'];
        delete styleOrderObj['margin-left'];
    }
    if (styleOrderObj['margin-right'] == 'auto') {
        delete styleOrderObj['margin-right'];
    }
    if (styleOrderObj['margin-left'] == 'auto') {
        delete styleOrderObj['margin-left'];
    }
    return styleOrderObj;
};
/**
 * css 格式化
 */
exports.default = (styleObj) => {
    if (styleObj instanceof Object && Object.keys(styleObj).length > 0) {
        let styleKeysList = Object.keys(styleObj);
        let styleOrderObj = {};
        for (let i = 0; i < styleKeysList.length; i++) {
            if ((styleObj[styleKeysList[i]] / 1 != 0) || styleKeysList[i] === 'left' || styleKeysList[i] === 'top') {
                if (!((styleKeysList[i] == 'width' && styleObj[styleKeysList[i]] == 'auto') ||
                    (styleKeysList[i] == 'font-weight' && styleObj[styleKeysList[i]] == 400) ||
                    (styleKeysList[i] == 'flex-direction' && styleObj[styleKeysList[i]] == 'row') ||
                    (styleKeysList[i] == 'text-align' && styleObj[styleKeysList[i]] == 'left'))) {
                    if (!isNaN(styleObj[styleKeysList[i]] / 1) && 'font-weight' != styleKeysList[i] && 'flex' != styleKeysList[i]) {
                        styleOrderObj[styleKeysList[i]] = styleObj[styleKeysList[i]] + 'px';
                    }
                    else {
                        styleOrderObj[styleKeysList[i]] = styleObj[styleKeysList[i]];
                    }
                }
            }
        }
        // 合并margin
        styleOrderObj = mergeMargin(styleOrderObj);
        // 生成的样式排序
        let styleKeysList2 = Object.keys(styleOrderObj);
        styleKeysList2.sort((a, b) => {
            return cssOrder_1.default(a) - cssOrder_1.default(b);
        });
        let styleOrderObj2 = {};
        for (let i = 0; i < styleKeysList2.length; i++) {
            styleOrderObj2[styleKeysList2[i]] = styleOrderObj[styleKeysList2[i]];
        }
        return styleOrderObj2;
    }
    else {
        return {};
    }
};


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.generateMargin = exports.generateBorderRadius = exports.generateProperty = exports.generateColor = void 0;
exports.generateColor = ({ red = '', green = '', blue = '', alpha = 1, } = {}) => {
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
};
// border处理
exports.generateProperty = (obj) => {
    let rst = {};
    if (Object.prototype.toString.call(obj) !== "[object Object]")
        return rst;
    let keys = Object.keys(obj);
    if (!keys || !keys.length)
        return rst;
    const isObjValEqual = (obj1, obj2) => {
        let isEqual = true;
        let objItem = Object.keys(obj1);
        for (let i = 0; i < objItem.length; i++) {
            if (objItem[i] == 'color') {
                if (obj1.color.alpha != obj2.color.alpha ||
                    obj1.color.red != obj2.color.red ||
                    obj1.color.blue != obj2.color.blue ||
                    obj1.color.green != obj2.color.green) {
                    isEqual = false;
                }
            }
            else {
                if (obj1[objItem[i]] != obj2[objItem[i]]) {
                    isEqual = false;
                    break;
                }
            }
        }
        return isEqual;
    };
    // 判断四个方向的值都是一样的
    if (keys.length == 4 &&
        isObjValEqual(obj.top, obj.bottom) &&
        isObjValEqual(obj.left, obj.right) &&
        isObjValEqual(obj.top, obj.left)) {
        let { width, color, style } = obj.left;
        rst.border = `${width}px ${style} ${exports.generateColor(color)}`;
    }
    else {
        for (let key of keys) {
            // top right bottom left
            if (obj[key] != undefined) {
                let { width, color, style } = obj[key];
                rst[`border-${key}`] = `${width}px ${style} ${exports.generateColor(color)}`;
            }
        }
    }
    return rst;
};
// border-radius处理
exports.generateBorderRadius = (obj) => {
    if (typeof obj == 'string')
        return obj;
    if (typeof obj == 'object') {
        let values = Object.values(obj);
        if (!values.length || (!values[0] && !values[1] && !values[2] && !values[3]))
            return '';
        if (values.length == 4 && new Set(values).size === 1) {
            return typeof obj.topLeft === 'string' ? obj.topLeft : `${obj.topLeft}px`;
        }
        return `${obj.topLeft}px ${obj.topRight}px ${obj.bottomRight}px ${obj.bottomLeft}px`;
    }
};
// margin、padding处理
exports.generateMargin = (obj) => {
    if (typeof obj == 'string')
        return obj;
    if (typeof obj == 'object') {
        let values = Object.values(obj);
        if (!values.length)
            return '';
        if (values.length == 4 && new Set(values).size == 1) {
            return `${obj.top}px`;
        }
        return `${obj.top}px ${obj.right}px ${obj.bottom}px ${obj.left}px`;
    }
};


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * css顺序数组
 */
const cssList = [
    'position',
    'top',
    'right',
    'bottom',
    'left',
    'z-index',
    'display',
    'float',
    'width',
    'height',
    'max-width',
    'max-height',
    'min-width',
    'min-height',
    'padding',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
    'margin',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'margin-collapse',
    'margin-top-collapse',
    'margin-right-collapse',
    'margin-bottom-collapse',
    'margin-left-collapse',
    'overflow',
    'overflow-x',
    'overflow-y',
    'clip',
    'clear',
    'font',
    'font-family',
    'font-size',
    'font-smoothing',
    'osx-font-smoothing',
    'font-style',
    'font-weight',
    'hyphens',
    'src',
    'line-height',
    'letter-spacing',
    'word-spacing',
    'color',
    'text-align',
    'text-decoration',
    'text-indent',
    'text-overflow',
    'text-rendering',
    'text-size-adjust',
    'text-shadow',
    'text-transform',
    'word-break',
    'word-wrap',
    'white-space',
    'vertical-align',
    'list-style',
    'list-style-type',
    'list-style-position',
    'list-style-image',
    'pointer-events',
    'cursor',
    'background',
    'background-attachment',
    'background-color',
    'background-image',
    'background-position',
    'background-repeat',
    'background-size',
    'border',
    'border-collapse',
    'border-top',
    'border-right',
    'border-bottom',
    'border-left',
    'border-color',
    'border-image',
    'border-top-color',
    'border-right-color',
    'border-bottom-color',
    'border-left-color',
    'border-spacing',
    'border-style',
    'border-top-style',
    'border-right-style',
    'border-bottom-style',
    'border-left-style',
    'border-width',
    'border-top-width',
    'border-right-width',
    'border-bottom-width',
    'border-left-width',
    'border-radius',
    'border-top-right-radius',
    'border-bottom-right-radius',
    'border-bottom-left-radius',
    'border-top-left-radius',
    'border-radius-topright',
    'border-radius-bottomright',
    'border-radius-bottomleft',
    'border-radius-topleft',
    'content',
    'quotes',
    'outline',
    'outline-offset',
    'opacity',
    'filter',
    'visibility',
    'size',
    'zoom',
    'transform',
    'box-align',
    'box-flex',
    'box-orient',
    'box-pack',
    'box-shadow',
    'box-sizing',
    'table-layout',
    'animation',
    'animation-delay',
    'animation-duration',
    'animation-iteration-count',
    'animation-name',
    'animation-play-state',
    'animation-timing-function',
    'animation-fill-mode',
    'transition',
    'transition-delay',
    'transition-duration',
    'transition-property',
    'transition-timing-function',
    'background-clip',
    'backface-visibility',
    'resize',
    'appearance',
    'user-select',
    'interpolation-mode',
    'direction',
    'marks',
    'page',
    'set-link-source',
    'unicode-bidi',
    'speak'
];
// 驼峰改连接符
const toKebabCase = (str) => str.replace(/([A-Z])/g, '-$1').toLowerCase();
/**
 * css 排序方法
 */
const order = (item) => {
    // 驼峰转连接符
    item = toKebabCase(item);
    let itemIndex = cssList.length;
    if (cssList.indexOf(item) > -1) {
        itemIndex = cssList.indexOf(item);
    }
    return itemIndex;
};
/**
 * css 格式化
 */
exports.default = (styleObj) => {
    if (styleObj instanceof Object && Object.keys(styleObj).length > 0) {
        // 生成的样式排序
        let styleKeysList = Object.keys(styleObj);
        styleKeysList.sort((a, b) => {
            return order(a) - order(b);
        });
        let styleOrderObj = {};
        for (let i = 0; i < styleKeysList.length; i++) {
            styleOrderObj[styleKeysList[i]] = styleObj[styleKeysList[i]];
        }
        return styleOrderObj;
    }
    else {
        return {};
    }
};


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.colorTrans = exports.color2HSLA = exports.color2RGBA = exports.color2HEXA = exports.color2AHEX = exports.color2HEX = void 0;
/**
 * Color => HEX
 * @param color
 */
exports.color2HEX = (color) => {
    const { red, green, blue, alpha } = color;
    const hex = "#" + ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1);
    return {
        hex: hex.toUpperCase(),
        alpha: `${Math.round(alpha * 100)}%`,
    };
};
/**
 * Color => AHEX
 * @param color
 */
exports.color2AHEX = (color) => {
    const { red, green, blue, alpha } = color;
    const hex = ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1);
    const a = ((1 << 8) + Math.round(alpha * 255)).toString(16).slice(1);
    return "#" + (a + hex).toUpperCase();
};
/**
 * Color => HEXA
 * @param color
 */
exports.color2HEXA = (color) => {
    const { red, green, blue, alpha } = color;
    const hex = ((1 << 24) + (red << 16) + (green << 8) + blue).toString(16).slice(1);
    const a = ((1 << 8) + Math.round(alpha * 255)).toString(16).slice(1);
    return `#${hex.slice(0, 6).toLowerCase()}${a.toUpperCase()}`;
};
/**
 * Color => RGBA
 * @param color
 */
exports.color2RGBA = (color) => {
    const { red, green, blue, alpha } = color;
    return `${red},${green},${blue},${alpha}`;
};
/**
 * Color => HSLA
 * @param color
 */
exports.color2HSLA = (color) => {
    let { red, green, blue, alpha } = color;
    red /= 255, green /= 255, blue /= 255;
    const max = Math.max(red, green, blue), min = Math.min(red, green, blue);
    let h, s, l = (max + min) / 2;
    if (max == min) {
        h = s = 0; // achromatic
    }
    else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
            case red:
                h = (green - blue) / d + (green < blue ? 6 : 0);
                break;
            case green:
                h = (blue - red) / d + 2;
                break;
            case blue:
                h = (red - green) / d + 4;
                break;
        }
        h /= 6;
    }
    return `${Math.round(h * 360)},${Math.round(s * 100)}%,${Math.round(l * 100)}%,${alpha}`;
};
/**
 * Color 产出不同格式的颜色值
 * @param color
 */
exports.colorTrans = (color) => {
    const hex = exports.color2HEX(color);
    const ahex = exports.color2AHEX(color);
    const hexa = exports.color2HEXA(color);
    const rgba = exports.color2RGBA(color);
    const hsla = exports.color2HSLA(color);
    return [{
            type: 'HEX',
            value: hex.hex,
            alpha: hex.alpha
        }, {
            type: 'AHEX',
            value: ahex,
        }, {
            type: 'HEXA',
            value: hexa,
        }, {
            type: 'RGBA',
            value: rgba,
        }, {
            type: 'HSLA',
            value: hsla,
        }];
};


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports._scale = exports.precisionControl = void 0;
/**
 * 精度控制
 * @param data 需要处理的数据
 * @param num 精度 eg. 0.1 0.01
 */
exports.precisionControl = (data, num = 1) => {
    const len = Math.round(1 / num).toString().length - 1;
    return +((Math.round(data / num) * num).toFixed(len));
};
exports._scale = (data, scale) => typeof data === 'number' ? exports.precisionControl(data / scale, 0.01) : data;


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoWeappCode = void 0;
const handleClassName_1 = __webpack_require__(57);
const src_1 = __webpack_require__(34);
const src_2 = __webpack_require__(19);
const generateWXML_1 = __webpack_require__(205);
const generateWXSS_1 = __webpack_require__(206);
/**
 * @description Picasso生成小程序代码
 * @param {Layer[]} data
 * @param { number } size 画板宽度
 */
exports.picassoWeappCode = (data, size) => {
    // class名称处理
    data = handleClassName_1.default(data);
    // 样式处理
    data = src_1.picassoTrans(data, {
        scale: src_2.WebScale.Points,
        unit: src_2.Unit.Weapp,
        colorFormat: src_2.ColorFormat.RGBA,
        codeType: src_2.CodeType.Weapp
    });
    //生成wxml模板
    const wxml = generateWXML_1.default(data);
    //生成wxss代码
    const wxss = generateWXSS_1.default(data, size);
    return {
        wxml,
        wxss
    };
};


/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList_1 = __webpack_require__(204);
const handleClassName = (data, numObj = { num: 0 }) => {
    for (let i = 0; i < data.length; i++) {
        const layer = data[i];
        const currIndex = numObj.num % classNameList_1.default.length; //英文单词下标
        const numIndex = Math.floor(numObj.num / classNameList_1.default.length) + 1; //数字后缀
        layer.className = numIndex > 1 ? classNameList_1.default[currIndex] + numIndex : classNameList_1.default[currIndex];
        numObj.num++;
        if (Array.isArray(layer.children)) {
            layer.children = handleClassName(layer.children, numObj);
        }
    }
    return data;
};
exports.default = handleClassName;


/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoRNCode = void 0;
const handleClassName_1 = __webpack_require__(57);
const src_1 = __webpack_require__(34);
const src_2 = __webpack_require__(19);
const generateJSX_1 = __webpack_require__(207);
const generateStyle_1 = __webpack_require__(208);
/**
 * @description Picasso生成代码
 * @param { Layer[] } data
 * @param { number } size 画板宽度
 */
exports.picassoRNCode = (data, size) => {
    // class 名称处理
    data = handleClassName_1.default(data);
    // 4. 样式处理
    data = src_1.picassoTrans(data, {
        scale: src_2.WebScale.Points,
        unit: src_2.Unit.ReactNative,
        colorFormat: src_2.ColorFormat.RGBA,
        codeType: src_2.CodeType.ReactNative
    });
    // 生成组件
    const jsxCode = generateJSX_1.generateRNJSX(data);
    // 生成样式
    const styleCode = generateStyle_1.generateRNStyle(data);
    return {
        jsx: `import React, { Component } from 'react';
        import {
            Image,
            View,
            Text,
            ImageBackground,
            ScrollView,
            Dimensions,
            StyleSheet,
            SafeAreaView,
            Platform,
            StatusBar,
            PixelRatio,
        } from 'react-native';
        ${/LinearGradient/.test(jsxCode) ? "import LinearGradient from 'react-native-linear-gradient';" : ""}
        
        const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
        
        const scaleSize = (size) => PixelRatio.roundToNearestPixel(size * (SCREEN_WIDTH / ${size}));
        
        const isIphoneX = () => {
            return Platform.OS === 'ios' &&
                !Platform.isPad &&
                !Platform.isTVOS &&
                (SCREEN_HEIGHT === 812 || SCREEN_WIDTH === 812 || SCREEN_WIDTH === 896 || SCREEN_HEIGHT === 896);
        }
            
        const STATUSBAR_HEIGHT = Platform.select({
            ios: isIphoneX() ? 44 : 20,
            android: StatusBar.currentHeight,
        })
        
        export default class PicasoPage extends Component {
            constructor(props) {
                super(props);
            }
        
            componentDidMount() {}
        
            componentWillUnmount() {}
        
            render() {
                return (
                    <ScrollView style={{ flex: 1, width: SCREEN_WIDTH, height: SCREEN_HEIGHT }}>
                        ${jsxCode}
                    </ScrollView>
                )
            }
        }
        
        const styles = StyleSheet.create(${styleCode})
        `
    };
};


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Browser window
(https://github.com/electron/electron/blob/master/docs/api/browser-window.md) */
var EventEmitter = __webpack_require__(38)
var buildBrowserAPI = __webpack_require__(67)
var buildWebAPI = __webpack_require__(68)
var fitSubviewToView = __webpack_require__(69)
var dispatchFirstClick = __webpack_require__(70)
var injectClientMessaging = __webpack_require__(71)
var movableArea = __webpack_require__(72)
var executeJavaScript = __webpack_require__(39)
var setDelegates = __webpack_require__(73)

function BrowserWindow(options) {
  options = options || {}

  var identifier = options.identifier || String(NSUUID.UUID().UUIDString())
  var threadDictionary = NSThread.mainThread().threadDictionary()

  var existingBrowserWindow = BrowserWindow.fromId(identifier)

  // if we already have a window opened, reuse it
  if (existingBrowserWindow) {
    return existingBrowserWindow
  }

  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (options.modal && !options.parent) {
    throw new Error('A modal needs to have a parent.')
  }

  // Long-running script
  var fiber = coscript.createFiber()

  // Window size
  var width = options.width || 800
  var height = options.height || 600
  var mainScreenRect = NSScreen.screens().firstObject().frame()
  var cocoaBounds = NSMakeRect(
    typeof options.x !== 'undefined'
      ? options.x
      : Math.round((NSWidth(mainScreenRect) - width) / 2),
    typeof options.y !== 'undefined'
      ? NSHeight(mainScreenRect) - options.y
      : Math.round((NSHeight(mainScreenRect) - height) / 2),
    width,
    height
  )

  if (options.titleBarStyle && options.titleBarStyle !== 'default') {
    options.frame = false
  }

  var useStandardWindow = options.windowType !== 'textured'
  var styleMask = NSTitledWindowMask

  // this is commented out because the toolbar doesn't appear otherwise :thinking-face:
  // if (!useStandardWindow || options.frame === false) {
  //   styleMask = NSFullSizeContentViewWindowMask
  // }
  if (options.minimizable !== false) {
    styleMask |= NSMiniaturizableWindowMask
  }
  if (options.closable !== false) {
    styleMask |= NSClosableWindowMask
  }
  if (options.resizable !== false) {
    styleMask |= NSResizableWindowMask
  }
  if (!useStandardWindow || options.transparent || options.frame === false) {
    styleMask |= NSTexturedBackgroundWindowMask
  }

  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
    cocoaBounds,
    styleMask,
    NSBackingStoreBuffered,
    true
  )

  // this would be nice but it's crashing on macOS 11.0
  // panel.releasedWhenClosed = true

  var wkwebviewConfig = WKWebViewConfiguration.alloc().init()
  var webView = WKWebView.alloc().initWithFrame_configuration(
    CGRectMake(0, 0, options.width || 800, options.height || 600),
    wkwebviewConfig
  )
  injectClientMessaging(webView)
  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  setDelegates(browserWindow, panel, webView, options)

  if (options.windowType === 'desktop') {
    panel.setLevel(kCGDesktopWindowLevel - 1)
    // panel.setCanBecomeKeyWindow(false)
    panel.setCollectionBehavior(
      NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorStationary |
        NSWindowCollectionBehaviorIgnoresCycle
    )
  }

  if (
    typeof options.minWidth !== 'undefined' ||
    typeof options.minHeight !== 'undefined'
  ) {
    browserWindow.setMinimumSize(options.minWidth || 0, options.minHeight || 0)
  }

  if (
    typeof options.maxWidth !== 'undefined' ||
    typeof options.maxHeight !== 'undefined'
  ) {
    browserWindow.setMaximumSize(
      options.maxWidth || 10000,
      options.maxHeight || 10000
    )
  }

  // if (options.focusable === false) {
  //   panel.setCanBecomeKeyWindow(false)
  // }

  if (options.transparent || options.frame === false) {
    panel.titlebarAppearsTransparent = true
    panel.titleVisibility = NSWindowTitleHidden
    panel.setOpaque(0)
    panel.isMovableByWindowBackground = true
    var toolbar2 = NSToolbar.alloc().initWithIdentifier(
      'titlebarStylingToolbar'
    )
    toolbar2.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar2)
  }

  if (options.titleBarStyle === 'hiddenInset') {
    var toolbar = NSToolbar.alloc().initWithIdentifier('titlebarStylingToolbar')
    toolbar.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar)
  }

  if (options.frame === false || !options.useContentSize) {
    browserWindow.setSize(width, height)
  }

  if (options.center) {
    browserWindow.center()
  }

  if (options.alwaysOnTop) {
    browserWindow.setAlwaysOnTop(true)
  }

  if (options.fullscreen) {
    browserWindow.setFullScreen(true)
  }
  browserWindow.setFullScreenable(!!options.fullscreenable)

  let title = options.title
  if (options.frame === false) {
    title = undefined
  } else if (
    typeof title === 'undefined' &&
    typeof __command !== 'undefined' &&
    __command.pluginBundle()
  ) {
    title = __command.pluginBundle().name()
  }

  if (title) {
    browserWindow.setTitle(title)
  }

  var backgroundColor = options.backgroundColor
  if (options.transparent) {
    backgroundColor = NSColor.clearColor()
  }
  if (!backgroundColor && options.frame === false && options.vibrancy) {
    backgroundColor = NSColor.clearColor()
  }

  browserWindow._setBackgroundColor(
    backgroundColor || NSColor.windowBackgroundColor()
  )

  if (options.hasShadow === false) {
    browserWindow.setHasShadow(false)
  }

  if (typeof options.opacity !== 'undefined') {
    browserWindow.setOpacity(options.opacity)
  }

  options.webPreferences = options.webPreferences || {}

  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.devTools !== false,
      'developerExtrasEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.javascript !== false,
      'javaScriptEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(!!options.webPreferences.plugins, 'plugInsEnabled')
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.minimumFontSize || 0,
      'minimumFontSize'
    )

  if (options.webPreferences.zoomFactor) {
    webView.setMagnification(options.webPreferences.zoomFactor)
  }

  var contentView = panel.contentView()

  if (options.frame !== false) {
    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)
  } else {
    // In OSX 10.10, adding subviews to the root view for the NSView hierarchy
    // produces warnings. To eliminate the warnings, we resize the contentView
    // to fill the window, and add subviews to that.
    // http://crbug.com/380412
    contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
    fitSubviewToView(contentView, contentView.superview())

    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)

    // The fullscreen button should always be hidden for frameless window.
    if (panel.standardWindowButton(NSWindowFullScreenButton)) {
      panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true)
    }

    if (!options.titleBarStyle || options.titleBarStyle === 'default') {
      // Hide the window buttons.
      panel.standardWindowButton(NSWindowZoomButton).setHidden(true)
      panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true)
      panel.standardWindowButton(NSWindowCloseButton).setHidden(true)

      // Some third-party macOS utilities check the zoom button's enabled state to
      // determine whether to show custom UI on hover, so we disable it here to
      // prevent them from doing so in a frameless app window.
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(false)
    }
  }

  if (options.vibrancy) {
    browserWindow.setVibrancy(options.vibrancy)
  }

  // Set maximizable state last to ensure zoom button does not get reset
  // by calls to other APIs.
  browserWindow.setMaximizable(options.maximizable !== false)

  panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false)

  if (options.remembersWindowFrame) {
    panel.setFrameAutosaveName(identifier)
    panel.setFrameUsingName_force(panel.frameAutosaveName(), false)
  }

  if (options.acceptsFirstMouse) {
    browserWindow.on('focus', function (event) {
      if (event.type() === NSEventTypeLeftMouseDown) {
        browserWindow.webContents
          .executeJavaScript(dispatchFirstClick(webView, event))
          .catch(() => {})
      }
    })
  }

  executeJavaScript.injectScript(webView)
  movableArea.injectScript(webView)
  movableArea.setupHandler(browserWindow)

  if (options.show !== false) {
    browserWindow.show()
  }

  browserWindow.on('closed', function () {
    browserWindow._destroyed = true
    threadDictionary.removeObjectForKey(identifier)
    var observer = threadDictionary[identifier + '.themeObserver']
    if (observer) {
      NSApplication.sharedApplication().removeObserver_forKeyPath(
        observer,
        'effectiveAppearance'
      )
      threadDictionary.removeObjectForKey(identifier + '.themeObserver')
    }
    fiber.cleanup()
  })

  threadDictionary[identifier] = panel

  fiber.onCleanup(function () {
    if (!browserWindow._destroyed) {
      browserWindow.destroy()
    }
  })

  return browserWindow
}

BrowserWindow.fromId = function (identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary()

  if (threadDictionary[identifier]) {
    return BrowserWindow.fromPanel(threadDictionary[identifier], identifier)
  }

  return undefined
}

BrowserWindow.fromPanel = function (panel, identifier) {
  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (!panel || !panel.contentView) {
    throw new Error('needs to pass an NSPanel')
  }

  var webView = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webView &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webView = subviews[i]
    }
  }

  if (!webView) {
    throw new Error('The panel needs to have a webview')
  }

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)

  return browserWindow
}

module.exports = BrowserWindow


/***/ }),
/* 60 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Popover; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(0);
/* harmony import */ var _stickers_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(24);
/* harmony import */ var _portal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7);
/* harmony import */ var _webview_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13);






var baseOptions = {
  sender: null,
  identifier: null,
  frame: false,
  show: false,
  width: 210,
  height: 200,
  inGravityType: 3,
  url: "".concat(_state__WEBPACK_IMPORTED_MODULE_2__[/* host */ "i"], "/popover.html"),
  index: 99,
  isDialog: false,
  isPopover: true
};
var Popover = /*#__PURE__*/function () {
  function Popover(_context, readingAbilitysNames) {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Popover);
    baseOptions.identifier = "".concat(_state__WEBPACK_IMPORTED_MODULE_2__[/* IdentifierPrefix */ "a"], "-webview.popover");
    var newAbilitysNames = Object.keys(_state__WEBPACK_IMPORTED_MODULE_2__[/* newAbilitys */ "j"]).filter(function (item) {
      return !~readingAbilitysNames.indexOf(item);
    });
    this.sketcthContext = _context;
    this.newAbilitys = _state__WEBPACK_IMPORTED_MODULE_2__[/* newAbilitys */ "j"];
    this.newAbilitysNames = newAbilitysNames;
    // newAbilitysNames.push('imageFill') // 测试用
    this.targetAbilityOptions = null;
    this.browser = null;
    this.browserWindow = null;
    this.stickerUI = null;
    this.offset = 0;
    if (!newAbilitysNames.length) return;
    this.abilityNext();
  }
  return _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Popover, [{
    key: "updateWebViewContent",
    value: function updateWebViewContent(options) {
      var userId = Object(_portal__WEBPACK_IMPORTED_MODULE_4__[/* getUserId */ "b"])(this.sketcthContext);
      var payloadString = '';
      for (var key in options) {
        payloadString += "".concat(key, "@:@").concat(options[key], "@,@");
      }
      payloadString += "userId@:@".concat(userId, "@,@");
      this.stickerUI.updateHandle(this.browserWindow, 'updateNewAbility', payloadString);
    }
  }, {
    key: "abilityNext",
    value: function abilityNext() {
      var newAbilitysNames = this.newAbilitysNames;
      var namesLength = newAbilitysNames.length;
      if (this.offset > namesLength) {
        this.browser.hide();
        return;
      }
      ;
      var abilityAame = newAbilitysNames[this.offset];
      if (abilityAame) {
        var targetAbility = _state__WEBPACK_IMPORTED_MODULE_2__[/* newAbilitys */ "j"][abilityAame];
        if (targetAbility) {
          this.targetAbilityOptions = targetAbility;
          this.offset++;
          if (this.browser) {
            this.updateAbility();
          } else {
            this.creatBrowser();
          }
        } else {
          // newAbilitys 当前值为空
          this.offset++;
          this.abilityNext();
          return;
        }
      } else {
        // newAbilitysNames 当前值为空
        this.offset++;
        this.abilityNext();
        return;
      }
    }
  }, {
    key: "creatBrowser",
    value: function creatBrowser() {
      var _this = this;
      var menuTarget = this.getMapSender();
      baseOptions.sender = menuTarget;
      this.browser = new _webview_index__WEBPACK_IMPORTED_MODULE_5__[/* Browser */ "a"](baseOptions);
      var browserWindow = this.browser.browserWindow;
      this.browserWindow = browserWindow;
      this.stickerUI = new _stickers_ui__WEBPACK_IMPORTED_MODULE_3__[/* StickersUI */ "a"](this.sketcthContext);
      this.stickerUI.setupWebAPI(browserWindow);
      this.updateWebViewContent(this.targetAbilityOptions);
      var webView = browserWindow.webContents;
      webView.on('did-finish-load', function () {
        // 先关闭阴影，然后再打开，不然有时候会把阴影卡没
        _this.browserWindow._panel.setHasShadow(false);
        setTimeout(function () {
          _this.browserWindow._panel.setHasShadow(true);
        }, 20);
      });
      this.browserWindow._panel.setOpaque(false);
      this.browserWindow._panel.setBackgroundColor(NSColor.clearColor());
    }
  }, {
    key: "updateAbility",
    value: function updateAbility() {
      var menuTarget = this.getMapSender();
      this.browser.updatePosition(menuTarget);
      this.updateWebViewContent(this.targetAbilityOptions);
    }
  }, {
    key: "getMapSender",
    value: function getMapSender() {
      var menuIdentifier = this.targetAbilityOptions.target;
      var threadDictionary = NSThread.mainThread().threadDictionary();
      var menuTarget = threadDictionary[menuIdentifier];
      return menuTarget;
    }
  }]);
}();

/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Dialog
(https://github.com/electron/electron/blob/master/docs/api/dialog.md) */

module.exports = {
  showOpenDialog: __webpack_require__(41).openDialog,
  showOpenDialogSync: __webpack_require__(41).openDialogSync,
  showSaveDialog: __webpack_require__(42).saveDialog,
  showSaveDialogSync: __webpack_require__(42).saveDialogSync,
  showMessageBox: __webpack_require__(43).messageBox,
  showMessageBoxSync: __webpack_require__(43).messageBoxSync,
  // showErrorBox: require('./error-box'),
}


/***/ }),
/* 62 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(Promise) {/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1);
/* harmony import */ var _skpm_fs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_skpm_fs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9);
/* harmony import */ var _skpm_path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_skpm_path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3);






/**
 * 处理部分选中时的sketch文件
 */
/* harmony default export */ __webpack_exports__["a"] = (function (type, pluginFolderPath) {
  return new Promise(function (resolve, reject) {
    try {
      // 当前选中文档
      var currDocument = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();

      // 全选
      if (type !== 1) {
        resolve(currDocument.path);
      } else {
        // 部分选中
        // sketch原文件在插件里的目标路径
        var sketchPath = _skpm_path__WEBPACK_IMPORTED_MODULE_3___default.a.join(pluginFolderPath, 'copyTemp.sketch');
        // 当前选中画板obj
        var currArts = {};

        // 删除已有的sketch源文件
        if (_skpm_fs__WEBPACK_IMPORTED_MODULE_2___default.a.existsSync(sketchPath)) {
          _skpm_fs__WEBPACK_IMPORTED_MODULE_2___default.a.unlinkSync(sketchPath);
        }
        console.log('currDocument.path', currDocument.path);
        console.log('handleFilePath(currDocument.path)', Object(_util__WEBPACK_IMPORTED_MODULE_4__[/* handleFilePath */ "f"])(currDocument.path));
        console.log('sketchPath', sketchPath);
        // 将原文件拷贝到目标路径
        _skpm_fs__WEBPACK_IMPORTED_MODULE_2___default.a.copyFileSync(Object(_util__WEBPACK_IMPORTED_MODULE_4__[/* handleFilePath */ "f"])(currDocument.path), sketchPath);
        // 过滤出选中的元素坐标
        currDocument.pages.forEach(function (layer, pageIndex) {
          layer.layers.forEach(function (item, itemIndex) {
            if (item.type === 'Artboard' && (item.selected || layer.selected)) {
              // if (item.type === 'Artboard' && item.selected) {
              // 获取当前选中画板位置
              currArts["".concat(pageIndex, "_").concat(itemIndex)] = '1';
            }
          });
        });
        sketch_dom__WEBPACK_IMPORTED_MODULE_0__["Document"].open(sketchPath, function (err, document) {
          if (err) {
            // oh no, we failed to open the document
            reject(err);
          }

          // 删除未选中的画板
          document.pages.forEach(function (layer, pageIndex) {
            layer.layers.forEach(function (item, itemIndex) {
              // 删除未选中的画板
              if (!currArts["".concat(pageIndex, "_").concat(itemIndex)] && item.type === 'Artboard') {
                item.remove();
              }
            });
          });

          // 当page完全为空没有子图层的时候, 则删除这个page
          document.pages.forEach(function (layer) {
            if (layer.layers.length === 0) {
              layer.remove();
            }
          });

          // 保存
          document.save(sketchPath, function (err1) {
            if (err1) {
              reject(err1);
            }

            // 关闭
            document.close();
            resolve(sketchPath);
          });
        });
      }
    } catch (error) {
      console.log(error);
      reject(error);
    }
  }).catch(function (err) {
    console.log('handleSketchFile error:', err);
    throw err;
  });
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

module.exports.parseStat = function parseStat(result) {
  return {
    dev: String(result.NSFileDeviceIdentifier),
    // ino: 48064969, The file system specific "Inode" number for the file.
    mode: result.NSFileType | result.NSFilePosixPermissions,
    nlink: Number(result.NSFileReferenceCount),
    uid: String(result.NSFileOwnerAccountID),
    gid: String(result.NSFileGroupOwnerAccountID),
    // rdev: 0, A numeric device identifier if the file is considered "special".
    size: Number(result.NSFileSize),
    // blksize: 4096, The file system block size for i/o operations.
    // blocks: 8, The number of blocks allocated for this file.
    atimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    mtimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    ctimeMs:
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000,
    birthtimeMs:
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000,
    atime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ), // the 0.5 comes from the node source. Not sure why it's added but in doubt...
    mtime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    ctime: new Date(
      Number(result.NSFileModificationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    birthtime: new Date(
      Number(result.NSFileCreationDate.timeIntervalSince1970()) * 1000 + 0.5
    ),
    isBlockDevice: function () {
      return result.NSFileType === NSFileTypeBlockSpecial;
    },
    isCharacterDevice: function () {
      return result.NSFileType === NSFileTypeCharacterSpecial;
    },
    isDirectory: function () {
      return result.NSFileType === NSFileTypeDirectory;
    },
    isFIFO: function () {
      return false;
    },
    isFile: function () {
      return result.NSFileType === NSFileTypeRegular;
    },
    isSocket: function () {
      return result.NSFileType === NSFileTypeSocket;
    },
    isSymbolicLink: function () {
      return result.NSFileType === NSFileTypeSymbolicLink;
    },
  };
};

var ERRORS = {
  EPERM: {
    message: "operation not permitted",
    errno: -1,
  },
  ENOENT: {
    message: "no such file or directory",
    errno: -2,
  },
  EACCES: {
    message: "permission denied",
    errno: -13,
  },
  ENOTDIR: {
    message: "not a directory",
    errno: -20,
  },
  EISDIR: {
    message: "illegal operation on a directory",
    errno: -21,
  },
};

function fsError(code, options) {
  var error = new Error(
    code +
      ": " +
      ERRORS[code].message +
      ", " +
      (options.syscall || "") +
      (options.path ? " '" + options.path + "'" : "")
  );

  Object.keys(options).forEach(function (k) {
    error[k] = options[k];
  });

  error.code = code;
  error.errno = ERRORS[code].errno;

  return error;
}

module.exports.fsError = fsError;

module.exports.fsErrorForPath = function fsErrorForPath(
  path,
  shouldBeDir,
  err,
  syscall
) {
  var fileManager = NSFileManager.defaultManager();
  var doesExist = fileManager.fileExistsAtPath(path);
  if (!doesExist) {
    return fsError("ENOENT", {
      path: path,
      syscall: syscall || "open",
    });
  }
  var isReadable = fileManager.isReadableFileAtPath(path);
  if (!isReadable) {
    return fsError("EACCES", {
      path: path,
      syscall: syscall || "open",
    });
  }
  if (typeof shouldBeDir !== "undefined") {
    var isDirectory = __webpack_require__(1).lstatSync(path).isDirectory();
    if (isDirectory && !shouldBeDir) {
      return fsError("EISDIR", {
        path: path,
        syscall: syscall || "read",
      });
    } else if (!isDirectory && shouldBeDir) {
      return fsError("ENOTDIR", {
        path: path,
        syscall: syscall || "read",
      });
    }
  }
  return new Error(err || "Unknown error while manipulating " + path);
};

module.exports.encodingFromOptions = function encodingFromOptions(
  options,
  defaultValue
) {
  return options && options.encoding
    ? String(options.encoding)
    : options
    ? String(options)
    : defaultValue;
};

module.exports.NOT_IMPLEMENTED = function NOT_IMPLEMENTED(name) {
  return function () {
    throw new Error(
      "fs." +
        name +
        " is not implemented yet. If you feel like implementing it, any contribution will be gladly accepted on https://github.com/skpm/fs"
    );
  };
};


/***/ }),
/* 64 */
/***/ (function(module, exports) {

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

module.exports = _arrayWithHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 65 */
/***/ (function(module, exports) {

function _iterableToArrayLimit(arr, i) {
  var _i = arr == null ? null : typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"];

  if (_i == null) return;
  var _arr = [];
  var _n = true;
  var _d = false;

  var _s, _e;

  try {
    for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

module.exports = _iterableToArrayLimit, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 66 */
/***/ (function(module, exports) {

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableRest, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 67 */
/***/ (function(module, exports) {

function parseHexColor(color) {
  // Check the string for incorrect formatting.
  if (!color || color[0] !== '#') {
    if (
      color &&
      typeof color.isKindOfClass === 'function' &&
      color.isKindOfClass(NSColor)
    ) {
      return color
    }
    throw new Error(
      'Incorrect color formating. It should be an hex color: #RRGGBBAA'
    )
  }

  // append FF if alpha channel is not specified.
  var source = color.substr(1)
  if (source.length === 3) {
    source += 'F'
  } else if (source.length === 6) {
    source += 'FF'
  }
  // Convert the string from #FFF format to #FFFFFF format.
  var hex
  if (source.length === 4) {
    for (var i = 0; i < 4; i += 1) {
      hex += source[i]
      hex += source[i]
    }
  } else if (source.length === 8) {
    hex = source
  } else {
    return NSColor.whiteColor()
  }

  var r = parseInt(hex.slice(0, 2), 16) / 255
  var g = parseInt(hex.slice(2, 4), 16) / 255
  var b = parseInt(hex.slice(4, 6), 16) / 255
  var a = parseInt(hex.slice(6, 8), 16) / 255

  return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a)
}

module.exports = function (browserWindow, panel, webview) {
  // keep reference to the subviews
  browserWindow._panel = panel
  browserWindow._webview = webview
  browserWindow._destroyed = false

  browserWindow.destroy = function () {
    return panel.close()
  }

  browserWindow.close = function () {
    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      var shouldClose = true
      browserWindow.emit('close', {
        get defaultPrevented() {
          return !shouldClose
        },
        preventDefault: function () {
          shouldClose = false
        },
      })
      if (shouldClose) {
        panel.delegate().utils.parentWindow.endSheet(panel)
      }
      return
    }

    if (!browserWindow.isClosable()) {
      return
    }

    panel.performClose(null)
  }

  function focus(focused) {
    if (!browserWindow.isVisible()) {
      return
    }
    if (focused) {
      NSApplication.sharedApplication().activateIgnoringOtherApps(true)
      panel.makeKeyAndOrderFront(null)
    } else {
      panel.orderBack(null)
      NSApp.mainWindow().makeKeyAndOrderFront(null)
    }
  }

  browserWindow.focus = focus.bind(this, true)
  browserWindow.blur = focus.bind(this, false)

  browserWindow.isFocused = function () {
    return panel.isKeyWindow()
  }

  browserWindow.isDestroyed = function () {
    return browserWindow._destroyed
  }

  browserWindow.show = function () {
    // This method is supposed to put focus on window, however if the app does not
    // have focus then "makeKeyAndOrderFront" will only show the window.
    NSApp.activateIgnoringOtherApps(true)

    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
        panel,
        __mocha__.createBlock_function('v16@?0q8', function () {
          browserWindow.emit('closed')
        })
      )
    }

    return panel.makeKeyAndOrderFront(null)
  }

  browserWindow.showInactive = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.hide = function () {
    return panel.orderOut(null)
  }

  browserWindow.isVisible = function () {
    return panel.isVisible()
  }

  browserWindow.isModal = function () {
    return false
  }

  browserWindow.maximize = function () {
    if (!browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }
  browserWindow.unmaximize = function () {
    if (browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }

  browserWindow.isMaximized = function () {
    if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
      return panel.isZoomed()
    }
    var rectScreen = NSScreen.mainScreen().visibleFrame()
    var rectWindow = panel.frame()
    return (
      rectScreen.origin.x == rectWindow.origin.x &&
      rectScreen.origin.y == rectWindow.origin.y &&
      rectScreen.size.width == rectWindow.size.width &&
      rectScreen.size.height == rectWindow.size.height
    )
  }

  browserWindow.minimize = function () {
    return panel.miniaturize(null)
  }

  browserWindow.restore = function () {
    return panel.deminiaturize(null)
  }

  browserWindow.isMinimized = function () {
    return panel.isMiniaturized()
  }

  browserWindow.setFullScreen = function (fullscreen) {
    if (fullscreen !== browserWindow.isFullscreen()) {
      panel.toggleFullScreen(null)
    }
  }

  browserWindow.isFullscreen = function () {
    return panel.styleMask() & NSFullScreenWindowMask
  }

  browserWindow.setAspectRatio = function (aspectRatio /* , extraSize */) {
    // Reset the behaviour to default if aspect_ratio is set to 0 or less.
    if (aspectRatio > 0.0) {
      panel.setAspectRatio(NSMakeSize(aspectRatio, 1.0))
    } else {
      panel.setResizeIncrements(NSMakeSize(1.0, 1.0))
    }
  }

  browserWindow.setBounds = function (bounds, animate) {
    if (!bounds) {
      return
    }

    // Do nothing if in fullscreen mode.
    if (browserWindow.isFullscreen()) {
      return
    }

    const newBounds = Object.assign(browserWindow.getBounds(), bounds)

    // TODO: Check size constraints since setFrame does not check it.
    // var size = bounds.size
    // size.SetToMax(GetMinimumSize());
    // gfx::Size max_size = GetMaximumSize();
    // if (!max_size.IsEmpty())
    //   size.SetToMin(max_size);

    var cocoaBounds = NSMakeRect(
      newBounds.x,
      0,
      newBounds.width,
      newBounds.height
    )
    // Flip Y coordinates based on the primary screen
    var screen = NSScreen.screens().firstObject()
    cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y

    panel.setFrame_display_animate(cocoaBounds, true, animate)
  }

  browserWindow.getBounds = function () {
    const cocoaBounds = panel.frame()
    var mainScreenRect = NSScreen.screens().firstObject().frame()
    return {
      x: cocoaBounds.origin.x,
      y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
      width: cocoaBounds.size.width,
      height: cocoaBounds.size.height,
    }
  }

  browserWindow.setContentBounds = function (bounds, animate) {
    // TODO:
    browserWindow.setBounds(bounds, animate)
  }

  browserWindow.getContentBounds = function () {
    // TODO:
    return browserWindow.getBounds()
  }

  browserWindow.setSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setBounds({ width: width, height: height }, animate)
  }

  browserWindow.getSize = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setContentSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setContentBounds(
      { width: width, height: height },
      animate
    )
  }

  browserWindow.getContentSize = function () {
    var bounds = browserWindow.getContentBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setMinimumSize = function (width, height) {
    const minSize = CGSizeMake(width, height)
    panel.setContentMinSize(minSize)
  }

  browserWindow.getMinimumSize = function () {
    const size = panel.contentMinSize()
    return [size.width, size.height]
  }

  browserWindow.setMaximumSize = function (width, height) {
    const maxSize = CGSizeMake(width, height)
    panel.setContentMaxSize(maxSize)
  }

  browserWindow.getMaximumSize = function () {
    const size = panel.contentMaxSize()
    return [size.width, size.height]
  }

  browserWindow.setResizable = function (resizable) {
    return browserWindow._setStyleMask(resizable, NSResizableWindowMask)
  }

  browserWindow.isResizable = function () {
    return panel.styleMask() & NSResizableWindowMask
  }

  browserWindow.setMovable = function (movable) {
    return panel.setMovable(movable)
  }
  browserWindow.isMovable = function () {
    return panel.isMovable()
  }

  browserWindow.setMinimizable = function (minimizable) {
    return browserWindow._setStyleMask(minimizable, NSMiniaturizableWindowMask)
  }

  browserWindow.isMinimizable = function () {
    return panel.styleMask() & NSMiniaturizableWindowMask
  }

  browserWindow.setMaximizable = function (maximizable) {
    if (panel.standardWindowButton(NSWindowZoomButton)) {
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable)
    }
  }

  browserWindow.isMaximizable = function () {
    return (
      panel.standardWindowButton(NSWindowZoomButton) &&
      panel.standardWindowButton(NSWindowZoomButton).isEnabled()
    )
  }

  browserWindow.setFullScreenable = function (fullscreenable) {
    browserWindow._setCollectionBehavior(
      fullscreenable,
      NSWindowCollectionBehaviorFullScreenPrimary
    )
    // On EL Capitan this flag is required to hide fullscreen button.
    browserWindow._setCollectionBehavior(
      !fullscreenable,
      NSWindowCollectionBehaviorFullScreenAuxiliary
    )
  }

  browserWindow.isFullScreenable = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary
  }

  browserWindow.setClosable = function (closable) {
    browserWindow._setStyleMask(closable, NSClosableWindowMask)
  }

  browserWindow.isClosable = function () {
    return panel.styleMask() & NSClosableWindowMask
  }

  browserWindow.setAlwaysOnTop = function (top, level, relativeLevel) {
    var windowLevel = NSNormalWindowLevel
    var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey)
    var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey)

    if (top) {
      if (level === 'normal') {
        windowLevel = NSNormalWindowLevel
      } else if (level === 'torn-off-menu') {
        windowLevel = NSTornOffMenuWindowLevel
      } else if (level === 'modal-panel') {
        windowLevel = NSModalPanelWindowLevel
      } else if (level === 'main-menu') {
        windowLevel = NSMainMenuWindowLevel
      } else if (level === 'status') {
        windowLevel = NSStatusWindowLevel
      } else if (level === 'pop-up-menu') {
        windowLevel = NSPopUpMenuWindowLevel
      } else if (level === 'screen-saver') {
        windowLevel = NSScreenSaverWindowLevel
      } else if (level === 'dock') {
        // Deprecated by macOS, but kept for backwards compatibility
        windowLevel = NSDockWindowLevel
      } else {
        windowLevel = NSFloatingWindowLevel
      }
    }

    var newLevel = windowLevel + (relativeLevel || 0)
    if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
      panel.setLevel(newLevel)
    } else {
      throw new Error(
        'relativeLevel must be between ' +
          minWindowLevel +
          ' and ' +
          maxWindowLevel
      )
    }
  }

  browserWindow.isAlwaysOnTop = function () {
    return panel.level() !== NSNormalWindowLevel
  }

  browserWindow.moveTop = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.center = function () {
    panel.center()
  }

  browserWindow.setPosition = function (x, y, animate) {
    return browserWindow.setBounds({ x: x, y: y }, animate)
  }

  browserWindow.getPosition = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.x, bounds.y]
  }

  browserWindow.setTitle = function (title) {
    panel.setTitle(title)
  }

  browserWindow.getTitle = function () {
    return String(panel.title())
  }

  var attentionRequestId = 0
  browserWindow.flashFrame = function (flash) {
    if (flash) {
      attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest)
    } else {
      NSApp.cancelUserAttentionRequest(attentionRequestId)
      attentionRequestId = 0
    }
  }

  browserWindow.getNativeWindowHandle = function () {
    return panel
  }

  browserWindow.getNativeWebViewHandle = function () {
    return webview
  }

  browserWindow.loadURL = function (url) {
    // When frameLocation is a file, prefix it with the Sketch Resources path
    if (/^(?!https?|file).*\.html?$/.test(url)) {
      if (typeof __command !== 'undefined' && __command.pluginBundle()) {
        url =
          'file://' + __command.pluginBundle().urlForResourceNamed(url).path()
      }
    }

    if (/^file:\/\/.*\.html?$/.test(url)) {
      // ensure URLs containing spaces are properly handled
      url = NSString.alloc().initWithString(url)
      url = url.stringByAddingPercentEncodingWithAllowedCharacters(
        NSCharacterSet.URLQueryAllowedCharacterSet()
      )
      webview.loadFileURL_allowingReadAccessToURL(
        NSURL.URLWithString(url),
        NSURL.URLWithString('file:///')
      )
      return
    }

    const properURL = NSURL.URLWithString(url)
    const urlRequest = NSURLRequest.requestWithURL(properURL)

    webview.loadRequest(urlRequest)
  }

  browserWindow.reload = function () {
    webview.reload()
  }

  browserWindow.setHasShadow = function (hasShadow) {
    return panel.setHasShadow(hasShadow)
  }

  browserWindow.hasShadow = function () {
    return panel.hasShadow()
  }

  browserWindow.setOpacity = function (opacity) {
    return panel.setAlphaValue(opacity)
  }

  browserWindow.getOpacity = function () {
    return panel.alphaValue()
  }

  browserWindow.setVisibleOnAllWorkspaces = function (visible) {
    return browserWindow._setCollectionBehavior(
      visible,
      NSWindowCollectionBehaviorCanJoinAllSpaces
    )
  }

  browserWindow.isVisibleOnAllWorkspaces = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces
  }

  browserWindow.setIgnoreMouseEvents = function (ignore) {
    return panel.setIgnoresMouseEvents(ignore)
  }

  browserWindow.setContentProtection = function (enable) {
    panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly)
  }

  browserWindow.setAutoHideCursor = function (autoHide) {
    panel.setDisableAutoHideCursor(autoHide)
  }

  browserWindow.setVibrancy = function (type) {
    var effectView = browserWindow._vibrantView

    if (!type) {
      if (effectView == null) {
        return
      }

      effectView.removeFromSuperview()
      panel.setVibrantView(null)
      return
    }

    if (effectView == null) {
      var contentView = panel.contentView()
      effectView = NSVisualEffectView.alloc().initWithFrame(
        contentView.bounds()
      )
      browserWindow._vibrantView = effectView

      effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
      effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow)
      effectView.setState(NSVisualEffectStateActive)
      effectView.setFrame(contentView.bounds())
      contentView.addSubview_positioned_relativeTo(
        effectView,
        NSWindowBelow,
        null
      )
    }

    var vibrancyType = NSVisualEffectMaterialLight

    if (type === 'appearance-based') {
      vibrancyType = NSVisualEffectMaterialAppearanceBased
    } else if (type === 'light') {
      vibrancyType = NSVisualEffectMaterialLight
    } else if (type === 'dark') {
      vibrancyType = NSVisualEffectMaterialDark
    } else if (type === 'titlebar') {
      vibrancyType = NSVisualEffectMaterialTitlebar
    } else if (type === 'selection') {
      vibrancyType = NSVisualEffectMaterialSelection
    } else if (type === 'menu') {
      vibrancyType = NSVisualEffectMaterialMenu
    } else if (type === 'popover') {
      vibrancyType = NSVisualEffectMaterialPopover
    } else if (type === 'sidebar') {
      vibrancyType = NSVisualEffectMaterialSidebar
    } else if (type === 'medium-light') {
      vibrancyType = NSVisualEffectMaterialMediumLight
    } else if (type === 'ultra-dark') {
      vibrancyType = NSVisualEffectMaterialUltraDark
    }

    effectView.setMaterial(vibrancyType)
  }

  browserWindow._setBackgroundColor = function (colorName) {
    var color = parseHexColor(colorName)
    webview.setValue_forKey(false, 'drawsBackground')
    panel.backgroundColor = color
  }

  browserWindow._invalidate = function () {
    panel.flushWindow()
    panel.contentView().setNeedsDisplay(true)
  }

  browserWindow._setStyleMask = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setStyleMask(panel.styleMask() | flag)
    } else {
      panel.setStyleMask(panel.styleMask() & ~flag)
    }
    // Change style mask will make the zoom button revert to default, probably
    // a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._setCollectionBehavior = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setCollectionBehavior(panel.collectionBehavior() | flag)
    } else {
      panel.setCollectionBehavior(panel.collectionBehavior() & ~flag)
    }
    // Change collectionBehavior will make the zoom button revert to default,
    // probably a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._showWindowButton = function (button) {
    var view = panel.standardWindowButton(button)
    view.superview().addSubview_positioned_relative(view, NSWindowAbove, null)
  }
}


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

var EventEmitter = __webpack_require__(38)
var executeJavaScript = __webpack_require__(39)

// let's try to match https://github.com/electron/electron/blob/master/docs/api/web-contents.md
module.exports = function buildAPI(browserWindow, panel, webview) {
  var webContents = new EventEmitter()

  webContents.loadURL = browserWindow.loadURL

  webContents.loadFile = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.downloadURL = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.getURL = function () {
    return String(webview.URL())
  }

  webContents.getTitle = function () {
    return String(webview.title())
  }

  webContents.isDestroyed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.focus = browserWindow.focus
  webContents.isFocused = browserWindow.isFocused

  webContents.isLoading = function () {
    return !!webview.loading()
  }

  webContents.isLoadingMainFrame = function () {
    // TODO:
    return !!webview.loading()
  }

  webContents.isWaitingForResponse = function () {
    return !webview.loading()
  }

  webContents.stop = function () {
    webview.stopLoading()
  }
  webContents.reload = function () {
    webview.reload()
  }
  webContents.reloadIgnoringCache = function () {
    webview.reloadFromOrigin()
  }
  webContents.canGoBack = function () {
    return !!webview.canGoBack()
  }
  webContents.canGoForward = function () {
    return !!webview.canGoForward()
  }
  webContents.canGoToOffset = function (offset) {
    return !!webview.backForwardList().itemAtIndex(offset)
  }
  webContents.clearHistory = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.goBack = function () {
    webview.goBack()
  }
  webContents.goForward = function () {
    webview.goForward()
  }
  webContents.goToIndex = function (index) {
    var backForwardList = webview.backForwardList()
    var backList = backForwardList.backList()
    var backListLength = backList.count()
    if (backListLength > index) {
      webview.loadRequest(NSURLRequest.requestWithURL(backList[index]))
      return
    }
    var forwardList = backForwardList.forwardList()
    if (forwardList.count() > index - backListLength) {
      webview.loadRequest(
        NSURLRequest.requestWithURL(forwardList[index - backListLength])
      )
      return
    }
    throw new Error('Cannot go to index ' + index)
  }
  webContents.goToOffset = function (offset) {
    if (!webContents.canGoToOffset(offset)) {
      throw new Error('Cannot go to offset ' + offset)
    }
    webview.loadRequest(
      NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
    )
  }
  webContents.isCrashed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setUserAgent = function (/* userAgent */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.getUserAgent = function () {
    const userAgent = webview.customUserAgent()
    return userAgent ? String(userAgent) : undefined
  }
  webContents.insertCSS = function (css) {
    var source =
      "var style = document.createElement('style'); style.innerHTML = " +
      css.replace(/"/, '\\"') +
      '; document.head.appendChild(style);'
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.insertJS = function (source) {
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.executeJavaScript = executeJavaScript(webview, browserWindow)
  webContents.setIgnoreMenuShortcuts = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setAudioMuted = function (/* muted */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.isAudioMuted = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setZoomFactor = function (factor) {
    webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0))
  }
  webContents.getZoomFactor = function (callback) {
    callback(Number(webview.magnification()))
  }
  webContents.setZoomLevel = function (level) {
    // eslint-disable-next-line no-restricted-properties
    webContents.setZoomFactor(Math.pow(1.2, level))
  }
  webContents.getZoomLevel = function (callback) {
    // eslint-disable-next-line no-restricted-properties
    callback(Math.log(Number(webview.magnification())) / Math.log(1.2))
  }
  webContents.setVisualZoomLevelLimits = function (/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setLayoutZoomLevelLimits = function (/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  // TODO:
  // webContents.undo = function() {
  //   webview.undoManager().undo()
  // }
  // webContents.redo = function() {
  //   webview.undoManager().redo()
  // }
  // webContents.cut = webview.cut
  // webContents.copy = webview.copy
  // webContents.paste = webview.paste
  // webContents.pasteAndMatchStyle = webview.pasteAsRichText
  // webContents.delete = webview.delete
  // webContents.replace = webview.replaceSelectionWithText

  webContents.send = function () {
    const script =
      'window.postMessage({' +
      'isSketchMessage: true,' +
      "origin: '" +
      String(__command.identifier()) +
      "'," +
      'args: ' +
      JSON.stringify([].slice.call(arguments)) +
      '}, "*")'
    webview.evaluateJavaScript_completionHandler(script, null)
  }

  webContents.getNativeWebview = function () {
    return webview
  }

  browserWindow.webContents = webContents
}


/***/ }),
/* 69 */
/***/ (function(module, exports) {

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(
    NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
      subview,
      edge,
      NSLayoutRelationEqual,
      view,
      edge,
      1,
      constant
    )
  )
}
module.exports = function fitSubviewToView(subview, view, constants) {
  constants = constants || []
  subview.setTranslatesAutoresizingMaskIntoConstraints(false)

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0)
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0)
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0)
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0)
}


/***/ }),
/* 70 */
/***/ (function(module, exports) {

var tagsToFocus =
  '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]'

module.exports = function (webView, event) {
  var point = webView.convertPoint_fromView(event.locationInWindow(), null)
  return (
    'var el = document.elementFromPoint(' + // get the DOM element that match the event
    point.x +
    ', ' +
    point.y +
    '); ' +
    'if (el && el.tagName === "SELECT") {' + // select needs special handling
    '  var event = document.createEvent("MouseEvents");' +
    '  event.initMouseEvent("mousedown", true, true, window);' +
    '  el.dispatchEvent(event);' +
    '} else if (el && ' + // some tags need to be focused instead of clicked
    tagsToFocus +
    '.indexOf(el.type) >= 0 && ' +
    'el.focus' +
    ') {' +
    'el.focus();' + // so focus them
    '} else if (el) {' +
    'el.dispatchEvent(new Event("click", {bubbles: true}))' + // click the others
    '}'
  )
}


/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(26)

module.exports = function (webView) {
  var source =
    'window.originalPostMessage = window.postMessage;' +
    'window.postMessage = function(actionName) {' +
    '  if (!actionName) {' +
    "    throw new Error('missing action name')" +
    '  }' +
    '  var id = String(Math.random()).replace(".", "");' +
    '    var args = [].slice.call(arguments);' +
    '    args.unshift(id);' +
    '  return new Promise(function (resolve, reject) {' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
    '" + id] = resolve;' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_ERROR +
    '" + id] = reject;' +
    '    window.webkit.messageHandlers.' +
    CONSTANTS.JS_BRIDGE +
    '.postMessage(JSON.stringify(args));' +
    '  });' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(26)

module.exports.injectScript = function (webView) {
  var source =
    '(function () {' +
    "document.addEventListener('mousedown', onMouseDown);" +
    '' +
    'function shouldDrag(target) {' +
    '  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }' +
    '  if ((target.dataset || {}).appRegion === "drag") { return true }' +
    '  return shouldDrag(target.parentElement)' +
    '};' +
    '' +
    'function onMouseDown(e) {' +
    '  if (e.button !== 0 || !shouldDrag(e.target)) { return }' +
    '  window.postMessage("' +
    CONSTANTS.START_MOVING_WINDOW +
    '");' +
    '};' +
    '})()'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}

module.exports.setupHandler = function (browserWindow) {
  var initialMouseLocation = null
  var initialWindowPosition = null
  var interval = null

  function moveWindow() {
    // if the user released the button, stop moving the window
    if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
      clearInterval(interval)
      initialMouseLocation = null
      initialWindowPosition = null
      return
    }

    var mouse = NSEvent.mouseLocation()
    browserWindow.setPosition(
      initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
      initialWindowPosition.y + (initialMouseLocation.y - mouse.y), // y is inverted
      false
    )
  }

  browserWindow.webContents.on(CONSTANTS.START_MOVING_WINDOW, function () {
    initialMouseLocation = NSEvent.mouseLocation()
    var position = browserWindow.getPosition()
    initialWindowPosition = {
      x: position[0],
      y: position[1],
    }

    interval = setInterval(moveWindow, 1000 / 60) // 60 fps
  })
}


/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var ObjCClass = __webpack_require__(35)
var parseWebArguments = __webpack_require__(74)
var CONSTANTS = __webpack_require__(26)

// We create one ObjC class for ourselves here
var WindowDelegateClass
var NavigationDelegateClass
var WebScriptHandlerClass
var ThemeObserverClass

// TODO: events
// - 'page-favicon-updated'
// - 'new-window'
// - 'did-navigate-in-page'
// - 'will-prevent-unload'
// - 'crashed'
// - 'unresponsive'
// - 'responsive'
// - 'destroyed'
// - 'before-input-event'
// - 'certificate-error'
// - 'found-in-page'
// - 'media-started-playing'
// - 'media-paused'
// - 'did-change-theme-color'
// - 'update-target-url'
// - 'cursor-changed'
// - 'context-menu'
// - 'select-bluetooth-device'
// - 'paint'
// - 'console-message'

module.exports = function (browserWindow, panel, webview, options) {
  if (!ThemeObserverClass) {
    ThemeObserverClass = new ObjCClass({
      utils: null,

      'observeValueForKeyPath:ofObject:change:context:': function (
        keyPath,
        object,
        change
      ) {
        const newAppearance = change[NSKeyValueChangeNewKey]
        const isDark =
          String(
            newAppearance.bestMatchFromAppearancesWithNames([
              'NSAppearanceNameAqua',
              'NSAppearanceNameDarkAqua',
            ])
          ) === 'NSAppearanceNameDarkAqua'

        this.utils.executeJavaScript(
          "document.body.classList.remove('__skpm-" +
            (isDark ? 'light' : 'dark') +
            "'); document.body.classList.add('__skpm-" +
            (isDark ? 'dark' : 'light') +
            "')"
        )
      },
    })
  }

  if (!WindowDelegateClass) {
    WindowDelegateClass = new ObjCClass({
      utils: null,
      panel: null,

      'windowDidResize:': function () {
        this.utils.emit('resize')
      },

      'windowDidMiniaturize:': function () {
        this.utils.emit('minimize')
      },

      'windowDidDeminiaturize:': function () {
        this.utils.emit('restore')
      },

      'windowDidEnterFullScreen:': function () {
        this.utils.emit('enter-full-screen')
      },

      'windowDidExitFullScreen:': function () {
        this.utils.emit('leave-full-screen')
      },

      'windowDidMove:': function () {
        this.utils.emit('move')
        this.utils.emit('moved')
      },

      'windowShouldClose:': function () {
        var shouldClose = 1
        this.utils.emit('close', {
          get defaultPrevented() {
            return !shouldClose
          },
          preventDefault: function () {
            shouldClose = 0
          },
        })
        return shouldClose
      },

      'windowWillClose:': function () {
        this.utils.emit('closed')
      },

      'windowDidBecomeKey:': function () {
        this.utils.emit('focus', this.panel.currentEvent())
      },

      'windowDidResignKey:': function () {
        this.utils.emit('blur')
      },
    })
  }

  if (!NavigationDelegateClass) {
    NavigationDelegateClass = new ObjCClass({
      state: {
        wasReady: 0,
      },
      utils: null,

      // // Called when the web view begins to receive web content.
      'webView:didCommitNavigation:': function (webView) {
        this.utils.emit('will-navigate', {}, String(String(webView.URL())))
      },

      // // Called when web content begins to load in a web view.
      'webView:didStartProvisionalNavigation:': function () {
        this.utils.emit('did-start-navigation')
        this.utils.emit('did-start-loading')
      },

      // Called when a web view receives a server redirect.
      'webView:didReceiveServerRedirectForProvisionalNavigation:': function () {
        this.utils.emit('did-get-redirect-request')
      },

      // // Called when the web view needs to respond to an authentication challenge.
      // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
      //   webView,
      //   challenge,
      //   completionHandler
      // ) {
      //   function callback(username, password) {
      //     completionHandler(
      //       0,
      //       NSURLCredential.credentialWithUser_password_persistence(
      //         username,
      //         password,
      //         1
      //       )
      //     )
      //   }
      //   var protectionSpace = challenge.protectionSpace()
      //   this.utils.emit(
      //     'login',
      //     {},
      //     {
      //       method: String(protectionSpace.authenticationMethod()),
      //       url: 'not implemented', // TODO:
      //       referrer: 'not implemented', // TODO:
      //     },
      //     {
      //       isProxy: !!protectionSpace.isProxy(),
      //       scheme: String(protectionSpace.protocol()),
      //       host: String(protectionSpace.host()),
      //       port: Number(protectionSpace.port()),
      //       realm: String(protectionSpace.realm()),
      //     },
      //     callback
      //   )
      // },

      // Called when an error occurs during navigation.
      // 'webView:didFailNavigation:withError:': function(
      //   webView,
      //   navigation,
      //   error
      // ) {},

      // Called when an error occurs while the web view is loading content.
      'webView:didFailProvisionalNavigation:withError:': function (
        webView,
        navigation,
        error
      ) {
        this.utils.emit('did-fail-load', error)
      },

      // Called when the navigation is complete.
      'webView:didFinishNavigation:': function () {
        if (this.state.wasReady == 0) {
          this.state.wasReady = 1
          this.utils.emitBrowserEvent('ready-to-show')
        }
        this.utils.emit('did-navigate')
        this.utils.emit('did-frame-navigate')
        this.utils.emit('did-stop-loading')
        this.utils.emit('did-finish-load')
        this.utils.emit('did-frame-finish-load')
      },

      // Called when the web view’s web content process is terminated.
      'webViewWebContentProcessDidTerminate:': function () {
        this.utils.emit('dom-ready')
      },

      // Decides whether to allow or cancel a navigation.
      // webView:decidePolicyForNavigationAction:decisionHandler:

      // Decides whether to allow or cancel a navigation after its response is known.
      // webView:decidePolicyForNavigationResponse:decisionHandler:
    })
  }

  if (!WebScriptHandlerClass) {
    WebScriptHandlerClass = new ObjCClass({
      utils: null,
      'userContentController:didReceiveScriptMessage:': function (_, message) {
        var args = this.utils.parseWebArguments(String(message.body()))
        if (!args) {
          return
        }
        if (!args[0] || typeof args[0] !== 'string') {
          return
        }
        args[0] = String(args[0])

        this.utils.emit.apply(this, args)
      },
    })
  }

  var themeObserver = ThemeObserverClass.new({
    utils: {
      executeJavaScript(script) {
        webview.evaluateJavaScript_completionHandler(script, null)
      },
    },
  })

  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    "document.addEventListener('DOMContentLoaded', function() { document.body.classList.add('__skpm-" +
      (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
        ? 'dark'
        : 'light') +
      "') }, false)",
    0,
    true
  )
  webview.configuration().userContentController().addUserScript(script)

  NSApplication.sharedApplication().addObserver_forKeyPath_options_context(
    themeObserver,
    'effectiveAppearance',
    NSKeyValueObservingOptionNew,
    null
  )

  var threadDictionary = NSThread.mainThread().threadDictionary()
  threadDictionary[browserWindow.id + '.themeObserver'] = themeObserver

  var navigationDelegate = NavigationDelegateClass.new({
    utils: {
      setTitle: browserWindow.setTitle.bind(browserWindow),
      emitBrowserEvent() {
        try {
          browserWindow.emit.apply(browserWindow, arguments)
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
    },
    state: {
      wasReady: 0,
    },
  })

  webview.setNavigationDelegate(navigationDelegate)

  var webScriptHandler = WebScriptHandlerClass.new({
    utils: {
      emit(id, type) {
        if (!type) {
          webview.evaluateJavaScript_completionHandler(
            CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + '()',
            null
          )
          return
        }

        var args = []
        for (var i = 2; i < arguments.length; i += 1) args.push(arguments[i])

        var listeners = browserWindow.webContents.listeners(type)

        Promise.all(
          listeners.map(function (l) {
            return Promise.resolve().then(function () {
              return l.apply(l, args)
            })
          })
        )
          .then(function (res) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
                id +
                '(' +
                JSON.stringify(res) +
                ')',
              null
            )
          })
          .catch(function (err) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_ERROR +
                id +
                '(' +
                JSON.stringify(err) +
                ')',
              null
            )
          })
      },
      parseWebArguments: parseWebArguments,
    },
  })

  webview
    .configuration()
    .userContentController()
    .addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE)

  var utils = {
    emit() {
      try {
        browserWindow.emit.apply(browserWindow, arguments)
      } catch (err) {
        if (
          typeof process !== 'undefined' &&
          process.listenerCount &&
          process.listenerCount('uncaughtException')
        ) {
          process.emit('uncaughtException', err, 'uncaughtException')
        } else {
          console.error(err)
          throw err
        }
      }
    },
  }
  if (options.modal) {
    // find the window of the document
    var msdocument
    if (options.parent.type === 'Document') {
      msdocument = options.parent.sketchObject
    } else {
      msdocument = options.parent
    }
    if (msdocument && String(msdocument.class()) === 'MSDocumentData') {
      // we only have an MSDocumentData instead of a MSDocument
      // let's try to get back to the MSDocument
      msdocument = msdocument.delegate()
    }
    utils.parentWindow = msdocument.windowForSheet()
  }

  var windowDelegate = WindowDelegateClass.new({
    utils: utils,
    panel: panel,
  })

  panel.setDelegate(windowDelegate)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(4)))

/***/ }),
/* 74 */
/***/ (function(module, exports) {

module.exports = function (webArguments) {
  var args = null
  try {
    args = JSON.parse(webArguments)
  } catch (e) {
    // malformed arguments
  }

  if (
    !args ||
    !args.constructor ||
    args.constructor !== Array ||
    args.length == 0
  ) {
    return null
  }

  return args
}


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

var util = __webpack_require__(40)

module.exports.getString = function getString(path, argumentName) {
  if (!util.isString(path)) {
    // let's make a special case for NSURL
    if (util.getNativeClass(path) === 'NSURL') {
      return String(path.path().copy())
    }
    throw new Error(argumentName + ' should be a string. Got ' + typeof path + ' instead.')
  }
  return String(path)
}

module.exports.cwd = function cwd() {
  if (typeof __command !== 'undefined' && __command.script() && __command.script().URL()) {
    return String(__command.script().URL().path().copy())
  }
  return String(MSPluginManager.defaultPluginURL().path().copy())
}

module.exports.resourcePath = function resourcePath(resourceName) {
  if (typeof __command === 'undefined' || !__command.pluginBundle()) {
    return undefined
  }
  var resource = __command.pluginBundle().urlForResourceNamed(resourceName)
  if (!resource) {
    return undefined
  }
  return String(resource.path())
}


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(37);

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 77 */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}

module.exports = _iterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 78 */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const parseText_1 = __webpack_require__(80);
const parseStructure_1 = __webpack_require__(89);
const parseStyle_1 = __webpack_require__(91);
const parseImage_1 = __webpack_require__(101);
const handleSlicePosition_1 = __webpack_require__(102);
const filterGroupLayer_1 = __webpack_require__(103);
// import * as fs from 'fs';
const _parseDSL = (sketchData, type) => {
    const dsl = [];
    sketchData.forEach((layer) => {
        let dslLayer = {
            type: 'Container',
            id: layer.do_objectID,
            name: layer.name,
            symbolName: layer.symbolName || '',
            groupBreadcrumb: layer.groupBreadcrumb || []
        };
        // 海葵组件
        if (type === 'lowcode') {
            dslLayer.type = 'View';
        }
        // 组件跳转信息
        if (layer.symbolComponentObject) {
            dslLayer.symbolComponentObject = layer.symbolComponentObject;
        }
        // 被解绑的组件
        if (layer.haikuiComponentInfo) {
            dslLayer.haikuiComponentInfo = layer.haikuiComponentInfo;
        }
        // 面板解析
        dslLayer.panel = layer.panel;
        // 结构解析
        dslLayer.structure = Object.assign(Object.assign({}, dslLayer.structure), parseStructure_1.default(layer));
        // 样式解析
        dslLayer.style = Object.assign(Object.assign({}, dslLayer.style), parseStyle_1.default(layer));
        // fs.writeFileSync(`./${layer.name}_code_dsl.json`, JSON.stringify(dslLayer.style,null,2));
        // 文本处理
        dslLayer = parseText_1.default(dslLayer, layer);
        // 图片处理
        dslLayer = parseImage_1.default(dslLayer, layer, type);
        if (dslLayer.type !== 'Text' && Array.isArray(layer.layers)) {
            dslLayer.children = _parseDSL(layer.layers, type);
        }
        dsl.push(dslLayer);
    });
    return dsl;
};
exports.default = (sketchData, type) => {
    const layers = [];
    for (let i = 0; i < sketchData.length; i++) {
        const layer = sketchData[i];
        layer.groupBreadcrumb = [{ id: layer.do_objectID, name: layer.name }];
        // 去掉分组
        layer.layers = filterGroupLayer_1.default(layer.layers, [], type, [{ id: layer.do_objectID, name: layer.name }]);
        // 标注模式下，切片进行排序
        if (type === 'measure') {
            layer.layers = handleSlicePosition_1.default(layer.layers);
        }
        layers.push(layer);
    }
    return _parseDSL(layers, type);
};


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const getString_1 = __webpack_require__(81);
const getStringStyle_1 = __webpack_require__(82);
exports.default = (text, layer) => {
    if (layer._class !== 'text') {
        return text;
    }
    // 设置类型
    text.type = 'Text';
    if (!text.style.textStyle) {
        text.style.textStyle = {};
    }
    text.value = getString_1.default(layer);
    let strStyleList = getStringStyle_1.default(layer);
    if (Array.isArray(strStyleList) && strStyleList.length > 0) {
        if (strStyleList[0].paragraphSpacing) {
            text.style.textStyle.paragraphSpacing = strStyleList[0].paragraphSpacing;
        }
        for (let i = 0; i < strStyleList.length; i++) {
            delete strStyleList[i].paragraphSpacing;
        }
    }
    // 默认取第一个文本样式
    const style = getStringStyle_1.default(layer)[0];
    if (style && style.pos) {
        delete style.pos;
    }
    text.style.textStyle = style || {};
    // 多段文本处理
    if (Array.isArray(strStyleList) && strStyleList.length > 1) {
        // TODO
        // if (!text.textStyle['lineHeight'] && text.textStyle['fontSize'] &&
        //     +text.textStyle['fontSize'] > text.height * 0.5
        // ) {
        //     text.textStyle['line-height'] = text.height;
        // }
        // text.style = {
        //     ...text.style,
        //     ...JSON.parse(JSON.stringify(text.textStyle))
        // };
        // text.type = 'Text';
        // Todo
        // if (/[a-zA-Z]+/.test(text.value) && text.style.textStyle.fontSize <= +text.structure.height * 0.5) { // 包含英文单词需要换行处理
        //     text.style.textStyle.wordBreak = 'break-all'
        // }
        // } else {
        // 处理一串字符多个样式的情况
        // TODO
        // if (layer.istransformContain) {
        //     text.istransformContain = true;
        // }
        // text.children = [];
        // text.textContainer = true;
        // if (!text.style) {
        //     text.style = {}
        // }
        // 存储多行文本。
        text.children = [];
        for (let i = 0; i < strStyleList.length; i++) {
            let strStyle = strStyleList[i];
            let tempObj = {
                type: 'Text',
                value: '',
                style: {
                    textStyle: {
                        lineHeight: +text.structure.height
                    }
                },
                structure: {
                    height: text.structure.height,
                    y: text.structure.y,
                }
                // parentId: layer.do_objectID,
            };
            if (i == 0) { // 第一个元素继承父元素的左偏移量
                tempObj.structure.x = text.structure.x;
                //todo ?
                // if (strStyle['font-size'] && 0.5 * text.structure.height < strStyle['font-size']) {
                //     text.style.display = 'flex';
                // }
            }
            for (let key in strStyle) {
                if (key === 'pos') {
                    let [location, length] = strStyle[key];
                    // 标注模式
                    tempObj.value = text.value.substr(location, length);
                    // 代码模式
                    // tempObj.value = text.value.substr(location, length).replace(/ | /g, '&nbsp;');
                    // if (i == strStyleList.length - 1) {
                    //     tempObj.value = tempObj.value.replace(/(&nbsp;)+$/, '');
                    // }
                    // TODO
                    // if (tempObj.value && /[a-zA-Z]+/.test(tempObj.value)) { // 包含英文单词需要换行处理
                    //     tempObj.style.textStyle.wordBreak = 'break-all';
                    // }
                    delete strStyle.pos;
                }
                else {
                    tempObj.style.textStyle[key] = strStyle[key];
                }
            }
            text.children.push(tempObj);
        }
    }
    return text;
};


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (layer) => {
    // 直接可以获取string值
    if (layer.attributedString &&
        layer.attributedString.string) {
        return layer.attributedString.string;
    }
    return '';
};


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const dealParagraph_1 = __webpack_require__(83);
const dealColor_1 = __webpack_require__(84);
const dealFont_1 = __webpack_require__(85);
const dealLetterSpacing_1 = __webpack_require__(87);
const dealTextDecorate_1 = __webpack_require__(88);
// :todo 结合 parseTypeFace
exports.default = (layer) => {
    // 直接解析text字体样式有字体大小的情况下
    if (layer.attributedString && layer.attributedString.string && layer.attributedString.attributes) {
        let size = 1;
        // TODO
        // if (layer.frame.sizeY) {
        //     size = layer.frame.sizeY;
        // }
        let attrList = layer.attributedString.attributes;
        let strStyleList = [];
        let minFontSize = 0;
        for (let attrItem of attrList) {
            if (attrItem._class == 'stringAttribute') {
                let attributes = attrItem.attributes;
                let fontStyle = attributes['MSAttributedStringFontAttribute'];
                let colorStyle = attributes['MSAttributedStringColorAttribute'] || { red: 0, green: 0, blue: 0, alpha: 1, _class: 'color' };
                let paragraphStyleObj = attributes['paragraphStyle'];
                let kerning = attributes['kerning'];
                const textStyle = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, dealParagraph_1.default(paragraphStyleObj, fontStyle, size)), dealColor_1.default(colorStyle, layer)), dealFont_1.default(fontStyle, size)), dealLetterSpacing_1.default(kerning)), dealTextDecorate_1.default(attributes));
                if (minFontSize > textStyle.fontSize) {
                    minFontSize = textStyle.fontSize;
                }
            }
        }
        let isTextBreak = false;
        if (minFontSize && minFontSize > 0.5 * layer.frame.height) {
            // 单行文字的情况
            isTextBreak = true;
            // TODO
            // layer.istransformContain = true;
        }
        // attrList = isTextBreak ? attrList : attrList.slice(0, 1);
        for (let attrItem of attrList) {
            if (attrItem._class == 'stringAttribute') {
                let attributes = attrItem.attributes;
                let fontStyle = attributes['MSAttributedStringFontAttribute'];
                let colorStyle = attributes['MSAttributedStringColorAttribute'] || { red: 0, green: 0, blue: 0, alpha: 1, _class: 'color' };
                let paragraphStyleObj = attributes['paragraphStyle'];
                let kerning = attributes['kerning'];
                const style = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({ pos: [attrItem.location, attrItem.length] }, dealParagraph_1.default(paragraphStyleObj, fontStyle, size)), dealColor_1.default(colorStyle, layer)), dealFont_1.default(fontStyle, size)), dealLetterSpacing_1.default(kerning)), dealTextDecorate_1.default(attributes));
                strStyleList.push(style);
            }
        }
        return strStyleList;
    }
    return [];
};


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const const_1 = __webpack_require__(44);
/**
 * 处理段落
 */
exports.default = (paragraphStyle, fontStyle, size = 1) => {
    var _a;
    const textStyle = {};
    if (paragraphStyle) {
        switch (paragraphStyle.alignment) {
            case 2:
                textStyle.textAlign = 'center';
                break;
            case 1:
                textStyle.textAlign = 'right';
                break;
            case 0:
                textStyle.textAlign = 'left';
                break;
            case 3: //两边对齐
                textStyle.textAlign = 'justify';
                break;
        }
        textStyle.lineHeight = paragraphStyle.maximumLineHeight ? paragraphStyle.maximumLineHeight : const_1.fontSizeLineHeightMap[((_a = fontStyle.attributes) === null || _a === void 0 ? void 0 : _a.size) * size];
    }
    return textStyle;
};


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(11);
const handleSolidColorFill_1 = __webpack_require__(45);
exports.default = (color, layer) => {
    //01. 如果文本有填充的时候，使用填充色
    let fillList = [];
    // 过滤无效填充
    if (layer.style && Array.isArray(layer.style.fills)) {
        fillList = layer.style.fills.filter(fillItem => {
            return fillItem.isEnabled;
        });
    }
    if (fillList.length > 0) {
        // 只解析单层渐变
        const fillStyle = fillList[fillList.length - 1];
        const fillType = fillStyle.fillType;
        //填充为纯色的情况
        if (fillType === 0) {
            return handleSolidColorFill_1.default(fillStyle, layer);
        }
    }
    //02. 没有填充的时候，使用默认颜色
    let alpha = color.alpha;
    if (layer.style && layer.style.contextSettings) { // colorStyle 里的 alpha 的值都是 1
        alpha = layer.style.contextSettings.opacity * color.alpha; // 设置透明度
    }
    return {
        color: utils_1.transSketchColor({ red: color.red, green: color.green, blue: color.blue, alpha }),
    };
};


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 获取字体大小, 文字字体, 字体粗细
 */
const getFontWeight_1 = __webpack_require__(86);
exports.default = (fontStyle, size = 1) => {
    var _a, _b, _c, _d;
    return ({
        fontSize: ((_a = fontStyle.attributes) === null || _a === void 0 ? void 0 : _a.size) * size,
        fontFamily: (_c = (_b = fontStyle.attributes) === null || _b === void 0 ? void 0 : _b.name) === null || _c === void 0 ? void 0 : _c.replace(/PingFang-SC|PingFang SC/, 'PingFangSC'),
        fontWeight: getFontWeight_1.default((_d = fontStyle.attributes) === null || _d === void 0 ? void 0 : _d.name)
    });
};


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (attrName) => {
    if (/black|heavy/i.test(attrName)) {
        return 900;
    }
    else if (/ultrabold|extrabold/i.test(attrName)) {
        return 800;
    }
    else if (/bold|boldmt|psboldmt/i.test(attrName)) {
        return 700;
    }
    else if (/semibold|demibold/i.test(attrName)) {
        return 600;
    }
    else if (/medium/i.test(attrName)) {
        return 500;
    }
    else if (/roman|regular|normal|book/i.test(attrName)) {
        return 400;
    }
    else if (/light/i.test(attrName)) {
        return 300;
    }
    else if (/extralight|ultralight/i.test(attrName)) {
        return 200;
    }
    else if (/thin/i.test(attrName)) {
        return 100;
    }
};


/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理字间距
 */
exports.default = (kerning) => {
    if (kerning !== undefined && kerning !== 0) {
        return {
            letterSpacing: Math.round(kerning * 10) / 10
        };
    }
    return {};
};


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理文字转换问题
 */
exports.default = (attributes) => {
    const textStyle = {};
    // 文字大小写转换
    if (attributes.MSAttributedStringTextTransformAttribute == 1) {
        textStyle.textTransform = 'uppercase';
    }
    else if (attributes.MSAttributedStringTextTransformAttribute == 2) {
        textStyle.textTransform = 'lowercase';
    }
    if (attributes.underlineStyle == 1) {
        textStyle.textDecoration = 'underline';
    }
    if (attributes.strikethroughStyle == 1) {
        textStyle.textDecoration = 'line-through';
    }
    return textStyle;
};


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const parseBorder_1 = __webpack_require__(90);
const utils_1 = __webpack_require__(11);
const parseStructure = (layer) => {
    const { x, y, height, width } = layer.frame;
    return {
        x: utils_1.precisionControl(x),
        y: utils_1.precisionControl(y),
        width: utils_1.precisionControl(width),
        height: utils_1.precisionControl(height),
        border: parseBorder_1.default(layer),
    };
};
exports.default = parseStructure;


/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(11);
/**
 * 'position': 属性表示 border 设置的位置
 * 1 => Inside border 位于盒子的内部
 * 0 => Center border 盒子便于位于 boder 之间
 * 2 =>  Outside 外边框
 */
exports.default = (layer) => {
    //没有处理多边框的情况，现在只支持单边框，其实borders是一个数组
    if (layer.style && layer.style.borders && layer.style.borders.length && layer._class != 'artboard') {
        let borderList = layer.style.borders.filter(item => item.isEnabled);
        if (borderList.length) {
            let borderStyle = borderList[0]; // 不规则 border 已经导出为图片
            let borderAlpha = borderStyle.color.alpha;
            // 只要判断是否存在即可， 因为可能 Opacity 的值为 0 的情况
            if (layer.style && layer.style.contextSettings) {
                borderAlpha = layer.style.contextSettings.opacity * borderAlpha;
            }
            // 设置边框
            const border = {
                width: utils_1.precisionControl(borderStyle.thickness),
                style: 'solid',
                color: utils_1.transSketchColor({
                    red: borderStyle.color.red,
                    green: borderStyle.color.green,
                    blue: borderStyle.color.blue,
                    alpha: borderAlpha,
                }),
            };
            return {
                left: border,
                top: border,
                right: border,
                bottom: border
            };
        }
    }
};


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const parseFill_1 = __webpack_require__(92);
const parseShadow_1 = __webpack_require__(98);
const parseBorderRadius_1 = __webpack_require__(99);
const parseBackGroundColor_1 = __webpack_require__(100);
const parseStyle = (layer) => {
    const layerStyle = Object.assign(Object.assign({}, parseShadow_1.default(layer)), { background: Object.assign(Object.assign({}, parseBackGroundColor_1.default(layer)), parseFill_1.default(layer)) });
    if (layer._class !== 'text') {
        layerStyle.borderRadius = parseBorderRadius_1.default(layer);
    }
    return layerStyle;
};
exports.default = parseStyle;


/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleSolidColorFill_1 = __webpack_require__(45);
const handleGradientColorFill_1 = __webpack_require__(93);
const handleImgFill_1 = __webpack_require__(97);
/**
  * 处理填充
  * 填充类型
  * fillStyle.fillType
  *           0  纯色
  *           1  渐变色
  *           2
  *           3
  *           4  填充图
  *           5  纹理效果
  * fillStyle.fillType fillStyle.gradient.gradientType
  *        1                    0   线性渐变色 完全css解析
  *        1                    1   径向渐变色
  *                                 - 圆形或者椭圆但是没有斜角度的CSS解析
  *                                 - 导出为图片
  *        1                    2   环形渐变色  css实验属性暂时不支持 ，导出为图片处理
  *
  * @param {Object} layer 图层
  */
exports.default = (layer) => {
    let fillList = [];
    // 过滤无效填充
    if (layer.style && Array.isArray(layer.style.fills)) {
        fillList = layer.style.fills.filter(fillItem => {
            return fillItem.isEnabled;
        });
    }
    if (fillList.length === 0 || layer._class === 'text') {
        return {};
    }
    // 只解析单层渐变
    const fillStyle = fillList[fillList.length - 1];
    const fillType = fillStyle.fillType;
    //填充为纯色的情况
    if (fillType == 0) {
        return handleSolidColorFill_1.default(fillStyle, layer);
    }
    //填充为渐变色的情况
    if (fillType == 1) {
        return handleGradientColorFill_1.default(fillStyle, layer);
    }
    //填充图片
    if (fillType == 4) {
        return handleImgFill_1.default(fillStyle, layer);
    }
    return {};
};


/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleLinearGradient_1 = __webpack_require__(94);
const handleRadialGradient_1 = __webpack_require__(96);
exports.default = (fillStyle, layer) => {
    if (!fillStyle.gradient) {
        return {};
    }
    let gradient = fillStyle.gradient;
    let contextSettings = fillStyle.contextSettings ? fillStyle.contextSettings.opacity : 1;
    let gradientType = gradient.gradientType;
    if (gradientType === 0) { // 线性渐变
        return {
            linearGradient: handleLinearGradient_1.default(gradient, layer, contextSettings)
        };
    }
    if (gradientType === 1) { // 径向渐变
        return {
            radialGradient: handleRadialGradient_1.default(gradient, layer, fillStyle, contextSettings)
        };
    }
    if (gradientType === 2) { // 环形渐色，导出该图层为图片
        return {};
    }
};


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const twoPointsAngle_1 = __webpack_require__(95);
const twoPointsDistance_1 = __webpack_require__(46);
const utils_1 = __webpack_require__(11);
exports.default = (gradient, layer, contextSettings = 1) => {
    let frame = layer.frame;
    let changePointList = [];
    let startPointStr = gradient.from;
    let startX = +startPointStr.split('{')[1].split(',')[0] * frame.width;
    let startY = -startPointStr.split(',')[1].split('}')[0] * frame.height;
    let endPointStr = gradient.to;
    let endX = +endPointStr.split('{')[1].split(',')[0] * frame.width;
    let endY = -endPointStr.split(',')[1].split('}')[0] * frame.height;
    let gAngle = twoPointsAngle_1.default(startX, startY, endX, endY);
    let gDistance = twoPointsDistance_1.default(startX, startY, endX, endY);
    let startPoint = {
        x: startX,
        y: startY
    };
    let endPoint = {
        x: endX,
        y: endY
    };
    let stops = gradient.stops;
    if (endX < startX) {
        startPoint = {
            x: endX,
            y: endY
        };
        endPoint = {
            x: startX,
            y: startY
        };
        gAngle = twoPointsAngle_1.default(endX, endY, startX, startY);
        gDistance = twoPointsDistance_1.default(endX, endY, startX, startY);
        stops = stops.reverse();
        stops = stops.map(item => {
            item.position = 1 - item.position;
            return item;
        });
    }
    let point1 = {
        x: 0,
        y: 0
    };
    let point2 = {
        x: frame.width,
        y: 0
    };
    let point3 = {
        x: frame.width,
        y: -frame.height
    };
    let point4 = {
        x: 0,
        y: -frame.height
    };
    let mainStart = point1;
    let mainEnd = point3;
    //根据不同角度，选取起始点和终止点
    if (gAngle >= 0 && gAngle < Math.PI / 2) {
        mainStart = point4;
        mainEnd = point2;
    }
    else if (gAngle >= Math.PI / 2 && gAngle < Math.PI) {
        mainStart = point1;
        mainEnd = point3;
    }
    let lengthStart = 0;
    let lengthEnd = 0;
    let startColor = {};
    let endColor = {};
    //计算向量距离
    const verticalDistance = (point1, point2, lineAngle) => {
        return Math.abs(twoPointsDistance_1.default(point1.x, point1.y, point2.x, point2.y)) *
            Math.cos(twoPointsAngle_1.default(point1.x, point1.y, point2.x, point2.y) - lineAngle);
    };
    //起始点和起始坐标点之间的向量距离
    if (!(startPoint.x == mainStart.x && startPoint.y == mainStart.y)) {
        lengthStart = verticalDistance(mainStart, startPoint, gAngle);
    }
    //结束点和结束坐标点之间的向量距离
    if (!(endPoint.x == mainEnd.x && endPoint.y == mainEnd.y)) {
        lengthEnd = verticalDistance(endPoint, mainEnd, gAngle);
    }
    //渐变起始坐标处理(起始距离为正值和负值两种情况)
    if (lengthStart < 0) {
        for (let i = 1; i < stops.length; i++) {
            if (stops[i].position > -lengthStart / gDistance) {
                let currColor = stops[i].color;
                let preColor = stops[i - 1].color;
                const getVal = (prop) => {
                    return preColor[prop] + (currColor[prop] - preColor[prop]) / (stops[i].position - stops[i - 1].position) * (-lengthStart / gDistance - stops[i - 1].position);
                };
                startColor = {
                    index: i,
                    color: {
                        'alpha': getVal('alpha'),
                        'blue': getVal('blue'),
                        'green': getVal('green'),
                        'red': getVal('red')
                    },
                    position: -lengthStart / gDistance
                };
                break;
            }
        }
    }
    else {
        startColor = {
            index: 0,
            color: stops[0].color,
            position: -lengthStart / gDistance
        };
    }
    //渐变结束坐标处理(结束距离为正值和负值两种情况)
    if (lengthEnd < 0) {
        for (let i = 0; i < stops.length - 1; i++) {
            if (stops[i + 1].position > 1 + lengthEnd / gDistance) {
                let currColor = stops[i].color;
                let nextColor = stops[i + 1].color;
                const getVal = (prop) => {
                    return currColor[prop] + (nextColor[prop] - currColor[prop]) / (stops[i + 1].position - stops[i].position) * (1 + lengthEnd / gDistance - stops[i].position);
                };
                endColor = {
                    index: i,
                    color: {
                        'alpha': getVal('alpha'),
                        'blue': getVal('blue'),
                        'green': getVal('green'),
                        'red': getVal('red')
                    },
                    position: 1 + lengthEnd / gDistance
                };
                break;
            }
        }
    }
    else {
        endColor = {
            index: stops.length - 1,
            color: stops[stops.length - 1].color,
            position: 1 + lengthEnd / gDistance
        };
    }
    if (startColor.color) {
        changePointList.push(startColor);
    }
    for (let n = 0; n < stops.length; n++) {
        if (n >= startColor.index && n <= endColor.index) {
            changePointList.push(stops[n]);
        }
    }
    if (endColor.color) {
        changePointList.push(endColor);
    }
    changePointList = changePointList.map(({ color, position }) => {
        position = (position - changePointList[0].position) / (changePointList[changePointList.length - 1].position - changePointList[0].position);
        return {
            color,
            position
        };
    });
    const valList = changePointList.map(({ color, position }) => {
        let { red, green, blue, alpha } = color;
        if (layer.style && layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * contextSettings * alpha;
        }
        return {
            color: utils_1.transSketchColor({ red, green, blue, alpha }),
            position: utils_1.precisionControl(position, 0.01),
        };
        // return `rgba(${Math.round(red * 255)},${Math.round(green * 255)},${Math.round(blue * 255)},${Math.round(alpha * 100) / 100}) ${Math.round(position * 10000) / 100}%`;
    });
    return {
        gAngle: Math.round(gAngle / Math.PI * 180 * 10) / 10,
        gList: valList,
    };
};


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 依据两点坐标计算两点与原点之间连线的夹角
 *
 * @param {*} startX 第一个点X轴坐标
 * @param {*} startY 第一个点Y轴坐标
 * @param {*} endX 第二个点X轴坐标
 * @param {*} endY 第二个点Y轴坐标
 * @returns
 */
exports.default = (startX, startY, endX, endY) => {
    let x = endX - startX;
    let y = endY - startY;
    if (x > 0 && y == 0) {
        return Math.PI * 0.5;
    }
    if (x < 0 && y == 0) {
        return Math.PI * 1.5;
    }
    if (y > 0 && x == 0) {
        return 0;
    }
    if (y < 0 && x == 0) {
        return Math.PI;
    }
    if (x >= 0 && y >= 0) {
        return Math.atan(x / y);
    }
    if (x >= 0 && y < 0) {
        return Math.PI + Math.atan(x / y);
    }
    if (x < 0 && y > 0) {
        return 2 * Math.PI + Math.atan(x / y);
    }
    if (x < 0 && y <= 0) {
        return Math.PI + Math.atan(x / y);
    }
};


/***/ }),
/* 96 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const twoPointsDistance_1 = __webpack_require__(46);
const utils_1 = __webpack_require__(11);
exports.default = (gradient, layer, fillStyle, contextSettings = 1) => {
    let frame = layer.frame;
    let startPointStr = gradient.from;
    let startX = +startPointStr.split('{')[1].split(',')[0] * frame.width;
    let startY = -startPointStr.split(',')[1].split('}')[0] * frame.height;
    let endPointStr = gradient.to;
    let endX = +endPointStr.split('{')[1].split(',')[0] * frame.width;
    let endY = -endPointStr.split(',')[1].split('}')[0] * frame.height;
    let r = Math.abs(twoPointsDistance_1.default(startX, startY, endX, endY));
    let stops = gradient.stops;
    const valList = stops.map(({ color, position }) => {
        let { red, green, blue, alpha } = color;
        if (layer.style && layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * contextSettings * alpha;
        }
        return {
            color: utils_1.transSketchColor({ red, green, blue, alpha }),
            position: utils_1.precisionControl(position, 0.01),
        };
    });
    if (fillStyle.gradient.elipseLength > 0) { //椭圆渐变
        let elipseLength = fillStyle.gradient.elipseLength;
        if (Math.abs(endY - startY) < 1) {
            return {
                smallRadius: utils_1.precisionControl(r),
                largeRadius: utils_1.precisionControl(elipseLength * r),
                position: {
                    left: utils_1.precisionControl(startX),
                    top: utils_1.precisionControl(-startY),
                },
                gList: valList
            };
        }
        else if (Math.abs(endX - startX) < 1) {
            return {
                smallRadius: utils_1.precisionControl(elipseLength * r),
                largeRadius: utils_1.precisionControl(r),
                position: {
                    left: utils_1.precisionControl(startX),
                    top: utils_1.precisionControl(-startY),
                },
                gList: valList
            };
        }
    }
    else { //圆形渐变
        return {
            smallRadius: utils_1.precisionControl(r),
            largeRadius: utils_1.precisionControl(r),
            position: {
                left: utils_1.precisionControl(startX),
                top: utils_1.precisionControl(-startY),
            },
            gList: valList
        };
    }
};


/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * fillStyle.patternFillType == 0   Mask_Tile repeat 平铺
 * fillStyle.patternFillType == 1  Mask_Fill  cover  填充
 * fillStyle.patternFillType == 2  Mask_Stretch  100% 100% 拉伸
 * fillStyle.patternFillType == 3   Mask_Fit  contain 包含
 */
exports.default = (fillStyle, layer) => {
    const background = {};
    if (!fillStyle.image) {
        return;
    }
    if (fillStyle.patternFillType == 0) {
        background.repeat = 'repeat';
    }
    if (fillStyle.patternFillType == 1) {
        background.repeat = 'no-repeat';
        background.position = {
            left: 'center',
            top: 'center'
        };
        background.size = 'cover';
    }
    if (fillStyle.patternFillType == 2) {
        background.repeat = 'no-repeat';
        background.position = {
            left: 'center',
            top: 'center'
        };
        background.size = {
            width: '100%',
            height: '100%',
        };
    }
    if (fillStyle.patternFillType == 3) {
        background.repeat = 'no-repeat';
        background.position = {
            left: 'center',
            top: 'center'
        };
        background.size = 'contain';
    }
    // TODO
    // if (layer.realFrame) {
    //     const realFrame = JSON.parse(JSON.stringify(layer.realFrame));
    //     layer.maskStyle['background-position'] = `${realFrame.x - layer.frame.x}px ${realFrame.y - layer.frame.y}px`;
    //     layer.maskStyle['background-size'] = `${realFrame.width}px ${realFrame.height}px`;
    //     layer.maskStyle['background-repeat'] = 'no-repeat';
    // }
    let imgPath = fillStyle.image._ref.slice(fillStyle.image._ref.lastIndexOf('/') + 1);
    if (!/.(png|pdf)$/.test(imgPath)) {
        imgPath = imgPath + '.png';
    }
    background.image = {
        url: imgPath
    };
    //图片类型，背景色去掉
    // TODO
    // delete record.style['background-color'];
    return background;
};


/***/ }),
/* 98 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(11);
/**
 *  处理阴影
 *  box-shadow 只解析一层的情况
 *  多个 shadow 的情况将导成图片, 每一层的 shadow 的模式都是 blendMode： 0 表示是正常的
 */
const getShadowStyle = (shadow, layer, type = '') => {
    let { alpha, red, green, blue } = shadow.color;
    alpha = shadow.contextSettings.opacity * alpha;
    const offY = !layer.hasScale && layer.isFlippedVertical ? -shadow.offsetY : shadow.offsetY;
    const offX = !layer.hasScale && layer.isFlippedHorizontal ? -shadow.offsetX : shadow.offsetX;
    return {
        type,
        blurRadius: utils_1.precisionControl(shadow.blurRadius),
        spread: utils_1.precisionControl(shadow.spread),
        offsetX: utils_1.precisionControl(offX),
        offsetY: utils_1.precisionControl(offY),
        color: utils_1.transSketchColor({ red, green, blue, alpha }),
    };
};
// 获取文本的 shadow 样式
const getTextShadowStyle = (shadow, layer) => {
    let { alpha, red, green, blue } = shadow.color;
    alpha = shadow.contextSettings.opacity * alpha;
    let offY = !layer.hasScale && layer.isFlippedVertical ? -shadow.offsetY : shadow.offsetY;
    let offX = !layer.hasScale && layer.isFlippedHorizontal ? -shadow.offsetX : shadow.offsetX;
    return {
        blurRadius: utils_1.precisionControl(shadow.blurRadius),
        spread: utils_1.precisionControl(shadow.spread),
        offsetX: utils_1.precisionControl(offX),
        offsetY: utils_1.precisionControl(offY),
        color: utils_1.transSketchColor({ red, green, blue, alpha }),
    };
};
exports.default = (layer) => {
    if (layer._class === 'text') {
        let shadowStyleList = [];
        // 处理文本外阴影
        if (layer.style && layer.style.shadows) {
            // 查找所有可用的阴影
            let shadowList = [];
            layer.style.shadows.map(item => {
                if (item.isEnabled) {
                    shadowList.push(item);
                }
            });
            for (let item of shadowList) {
                let proStyle = getTextShadowStyle(item, layer);
                shadowStyleList.push(proStyle);
            }
            return {
                textShadow: shadowStyleList
            };
        }
    }
    else {
        // 盒子阴影的设置
        let shadowStyleList = [], innerShadowStyleList = [];
        if (layer.style && layer.style.shadows) {
            // 查找所有可用的阴影
            let shadowList = [];
            layer.style.shadows.map(item => {
                if (item.isEnabled) {
                    shadowList.push(item);
                }
            });
            for (let item of shadowList) {
                let proStyle = getShadowStyle(item, layer);
                shadowStyleList.push(proStyle);
            }
        }
        if (layer.style && layer.style.innerShadows) {
            let innerShadowList = [];
            layer.style.innerShadows.map(item => {
                if (item.isEnabled) {
                    innerShadowList.push(item);
                }
            });
            for (let item of innerShadowList) {
                let proStyle = getShadowStyle(item, layer, 'inset');
                innerShadowStyleList.push(proStyle);
            }
        }
        return {
            boxShadow: [...shadowStyleList.reverse(), ...innerShadowStyleList.reverse()]
        };
    }
};


/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(11);
// import * as fs from 'fs';
/**
 * 计算圆角
 * @param {*} layer 图层
 *  pointRadiusBehaviour: 1 round Corners
 *  pointRadiusBehaviour: 2 smooth Corners
 *  四个角顺序：左上、右上、右下、左下
 */
const calculateBorderRadius = (layer) => {
    var _a;
    if (layer.points && layer.points.length !== 4) { // 不是 4 个锚点组成的不计算圆角
        return {};
    }
    // 如果 points 的模式是   curveMode: 1 的情况， 以四个角的角度作为圆角的大小
    if (layer.points && layer.points.length == 4 && layer.points[0].curveMode == 1 && layer.points[1].curveMode == 1 && layer.points[2].curveMode == 1 && layer.points[3].curveMode == 1 && layer.fixedRadius !== undefined) {
        const cornerRadiusList = [];
        for (let item of layer.points) {
            cornerRadiusList.push(item.cornerRadius);
        }
        const [topLeft, topRight, bottomRight, bottomLeft] = cornerRadiusList; // 上、右、下、左
        return {
            topLeft: utils_1.precisionControl(topLeft),
            topRight: utils_1.precisionControl(topRight),
            bottomRight: utils_1.precisionControl(bottomRight),
            bottomLeft: utils_1.precisionControl(bottomLeft)
        };
    }
    // 如果 points 的模式是 curveMode: 2 cornerRadius: 0 的情况，为正圆
    if (((_a = layer.points) === null || _a === void 0 ? void 0 : _a.length) === 4 && layer.points[0].curveMode === 2 && layer.points[1].curveMode === 2 && layer.points[2].curveMode === 2 && layer.points[3].curveMode === 2) {
        const cornerRadiusList = [];
        for (let item of layer.points) {
            cornerRadiusList.push(item.cornerRadius);
        }
        const [topLeft, topRight, bottomRight, bottomLeft] = cornerRadiusList; // 上、右、下、左
        if (topLeft === 0 && topRight === 0 && bottomRight === 0 && bottomLeft === 0) {
            return {
                topLeft: '50%',
                topRight: '50%',
                bottomRight: '50%',
                bottomLeft: '50%',
            };
        }
    }
    // 按照比例计算
    let radius = 0;
    if (layer.layers && layer.layers.length && layer.layers[0].fixedRadius) {
        radius = layer.layers[0].fixedRadius > layer.frame.height / 2 ? layer.frame.height / 2 : layer.layers[0].fixedRadius;
    }
    else if (layer.fixedRadius) { //兼容52.2版本
        radius = layer.fixedRadius > layer.frame.height / 2 ? layer.frame.height / 2 : layer.fixedRadius;
    }
    return {
        topLeft: utils_1.precisionControl(radius),
        topRight: utils_1.precisionControl(radius),
        bottomRight: utils_1.precisionControl(radius),
        bottomLeft: utils_1.precisionControl(radius)
    };
};
exports.default = calculateBorderRadius;


/***/ }),
/* 100 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = __webpack_require__(11);
exports.default = (layer) => {
    var _a;
    let { alpha, red, green, blue } = layer.backgroundColor || {};
    // 如果设置了 Opacity 属性，则 fills border 需要乘以这个数值
    if ((_a = layer.style) === null || _a === void 0 ? void 0 : _a.contextSettings) {
        alpha = layer.style.contextSettings.opacity * alpha;
    }
    if (alpha > 0) {
        return {
            color: utils_1.transSketchColor({ red, green, blue, alpha }),
        };
    }
    return {};
};


/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 切片(Slice) => 图片
 * @param image Picasso-DSL图层
 * @param layer Sketch图层
 */
const parseImage = (image, layer, type) => {
    // 画板图赋值
    if (layer._class === 'artboard') {
        image.value = layer.imageUrl;
        // 切片转换为图片
    }
    else if (layer.imageUrl) {
        if (type === 'lowcode') {
            image.type = 'WBImage';
        }
        else {
            image.type = 'Image';
        }
        image.value = layer.imageUrl;
    }
    return image;
};
exports.default = parseImage;


/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// 切片位置调整
const _handleSlicePosition = (layers) => {
    layers.sort((layerA, layerB) => {
        if (layerB._class === 'slice' || layerB._class === 'image') {
            if (layerA.frame.x <= layerB.frame.x
                && layerA.frame.y <= layerB.frame.y
                && layerA.frame.x + layerA.frame.width >= layerB.frame.x + layerB.frame.width
                && layerA.frame.y + layerA.frame.height >= layerB.frame.y + layerB.frame.height) {
                return -1;
            }
        }
        return 0;
    });
    for (let i = 0; i < layers.length; i++) {
        if (Array.isArray(layers[i].layers)) {
            layers[i].layers = _handleSlicePosition(layers[i].layers);
        }
    }
    return layers;
};
exports.default = _handleSlicePosition;


/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description 去掉分组，同时去掉图层层级
 * @param {SKLayer[]} layers
 * @param {SKLayer[]} [afterLayer=[]]
 * @returns {SKLayer[]}
 */
const filterGroupLayer = (layers, afterLayer = [], type, groupBreadcrumb = []) => {
    layers.forEach((layer) => {
        // 组的面包屑西信息
        const $groupBreadcrumb = [
            ...groupBreadcrumb,
            { id: layer.do_objectID, name: layer.name },
        ];
        // 非组件 或 是未解绑组件 或 组件解绑之后的组件
        if (layer._class !== 'group' ||
            // 组行为:{ Default: 0, Frame: 1, Graphic: 2 }
            [1, 2].includes(layer.groupBehavior) ||
            layer.symbolComponentObject ||
            layer.haikuiComponentInfo) {
            afterLayer.push(Object.assign(Object.assign({}, layer), { layers: [], groupBreadcrumb: [...$groupBreadcrumb] }));
        }
        if (Array.isArray(layer.layers)) {
            filterGroupLayer(layer.layers, afterLayer, type, [
                ...$groupBreadcrumb,
            ]);
        }
    });
    return afterLayer;
};
exports.default = filterGroupLayer;


/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const filterHideLayer_1 = __webpack_require__(105);
const handleBorderCoordinate_1 = __webpack_require__(106);
const handleOpacity_1 = __webpack_require__(107);
const fixPosition_1 = __webpack_require__(108);
const handleSlice_1 = __webpack_require__(109);
const formatCoordinate_1 = __webpack_require__(110);
const trimByMask_1 = __webpack_require__(111);
const handleNotFillLayerOrder_1 = __webpack_require__(112);
const handlePanel_1 = __webpack_require__(113);
/**
 * 分别对每个画板进行处理
 */
exports.default = (layer, type) => {
    let layers = [layer];
    // 代码模式，border坐标处理
    if (type === 'code' || type === 'lowcode') {
        layers = handleBorderCoordinate_1.default(layers);
    }
    // 透明度透传
    layers = handleOpacity_1.default(layers);
    // 相对坐标系 => 绝对坐标系
    layers = formatCoordinate_1.default(layers);
    // 修正坐标值 基础坐标系调整为：0,0;
    layers = fixPosition_1.default(layers);
    // Mask剪切处理
    layers = trimByMask_1.default(layers);
    // 代码模式，处理切片
    if (type === 'code' || type === 'lowcode') {
        layers = handleSlice_1.default(layers);
    }
    // 过滤隐藏图层
    layers = filterHideLayer_1.default(layers);
    // 处理透明图层顺序
    layers = handleNotFillLayerOrder_1.default(layers);
    // 属性面板解析
    layers = handlePanel_1.handlePanel(layers);
    return layers[0];
};


/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 过滤掉隐藏图层
 * @param layers
 */
const handleHideLayer = (layers) => {
    const layerArr = [];
    layers.forEach((layer) => {
        if (layer.isVisible) {
            if (Array.isArray(layer.layers)) {
                layer.layers = handleHideLayer(layer.layers);
            }
            layerArr.push(layer);
        }
    });
    return layerArr;
};
exports.default = handleHideLayer;


/***/ }),
/* 106 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleBorderCoordinate = (layers) => {
    layers = layers.map((layer) => {
        if (layer.style && layer.style.borders && layer._class != 'artboard') {
            let borderList = layer.style.borders.filter(item => item.isEnabled);
            // 只处理一层border的情况
            if (borderList.length == 1) {
                let borderStyle = borderList[0];
                if (borderStyle.position == 0) { // 中间边框
                    let w = borderStyle.thickness / 2;
                    layer.frame.width += borderStyle.thickness;
                    layer.frame.height += borderStyle.thickness;
                    layer.frame.x -= w;
                    layer.frame.y -= w;
                }
                else if (borderStyle.position == 2) { // 外边框
                    let w = borderStyle.thickness;
                    layer.frame.width += w * 2;
                    layer.frame.height += w * 2;
                    layer.frame.x -= w;
                    layer.frame.y -= w;
                }
            }
        }
        // 递归
        if (Array.isArray(layer.layers)) {
            layer.layers = handleBorderCoordinate(layer.layers);
        }
        return layer;
    });
    return layers;
};
exports.default = handleBorderCoordinate;


/***/ }),
/* 107 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleOpacity = (layers, commonOpacity = 1) => {
    // 透明度传递
    layers = layers.map((layer) => {
        if (!layer.style) {
            layer.style = {
                _class: 'style'
            };
        }
        if (!layer.style.contextSettings) {
            layer.style.contextSettings = {
                _class: 'graphicsContextSettings',
                opacity: 1
            };
        }
        layer.style.contextSettings.opacity = layer.style.contextSettings.opacity * commonOpacity;
        if (Array.isArray(layer.layers)) {
            layer.layers = handleOpacity(layer.layers, layer.style.contextSettings.opacity);
        }
        return layer;
    });
    return layers;
};
exports.default = handleOpacity;


/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const _fixPosition = (layers, { x, y }) => {
    // 透明度传递
    layers = layers.map((layer) => {
        // x值修正
        layer.frame.x = layer.frame.x - x;
        // y值修正
        layer.frame.y = layer.frame.y - y;
        if (Array.isArray(layer.layers)) {
            layer.layers = _fixPosition(layer.layers, { x, y });
        }
        return layer;
    });
    return layers;
};
exports.default = (layers) => {
    // 基础坐标系
    const { x = 0, y = 0 } = layers[0] && layers[0].frame ? layers[0].frame : { x: 0, y: 0 };
    return _fixPosition(layers, { x, y });
};


/***/ }),
/* 109 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleSlice = (layers) => {
    // 子元素为切片
    if (Array.isArray(layers) && layers.length > 0) {
        for (let i = 0; i < layers.length; i++) {
            if (layers[i]._class === 'slice' && layers[i].isVisible) {
                let currSliceFrame = layers[i].frame;
                for (let j = 0; j < layers.length; j++) {
                    if (layers[j]._class !== 'slice' &&
                        layers[j].isVisible &&
                        layers[j].frame) {
                        let currFrame = layers[j].frame;
                        if (currFrame.x >= currSliceFrame.x &&
                            currFrame.y >= currSliceFrame.y &&
                            currFrame.x + currFrame.width <= currSliceFrame.x + currSliceFrame.width &&
                            currFrame.y + currFrame.height <= currSliceFrame.y + currSliceFrame.height) {
                            layers[j].isVisible = false;
                        }
                    }
                }
            }
            if (Array.isArray(layers[i].layers)) {
                layers[i].layers = handleSlice(layers[i].layers);
            }
        }
    }
    return layers;
};
exports.default = handleSlice;


/***/ }),
/* 110 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 *
 * 坐标格式转换，将相对坐标系转换为绝对坐标系
 *
 */
const formatCoordinate = (layers, groupX = 0, groupY = 0, sizeX = 1, sizeY = 1, parentList = []) => {
    layers = layers.map((layer) => {
        // 背景色记录
        let bg = '0-0-0-0';
        if (layer.backgroundColor && layer.hasBackgroundColor && layer.includeBackgroundColorInExport) {
            const { red, green, blue, alpha } = layer.backgroundColor;
            bg = `${red}-${green}-${blue}-${alpha}`;
        }
        // 当前父图层属性列表
        let currParentList = [`${layer.frame.x},${layer.frame.y},${layer.frame.imgWidth},${layer.frame.imgHeight},${layer.do_objectID},${layer._class},${bg}`, ...parentList];
        layer.parentList = currParentList;
        layer.frame = {
            _class: 'rect',
            x: layer.frame.x * sizeX + groupX,
            y: layer.frame.y * sizeY + groupY,
            imgWidth: layer.frame.width,
            imgHeight: layer.frame.height,
            width: layer.frame.width * sizeX,
            height: layer.frame.height * sizeY,
            sizeX,
            sizeY,
        };
        // 当前缩放比例
        let currSizeX = sizeX, currSizeY = sizeY;
        //基础缩放比例计算
        if (layer._class === 'symbolInstance' && Array.isArray(layer.layers) && layer.layers.length === 1 && layer.layers[0]._class === 'symbolMaster') {
            let symbolInstanceRect = layer.frame;
            let symbolMasterRect = layer.layers[0].frame;
            currSizeX = sizeX * symbolInstanceRect.width / symbolMasterRect.width;
            currSizeY = sizeY * symbolInstanceRect.height / symbolMasterRect.height;
        }
        if (Array.isArray(layer.layers)) {
            layer.layers = formatCoordinate(layer.layers, layer.frame.x, layer.frame.y, currSizeX, currSizeY, currParentList);
        }
        return layer;
    });
    return layers;
};
exports.default = formatCoordinate;


/***/ }),
/* 111 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const calculateMaskIntersection = (parentMask, childMask) => {
    const maskFrame = Object.assign({}, childMask);
    const defaultFrame = { _class: 'rect', x: 0, y: 0, width: 0, height: 0 };
    if (maskFrame.x + maskFrame.width <= parentMask.x) {
        return defaultFrame;
    }
    if (maskFrame.y + maskFrame.height <= parentMask.y) {
        return defaultFrame;
    }
    if (maskFrame.x >= parentMask.x + parentMask.width) {
        return defaultFrame;
    }
    if (maskFrame.y >= parentMask.y + parentMask.height) {
        return defaultFrame;
    }
    if (maskFrame.x < parentMask.x) {
        maskFrame.width = maskFrame.x + maskFrame.width - parentMask.x;
        maskFrame.x = parentMask.x;
    }
    if (maskFrame.y < parentMask.y) {
        maskFrame.height = maskFrame.y + maskFrame.height - parentMask.y;
        maskFrame.y = parentMask.y;
    }
    if (maskFrame.x + maskFrame.width > parentMask.x + parentMask.width) {
        maskFrame.width = parentMask.x + parentMask.width - maskFrame.x;
    }
    if (maskFrame.y + maskFrame.height > parentMask.y + parentMask.height) {
        maskFrame.height = parentMask.y + parentMask.height - maskFrame.y;
    }
    return maskFrame;
};
/**
 * Mask剪切处理
 *
 * 作用范围：Mask上层的兄弟元素及其子元素
 * 关键点：
 * 1. Artboard是最大的Mask
 * 2. hasClippingMask Mask图层标识
 * 3. shouldBreakMaskChain 中断Mask标识
 * @param layers
 * @param param1
 */
const _mask = (layers, { flag = false, frame, baseFrame }) => {
    let currFrame;
    let maskFlag = false;
    const defaultFrame = Object.assign({}, frame);
    // 标记阶段
    for (let i = 0; i < layers.length; i++) {
        // 中断mark, 从本层开始
        if (layers[i].shouldBreakMaskChain) {
            maskFlag = false;
            // 同时恢复剪刀主体
            frame = Object.assign({}, defaultFrame);
        }
        if (flag || maskFlag) {
            if (flag && maskFlag) {
                // frame = calculateMaskIntersection(defaultFrame, currFrame);
            }
            else if (maskFlag) {
                frame = Object.assign({}, currFrame);
            }
            flag = true;
            // 1.切片只被画板剪切
            if (layers[i]._class === 'slice') {
                layers[i].frame = calculateMaskIntersection(baseFrame, layers[i].frame);
            }
            else {
                // 2.其他图层存在mask的时候用mask进行剪切
                layers[i].frame = calculateMaskIntersection(frame, layers[i].frame);
            }
        }
        // 是否中断
        if (layers[i].hasClippingMask) {
            maskFlag = true;
            flag = true;
            currFrame = Object.assign({}, layers[i].frame);
            frame = calculateMaskIntersection(defaultFrame, layers[i].frame);
        }
        // console.log('layers[i].name', layers[i].name, layers[i].layers);
        // 递归子元素
        if (Array.isArray(layers[i].layers)) {
            layers[i].layers = _mask(layers[i].layers, { flag, frame, baseFrame });
        }
    }
    // 删除超出画板的图层
    layers = layers.filter((layer) => {
        if (layer.frame.width === 0 || layer.frame.height === 0) {
            return false;
        }
        return true;
    });
    return layers;
};
exports.default = (layers) => {
    return _mask(layers, { flag: true, frame: layers[0].frame, baseFrame: layers[0].frame });
};


/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 透明图层判断方法，需满足下方所有条件
 * 1. fills数组为空
 * 2. 图层类型_class: 'rectangle', 'triangle', 'oval', 'star', 'polygon',只对这几种类型做处理
 * @param layer
 */
const isTouMing = (layer) => {
    var _a, _b;
    if (!['rectangle', 'triangle', 'oval', 'star', 'polygon'].includes(layer._class)) {
        return false;
    }
    if (!(((_b = (_a = layer.style) === null || _a === void 0 ? void 0 : _a.fills) === null || _b === void 0 ? void 0 : _b.filter(item => item.isEnabled).length) === 0)) {
        return false;
    }
    return true;
};
/**
 * 处理没有填充的图层遮挡问题
 *
 * @param layers
 */
const handleNotFillLayerOrder = (layers) => {
    layers.sort((bLayer, aLayer) => {
        const aLayerIsTouMing = isTouMing(aLayer);
        const bLayerIsTouMing = isTouMing(bLayer);
        // a 不透明，b 透明；当a无法完全覆盖b的时候替换顺序
        if (!aLayerIsTouMing && bLayerIsTouMing &&
            !(aLayer.frame.x <= bLayer.frame.x &&
                aLayer.frame.y <= bLayer.frame.y &&
                aLayer.frame.x + aLayer.frame.width >= bLayer.frame.x + bLayer.frame.width &&
                aLayer.frame.y + aLayer.frame.height >= bLayer.frame.y + bLayer.frame.height)) {
            return -1;
        }
        //  a b都透明的时候 b完全覆盖a 则替换排序
        if (aLayerIsTouMing && bLayerIsTouMing &&
            (aLayer.frame.x >= bLayer.frame.x &&
                aLayer.frame.y >= bLayer.frame.y &&
                aLayer.frame.x + aLayer.frame.width <= bLayer.frame.x + bLayer.frame.width &&
                aLayer.frame.y + aLayer.frame.height <= bLayer.frame.y + bLayer.frame.height)) {
            return -1;
        }
        return 0;
    });
    layers = layers.map((layer) => {
        if (Array.isArray(layer.layers)) {
            layer.layers = handleNotFillLayerOrder(layer.layers);
        }
        return layer;
    });
    return layers;
};
exports.default = handleNotFillLayerOrder;


/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePanel = void 0;
const parsePanel_1 = __webpack_require__(114);
exports.handlePanel = (layers) => {
    for (let i = 0; i < layers.length; i++) {
        layers[i].panel = parsePanel_1.parsePanel(layers[i]);
        if (Array.isArray(layers[i].layers)) {
            layers[i].layers = exports.handlePanel(layers[i].layers);
        }
    }
    return layers;
};


/***/ }),
/* 114 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parsePanel = void 0;
const parseProperty_1 = __webpack_require__(115);
const parseFill_1 = __webpack_require__(116);
const parseTypeFace_1 = __webpack_require__(117);
const parseBorder_1 = __webpack_require__(118);
const parseShadow_1 = __webpack_require__(119);
exports.parsePanel = (layer) => {
    return {
        properties: parseProperty_1.parseProperty(layer),
        fills: parseFill_1.parseFill(layer),
        typefaces: parseTypeFace_1.parseTypeFace(layer),
        borders: parseBorder_1.parseBorder(layer),
        shadows: parseShadow_1.parseShadow(layer),
        code: '',
    };
};


/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseProperty = void 0;
const utils_1 = __webpack_require__(11);
/**
 * 基础属性解析
 * @param layer
 */
exports.parseProperty = (layer) => {
    var _a;
    const { frame, name, style, points, _class, symbolName = '', sharedLayerStyleName = '', sharedTextStyleName = '' } = layer;
    return {
        name,
        position: {
            x: frame.x,
            y: frame.y,
        },
        size: {
            width: frame.width,
            height: frame.height,
        },
        opacity: utils_1.precisionControl((_a = style.contextSettings) === null || _a === void 0 ? void 0 : _a.opacity, 0.01),
        radius: _class === 'rectangle' && points.length === 4 ? points.map(({ cornerRadius }) => +cornerRadius) : [0, 0, 0, 0],
        symbolName,
        sharedLayerStyleName,
        sharedTextStyleName,
    };
};


/***/ }),
/* 116 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseFill = void 0;
const utils_1 = __webpack_require__(11);
/**
 * 填充样式解析
 * 0. 画板=>取背景色即可
 * 1. 填充解析
 *   a. 对纯色填充、渐变填充进行了解析。
 *   b. 图片填充及其他填充未进行解析。
 *
 * @param layer
 */
exports.parseFill = (layer) => {
    // 1. 画板 => 取背景色即可
    if (layer._class === 'artboard' && layer.hasBackgroundColor) {
        return [{
                type: 0,
                color: utils_1.transSketchColor(layer.backgroundColor),
            }];
    }
    // 2. 其他图层
    const { fills = [] } = layer.style;
    return fills
        // 过滤出纯色、渐变切可用的填充
        .filter(({ isEnabled, fillType }) => isEnabled && ([0, 1].includes(fillType)))
        .map(({ fillType, color, gradient }) => {
        // 纯色填充
        if (fillType === 0) {
            return {
                type: 0,
                color: utils_1.transSketchColor(color)
            };
        }
        // 渐变填充
        if (fillType === 1 && [0, 1, 2].includes(gradient.gradientType)) {
            return {
                type: gradient.gradientType + 1,
                stops: gradient.stops.map(({ position, color }) => ({
                    position,
                    color: utils_1.transSketchColor(color),
                }))
            };
        }
    });
};


/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseTypeFace = void 0;
const utils_1 = __webpack_require__(11);
const const_1 = __webpack_require__(44);
/**
 * 基础属性解析
 * @param layer
 */
exports.parseTypeFace = (layer) => {
    const { attributedString, style } = layer;
    if (!attributedString) {
        return [];
    }
    const { string: textContent, // 文本内容
    attributes // 分段样式
     } = attributedString;
    // 分段处理
    const typefaces = attributes.map(({ location, length, attributes }) => {
        var _a, _b, _c, _d, _e, _f, _g;
        let { name: fontFamily, // 获取字体类型
        size: fontSize, } = (_a = attributes.MSAttributedStringFontAttribute) === null || _a === void 0 ? void 0 : _a.attributes;
        /**
         * fontFamily处理
         * 1.PingFang-SCPingFang SC 针对PingFang-SC和PingFang SC在web端不生效的问题，进行修正处理
         *
         */
        fontFamily = fontFamily ? fontFamily.replace(/PingFang-SC|PingFang SC/, 'PingFangSC') : '';
        // 获取字体重量, 默认 Regular;
        const val = fontFamily.split('-').pop();
        const fontWeight = fontFamily.split('-').length >= 2 && const_1.fontWeightTypes.includes(val.toLowerCase()) ? val : '';
        // 获取字体颜色 默认：{ red: 0, green: 0,blue: 0,alpha: 1 }
        const { red, green, blue, alpha } = attributes.MSAttributedStringColorAttribute || { red: 0, green: 0, blue: 0, alpha: 1, _class: 'color' };
        const color = utils_1.transSketchColor({ red, green, blue, alpha });
        // 获取字间距
        const letterSpacing = attributes.kerning || 0;
        /**
         * 获取行间距
         * 1. maximumLineHeight存在，则取maximumLineHeight值
         * 2. maximumLineHeight不存在，则根据字体映射出对应的默认行高
         */
        const lineHeight = ((_b = attributes.paragraphStyle) === null || _b === void 0 ? void 0 : _b.maximumLineHeight) ? (_c = attributes.paragraphStyle) === null || _c === void 0 ? void 0 : _c.maximumLineHeight : const_1.fontSizeLineHeightMap[fontSize];
        // 获取段间距
        const paragraphSpacing = ((_d = attributes.paragraphStyle) === null || _d === void 0 ? void 0 : _d.paragraphSpacing) || 0;
        /**
         * 获取字体水平居中方式
         * 0 水平左对齐
         * 1 水平居中对齐
         * 2 水平右对齐
         * 3 水平两端对齐
         */
        const alignment = ((_e = attributes.paragraphStyle) === null || _e === void 0 ? void 0 : _e.alignment) !== undefined ? +((_f = attributes.paragraphStyle) === null || _f === void 0 ? void 0 : _f.alignment) : 0;
        /**
         * 获取字体垂直居中方式
         * 0 垂直顶部对齐
         * 1 垂直居中对齐
         * 2 垂直底部对齐
         */
        const verticalAlignment = +((_g = style.textStyle) === null || _g === void 0 ? void 0 : _g.verticalAlignment);
        // 获取该段文本内容
        const content = textContent.substr(location, length);
        return {
            fontFamily,
            fontWeight,
            alignment,
            verticalAlignment,
            color,
            fontSize,
            letterSpacing,
            lineHeight,
            paragraphSpacing,
            content
        };
    });
    return typefaces;
};


/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseBorder = void 0;
const utils_1 = __webpack_require__(11);
/**
 * 边框解析
 * 1. 对纯色填充、渐变填充进行了解析。
 * 2. TODO 图片填充及其他填充未进行解析。
 *
 * @param layer
 */
exports.parseBorder = (layer) => {
    const { borders = [] } = layer.style;
    return borders.filter(({ isEnabled, fillType }) => isEnabled && ([0, 1].includes(fillType))) // 过滤出纯色、渐变切可用的填充边框才解析
        .map(({ position, thickness, color, fillType, gradient }) => {
        let fill;
        // 纯色填充
        if (fillType === 0) {
            fill = {
                type: 0,
                color: utils_1.transSketchColor(color)
            };
            // 渐变填充
        }
        else if (fillType === 1 && [0, 1, 2].includes(gradient.gradientType)) {
            fill = {
                type: gradient.gradientType + 1,
                stops: gradient.stops.map(({ position, color }) => ({
                    position,
                    color: utils_1.transSketchColor(color),
                }))
            };
        }
        return {
            position: +position,
            thickness,
            fill
        };
    });
};


/***/ }),
/* 119 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.parseShadow = void 0;
const utils_1 = __webpack_require__(11);
/**
 * 边框解析
 * 1. 对纯色填充、渐变填充进行了解析。
 * 2. TODO 图片填充及其他填充未进行解析。
 *
 * @param layer
 */
exports.parseShadow = (layer) => {
    const { shadows = [], innerShadows = [] } = layer.style;
    return [...shadows, ...innerShadows].filter(({ isEnabled }) => isEnabled) // 过滤出可用的阴影
        .map(({ offsetX, offsetY, blurRadius, spread, color, _class }) => ({
        type: _class === 'innerShadow' ? 0 : 1,
        offsetX,
        offsetY,
        blurRadius,
        spread,
        color: utils_1.transSketchColor(color)
    }));
};


/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList_1 = __webpack_require__(121);
/**
 * 为代码添加className
 * @param data
 * @param numObj
 */
const handleClassName = (data, numObj = { num: 0 }) => {
    for (let i = 0; i < data.length; i++) {
        const layer = data[i];
        const currIndex = numObj.num % classNameList_1.default.length; //英文单词下标
        const numIndex = Math.floor(numObj.num / classNameList_1.default.length) + 1; //数字后缀
        layer.className = numIndex > 1 ? classNameList_1.default[currIndex] + numIndex : classNameList_1.default[currIndex];
        numObj.num++;
        if (Array.isArray(layer.children)) {
            layer.children = handleClassName(layer.children, numObj);
        }
    }
    return data;
};
exports.default = handleClassName;


/***/ }),
/* 121 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList = [
    'rat',
    'valley',
    'pence',
    'unconditional',
    'feather',
    'zoo',
    'build',
    'field',
    'nationality',
    'salad',
    'ferry',
    'building',
    'limit',
    'stewardess',
    'water',
    'manage',
    'path',
    'example',
    'purple',
    'valid',
    'hurry',
    'argue',
    'accommodation',
    'mixture',
    'time',
    'picnic',
    'consensus',
    'smoke',
    'protection',
    'conscience',
    'sense',
    'owe',
    'chant',
    'term',
    'urban',
    'considerate',
    'afraid',
    'bandage',
    'table',
    'tennis',
    'candidate',
    'combine',
    'hurricane',
    'independent',
    'cancer',
    'choose',
    'town',
    'desire',
    'visual',
    'life',
    'submit',
    'physics',
    'meaning',
    'country',
    'half',
    'joy',
    'adult',
    'servant',
    'care',
    'search',
    'same',
    'furniture',
    'agree',
    'heart',
    'unemployment',
    'nearly',
    'bond',
    'master',
    'rise',
    'punish',
    'monument',
    'stick',
    'tax',
    'personnel',
    'fact',
    'therefore',
    'ox',
    'ocean',
    'eagle',
    'cloud',
    'fibre',
    'fiber',
    'bingo',
    'fortunate',
    'mommy',
    'wage',
    'along',
    'surplus',
    'add',
    'outdoors',
    'paper',
    'fetch',
    'church',
    'edition',
    'weather',
    'opera',
    'dot',
    'service',
    'disease',
    'symphony',
    'survival',
    'thus',
    'satisfy',
    'arise',
    'sorry',
    'dinosaur',
    'properly',
    'story',
    'appetite',
    'pronounce',
    'socialist',
    'certain',
    'pea',
    'bacterium',
    'contrary',
    'roof',
    'carve',
    'essay',
    'reward',
    'convenience',
    'export',
    'fit',
    'racial',
    'herself',
    'bid',
    'novelist',
    'safety',
    'off',
    'east',
    'misunderstand',
    'razor',
    'waiting',
    'room',
    'short',
    'surprise',
    'pleasure',
    'tidy',
    'garage',
    'analyse',
    'Am',
    'analyze',
    'notice',
    'violinist',
    'ice',
    'deliberately',
    'alike',
    'perfect',
    'broom',
    'welfare',
    'keyboard',
    'dad',
    'daddy',
    'approximately',
    'hopeful',
    'habit',
    'confidential',
    'complex',
    'recreation',
    'data',
    'kindergarten',
    'sniff',
    'we',
    'studio',
    'overlook',
    'barbershop',
    'minority',
    'escape',
    'jeans',
    'videophone',
    'adapt',
    'report',
    'recorder',
    'betray',
    'vast',
    'arrow',
    'usual',
    'eat',
    'spread',
    'agent',
    'spare',
    'conclusion',
    'rock',
    'hometown',
    'bakery',
    'conclude',
    'worry',
    'operate',
    'floor',
    'area',
    'noise',
    'chairwoman',
    'classroom',
    'communicate',
    'attack',
    'event',
    'dream',
    'criminal',
    'authentic',
    'scarf',
    'senior',
    'OK',
    'okay',
    'description',
    'representative',
    'carriage',
    'sacred',
    'run',
    'software',
    'diet',
    'copy',
    'eastern',
    'carbon',
    'sow',
    'universe',
    'folk',
    'tendency',
    'camp',
    'likely',
    'alive',
    'harvest',
    'devote',
    'marathon',
    'Christian',
    'government',
    'Franc',
    'seminar',
    'departure',
    'forward',
    'person',
    'violence',
    'basketball',
    'gas',
    'fox',
    'advance',
    'majority',
    'credit',
    'relief',
    'prefer',
    'qualification',
    'sand',
    'lift',
    'attain',
    'fantasy',
    'trap',
    'interesting',
    'nothing',
    'civilian',
    'besides',
    'homework',
    'container',
    'fireworks',
    'toy',
    'focus',
    'decide',
    'frighten',
    'cleaner',
    'autumn',
    'beneath',
    'hostess',
    'climb',
    'expert',
    'super',
    'significance',
    'hair',
    'phrase',
    'authority',
    'agricultural',
    'explore',
    'framework',
    'caf',
    'consequence',
    'geography',
    'your',
    'match',
    'hall',
    'ship',
    'suppose',
    'signature',
    'borrow',
    'create',
    'companion',
    'direction',
    'except',
    'big',
    'nutrition',
    'anecdote',
    'string',
    'breast',
    'flashlight',
    'unconscious',
    'champion',
    'funeral',
    'since',
    'how',
    'jacket',
    'robot',
    'like',
    'pleasant',
    'airport',
    'compensate',
    'more',
    'sandwich',
    'boring',
    'seldom',
    'jazz',
    'mile',
    'apologize',
    'shout',
    'commit',
    'can',
    'institution',
    'upstairs',
    'abortion',
    'storage',
    'bravery',
    'envelope',
    'amazing',
    'disappoint',
    'advantage',
    'lab',
    'laboratory',
    'foreign',
    'conduct',
    'prison',
    'agreement',
    'botany',
    'famous',
    'mix',
    'level',
    'go',
    'urgent',
    'scholar',
    'jet',
    'cottage',
    'sigh',
    'maid',
    'pop',
    'popular',
    'advertisement',
    'western',
    'course',
    'wound',
    'together',
    'reservation',
    'because',
    'realise',
    'grateful',
    'huge',
    'turn',
    'knowledge',
    'arrive',
    'seaside',
    'assessment',
    'kilometre',
    'plug',
    'impress',
    'else',
    'fail',
    'discuss',
    'temporary',
    'volcano',
    'call',
    'asleep',
    'amateur',
    'material',
    'fragrant',
    'slave',
    'itself',
    'stupid',
    'central',
    'evening',
    'collision',
    'highway',
    'staff',
    'Asia',
    'medicine',
    'shop',
    'pump',
    'discourage',
    'political',
    'continent',
    'bless',
    'jeep',
    'account',
    'zoom',
    'content',
    'trousers',
    'tonight',
    'spend',
    'astronaut',
    'belt',
    'yet',
    'result',
    'gravity',
    'worth',
    'prize',
    'up',
    'quarrel',
    'born',
    'ring',
    'guard',
    'driver',
    'otherwise',
    'repair',
    'back',
    'reasonable',
    'could',
    'disappear',
    'shy',
    'questionnaire',
    'cheers',
    'interview',
    'kindness',
    'gold',
    'gradual',
    'quit',
    'medical',
    'waste',
    'airmail',
    'expensive',
    'wisdom',
    'favourite',
    'attitude',
    'touch',
    'soil',
    'especially',
    'who',
    'suck',
    'breath',
    'rice',
    'stout',
    'version',
    'oxygen',
    'grey',
    'humorous',
    'burn',
    'regard',
    'seaweed',
    'tremble',
    'pillow',
    'garlic',
    'straw',
    'pineapple',
    'hot',
    'tradition',
    'rescue',
    'again',
    'violent',
    'as',
    'terror',
    'fortune',
    'until',
    'pride',
    'foster',
    'home',
    'peace',
    'shorts',
    'vertical',
    'jam',
    'hatch',
    'atmosphere',
    'stadium',
    'main',
    'people',
    'light',
    'injure',
    'witness',
    'component',
    'weekly',
    'right',
    'dialogue',
    'audience',
    'acquire',
    'store',
    'decline',
    'very',
    'user',
    'spit',
    'undertake',
    'terrible',
    'vacation',
    'much',
    'handbag',
    'saucer',
    'officer',
    'whisper',
    'pleased',
    'greedy',
    'horse',
    'little',
    'cloudy',
    'mainland',
    'fee',
    'taste',
    'alternative',
    'opening',
    'toothache',
    'universal',
    'cow',
    'wheel',
    'pipe',
    'profession',
    'dig',
    'conversation',
    'gain',
    'subjective',
    'thunder',
    'clay',
    'hill',
    'give',
    'budget',
    'against',
    'cage',
    'on',
    'unfit',
    'scene',
    'pint',
    'freezing',
    'oilfield',
    'onion',
    'seed',
    'outstanding',
    'wool',
    'crazy',
    'sew',
    'shelf',
    'freeze',
    'speed',
    'behaviour',
    'behavior',
    'TV',
    'television',
    'chest',
    'knock',
    'something',
    'directory',
    'platform',
    'sightseeing',
    'bay',
    'foreigner',
    'another',
    'oh',
    'zero',
    'boy',
    'handsome',
    'rest',
    'study',
    'front',
    'rely',
    'aside',
    'appeal',
    'competence',
    'fresh',
    'question',
    'south',
    'annoy',
    'pretty',
    'conference',
    'communist',
    'sunlight',
    'cure',
    'slide',
    'glance',
    'paint',
    'wine',
    'dive',
    'admire',
    'existence',
    'bureaucratic',
    'price',
    'skill',
    'nor',
    'enthusiastic',
    'volleyball',
    'dam',
    'delicate',
    'someone',
    'post',
    'father',
    'disgusting',
    'radioactive',
    'offense',
    'passer',
    'by',
    'what',
    'human',
    'guarantee',
    'husband',
    'island',
    'painting',
    'nowadays',
    'hardship',
    'counter',
    'collar',
    'appropriate',
    'thriller',
    'repeat',
    'perform',
    'unbelievable',
    'dozen',
    'Easter',
    'noisy',
    'see',
    'idea',
    'uncomfortable',
    'load',
    'reception',
    'look',
    'value',
    'chess',
    'thunderstorm',
    'convenient',
    'kilo',
    'cassette',
    'toward',
    's',
    'wood',
    'theft',
    'chef',
    'businessman',
    'silly',
    'tomato',
    'brunch',
    'laugh',
    'suitcase',
    'coin',
    'spade',
    'mental',
    'comfort',
    'receiver',
    'Africa',
    'percentage',
    'wrong',
    'correspond',
    'reflect',
    'spy',
    'somebody',
    'religious',
    'last',
    'shade',
    'perfume',
    'pity',
    'trouble',
    'necklace',
    'pancake',
    'interest',
    'hen',
    'dynasty',
    'single',
    'puzzle',
    'head',
    'mean',
    'break',
    'among',
    'certificate',
    'crowd',
    'wander',
    'box',
    'fix',
    'clinic',
    'grammar',
    'ball',
    'translate',
    'delete',
    'cheat',
    'adjust',
    'ill',
    'swing',
    'privilege',
    'quarter',
    'brain',
    'orbit',
    'attach',
    'blind',
    'wild',
    'plastic',
    'adaption',
    'lively',
    'reply',
    'yours',
    'assume',
    'saying',
    'composition',
    'sunshine',
    'union',
    'angle',
    'legal',
    'death',
    'observe',
    'splendid',
    'scar',
    'buy',
    'kill',
    'rent',
    'distinguish',
    'lead',
    'vest',
    'effect',
    'mud',
    'refer',
    'globe',
    'zip',
    'power',
    'marriage',
    'brilliant',
    'pick',
    'speech',
    'ancient',
    'director',
    'replace',
    'pig',
    'autonomous',
    'red',
    'output',
    'die',
    'gifted',
    'station',
    'apple',
    'teamwork',
    'revision',
    'revolution',
    'surgeon',
    'link',
    'average',
    'section',
    'fluency',
    'underground',
    'number',
    'amusement',
    'develop',
    'sword',
    'star',
    'greengrocer',
    'lucky',
    'eraser',
    'rainbow',
    'anxious',
    'beyond',
    'news',
    'waitress',
    'reference',
    'switch',
    'caption',
    'rough',
    'rail',
    'photo',
    'photograph',
    'parrot',
    'must',
    'instant',
    'centre',
    'determine',
    'street',
    'voyage',
    'Ms',
    'patient',
    'wake',
    'worker',
    'Internet',
    'coast',
    'benefit',
    'with',
    'already',
    'face',
    'none',
    'broad',
    'feed',
    'shoot',
    'across',
    'male',
    'Antarctic',
    'zone',
    'continue',
    'blackboard',
    'join',
    'defend',
    'tentative',
    'channel',
    'technical',
    'snow',
    'difficult',
    'bird',
    'widespread',
    'war',
    'pear',
    'lot',
    'excuse',
    'actress',
    'tablet',
    'score',
    'pronunciation',
    'such',
    'accent',
    'chat',
    'deer',
    'memorial',
    'within',
    'tent',
    'microwave',
    'success',
    'luggage',
    'ending',
    'noodle',
    'vain',
    'dentist',
    'district',
    'control',
    'bill',
    'professor',
    'indicate',
    'gentle',
    'helicopter',
    'airplane',
    'please',
    'allowance',
    'forehead',
    'stable',
    'fast',
    'lake',
    'quilt',
    'agenda',
    'command',
    'photographer',
    'monitor',
    'gift',
    'middle',
    'means',
    'glare',
    'breakfast',
    'mad',
    'currency',
    'detective',
    'VCD',
    'visual',
    'compact',
    'disk',
    'prisoner',
    'dinner',
    'helmet',
    'handwriting',
    'thankful',
    'enough',
    'psychology',
    'skin',
    'amuse',
    'cut',
    'poisonous',
    'hearing',
    'praise',
    'flight',
    'ash',
    'crime',
    'troublesome',
    'coke',
    'circulate',
    'address',
    'numb',
    'drunk',
    'resign',
    'menu',
    'congratulate',
    'gay',
    'plain',
    'affair',
    'chicken',
    'deed',
    'pure',
    'cover',
    'error',
    'relationship',
    'snowy',
    'ticket',
    'subject',
    'throughout',
    'applicant',
    'ceiling',
    'manner',
    'type',
    'remark',
    'mop',
    'smog',
    'lid',
    'topic',
    'literature',
    'garment',
    'squirrel',
    'aloud',
    'next',
    'barrier',
    'sharp',
    'declare',
    'headline',
    'appreciation',
    'vivid',
    'well',
    'a',
    'm',
    'am',
    'A',
    'M',
    'AM',
    'thief',
    'skirt',
    'wildlife',
    'cater',
    'tissue',
    'leader',
    'hide',
    'bit',
    'pioneer',
    'nation',
    'disagree',
    'relevant',
    'drawer',
    'dip',
    'treatment',
    'regular',
    'duty',
    'metre',
    'download',
    'canal',
    'vague',
    'foot',
    'letter',
    'sadness',
    'skate',
    'motherland',
    'dress',
    'some',
    'major',
    'lie',
    'tractor',
    'plus',
    'honour',
    'bow',
    'public',
    'reform',
    'fill',
    'mathematics',
    'math',
    'maths',
    'admission',
    'throat',
    'civil',
    'goat',
    'watch',
    'environment',
    'taxpayer',
    'whether',
    'anxiety',
    'carrier',
    'captain',
    'apology',
    'broadcast',
    'compete',
    'matter',
    'decision',
    'unwilling',
    'Europe',
    'coincidence',
    'circle',
    'oppose',
    'forty',
    'arrest',
    'shore',
    'unit',
    'origin',
    'use',
    'inn',
    'electronic',
    'volunteer',
    'team',
    'burst',
    'thread',
    'innocent',
    'skyscraper',
    'hero',
    'twin',
    'tiny',
    'expense',
    'surface',
    'swift',
    'thermos',
    'tutor',
    'dimension',
    'god',
    'behave',
    'jog',
    'wax',
    'bad',
    'outside',
    'vital',
    'leaf',
    'Asian',
    'pet',
    'each',
    'no',
    'theater',
    'think',
    'storm',
    'neighbourhood',
    'clock',
    'dare',
    'explode',
    'peaceful',
    'pale',
    'assumption',
    'typewriter',
    'concentrate',
    'several',
    'bell',
    'bitter',
    'reason',
    'dance',
    'pest',
    'shame',
    'bored',
    'point',
    'analysis',
    'bus',
    'identification',
    'need',
    'spoon',
    'nephew',
    'physician',
    'judgment',
    'gallon',
    'meeting',
    'tobacco',
    'wash',
    'relation',
    'breathe',
    'clean',
    'chart',
    'faith',
    'hook',
    'percent',
    'instruction',
    'daughter',
    'intention',
    'yourself',
    'booth',
    'secure',
    'semicircle',
    'voice',
    'food',
    'strait',
    'addicted',
    'cartoon',
    'prepare',
    'shave',
    'fight',
    'apparent',
    'metal',
    'pink',
    'passive',
    'lovely',
    'transparent',
    'click',
    'outward',
    's',
    'adolescent',
    'than',
    'fire',
    'sick',
    'grasp',
    'ashamed',
    'black',
    'interpreter',
    'weed',
    'from',
    'beauty',
    'schoolboy',
    'towel',
    'beg',
    'biochemistry',
    'into',
    'symptom',
    'subscribe',
    'shrink',
    'allow',
    'accountant',
    'disturb',
    'avenue',
    'meet',
    'message',
    'bread',
    'sheet',
    'secret',
    'whenever',
    'pardon',
    'physical',
    'athlete',
    'requirement',
    'glory',
    'surround',
    'violin',
    'aluminium',
    'birthplace',
    'nuclear',
    'equal',
    'most',
    'often',
    'soup',
    'rigid',
    'adjustment',
    'blue',
    'abstract',
    'steady',
    'rope',
    'sink',
    'goose',
    'place',
    'truck',
    'job',
    'wide',
    'compromise',
    'arrival',
    'rooster',
    'tick',
    'intelligence',
    'theme',
    'wait',
    'postpone',
    'hole',
    'deserve',
    'institute',
    'surrounding',
    'twice',
    'coal',
    'draw',
    'yard',
    'destroy',
    'rag',
    'correction',
    'ownership',
    'predict',
    'agency',
    'I',
    'automatic',
    'guess',
    'lunch',
    'rugby',
    'burden',
    'enter',
    'discussion',
    'struggle',
    'editor',
    'reduce',
    'prohibit',
    'persuade',
    'day',
    'sharpener',
    'research',
    'greet',
    'educator',
    'penny',
    'get',
    'cheap',
    'lose',
    'customs',
    'salty',
    'height',
    'find',
    'above',
    'aid',
    'Arctic',
    'fuel',
    'socialism',
    'bend',
    'terminal',
    'compulsory',
    'winner',
    'grass',
    'sweet',
    'stream',
    'irrigation',
    'busy',
    'low',
    'swap',
    'musician',
    'cuisine',
    'sacrifice',
    'recommend',
    'soldier',
    'ruin',
    'possible',
    'anyway',
    'judge',
    'triangle',
    'mother',
    'attraction',
    'pool',
    'birthday',
    'brown',
    'howl',
    'personally',
    'offshore',
    'application',
    'dioxide',
    'suite',
    'obvious',
    'wife',
    'ham',
    'speaker',
    'mistake',
    'least',
    'game',
    'sympathy',
    'league',
    'clumsy',
    'millionaire',
    'tournament',
    'nod',
    'socket',
    'willing',
    'blame',
    'status',
    'sincerely',
    'emergency',
    'nature',
    'seal',
    'pollute',
    'sometimes',
    'contribute',
    'poster',
    'postage',
    'routine',
    'kettle',
    'piece',
    'listen',
    'lesson',
    'painter',
    'neither',
    'postcode',
    'electric',
    'competition',
    'leather',
    'seem',
    'sausage',
    'format',
    'bamboo',
    'expose',
    'protect',
    'accident',
    'cubic',
    'yoghurt',
    'dictation',
    'plate',
    'inspire',
    'grandson',
    'stop',
    'anyhow',
    'merciful',
    'bathroom',
    'journey',
    'patience',
    'cinema',
    'chair',
    'survive',
    'change',
    'litre',
    'onto',
    'dirty',
    'mineral',
    'gather',
    'milk',
    'grill',
    'wall',
    'object',
    'spot',
    'ready',
    'patent',
    'land',
    'policewoman',
    'media',
    'tale',
    'guest',
    'positive',
    'precise',
    'march',
    'speed',
    'o',
    'clock',
    'donate',
    'want',
    'polite',
    'troop',
    'hotel',
    'classify',
    'fingernail',
    'facial',
    'classmate',
    'graduation',
    'pattern',
    'card',
    'powerful',
    'brewery',
    'homeland',
    'distant',
    'trust',
    'stage',
    'is',
    'sell',
    'import',
    'convince',
    'suffering',
    'pork',
    'grocer',
    'satellite',
    'statistics',
    'himself',
    'defence',
    'rate',
    'tense',
    'army',
    'factory',
    'necessary',
    'agriculture',
    'impression',
    'accustomed',
    'few',
    'flow',
    'hold',
    'moustache',
    'corrupt',
    'tasty',
    'swear',
    'condition',
    'steep',
    'courage',
    'marry',
    'extreme',
    'those',
    'that',
    'tourism',
    'ground',
    'glove',
    'contain',
    'chain',
    'midnight',
    'obtain',
    'will',
    'acid',
    'stair',
    'update',
    'pay',
    'evidence',
    'carpet',
    'advocate',
    'cheer',
    'blow',
    'reject',
    'comprehension',
    'bathe',
    'dumpling',
    'high',
    'my',
    'airspace',
    'promise',
    'athletic',
    'headmistress',
    'slim',
    'after',
    'afterward',
    's',
    'refuse',
    'organ',
    'cautious',
    'advise',
    'fountain',
    'wet',
    'PE',
    'physical',
    'education',
    'remind',
    'whole',
    'down',
    'weekend',
    'punctuation',
    'shopping',
    'flag',
    'violate',
    'premier',
    'slice',
    'hunt',
    'healthy',
    'respond',
    'approve',
    'peach',
    'avoid',
    'sort',
    'daily',
    'trick',
    'bean',
    'curd',
    'many',
    'approach',
    'enquiry',
    'rude',
    'slow',
    'cab',
    'band',
    'transform',
    'paragraph',
    'freeway',
    'production',
    'international',
    'invent',
    'security',
    'rectangle',
    'his',
    'treasure',
    'govern',
    'discount',
    'fantastic',
    'sight',
    'delay',
    'restaurant',
    'independence',
    'spoken',
    'might',
    'which',
    'accept',
    'read',
    'every',
    'scientist',
    'so',
    'fever',
    'acre',
    'argument',
    'holy',
    'crew',
    'door',
    'today',
    'meal',
    'walk',
    'scenery',
    'found',
    'gesture',
    'come',
    'ample',
    'due',
    'tree',
    'meanwhile',
    'try',
    'construction',
    'intend',
    'nervous',
    'here',
    'divide',
    'page',
    'movement',
    'decrease',
    'raise',
    'bench',
    'fence',
    'manager',
    'interval',
    'bowl',
    'heel',
    'disability',
    'case',
    'sweat',
    'link',
    'exist',
    'mourn',
    'performance',
    'glad',
    'ancestor',
    'gun',
    'recognise',
    'different',
    'toast',
    'civilization',
    'language',
    'flee',
    'zebra',
    'select',
    'never',
    'broken',
    'mutton',
    'video',
    'twist',
    'shadow',
    'stocking',
    'algebra',
    'help',
    'cookie',
    'elegant',
    'endless',
    'centigrade',
    'glue',
    'concern',
    'basic',
    'wallet',
    'wave',
    'dish',
    'spelling',
    'know',
    'goods',
    'practise',
    'clothes',
    'scientific',
    'instead',
    'teenager',
    'welcome',
    'careless',
    'weigh',
    'parking',
    'human',
    'being',
    'used',
    'north',
    'chopsticks',
    'principle',
    'loud',
    'African',
    'size',
    'strike',
    'biology',
    'absence',
    'deaf',
    'rare',
    'unrest',
    'saleswoman',
    'royal',
    'below',
    'movie',
    'bowling',
    'resist',
    'kingdom',
    'powder',
    'condemn',
    'capsule',
    'let',
    'practical',
    'paddle',
    'temperature',
    'apart',
    'butterfly',
    'stand',
    'concert',
    'maximum',
    'simplify',
    'sleep',
    'spring',
    'tooth',
    'exercise',
    'reach',
    'overhead',
    'heaven',
    'dignity',
    'believe',
    'commitment',
    'parent',
    'tired',
    'tennis',
    'flesh',
    'ping',
    'pong',
    'circuit',
    'decoration',
    'review',
    'courtyard',
    'potato',
    'various',
    'destination',
    'appoint',
    'affection',
    'severe',
    'bush',
    'conductor',
    'sceptical',
    'mask',
    'why',
    'poor',
    'great',
    'solid',
    'permanent',
    'nest',
    'dust',
    'assess',
    'impossible',
    'would',
    'fat',
    'rapid',
    'northeast',
    'oral',
    'typical',
    'harmful',
    'darkness',
    'defeat',
    'spokeswoman',
    'beneficial',
    'wherever',
    'skip',
    'but',
    'Olympic',
    'confuse',
    'preference',
    'artificial',
    'expression',
    'drink',
    'check',
    'ban',
    'interrupt',
    'divorce',
    'variety',
    'altogether',
    'anniversary',
    'herb',
    'jump',
    'foolish',
    'quick',
    'he',
    'deposit',
    'at',
    'train',
    'shabby',
    'ripen',
    'worldwide',
    'computer',
    'sob',
    'kick',
    'thirst',
    'partly',
    'upset',
    'chalk',
    'diagram',
    'appear',
    'lamp',
    'if',
    'lorry',
    'congratulation',
    'forgetful',
    'castle',
    'skatebroad',
    'toothpaste',
    'ordinary',
    'piano',
    'collection',
    'emperor',
    'remove',
    'unlike',
    'encouragement',
    'bungalow',
    'lazy',
    'measure',
    'perhaps',
    'native',
    'ought',
    'wag',
    'become',
    'astronomer',
    'contemporary',
    'villager',
    'rewind',
    'when',
    'receive',
    'other',
    'salary',
    'potential',
    'compass',
    'animal',
    'ear',
    'pension',
    'annual',
    'salesman',
    'month',
    'behind',
    'drug',
    'creature',
    'hire',
    'respect',
    'granddaughter',
    'partner',
    'jaw',
    'mind',
    'total',
    'alarm',
    'aggressive',
    'mobile',
    'attention',
    'require',
    'air',
    'basement',
    'belong',
    'equipment',
    'recite',
    'standard',
    'straight',
    'chief',
    'decade',
    'shot',
    'earthquake',
    'scare',
    'PC',
    'personal',
    'computer',
    'access',
    'inform',
    'rain',
    'envy',
    'feeling',
    'keep',
    'flour',
    'yell',
    'rid',
    'badminton',
    'newspaper',
    'aim',
    'disadvantage',
    'admirable',
    'stress',
    'unable',
    'occupy',
    'laughter',
    'referee',
    'part',
    'introduce',
    'time',
    'pulse',
    'information',
    'soon',
    'theoretical',
    'junior',
    'journalist',
    'chemist',
    'pace',
    'frequent',
    'explicit',
    'bounce',
    'cat',
    'happen',
    'chemistry',
    'sharpen',
    'safe',
    'form',
    'steal',
    'toilet',
    'clothing',
    'prescription',
    'spell',
    'advice',
    'belief',
    'differ',
    'graduate',
    'seek',
    'spirit',
    'nail',
    'female',
    'development',
    'bottle',
    'blank',
    'round',
    'host',
    'cattle',
    'barber',
    'basis',
    'bite',
    'phone',
    'telephone',
    'parallel',
    'friend',
    'gym',
    'gymnasium',
    'equip',
    'way',
    'occupation',
    'appearance',
    'health',
    'bomb',
    'tour',
    'print',
    'addition',
    'apartment',
    'shut',
    'supper',
    'play',
    'guilty',
    'beast',
    'diary',
    'local',
    'dog',
    'progress',
    'boxing',
    'line',
    'diverse',
    'breakthrough',
    'dictionary',
    'supermarket',
    'shower',
    'wise',
    'controversial',
    'background',
    'spiritual',
    'handle',
    'bridge',
    'succeed',
    'calculate',
    'private',
    'reality',
    'accuracy',
    'smart',
    'sad',
    'butter',
    'contradictory',
    'passenger',
    'contribution',
    'beautiful',
    'sideway',
    'brand',
    'maybe',
    'easy',
    'close',
    'bunch',
    'actual',
    'statesman',
    'province',
    'fierce',
    'Mrs',
    'net',
    'age',
    'owner',
    'silver',
    'per',
    'deep',
    'summary',
    'flash',
    'citizen',
    'Christmas',
    'opposite',
    'blanket',
    'pregnant',
    'one',
    'anchor',
    'root',
    'wear',
    'participate',
    'firm',
    'neck',
    'request',
    'refrigerator',
    'pile',
    'changeable',
    'brave',
    'technology',
    'magazine',
    'the',
    'sparrow',
    'cook',
    'evaluate',
    'traditional',
    'man',
    'profit',
    'random',
    'bean',
    'botanical',
    'natural',
    'night',
    'double',
    'shortly',
    'lounge',
    'teapot',
    'scholarship',
    'tease',
    'warehouse',
    'quiet',
    'bag',
    'side',
    'uniform',
    'pray',
    'just',
    'pupil',
    'whale',
    'helpful',
    'tall',
    'hers',
    'outcome',
    'eager',
    'title',
    'northern',
    'bother',
    'silence',
    'sensitive',
    'scissors',
    'oneself',
    'sail',
    'arrange',
    'postcard',
    'ray',
    'clear',
    'kilogram',
    'typhoon',
    'dismiss',
    'law',
    'disappointed',
    'failure',
    'contradict',
    'primitive',
    'artist',
    'boss',
    'Catholic',
    'chemical',
    'aunt',
    'science',
    'operator',
    'outer',
    'dangerous',
    'birth',
    'arm',
    'improve',
    'separate',
    'expand',
    'America',
    'rubber',
    'police',
    'wire',
    'hurt',
    'virus',
    'textbook',
    'away',
    'winter',
    'carry',
    'acknowledge',
    'block',
    'cycle',
    'fisherman',
    'housework',
    'freedom',
    'discrimination',
    'normal',
    'official',
    'reserve',
    'refresh',
    'accurate',
    'finance',
    'cross',
    'everybody',
    'enjoyable',
    'visit',
    'modem',
    'word',
    'raincoat',
    'nationwide',
    'learn',
    'injury',
    'brother',
    'garbage',
    'tomb',
    'unfair',
    'insect',
    'her',
    'jar',
    'vegetable',
    'she',
    'silent',
    'pack',
    'clap',
    'pain',
    'able',
    'remote',
    'heat',
    'dormitory',
    'worthy',
    'choke',
    'send',
    'both',
    'industry',
    'fall',
    'fragile',
    'maple',
    'bank',
    'suspension',
    'minus',
    'mouse',
    'seize',
    'fax',
    'sing',
    'smell',
    'foggy',
    'occur',
    'pie',
    'cushion',
    'absurd',
    'examine',
    'thin',
    'yellow',
    'salt',
    'sea',
    'free',
    'cream',
    'hungry',
    'elect',
    'policeman',
    'confident',
    'drive',
    'room',
    'nobody',
    'board',
    'cash',
    'important',
    'blouse',
    'name',
    'acquisition',
    'write',
    'article',
    'sheep',
    'marble',
    'self',
    'lung',
    'incident',
    'juice',
    'vinegar',
    'overcoat',
    'tea',
    'simple',
    'snake',
    'concrete',
    'wealth',
    'hand',
    'encourage',
    'swell',
    'good',
    'record',
    'pair',
    'package',
    'entry',
    'extraordinary',
    'harmony',
    'ton',
    'him',
    'quite',
    'attract',
    'publish',
    'uncertain',
    'invitation',
    'whose',
    'enjoy',
    'conservative',
    'stare',
    'spray',
    'money',
    'garden',
    'either',
    'map',
    'e',
    'mail',
    'email',
    'theory',
    'noble',
    'nowhere',
    'produce',
    'sunburnt',
    'shape',
    'too',
    'receipt',
    'me',
    'ski',
    'son',
    'fur',
    'date',
    'optimistic',
    'toothbrush',
    'cap',
    'vote',
    'mirror',
    'shoe',
    'butcher',
    'specialist',
    'cake',
    'bachelor',
    'fruit',
    'tongue',
    'pyramid',
    'kite',
    'carpenter',
    'supreme',
    'cousin',
    'special',
    'somehow',
    'honest',
    'generation',
    'figure',
    'capital',
    'friendship',
    'pencil',
    'lantern',
    'social',
    'lame',
    'drop',
    'finger',
    'allocate',
    'boat',
    'farmer',
    'turning',
    'brochure',
    'possess',
    'pull',
    'magic',
    'save',
    'goal',
    'schoolmate',
    'period',
    'smooth',
    'wealthy',
    'merely',
    'serious',
    'dawn',
    'cup',
    'consume',
    'pond',
    'kind',
    'cough',
    'somewhere',
    'mine',
    'soccer',
    'politician',
    'anywhere',
    'second',
    'alphabet',
    'ripe',
    'hopeless',
    'performer',
    'steam',
    'digital',
    'biography',
    'abundant',
    'canteen',
    'introduction',
    'past',
    'mature',
    'quiz',
    'planet',
    'ourselves',
    'start',
    'seashell',
    'insurance',
    'adventure',
    'enemy',
    'appendix',
    'cancel',
    'unite',
    'damage',
    'rob',
    'method',
    'immediately',
    'fun',
    'brief',
    'electricity',
    'football',
    'exit',
    'morning',
    'liberty',
    'swim',
    'assistant',
    'moral',
    'book',
    'umbrella',
    'operation',
    'however',
    'hunger',
    'order',
    'consult',
    'unusual',
    'preserve',
    'headache',
    'teach',
    'palace',
    'desperate',
    'accessible',
    'lay',
    'am',
    'cause',
    'lemon',
    'motto',
    'stainless',
    'slip',
    'mosquito',
    'small',
    'understand',
    'talent',
    'activity',
    'astonish',
    'regardless',
    'training',
    'season',
    'although',
    'fiction',
    'take',
    'key',
    'bonus',
    'hard',
    'republic',
    'railway',
    'early',
    'final',
    'sit',
    'adequate',
    'accelerate',
    'education',
    'voluntary',
    'desert',
    'pollution',
    'pianist',
    'via',
    'settlement',
    'receptionist',
    'alongside',
    'out',
    'arithmetic',
    'foresee',
    'dilemma',
    'madam',
    'madame',
    'purse',
    'exhibition',
    'popular',
    'year',
    'dynamic',
    'CD',
    'compact',
    'disk',
    'awkward',
    'cabbage',
    'conservation',
    'by',
    'leak',
    'note',
    'strange',
    'inspect',
    'tube',
    'symbol',
    'sleepy',
    'acquaintance',
    'slight',
    'scan',
    'national',
    'shopkeeper',
    'sky',
    'behalf',
    'engine',
    'recover',
    'yes',
    'fine',
    'teacher',
    'accomplish',
    'explain',
    'tram',
    'company',
    'transport',
    'fellow',
    'attend',
    'colour',
    'bury',
    'purchase',
    'quake',
    'act',
    'follow',
    'grocery',
    'crash',
    'plane',
    'systematic',
    'network',
    'fundamental',
    'trade',
    'superior',
    'hotdog',
    'dial',
    'complete',
    'cheerful',
    'frontier',
    'battle',
    'pause',
    'warmth',
    'ruler',
    'mild',
    'explanation',
    'drawback',
    'proud',
    'cigarette',
    'strong',
    'tune',
    'offer',
    'long',
    'thought',
    'absorb',
    'mend',
    'invention',
    'victim',
    'responsibility',
    'minister',
    'tell',
    'sun',
    'rot',
    'beside',
    'approval',
    'radium',
    'pressure',
    'sorrow',
    'consider',
    'diamond',
    'drag',
    'apply',
    'useless',
    'register',
    'depth',
    'difference',
    'X',
    'ray',
    'X',
    'lack',
    'sentence',
    'tend',
    'announce',
    'division',
    'initial',
    'income',
    'all',
    'fist',
    'abolish',
    'them',
    'they',
    'grandma',
    'grandmother',
    'stand',
    'bicycle',
    'fear',
    'engineer',
    'arbitrary',
    'spoonful',
    'hang',
    'tape',
    'particular',
    'assistance',
    'mail',
    'hi',
    'settle',
    'forecast',
    'comment',
    'lady',
    'nursery',
    'radiation',
    'passport',
    'prove',
    'road',
    'house',
    'while',
    'row',
    'precious',
    'arch',
    'mass',
    'grape',
    'poison',
    'statement',
    'mouth',
    'merchant',
    'European',
    'roundabout',
    'wish',
    'enlarge',
    'AIDS',
    'abuse',
    'narrow',
    'grandparents',
    'action',
    'quality',
    'beach',
    'acute',
    'yesterday',
    'general',
    'far',
    'celebration',
    'react',
    'elder',
    'doctor',
    'stone',
    'loss',
    'playground',
    'cheque',
    'sneeze',
    'distinction',
    'gymnastics',
    'concept',
    'excellent',
    'common',
    'commercial',
    'demand',
    'presentation',
    'choir',
    'white',
    'stateswoman',
    'southern',
    'crossroads',
    'kitchen',
    'hobby',
    'preview',
    'win',
    'west',
    'hour',
    'haircut',
    'relay',
    'humour',
    'text',
    'possibility',
    'literary',
    'effort',
    'sir',
    'shark',
    'T',
    'shirt',
    'T',
    'art',
    'grow',
    'forever',
    'banana',
    'opinion',
    'awake',
    'invite',
    'administration',
    'slavery',
    'bishop',
    'diploma',
    'attractive',
    'between',
    'watermelon',
    'deadline',
    'car',
    'elephant',
    'minimum',
    'hammer',
    'baby',
    'exchange',
    'kangaroo',
    'crossing',
    'do',
    'work',
    'ambition',
    'base',
    'loaf',
    'president',
    'businesswoman',
    'merry',
    'minibus',
    'insure',
    'drum',
    'dark',
    'mistaken',
    'Moslem',
    'Muslim',
    'weak',
    'hunter',
    'rainy',
    'degree',
    'club',
    'scold',
    'session',
    'whom',
    'tomorrow',
    'cooker',
    'process',
    'library',
    'beat',
    'neighbour',
    'truth',
    'recent',
    'author',
    'dollar',
    'abandon',
    'beard',
    'silk',
    'BC',
    'tight',
    'bat',
    'victory',
    'honey',
    'substitute',
    'themselves',
    'zipper',
    'licence',
    'chapter',
    'unique',
    'hardly',
    'nut',
    'lawyer',
    'aware',
    'being',
    'alcoholic',
    'vehicle',
    'campaign',
    'upper',
    'lamb',
    'track',
    'branch',
    'large',
    'optional',
    'bacon',
    'whichever',
    'fasten',
    'convey',
    'problem',
    'pilot',
    'sickness',
    'hardworking',
    'atom',
    'eggplant',
    'lip',
    'rubbish',
    'hope',
    'embassy',
    'tin',
    'cost',
    'pin',
    'favour',
    'walnut',
    'entire',
    'mom',
    'mum',
    'share',
    'experiment',
    'leave',
    'sugar',
    'bent',
    'serve',
    'permit',
    'missile',
    'pill',
    'earth',
    'upward',
    's',
    'golf',
    'sculpture',
    'fortnight',
    'lend',
    'fish',
    'near',
    'sound',
    'feel',
    'successful',
    'dry',
    'return',
    'only',
    'waist',
    'trial',
    'ride',
    'put',
    'thorough',
    'and',
    'green',
    'sideroad',
    'rebuild',
    'around',
    'bathtub',
    'conventional',
    'discovery',
    'communication',
    'illegal',
    'now',
    'wrist',
    'museum',
    'guidance',
    'rainfall',
    'awful',
    'cosy',
    'tolerate',
    'rank',
    'throw',
    'category',
    'illness',
    'everywhere',
    'retell',
    'member',
    'petrol',
    'bedroom',
    'ceremony',
    'balance',
    'mustard',
    'polish',
    'constant',
    'uncle',
    'tiresome',
    'tailor',
    'disturbing',
    'moment',
    'statue',
    'moon',
    'system',
    'bargain',
    'energetic',
    'alcohol',
    'expectation',
    'instrument',
    'reliable',
    'equality',
    'greeting',
    'generous',
    'shuttle',
    'or',
    'handkerchief',
    'to',
    'fog',
    'everyone',
    'enterprise',
    'trunk',
    'soft',
    'comb',
    'useful',
    'bride',
    'oil',
    'sudden',
    'before',
    'sponsor',
    'always',
    'candy',
    'pavement',
    'hit',
    'biscuit',
    'table',
    'of',
    'modern',
    'kiss',
    'instruct',
    'without',
    'weight',
    'starvation',
    'city',
    'you',
    'consistent',
    'orange',
    'scream',
    'Oceania',
    'shelter',
    'characteristic',
    'evident',
    'inside',
    'trend',
    'appreciate',
    'fan',
    'attempt',
    'ankle',
    'spaceship',
    'indeed',
    'carrot',
    'abrupt',
    'curriculum',
    'depend',
    'plan',
    'market',
    'eventually',
    'schedule',
    'cool',
    'yummy',
    'strength',
    'fluent',
    'pedestrian',
    'claw',
    'suit',
    'party',
    'set',
    'task',
    'seat',
    'school',
    'applaud',
    'world',
    'furnished',
    'anger',
    'seagull',
    'department',
    'bring',
    'cheese',
    'press',
    'sweep',
    'panic',
    'pub',
    'suspect',
    'prevent',
    'challenging',
    'live',
    'bar',
    'pan',
    'corner',
    'temple',
    'pass',
    'real',
    'frost',
    'trip',
    'character',
    'tyre',
    'race',
    'through',
    'aspect',
    'novel',
    'permission',
    'wonder',
    'false',
    'our',
    'energy',
    'microscope',
    'grandchild',
    'exam',
    'examination',
    'climate',
    'suggestion',
    'consultant',
    'college',
    'Pacific',
    'shirt',
    'phenomenon',
    'cotton',
    'organization',
    'vase',
    'bleed',
    'cruel',
    'smoker',
    'terrify',
    'consist',
    'latter',
    'advertise',
    'harbour',
    'mark',
    'proper',
    'empty',
    'curtain',
    'style',
    'restriction',
    'upon',
    'camera',
    'loose',
    'university',
    'boot',
    'melon',
    'sour',
    'border',
    'coat',
    'hear',
    'consideration',
    'open',
    'anyone',
    'rocket',
    'ours',
    'notebook',
    'ambassadress',
    'skillful',
    'sale',
    'beer',
    'criterion',
    'translation',
    'weep',
    'tiger',
    'woollen',
    'have',
    'hesitate',
    'weakness',
    'balcony',
    'armchair',
    'extension',
    'southwest',
    'function',
    'reading',
    'business',
    'ugly',
    'connect',
    'cigar',
    'aboard',
    'grandpa',
    'grandfather',
    'justice',
    'debt',
    'begin',
    'raw',
    'countryside',
    'fry',
    'wipe',
    'smile',
    'fool',
    'everyday',
    'boom',
    'shaver',
    'erupt',
    'brush',
    'frog',
    'this',
    'court',
    'evolution',
    'insist',
    'grand',
    'week',
    'admit',
    'split',
    'forbid',
    'disaster',
    'society',
    'awesome',
    'embarrass',
    'provide',
    'vice',
    'muddy',
    'couple',
    'ant',
    'relax',
    'pocket',
    'cheek',
    'selfish',
    'forget',
    'balloon',
    'memory',
    'p',
    'm',
    'pm',
    'P',
    'M',
    'PM',
    'dead',
    'chocolate',
    'superb',
    'bee',
    'ad',
    'advertisement',
    'truly',
    'valuable',
    'draft',
    'scratch',
    'procedure',
    'be',
    'should',
    'soap',
    'alley',
    'religion',
    'primary',
    'No',
    'number',
    'punishment',
    'granny',
    'mat',
    'waiter',
    'include',
    'oval',
    'finish',
    'flexible',
    'dustbin',
    'any',
    'top',
    'stay',
    'souvenir',
    'left',
    'bone',
    'ability',
    'stomach',
    'basket',
    'available',
    'regret',
    'ever',
    'anything',
    'ago',
    'previous',
    'window',
    'thrill',
    'federal',
    'bottom',
    'physicist',
    'accompany',
    'increase',
    'murder',
    'accumulate',
    'for',
    'excite',
    'bath',
    'traffic',
    'classic',
    'festival',
    'rather',
    'drill',
    'allergic',
    'insert',
    'fare',
    'spear',
    'theirs',
    'conflict',
    'lecture',
    'even',
    'chaos',
    'youth',
    'fault',
    'desk',
    'list',
    'porridge',
    'tasteless',
    'backward',
    's',
    'suggest',
    'influence',
    'disagreement',
    'virtue',
    'personal',
    'guide',
    'damp',
    'future',
    'cent',
    'fold',
    'over',
    'golden',
    'translator',
    'queen',
    'queue',
    'librarian',
    'communism',
    'signal',
    'outgoing',
    'burglar',
    'deal',
    'motor',
    'growth',
    'state',
    'glass',
    'presence',
    'database',
    'office',
    'family',
    'motorcycle',
    'ridiculous',
    'duck',
    'overcome',
    'cafeteria',
    'motivation',
    'culture',
    'poet',
    'preparation',
    'centimetre',
    'gate',
    'tortoise',
    'hospital',
    'they',
    'architect',
    'heavy',
    'chance',
    'messy',
    'solar',
    'multiply',
    'plant',
    'film',
    'guitar',
    'then',
    'sister',
    'count',
    'experience',
    'once',
    'poem',
    'choice',
    'quantity',
    'immigration',
    'inch',
    'also',
    'similar',
    'outline',
    'ministry',
    'remain',
    'grain',
    'baggage',
    'clerk',
    'withdraw',
    'idiom',
    'architecture',
    'alone',
    'ward',
    'flame',
    'thinking',
    'pot',
    'mailbox',
    'academic',
    'bed',
    'hat',
    'caution',
    'pepper',
    'afford',
    'bound',
    'jewellery',
    'dash',
    'lightning',
    'stranger',
    'port',
    'nose',
    'customer',
    'practice',
    'turkey',
    'meat',
    'tail',
    'situation',
    'position',
    'construct',
    'push',
    'secretary',
    'stain',
    'tension',
    'schoolgirl',
    'risk',
    'late',
    'stamp',
    'absent',
    'challenge',
    'shine',
    'cell',
    'grade',
    'full',
    'collect',
    'minute',
    'catalogue',
    'clarify',
    'fade',
    'sunny',
    'worn',
    'roast',
    'picture',
    'horrible',
    'population',
    'nice',
    'AD',
    'colleague',
    'speak',
    'love',
    'child',
    'achieve',
    'discover',
    'spin',
    'adolescence',
    'nurse',
    'active',
    'panda',
    'adore',
    'forgive',
    'tire',
    'cold',
    'earn',
    'travel',
    'distribute',
    'jungle',
    'dull',
    'clever',
    'dislike',
    'pole',
    'radio',
    'former',
    'careful',
    'employ',
    'whistle',
    'separation',
    'happiness',
    'prayer',
    'underwear',
    'pine',
    'downstairs',
    'dizzy',
    'space',
    'cocoa',
    'abnormal',
    'young',
    'passage',
    'sideways',
    'cube',
    'extra',
    'tool',
    'show',
    'plot',
    'express',
    'southeast',
    'girl',
    'cave',
    'ache',
    'monkey',
    'target',
    'Mr',
    'ambulance',
    'unless',
    'noon',
    'range',
    'shake',
    'vocabulary',
    'miss',
    'dessert',
    'painful',
    'connection',
    'true',
    'casual',
    'strengthen',
    'circumstance',
    'knee',
    'tank',
    'handful',
    'gram',
    'during',
    'correct',
    'importance',
    'wheat',
    'ahead',
    'joke',
    'coffee',
    'shock',
    'punctual',
    'leg',
    'ink',
    'brake',
    'its',
    'anybody',
    'washroom',
    'sex',
    'holiday',
    'downtown',
    'mountainous',
    'organise',
    'strawberry',
    'starve',
    'expect',
    'worthwhile',
    'candle',
    'obey',
    'geometry',
    'doubt',
    'DVD',
    'digital',
    'video',
    'disk',
    'ballet',
    'web',
    'housewife',
    'role',
    'roll',
    'wrinkle',
    'tap',
    'make',
    'eye',
    'traveller',
    'neat',
    'where',
    'almost',
    'ask',
    'laundry',
    'move',
    'labour',
    'a',
    'feast',
    'swallow',
    'pen',
    'award',
    'handy',
    'reporter',
    'relate',
    'stubborn',
    'identify',
    'entrance',
    'forest',
    'that',
    'ice',
    'cream',
    'remember',
    'lemonade',
    'dusty',
    'delight',
    'westward',
    's',
    'litter',
    'imagine',
    'support',
    'machine',
    'charge',
    'fancy',
    'end',
    'disabled',
    'associate',
    'entertainment',
    'fond',
    'porter',
    'hate',
    'appointment',
    'woman',
    'class',
    'album',
    'delighted',
    'fork',
    'promote',
    'doll',
    'cry',
    'bright',
    'deliver',
    'catastrophe',
    'comfortable',
    'portable',
    'not',
    'retire',
    'visitor',
    'ecology',
    'own',
    'recipe',
    'history',
    'luck',
    'visa',
    'unfortunate',
    'achievement',
    'rabbit',
    'programme',
    'sofa',
    'battery',
    'postman',
    'electrical',
    'talk',
    'mercy',
    'iron',
    'present',
    'baseball',
    'strict',
    'bare',
    'airline',
    'comedy',
    'century',
    'dear',
    'apron',
    'flat',
    'assist',
    'sport',
    'politics',
    'fly',
    'actor',
    'farm',
    'song',
    'outing',
    'belly',
    'typist',
    'policy',
    'float',
    'buffet',
    'settler',
    'headmaster',
    'happy',
    'catch',
    'medium',
    'steward',
    'riddle',
    'bear',
    'nearby',
    'mess',
    'paperwork',
    'flu',
    'supply',
    'model',
    'mist',
    'Dr',
    'doctor',
    'popcorn',
    'corn',
    'old',
    'chew',
    'exact',
    'aircraft',
    'view',
    'bike',
    'bicycle',
    'hydrogen',
    'astronomy',
    'cupboard',
    'rule',
    'flower',
    'project',
    'test',
    'represent',
    'shallow',
    'weekday',
    'document',
    'thank',
    'purpose',
    'step',
    'bark',
    'overweight',
    'tower',
    'direct',
    'liquid',
    'worm',
    'hello',
    'hamburger',
    'chorus',
    'stove',
    'reputation',
    'sweater',
    'affect',
    'windy',
    'may',
    'niece',
    'regulation',
    'soul',
    'eyesight',
    'brick',
    'till',
    'harm',
    'ambassador',
    'sailor',
    'egg',
    'wind',
    'tourist',
    'mountain',
    'gallery',
    'clone',
    'mushroom',
    'northwest',
    'needle',
    'tie',
    'trolleybus',
    'committee',
    'in',
    'lap',
    'everything',
    'warm',
    'cyclist',
    'widow',
    'shall',
    'yawn',
    'afternoon',
    'Buddhism',
    'timetable',
    'chairman',
    'are',
    'funny',
    'decorate',
    'edge',
    'file',
    'boycott',
    'underline',
    'technique',
    'childhood',
    'blood',
    'pound',
    'crop',
    'celebrate',
    'absolute',
    'describe',
    'sock',
    'breathless',
    'liberation',
    'knife',
    'rose',
    'custom',
    'resemble',
    'bye',
    'graph',
    'worried',
    'salute',
    'amount',
    'ignore',
    'whoever',
    'barbecue',
    'delicious',
    'summer',
    'rich',
    'telescope',
    'abroad',
    'beef',
    'accuse',
    'sleeve',
    'mm',
    'millimetre',
    'body',
    'navy',
    'basin',
    'say',
    'dusk',
    'these',
    'this',
    'student',
    'steel',
    'friendly',
    'music',
    'altitude',
    'sure',
    'wrestle',
    'it',
    'treat',
    'wonderful',
    'probably',
    'button',
    'force',
    'ambiguous',
    'bridegroom',
    'really',
    'gentleman',
    'giraffe',
    'possession',
    'boil',
    'telephone',
    'recycle',
    'cloth',
    'shoulder',
    'park',
    'confirm',
    'compare',
    'answer',
    'mankind',
    'wolf',
    'danger',
    'hug',
    'camel',
    'shortcoming',
    'river',
    'about',
    'tear',
    'antique',
    'thing',
    'unbearable',
    'sneaker',
    'circus',
    'familiar',
    'still',
    'pretend',
    'beddings',
    'whatever',
    'amaze',
    'vacant',
    'suffer',
    'Atlantic',
    'flood',
    'devotion',
    'wedding',
    'rush',
    'difficulty',
    'friction',
    'king',
    'schoolbag',
    'urge',
    'screen',
    'cast',
    'steak',
    'parcel',
    'square',
    'warn',
    'lock',
    'under',
    'debate',
    'tough',
    'design',
    'corporation',
    'negotiate',
    'new',
    'tip',
    'modest',
    'association',
    'adopt',
    'constitution',
    'curious',
    'medal',
    'taxi',
    'arrangement',
    'packet',
    'pour',
    'group',
    'crayon',
    'musical',
    'angry',
    'boundary',
    'spokesman',
    'lonely',
    'though',
    'academy',
    'their',
    'outspoken',
    'length',
    'thick',
    'wing',
    'myself',
    'digest',
    'plenty',
    'fair',
    'squeeze',
    'product',
    'mention',
    'coach',
    'suitable',
    'kid',
    'lion',
    'straight',
    'forward',
    'there',
    'educate',
    'disk',
    'disc',
    'calm',
    'fridge',
    'refrigerator',
    'distance',
    'relative',
    'satisfaction',
    'village',
    'television',
];
exports.default = classNameList;


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 判断图层是否为单行纯文本
 *
 * @param {Object} layer 图层对象
 */
const isSingleText = (layer) => {
    if (layer.type != "Text") {
        return false;
    }
    if (!layer.style) {
        return false;
    }
    if (layer.style.borderRadius
        || layer.structure.border
        || layer.style.background.color
        || layer.style.background.image
        || (layer.structure.height && layer.style.textStyle.fontSize && layer.style.textStyle.fontSize <= layer.structure.height * 0.5)) {
        return false;
    }
    return true;
};
exports.default = (data) => {
    // 判断是否为M端页面
    const isM = [375, 750].includes(data[0].structure.width);
    data[0].style.width = data[0].structure.width;
    data[0].style.height = data[0].structure.height;
    data[0].style.overflow = 'hidden';
    // PC 端处理
    if (!isM) {
        data[0].style.position = 'absolute';
        data[0].style = Object.assign(Object.assign({}, data[0].style), { position: 'absolute', left: '50%', top: 0, marginLeft: -Math.round(data[0].structure.width * 0.5) });
        // M端处理
    }
    else {
        data[0].style.position = 'relative';
    }
    const childLayerList = data[0].children.map(item => {
        item.style = Object.assign(Object.assign({}, item.style), { position: 'absolute', left: Math.round(item.structure.x), top: Math.round(item.structure.y), width: item.structure.width, height: item.structure.height });
        /**
         * 单行文本不设置宽度
         */
        if (isSingleText(item)) {
            item.style.width = 'auto';
        }
        return item;
    });
    return [Object.assign(Object.assign({}, data[0]), { children: childLayerList })];
};


/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const IdentifyLayout_1 = __webpack_require__(124);
const handleLayer_1 = __webpack_require__(129);
const handleCascading_1 = __webpack_require__(130);
const recombine_1 = __webpack_require__(131);
const handleRow_1 = __webpack_require__(135);
const styleFix_1 = __webpack_require__(137);
// import * as fs from 'fs';
/**
 * 处理单层图层结构
 */
exports.default = (dsl) => {
    let { baseJson, cascadingJson } = handleCascading_1.default(dsl[0]);
    // console.log('12222', JSON.stringify(layer))
    // fs.writeFileSync('./code_dsl_90.json',JSON.stringify(dsl,null,2));
    [baseJson, cascadingJson] = [baseJson, cascadingJson].map(dsl => {
        if (dsl.length === 0) {
            return [];
        }
        // 格式化
        // dsl = formatData(dsl);
        // 结构处理 方案1 
        // dsl = domFormat(dsl);
        // fs.writeFileSync('./code_dsl_91.json',JSON.stringify(dsl,null,2));
        // 结构处理 方案2
        dsl = recombine_1.default(dsl);
        // fs.writeFileSync('./code_dsl_92.json',JSON.stringify(dsl,null,2));
        // 行列处理
        dsl = handleRow_1.default(dsl);
        // fs.writeFileSync('./code_dsl_93.json',JSON.stringify(dsl,null,2));
        // 列合并
        dsl = IdentifyLayout_1.handleSpanGroup(dsl);
        // fs.writeFileSync('./code_dsl_94.json',JSON.stringify(dsl,null,2));
        // 多label标签识别
        dsl = IdentifyLayout_1.handleLabelList(dsl);
        // fs.writeFileSync('./code_dsl_95.json',JSON.stringify(dsl,null,2));
        // 同一行中依据元素的聚合特性进行合并
        dsl = IdentifyLayout_1.handleMergeItem(dsl);
        // fs.writeFileSync('./code_dsl_96.json',JSON.stringify(dsl,null,2));
        // 处理冗余结构
        dsl = handleLayer_1.default(dsl);
        // fs.writeFileSync('./code_dsl_97.json',JSON.stringify(dsl,null,2));
        // 样式修正处理
        dsl = styleFix_1.default(dsl);
        return dsl;
    });
    // fs.writeFileSync('./code_dsl_98.json',JSON.stringify(baseJson,null,2));
    if (Array.isArray(cascadingJson) && cascadingJson.length > 0) {
        // 弹窗
        cascadingJson = cascadingJson.map(item => {
            item.isPosition = true;
            return item;
        });
        if (!baseJson[0].children) {
            baseJson[0].children = [];
        }
        baseJson[0].children = [...baseJson[0].children, ...cascadingJson];
    }
    return baseJson;
};


/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(125), exports);
__exportStar(__webpack_require__(127), exports);
__exportStar(__webpack_require__(128), exports);


/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleLabelList = void 0;
const utils = __webpack_require__(126);
const markLabelList = (data, parent) => {
    // 标记lableList 的情况  距离左边的距离相等 只有一行的情况下
    try {
        for (let item of data) {
            if (utils.isEqualHeight(data) &&
                utils.isSameSpacing(data) &&
                (utils.hasBorder(data) || utils.hasBackground(data)) &&
                utils.hasTextType(data)) {
                parent.isLabelList = true;
            }
            if (item.children && !item.isLabelList) {
                markLabelList(item.children, item);
            }
        }
        return data;
    }
    catch (error) {
        console.log(error);
    }
};
const mergeLabelList = (data) => {
    // 标记 isLabelList=true 合并的相邻行
    try {
        for (let i = 0; i < data.length; i++) {
            let prev = data[i];
            let next = i + 1 <= data.length ? data[i + 1] : null;
            if (next && prev.isLabelList && next.isLabelList) {
                // children 合并
                prev.children = [...prev.children, ...next.children];
                prev.marginBottom = next.structure.y - prev.structure.y - prev.structure.height;
                prev.marginRight = prev.children[1].structure.x - prev.children[0].structure.x - prev.children[0].structure.width;
                prev.structure.height = next.structure.y - prev.structure.y + next.structure.height;
                data.splice(i + 1, 1); // 删除合并完之后的 next
                i--;
            }
            if (prev.children) {
                mergeLabelList(prev.children);
            }
        }
        return data;
    }
    catch (error) {
        console.log(error);
    }
};
exports.handleLabelList = data => {
    data = markLabelList(data);
    data = mergeLabelList(data);
    return data;
};


/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.hasBackground = exports.hasBorder = exports.isSameSpacing = exports.hasTextType = exports.isEqualHeight = exports.isEqualWidth = void 0;
// 公用方法
exports.isEqualWidth = (data) => {
    if (data.length < 2)
        return false;
    // 判断所有的元素是否等宽
    const setList = new Set();
    for (let item of data) {
        setList.add(item.structure.width);
    }
    return setList.keys.length === 1;
};
exports.isEqualHeight = (data) => {
    if (data.length < 2)
        return false;
    // 判断所有的元素是否等高
    const setList = new Set();
    for (let item of data) {
        setList.add(item.structure.height);
    }
    return setList.keys.length === 1;
};
// 第一层级只包含一个文本节点
exports.hasTextType = (data) => {
    var _a;
    let flag = false;
    for (let item of data) {
        if (item.type === "Container" && ((_a = item.children) === null || _a === void 0 ? void 0 : _a.length)) {
            let textList = [];
            for (let subItem of item.children) {
                if (subItem.type === 'Text') {
                    textList.push(subItem.name);
                }
            }
            flag = textList.length === 1;
            if (!flag) {
                break;
            }
        }
    }
    return flag;
};
// 多行之间判断是否是否相同间距
exports.isSameSpacing = (data) => {
    if (data.length < 2)
        return false;
    let flag = true;
    let space = data[1].structure.x - data[0].structure.x - data[0].structure.width;
    for (let i = 2; i < data.length; i++) {
        if (data[i].structure.y == data[i - 1].structure.y &&
            Math.abs(data[i].structure.x - data[i - 1].structure.x - data[i - 1].structure.width - space) > 2) {
            flag = false;
            break;
        }
    }
    return flag;
};
exports.hasBorder = (data) => {
    for (let item of data) {
        if (!(item.structure.border && item.structure.border.top.width)) {
            return false;
        }
    }
    return true;
};
exports.hasBackground = (data) => {
    var _a, _b;
    for (let item of data) {
        if (!((_b = (_a = item.style) === null || _a === void 0 ? void 0 : _a.background) === null || _b === void 0 ? void 0 : _b.color)) {
            return false;
        }
    }
    return true;
};


/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleSpanGroup = void 0;
const utils_1 = __webpack_require__(32);
// import * as fs from 'fs';
//判断是否为列关系
function isSpan(item, beforeItem) {
    if (Array.isArray(item.children) &&
        Array.isArray(beforeItem.children) &&
        item.children.length == beforeItem.children.length &&
        item.children.length >= 2) {
        let centreFlag = true;
        let itemClass = item.children[0].type != 'Text' ? 'notext' : 'text';
        let beforeItemClass = beforeItem.children[0].type != 'Text' ? 'notext' : 'text';
        if (itemClass == beforeItemClass) { // ?: 同为文案，或同时不是文案，不判定为列元素
            centreFlag = false;
        }
        for (let i = 0; i < item.children.length; i++) {
            const currItem = item.children[i];
            const currBeforeItem = beforeItem.children[i];
            let currClass = currItem.type != 'Text' ? 'notext' : 'text';
            if (currClass != itemClass) { // 与该行第一个元素相比较，不相同不判定为列
                centreFlag = false;
            }
            let beforeClass = currBeforeItem.type != 'Text' ? 'notext' : 'text';
            if (beforeClass != beforeItemClass) {
                centreFlag = false;
            }
            // 排除多段文案的情况
            if ((!currItem.id && currClass === 'text') || (!currBeforeItem.id && beforeClass === 'text')) {
                centreFlag = false;
            }
            if (Math.abs(currItem.structure.x +
                currItem.structure.width / 2 -
                currBeforeItem.structure.x -
                currBeforeItem.structure.width / 2) > 2) {
                centreFlag = false;
            }
        }
        return centreFlag;
    }
    else {
        return false;
    }
}
// 判断是否为文本列关系
function isTextSpan(item, beforeItem) {
    if (Array.isArray(item.children) &&
        Array.isArray(beforeItem.children) &&
        item.children.length == beforeItem.children.length &&
        item.children.length >= 2) {
        let centreFlag = true;
        if (item.children[0].type !== 'Text' || beforeItem.children[0].type !== 'Text') {
            return false;
        }
        if (!item.children[0].style.textStyle.fontSize || !item.children[0].style.textStyle.fontWeight) {
            return false;
        }
        if (!beforeItem.children[0].style.textStyle.fontSize || !beforeItem.children[0].style.textStyle.fontWeight) {
            return false;
        }
        const getClass = (layer) => {
            var _a, _b, _c, _d;
            return `${(_b = (_a = layer.style) === null || _a === void 0 ? void 0 : _a.textStyle) === null || _b === void 0 ? void 0 : _b.fontSize}_${(_d = (_c = layer.style) === null || _c === void 0 ? void 0 : _c.textStyle) === null || _d === void 0 ? void 0 : _d.fontWeight}`;
        };
        let itemClass = getClass(item.children[0]);
        let beforeItemClass = getClass(beforeItem.children[0]);
        if (itemClass === beforeItemClass) {
            centreFlag = false;
        }
        if ((!item.id && itemClass === 'text') || (!beforeItem.id && beforeItemClass === 'text')) {
            centreFlag = false;
        }
        for (let i = 0; i < item.children.length; i++) {
            const currItem = item.children[i];
            const currBeforeItem = beforeItem.children[i];
            let currClass = getClass(currItem);
            if (currClass != itemClass) {
                centreFlag = false;
            }
            let beforeClass = getClass(currBeforeItem);
            if (beforeClass != beforeItemClass) {
                centreFlag = false;
            }
            if (Math.abs(//不垂直居中
            currItem.structure.x +
                currItem.structure.width / 2 -
                currBeforeItem.structure.x -
                currBeforeItem.structure.width / 2) > 2
                &&
                    Math.abs(//不左对齐
                    currItem.structure.x - currBeforeItem.structure.x) > 2) {
                centreFlag = false;
            }
        }
        return centreFlag;
    }
    else {
        return false;
    }
}
exports.handleSpanGroup = (data) => {
    if (!data)
        return data;
    if (data.length > 1) {
        let totalArr = []; // 包含列关系和非列关系的所有layer数据
        let itemArr = [data[0]]; // 存储 没有列关系 或合并在一起的列关系 的数据
        for (let i = 1; i < data.length; i++) {
            const item = data[i];
            const beforeItem = data[i - 1];
            // 直接进入总layer数据列表totalArr: itemArr.length >= 2 或 (!isSpan && !isTextSpan)
            // 否则判定为列关系，将列关系数组加入到totalArr
            if (!(itemArr.length < 2 && (isSpan(item, beforeItem) || isTextSpan(item, beforeItem)))) {
                totalArr.push(itemArr);
                itemArr = []; // itemArr.length >= 2 时清空
            }
            itemArr.push(item); // 否则加入当前 item 的数据
        }
        totalArr.push(itemArr);
        if (totalArr.length > 1) {
            let dataChildren = [];
            for (let j = 0; j < totalArr.length; j++) {
                const item = totalArr[j];
                if (item.length == 1) {
                    dataChildren.push(item[0]);
                }
                else if (item.length >= 2) {
                    let spanList = {};
                    //计算span的strutrue
                    let currDivX = 0, currDivY = 0, currMaxX = 0, currMaxY = 0;
                    spanList.children = item;
                    for (let j = 0; j < spanList.children.length; j++) {
                        if (j == 0) {
                            currDivX = spanList.children[j].structure.x;
                            currDivY = spanList.children[j].structure.y;
                            currMaxX = spanList.children[j].structure.x + spanList.children[j].structure.width;
                            currMaxY = spanList.children[j].structure.y + spanList.children[j].structure.height;
                        }
                        else {
                            if (currDivX > spanList.children[j].structure.x) {
                                currDivX = spanList.children[j].structure.x;
                            }
                            if (currDivY > spanList.children[j].structure.y) {
                                currDivY = spanList.children[j].structure.y;
                            }
                            if (currMaxX <
                                spanList.children[j].structure.x + spanList.children[j].structure.width) {
                                currMaxX = spanList.children[j].structure.x + spanList.children[j].structure.width;
                            }
                            if (currMaxY <
                                spanList.children[j].structure.y + spanList.children[j].structure.height) {
                                currMaxY = spanList.children[j].structure.y + spanList.children[j].structure.height;
                            }
                        }
                    }
                    let itemList = [];
                    for (let j = 0; j < item[0].children.length; j++) {
                        const oneItem = item[0].children[j];
                        const twoItem = item[1].children[j];
                        let currDivX = Math.min(oneItem.structure.x, twoItem.structure.x), currDivY = Math.min(oneItem.structure.y, twoItem.structure.y), currMaxX = Math.max(oneItem.structure.x + oneItem.structure.width, twoItem.structure.x + twoItem.structure.width), currMaxY = Math.max(oneItem.structure.y + oneItem.structure.height, twoItem.structure.y + twoItem.structure.height);
                        itemList.push({
                            id: utils_1.uniqueId(),
                            name: 'ItemList',
                            class: 'Span',
                            type: 'Container',
                            structure: {
                                x: currDivX,
                                y: currDivY,
                                width: currMaxX - currDivX,
                                height: currMaxY - currDivY,
                            },
                            style: {},
                            children: [oneItem, twoItem]
                        });
                    }
                    dataChildren.push({
                        id: utils_1.uniqueId(),
                        name: 'List',
                        class: 'Span',
                        type: 'Container',
                        structure: {
                            x: currDivX,
                            y: currDivY,
                            width: currMaxX - currDivX,
                            height: currMaxY - currDivY,
                        },
                        style: {},
                        children: itemList
                    });
                }
            }
            data = dataChildren;
        }
        else if (data.length == 2) {
            let itemList = [];
            for (let j = 0; j < data[0].children.length; j++) {
                const oneItem = data[0].children[j];
                const twoItem = data[1].children[j];
                let currDivX = Math.min(oneItem.structure.x, twoItem.structure.x), currDivY = Math.min(oneItem.structure.y, twoItem.structure.y), currMaxX = Math.max(oneItem.structure.x + oneItem.structure.width, twoItem.structure.x + twoItem.structure.width), currMaxY = Math.max(oneItem.structure.y + oneItem.structure.height, twoItem.structure.y + twoItem.structure.height);
                itemList.push({
                    id: utils_1.uniqueId(),
                    name: 'ItemList',
                    class: 'Span',
                    type: 'Container',
                    structure: {
                        x: currDivX,
                        y: currDivY,
                        width: currMaxX - currDivX,
                        height: currMaxY - currDivY,
                    },
                    style: {},
                    children: [oneItem, twoItem]
                });
            }
            data = itemList;
        }
    }
    for (let i = 0; i < data.length; i++) {
        if (Array.isArray(data[i].children)) {
            data[i].children = exports.handleSpanGroup(data[i].children);
        }
    }
    return data;
};


/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleMergeItem = void 0;
const utils_1 = __webpack_require__(32);
const isEqualList = (data) => {
    let widthInit = data[0].structure.height;
    for (let i = 1; i < data.length; i++) {
        const item = data[i];
        if (Math.abs(item.structure.height - widthInit) >= 2) {
            return false;
        }
    }
    return true;
};
//所有元素在同一条线上
const isLine = (data) => {
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        for (let j = i; j < data.length; j++) {
            const itemJ = data[j];
            if (itemJ.structure.y >= item.structure.y + item.structure.height || item.structure.y >= itemJ.structure.y + itemJ.structure.height) {
                return false;
            }
        }
    }
    return true;
};
exports.handleMergeItem = (data, parent) => {
    if (!data) {
        return data;
    }
    /**
     * 1.父元素宽度接近画板
     * 2.子元素呈现出明显的聚合
     *
     * 左聚合：当中心在左边时且全部元素在左边
     * 右聚合：当中心在右边时且全部元素在右边
     */
    if (isLine(data) && parent && parent.structure.height > 0.7 * 750 && data.length > 2 && !isEqualList(data) && data[0].name != 'ItemList') {
        let flagL = true;
        let flagR = true;
        for (let i = 0; i < data.length; i++) {
            const item = data[i];
            if (item.structure.x + item.structure.height / 2 < parent.structure.x + parent.structure.height / 2) {
                if (item.structure.x + item.structure.height > parent.structure.x + parent.structure.height * 0.5) {
                    flagL = false;
                }
            }
            if (item.structure.x + item.structure.height / 2 >= parent.structure.x + parent.structure.height / 2) {
                if (item.structure.x < parent.structure.x + parent.structure.height * 0.5) {
                    flagR = false;
                }
            }
        }
        if (flagL) {
            let spanArr = [];
            let otherArr = [];
            for (let i = 0; i < data.length; i++) {
                const item = data[i];
                if (item.structure.x + item.structure.height / 2 < parent.structure.x + parent.structure.height / 2) {
                    spanArr.push(item);
                }
                else {
                    otherArr.push(item);
                }
            }
            if (spanArr.length > 1) {
                let spanMinX = spanArr[0].structure.x, spanMinY = spanArr[0].structure.y, spanMaxX = spanArr[0].structure.x + spanArr[0].structure.height, spanMaxY = spanArr[0].structure.y + spanArr[0].structure.height;
                for (let i = 0; i < spanArr.length; i++) {
                    const item = spanArr[i];
                    if (item.structure.x < spanMinX) {
                        spanMinX = item.structure.x;
                    }
                    if (item.structure.y < spanMinY) {
                        spanMinY = item.structure.y;
                    }
                    if (item.structure.x + item.structure.height > spanMaxX) {
                        spanMaxX = item.structure.x + item.structure.height;
                    }
                    if (item.structure.y + item.structure.height > spanMaxY) {
                        spanMaxY = item.structure.y + item.structure.height;
                    }
                }
                data = [{
                        id: utils_1.uniqueId(),
                        class: 'Span',
                        type: 'Container',
                        name: 'Span3',
                        structure: {
                            zIndex: parent.structure.zIndex,
                            x: spanMinX,
                            y: spanMinY,
                            width: spanMaxX - spanMinX,
                            height: spanMaxY - spanMinY,
                        },
                        children: spanArr,
                        style: {}
                    }, ...otherArr];
            }
        }
        if (flagR) {
            let spanArr = [];
            let otherArr = [];
            for (let i = 0; i < data.length; i++) {
                const item = data[i];
                if (item.structure.x + item.structure.height / 2 >= parent.structure.x + parent.structure.height / 2) {
                    spanArr.push(item);
                }
                else {
                    otherArr.push(item);
                }
            }
            if (spanArr.length > 1) {
                let spanMinX = spanArr[0].structure.x, spanMinY = spanArr[0].structure.y, spanMaxX = spanArr[0].structure.x + spanArr[0].structure.height, spanMaxY = spanArr[0].structure.y + spanArr[0].structure.height;
                for (let i = 0; i < spanArr.length; i++) {
                    const item = spanArr[i];
                    if (item.structure.x < spanMinX) {
                        spanMinX = item.structure.x;
                    }
                    if (item.structure.y < spanMinY) {
                        spanMinY = item.structure.y;
                    }
                    if (item.structure.x + item.structure.height > spanMaxX) {
                        spanMaxX = item.structure.x + item.structure.height;
                    }
                    if (item.structure.y + item.structure.height > spanMaxY) {
                        spanMaxY = item.structure.y + item.structure.height;
                    }
                }
                data = [...otherArr, {
                        id: utils_1.uniqueId(),
                        class: 'Row',
                        type: 'Container',
                        name: 'Row',
                        structure: {
                            zIndex: parent.structure.zIndex,
                            x: spanMinX,
                            y: spanMinY,
                            width: spanMaxX - spanMinX,
                            height: spanMaxY - spanMinY,
                        },
                        children: spanArr,
                        style: {}
                    }];
            }
        }
    }
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        if (Array.isArray(item.children)) {
            item.children = exports.handleMergeItem(item.children, item);
        }
    }
    return data;
};


/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 冗余html结构处理
 * 1.Container 子元素无背景，无边框属于无意义元素 -删除子元素处理
 * 2.Container 子元素有背景或者边框，父元素无背景及边框-删除父元素
 * 3.Image 父元素无背景及边框-删除父元素
 * 4.Image 子元素与父元素位置大小完全相同 -删除父元素
 * 5.父元素为artboard的情况下，不删除父元素
 * @param {Array} item
 */
const handleSingleLayer = (item) => {
    var _a, _b;
    if (item.children && item.children.length == 1 && !(item.type == 'Mask' && item.style['border-radius'])) {
        //Container 子元素无背景，无边框属于无意义元素 -删除子元素处理
        if (item.children[0].type == 'Container' || (!item.children[0].type && (item.children[0].sign === '__li' || item.children[0].sign === '__oth'))) {
            if (!item.children[0].textContainer &&
                !item.children[0].structure.border &&
                item.children[0]._class != 'artboard' &&
                !item.children[0].style.transform &&
                !item.children[0].style.background &&
                !item.children[0].isList) {
                if (item.children[0].children) {
                    item.children = JSON.parse(JSON.stringify(item.children[0].children));
                }
                else {
                    item.children = [];
                }
                item = handleSingleLayer(item);
            }
            //Container 子元素有背景或者边框 且父元素不为artboard
            else if (item._class != 'artboard' && !item.style.transform) {
                //父元素无背景及边框-删除父元素
                if (item.type === 'Container' && !item.children[0].structure.border && !item.style.background && !item.style.borderRadius) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                    //子元素有背景色，父子结构大小完全相同-删除父元素
                    /* eslint-disable */
                }
                else if (((_b = (_a = item.children[0].style.background) === null || _a === void 0 ? void 0 : _a.color) === null || _b === void 0 ? void 0 : _b.alpha) === 1 &&
                    !item.style.borderRadius &&
                    item.children[0].structure.height === item.structure.height &&
                    item.children[0].structure.width === item.structure.width &&
                    item.children[0].structure.x === item.structure.x &&
                    item.children[0].structure.y === item.structure.y) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                }
                /* eslint-disable */
            }
        }
        //Image
        else if (item.children[0].type == 'Image' && item._class != 'artboard' && !item.style['transform']) {
            //父元素无背景及边框-删除父元素
            if (item.type == 'Container') {
                if (!item.structure.border && !item.style.background) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                    //子元素与父元素完全相同-删除父元素
                }
                else if (item.children[0].structure.height === item.structure.height &&
                    item.children[0].structure.width === item.structure.width &&
                    item.children[0].structure.x === item.structure.x &&
                    item.children[0].structure.y === item.structure.y &&
                    !item.style.background) {
                    item = item.children[0];
                    item = handleSingleLayer(item);
                }
            }
        }
        //Text -暂时不处理
        else if (item.children[0].type === 'Text') {
            //父元素无背景及边框-删除父元素
            // if (item.type==Container) {
            //   if (!item.style['border']&&!item.style['background']) {
            //     item =item.children[0];
            //     item= handleSingleLayer(item);
            //   }
            // }
        }
    }
    return item;
};
const handleLayer = (data) => {
    for (let i = 0; i < data.length; i++) {
        data[i] = handleSingleLayer(data[i]);
        if (Array.isArray(data[i].children)) {
            data[i].children = handleLayer(data[i].children);
        }
    }
    return data;
};
exports.default = handleLayer;


/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 判断是否有包含或者重叠
 *
 * @param {*} target
 * @param {*} container
 * @returns
 */
const isContain = (target, container) => {
    if (!target.structure || !container.structure) {
        return false;
    }
    target = target.structure;
    container = container.structure;
    var targetWidth = target.width, targetHeight = target.height, targetLeft = target.x, targetRight = target.x + target.width, targetTop = target.y, targetBottom = target.y + target.height, containerWidth = container.width, containerHeight = container.height, containerLeft = container.x, containerRight = container.x + container.width, containerTop = container.y, containerBottom = container.y + container.height;
    if (targetLeft >= containerLeft &&
        targetTop >= containerTop &&
        targetRight <= containerRight &&
        targetBottom <= containerBottom) {
        return true;
    }
    return false;
};
/**
 * 判断图层是否有半透明背景
 *
 * @param {Object} layer 图层
 * @returns
 */
const isOpacityBackground = (layer) => {
    let isHasBackground = false;
    if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length) {
        layer.style.fills = layer.style.fills.filter((fillItem) => {
            return fillItem.isEnabled;
        });
    }
    if (layer.backgroundColor && layer.hasBackgroundColor) {
        const { alpha } = layer.backgroundColor;
        if (0 < alpha && alpha < 1) {
            isHasBackground = true;
        }
    }
    else if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length &&
        layer.style.fills[layer.style.fills.length - 1].isEnabled) {
        // 处理填充 fills,fills是数组，只支持单个情况,处理成背景色
        const fillStyle = layer.style.fills[layer.style.fills.length - 1];
        let { alpha, red, green, blue } = fillStyle.color;
        // 如果设置了 Opacity 属性，则 fills border 需要乘于这个数值
        if (layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * alpha;
        }
        if (0 < alpha && alpha < 1) {
            isHasBackground = true;
        }
    }
    return isHasBackground;
};
const isNotOpacityBackground = (layer) => {
    let isHasBackground = false;
    if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length) {
        layer.style.fills = layer.style.fills.filter((fillItem) => {
            return fillItem.isEnabled;
        });
    }
    if (layer.backgroundColor && layer.hasBackgroundColor) {
        const { alpha, red, green, blue } = layer.backgroundColor;
        if (alpha == 1) {
            isHasBackground = true;
        }
    }
    else if (layer.style &&
        Array.isArray(layer.style.fills) &&
        layer.style.fills.length &&
        layer.style.fills[layer.style.fills.length - 1].isEnabled) {
        // 处理填充 fills,fills是数组，只支持单个情况,处理成背景色
        const fillStyle = layer.style.fills[layer.style.fills.length - 1];
        let { alpha, red, green, blue } = fillStyle.color;
        // 如果设置了 Opacity 属性，则 fills border 需要乘于这个数值
        if (layer.style.contextSettings) {
            alpha = layer.style.contextSettings.opacity * alpha;
        }
        if (alpha == 1) {
            isHasBackground = true;
        }
    }
    return isHasBackground;
};
// 判断是否为底栏
const isBottomBar = (layer, artLayer) => {
    if (layer.structure &&
        artLayer.structure &&
        isNotOpacityBackground(layer) &&
        layer.isVisible &&
        layer.structure.x == artLayer.structure.x &&
        layer.structure.width == artLayer.structure.width &&
        layer.structure.y + layer.structure.height ==
            artLayer.structure.y + artLayer.structure.height &&
        layer.structure.height > 40 &&
        layer.structure.height < 140) {
        return true;
    }
    return false;
};
const handleCascading = (data) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
    if (data.children.length < 2) {
        return {
            baseJson: [Object.assign(Object.assign({}, data), { children: [] }), ...data.children],
            cascadingJson: [],
        };
    }
    let cascadingIndex = -1;
    for (let i = 0; i < data.children.length; i++) {
        const layer = data.children[i];
        if (layer.type !== 'Text' &&
            ((_a = layer.structure) === null || _a === void 0 ? void 0 : _a.x) <= ((_b = data.structure) === null || _b === void 0 ? void 0 : _b.x) + 1 &&
            ((_c = layer.structure) === null || _c === void 0 ? void 0 : _c.y) <= ((_d = data.structure) === null || _d === void 0 ? void 0 : _d.y) + 1 &&
            ((_e = layer.structure) === null || _e === void 0 ? void 0 : _e.x) + ((_f = layer.structure) === null || _f === void 0 ? void 0 : _f.width) >=
                ((_g = data.structure) === null || _g === void 0 ? void 0 : _g.width) + ((_h = data.structure) === null || _h === void 0 ? void 0 : _h.x) - 1 &&
            ((_j = layer.structure) === null || _j === void 0 ? void 0 : _j.y) + ((_k = layer.structure) === null || _k === void 0 ? void 0 : _k.height) >=
                ((_l = data.structure) === null || _l === void 0 ? void 0 : _l.height) + ((_m = data.structure) === null || _m === void 0 ? void 0 : _m.y) - 1) {
            cascadingIndex = i;
            break;
        }
    }
    if (cascadingIndex > 0) {
        return {
            baseJson: [Object.assign(Object.assign({}, data), { children: [] }), ...data.children.slice(0, cascadingIndex)],
            cascadingJson: data.children.slice(cascadingIndex),
        };
    }
    return {
        baseJson: [Object.assign(Object.assign({}, data), { children: [] }), ...data.children],
        cascadingJson: [],
    };
};
exports.default = handleCascading;


/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleOver_1 = __webpack_require__(132);
const handleDelete_1 = __webpack_require__(133);
const recombineTreeDataNew = (data) => {
    let currRecord = data[data.length - 1];
    if (data.length > 1) {
        let preLength = data.length;
        for (let i = 0; i < data.length - 1; i++) {
            let record = data[data.length - 2 - i];
            // 父元素被指定的情况
            if (currRecord.parentId) {
                if (currRecord.parentId === record.id) {
                    if (!record.children) {
                        record.children = [];
                    }
                    record.children.unshift(JSON.parse(JSON.stringify(currRecord)));
                    data.length = data.length - 1;
                    break;
                }
                // 包含关系的情况
            }
            else if (isContain(currRecord, record, data[0])) {
                if (!record.children) {
                    record.children = [];
                }
                record.children.unshift(JSON.parse(JSON.stringify(currRecord)));
                data.length = data.length - 1;
                break;
            }
        }
        if (preLength > data.length) {
            recombineTreeDataNew(data);
        }
    }
    return data;
};
const isContain = (target, container, artboard) => {
    if (!target || !container) {
        return false;
    }
    // 如果容器是画板，所有元素都被画板包含
    if (container.id === artboard.id) {
        return true;
    }
    // 如果是旋转
    if (container.istransformContain) {
        return false;
    }
    if (target.structure.x <= container.structure.x &&
        target.structure.y <= container.structure.y &&
        target.structure.x + target.structure.width >=
            container.structure.x + container.structure.width &&
        target.structure.y + target.structure.height >=
            container.structure.y + container.structure.height &&
        !(target.structure.x == container.structure.x &&
            target.structure.y == container.structure.y &&
            target.structure.x + target.structure.width ==
                container.structure.x + container.structure.width &&
            target.structure.y + target.structure.height ==
                container.structure.y + container.structure.height)) {
        return false;
    }
    let currTarget = JSON.parse(JSON.stringify(target));
    let curr = handleOver_1.default(currTarget, container);
    let targetH = target.structure.height;
    if (artboard.structure.y + artboard.structure.height - target.structure.y <
        targetH) {
        targetH =
            artboard.structure.y +
                artboard.structure.height -
                target.structure.y;
        targetH = targetH < 0 ? 0 : targetH;
    }
    if (curr > target.structure.width * targetH * 0.3) {
        return true;
    }
    return false;
};
exports.default = (data, currIndex = { num: 0 }) => {
    // 记录层级标识
    data = data.map((item) => {
        currIndex.num = currIndex.num + 1;
        item.structure.zIndex = currIndex.num;
        return item;
    });
    data = recombineTreeDataNew(data);
    data = handleDelete_1.default(data);
    return data;
};


/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理超出
 * @param {*} targetLayer 被比较的图层
 * @param {*} currLayer 比较的图层
 */
exports.default = (targetLayer, currLayer) => {
    if (!targetLayer || !currLayer) {
        return -1;
    }
    let targetLayerLeft = targetLayer.structure.x, targetLayerRight = targetLayer.structure.x + targetLayer.structure.width, targetLayerTop = targetLayer.structure.y, targetLayerBottom = targetLayer.structure.y + targetLayer.structure.height, currLayerLeft = currLayer.structure.x, currLayerRight = currLayer.structure.x + currLayer.structure.width, currLayerTop = currLayer.structure.y, currLayerBottom = currLayer.structure.y + currLayer.structure.height;
    if (currLayerLeft > targetLayerLeft) {
        targetLayer.structure.x = currLayer.structure.x;
        targetLayer.structure.width =
            targetLayer.structure.width - (currLayerLeft - targetLayerLeft) > 0
                ? targetLayer.structure.width - (currLayerLeft - targetLayerLeft)
                : 0;
    }
    if (currLayerTop > targetLayerTop) {
        targetLayer.structure.y = currLayer.structure.y;
        targetLayer.structure.height =
            targetLayer.structure.height - (currLayerTop - targetLayerTop) > 0
                ? targetLayer.structure.height - (currLayerTop - targetLayerTop)
                : 0;
    }
    if (currLayerBottom < targetLayerBottom) {
        targetLayer.structure.height =
            targetLayer.structure.height - (targetLayerBottom - currLayerBottom) > 0
                ? targetLayer.structure.height - (targetLayerBottom - currLayerBottom)
                : 0;
    }
    if (currLayerRight < targetLayerRight) {
        targetLayer.structure.width =
            targetLayer.structure.width - (targetLayerRight - currLayerRight) > 0
                ? targetLayer.structure.width - (targetLayerRight - currLayerRight)
                : 0;
    }
    return targetLayer.structure.width * targetLayer.structure.height;
};


/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const isCover_1 = __webpack_require__(134);
/**
 * 反向覆盖的元素则进行定位处理
 */
const handleDelete = (data) => {
    var _a, _b, _c, _d, _e, _f;
    for (let i = 0; i < data.length; i++) {
        const currItemI = data[i];
        // if (currItemI.width <= 1) {
        //     console.log(1111)
        //   currItemI.isPosition = true;
        // }
        for (let j = i; j < data.length; j++) {
            const currItemJ = data[j];
            if (currItemI.structure.zIndex > currItemJ.structure.zIndex &&
                isCover_1.default(currItemI, currItemJ)) {
                if (((_c = (_b = (_a = currItemI.style) === null || _a === void 0 ? void 0 : _a.background) === null || _b === void 0 ? void 0 : _b.color) === null || _c === void 0 ? void 0 : _c.alpha) === 1) {
                    currItemJ.isDelete = true;
                }
                // if (!currItemI.isPosition) {
                //   currItemI.isPosition = true;
                // }
            }
            else if (currItemI.structure.zIndex < currItemJ.structure.zIndex &&
                isCover_1.default(currItemJ, currItemI)) {
                if (((_f = (_e = (_d = currItemJ.style) === null || _d === void 0 ? void 0 : _d.background) === null || _e === void 0 ? void 0 : _e.color) === null || _f === void 0 ? void 0 : _f.alpha) === 1) {
                    currItemI.isDelete = true;
                }
                // if (!currItemJ.isPosition) {
                //   currItemJ.isPosition = true;
                // }
            }
            //   else if(j!=i&&handleOver(JSON.parse(JSON.stringify(currItemI)),currItemJ)>0){
            //     if (currItemI.structure.zIndex >currItemJ.structure.zIndex ) {
            //         console.log(4111)
            //       currItemI.isPosition = true;
            //     }else{
            //         console.log(5111)
            //       currItemJ.isPosition = true;
            //     }
            //   }
        }
    }
    // 去掉需要删除的
    data = data.filter((item) => !item.isDelete);
    //递归处理children
    for (let i = 0; i < data.length; i++) {
        if (Array.isArray(data[i].children) && data[i].children.length > 0) {
            data[i].children = handleDelete(data[i].children);
        }
    }
    return data;
};
exports.default = handleDelete;


/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 判断包含关系
 * @param {*} target
 * @param {*} contain
 */
const isCover = (target, contain) => {
    if (target.structure.x <= contain.structure.x &&
        target.structure.y <= contain.structure.y &&
        target.structure.x + target.structure.width >= contain.structure.x + contain.structure.width &&
        target.structure.y + target.structure.height >= contain.structure.y + contain.structure.height &&
        !(target.structure.x == contain.structure.x &&
            target.structure.y == contain.structure.y &&
            target.structure.x + target.structure.width == contain.structure.x + contain.structure.width &&
            target.structure.y + target.structure.height == contain.structure.y + contain.structure.height)) {
        return true;
    }
    return false;
};
exports.default = isCover;


/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const const_1 = __webpack_require__(136);
const utils_1 = __webpack_require__(32);
const handleSpan = (data) => {
    let positionList = [];
    let noPostionList = [];
    data.forEach((item) => {
        if (item.isPosition) {
            positionList.push(item);
        }
        else {
            noPostionList.push(item);
        }
    });
    data = noPostionList;
    //让宽度最大的元素放在最前面
    data = data.sort((a, b) => b.structure.width - a.structure.width);
    //处理进行分列
    //同列的元素外面加一个Span容器
    // 结构调整data
    //children本身全部在一行的不需要加Span容器
    let assignSpanList = [];
    for (let i = 0; i < data.length; i++) {
        let flag = true;
        for (let j = 0; j < assignSpanList.length; j++) {
            //属于哪个容器就放到哪个容器中
            for (let n = 0; n < assignSpanList[j].length; n++) {
                if (flag && ((assignSpanList[j][n].structure.x <= data[i].structure.x && data[i].structure.x < (+assignSpanList[j][n].structure.x + assignSpanList[j][n].structure.width)) ||
                    (+assignSpanList[j][n].structure.x < +data[i].structure.x + data[i].structure.width && +data[i].structure.x + data[i].structure.width <= (+assignSpanList[j][n].structure.x + assignSpanList[j][n].structure.width)))) {
                    assignSpanList[j].push(data[i]);
                    flag = false;
                }
            }
        }
        //都不属于则新建容器，放入其中
        if (flag) {
            assignSpanList.push([data[i]]);
        }
    }
    //children本身全部在一列的不需要加Span容器
    if (data.length == assignSpanList[0].length) {
        assignSpanList = assignSpanList[0].map(item => [item]);
    }
    /**
     * 分列完成后，给属于同一列的加容器
     * 同时给容器赋值x,y,width,height
     * 获取结构调整后的data
     */
    let spanList = [];
    for (let i = 0; i < assignSpanList.length; i++) {
        if (assignSpanList[i].length == 1) {
            spanList.push(assignSpanList[i][0]);
        }
        else {
            let currSpan = [], currDivX = 0, currDivY = 0, currMaxX = 0, currMaxY = 0, zIndex = 0;
            currSpan = assignSpanList[i].sort((a, b) => a.structure.y - b.structure.y);
            // currSpan = assignSpanList[i];
            zIndex = currSpan[0].structure.zIndex;
            for (let j = 0; j < currSpan.length; j++) {
                zIndex = currSpan[j].structure.zIndex > zIndex ? currSpan[j].structure.zIndex : zIndex;
                if (j == 0) {
                    currDivX = currSpan[j].structure.x;
                    currDivY = currSpan[j].structure.y;
                    currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                }
                else {
                    if (currDivX > currSpan[j].structure.x) {
                        currDivX = currSpan[j].structure.x;
                    }
                    if (currDivY > currSpan[j].structure.y) {
                        currDivY = currSpan[j].structure.y;
                    }
                    if (currMaxX < currSpan[j].structure.x + currSpan[j].structure.width) {
                        currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    }
                    if (currMaxY < currSpan[j].structure.y + currSpan[j].structure.height) {
                        currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                    }
                }
            }
            spanList.push({
                id: utils_1.uniqueId(),
                name: 'Span1',
                class: 'Span',
                type: 'Container',
                structure: {
                    zIndex,
                    x: currDivX,
                    y: currDivY,
                    width: currMaxX - currDivX,
                    height: currMaxY - currDivY,
                },
                children: currSpan,
                style: {}
            });
        }
    }
    data = spanList.sort((a, b) => a.structure.x - b.structure.x);
    data = [...data, ...positionList];
    return data;
};
//分行处理
//判断是否为同一行
//同一行给予DIV包裹并且将该行元素作为DIV的子元素
function isSame(data) {
    let flag = true;
    if (Array.isArray(data) && data.length > 2) {
        let firstItemWidth = data[0].structure.width;
        let firstItemHeight = data[0].structure.height;
        data.forEach((item) => {
            if (Math.abs(firstItemWidth - item.structure.width) > 1 || Math.abs(firstItemHeight - item.structure.height) > 1) {
                flag = false;
            }
        });
    }
    return flag;
}
//判断属于左边的图片
const isLeftImg = (layer, parent) => {
    //必须为图片类型
    if (layer.type !== 'Image') {
        return false;
    }
    //距离画板左边的距离<100
    if (layer.structure.x > 100) {
        return false;
    }
    //距离画板左边的距离<100
    if (layer.structure.width < 40) {
        return false;
    }
    //父元素必须存在
    if (!parent) {
        return false;
    }
    //容器的宽度>750*0.7
    if (parent.structure.width < 750 * 0.7) {
        return false;
    }
    for (let i = 1; i < parent.children.length; i++) {
        const item = parent.children[i];
        if (item.structure.x < layer.structure.x + layer.structure.width) {
            return false;
        }
    }
    return true;
};
const isLeftImgRightInfo = (item) => {
    if (Array.isArray(item.children) && item.children.length > 3 && isLeftImg(item.children[0], item)) {
        let itemChildren = [...item.children];
        let firstChildren = itemChildren.shift();
        let currSpan = itemChildren;
        let flag = false;
        for (let j = 0; j < currSpan.length; j++) {
            let item = currSpan[j];
            for (let i = j; i < currSpan.length; i++) {
                const itemI = currSpan[i];
                if (((itemI.structure.x + itemI.structure.width > item.structure.x && item.structure.x >= itemI.structure.x) ||
                    (item.structure.x + item.structure.width > itemI.structure.x && itemI.structure.x >= item.structure.x)) && (item.structure.y + item.structure.height <= itemI.structure.y ||
                    itemI.structure.y + itemI.structure.height <= item.structure.y)) {
                    flag = true;
                }
            }
        }
        if (flag) {
            let currDivX, currDivY, currMaxX, currMaxY;
            let zIndex = currSpan[0].structure.zIndex;
            for (let j = 0; j < currSpan.length; j++) {
                zIndex = currSpan[j].structure.zIndex > zIndex ? currSpan[j].structure.zIndex : zIndex;
                if (j == 0) {
                    currDivX = currSpan[j].structure.x;
                    currDivY = currSpan[j].structure.y;
                    currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                }
                else {
                    if (currDivX > currSpan[j].structure.x) {
                        currDivX = currSpan[j].structure.x;
                    }
                    if (currDivY > currSpan[j].structure.y) {
                        currDivY = currSpan[j].structure.y;
                    }
                    if (currMaxX < currSpan[j].structure.x + currSpan[j].structure.width) {
                        currMaxX = currSpan[j].structure.x + currSpan[j].structure.width;
                    }
                    if (currMaxY < currSpan[j].structure.y + currSpan[j].structure.height) {
                        currMaxY = currSpan[j].structure.y + currSpan[j].structure.height;
                    }
                }
            }
            item.name = 'LeftImgRightInfo';
            firstChildren.class_name = 'left';
            firstChildren.class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
            item.children = [firstChildren, {
                    id: utils_1.uniqueId(),
                    name: 'Span2',
                    class: 'Span',
                    type: 'Container',
                    structure: {
                        zIndex,
                        x: currDivX,
                        y: currDivY,
                        width: currMaxX - currDivX,
                        height: currMaxY - currDivY,
                    },
                    children: currSpan,
                    style: {},
                    class_name: 'right',
                    class_type: const_1.CLASS_TYPE.RELY_ON_PARENT,
                }];
        }
        else {
            item.children = handleSpan(item.children);
        }
        return item;
    }
    else {
        item.children = handleSpan(item.children);
    }
    return item;
};
//上下合并
const handleMerge = (data) => {
    let leftRItem = {};
    let flag = false;
    for (let i = 0; i < data.length; i++) {
        if (flag) {
            let secondChild = leftRItem.children[1];
            if (data[i].structure.x > secondChild.structure.x - 2) {
                secondChild.children.push(Object.assign({}, data[i]));
                secondChild.structure.height = data[i].structure.y + data[i].structure.height - secondChild.structure.y;
                leftRItem.structure.height = data[i].structure.y + data[i].structure.height - leftRItem.structure.y;
                if (secondChild.structure.width + secondChild.structure.x < data[i].structure.x + data[i].structure.width) {
                    secondChild.structure.width = data[i].structure.x + data[i].structure.width - secondChild.structure.x;
                }
                leftRItem.structure.width = secondChild.structure.width + secondChild.structure.x - leftRItem.structure.x;
                data[i].delete = true;
            }
            else {
                flag = false;
            }
        }
        if (data[i].name == 'LeftImgRightInfo') {
            flag = true;
            leftRItem = data[i];
        }
    }
    return data.filter(item => !item.delete);
};
const handleRow = (data, parent) => {
    if (parent && parent.textContainer) {
        return data;
    }
    if (isSame(data)) {
        //递归处理children
        for (let i = 0; i < data.length; i++) {
            if (Array.isArray(data[i].children) && data[i].children.length > 0) {
                data[i].children = handleRow(data[i].children, data[i]);
            }
        }
        return data;
    }
    //让高度最大的元素放在最前面
    // data = data.sort((a, b) => b.structure.height - a.structure.height);
    //处理进行分行
    //同行的元素外面加一个Row容器
    // 结构调整data
    //children本身全部在一行的不需要加Row容器
    //let assignRowList = [];
    // let rowArr = [];
    // for (let i = 0; i < data.length; i++) {
    //     let flag = true;
    //     if (rowArr.length > 0) {
    //         flag = false;
    //         for (let j = 0; j < rowArr.length; j++) {
    //             const item = rowArr[j];
    //             if (data[i].structure.y + data[i].structure.height > item.structure.y && item.structure.y + item.structure.height > data[i].structure.y) {
    //                 flag = true;
    //             }
    //         }
    //         if (!flag) {
    //             assignRowList.push(rowArr);
    //             rowArr = [];
    //         }
    //     }
    //     rowArr.push(data[i]);
    // }
    // if (rowArr.length > 0) {
    //     if (rowArr.length == data.length) {
    //         //等待华哥算法更新后 过滤掉其中已经处理的部分
    //         if (parent && parent.type != '__li') {
    //             data = handleSpan(data);
    //         }
    //         for (let i = 0; i < data.length; i++) {
    //             if (Array.isArray(data[i].children) && data[i].children.length > 0) {
    //                 data[i].children = handleRow(data[i].children, data[i]);
    //             }
    //         }
    //         return data;
    //     } else {
    //         assignRowList.push(rowArr);
    //     }
    // }
    let assignRowList = [];
    for (let i = 0; i < data.length; i++) {
        let flag = true;
        for (let j = 0; j < assignRowList.length; j++) {
            //属于哪个容器就放到哪个容器中
            for (let n = 0; n < assignRowList[j].length; n++) {
                if (flag && ((assignRowList[j][n].structure.y <= data[i].structure.y && data[i].structure.y < (+assignRowList[j][n].structure.y + assignRowList[j][n].structure.height)) ||
                    (+assignRowList[j][n].structure.y < +data[i].structure.y + data[i].structure.height && +data[i].structure.y + data[i].structure.height <= (+assignRowList[j][n].structure.y + assignRowList[j][n].structure.height)))) {
                    assignRowList[j].push(data[i]);
                    flag = false;
                }
            }
        }
        //都不属于则新建容器，放入其中
        if (flag) {
            assignRowList.push([data[i]]);
        }
    }
    /**
     * 分行完成后，给属于同一行的加容器
     * 同时给容器赋值x,y,width,height
     * 获取结构调整后的data
     */
    let rowList = [];
    //children本身全部在一行的不需要加Row容器
    if (assignRowList.length && data.length == assignRowList[0].length) {
        if (parent && parent.sign != '__li') {
            rowList = handleSpan(assignRowList[0]);
        }
        else {
            rowList = assignRowList[0];
        }
        if (parent) {
            parent.class = 'Row';
        }
    }
    else {
        for (let i = 0; i < assignRowList.length; i++) {
            if (assignRowList[i].length == 1) {
                //分行之后进行分列
                if (assignRowList[i][0].children && assignRowList[i].name == 'Row') {
                    assignRowList[i][0].children = handleSpan(assignRowList[i][0].children);
                }
                rowList.push(assignRowList[i][0]);
            }
            else {
                let currRow = [], currDivX = 0, currDivY = 0, currMaxX = 0, currMaxY = 0, zIndex = 0;
                currRow = assignRowList[i].sort((a, b) => a.structure.x - b.structure.x);
                zIndex = currRow[0].structure.zIndex;
                for (let j = 0; j < currRow.length; j++) {
                    zIndex = currRow[j].structure.zIndex > zIndex ? currRow[j].structure.zIndex : zIndex;
                    if (j == 0) {
                        currDivX = currRow[j].structure.x;
                        currDivY = currRow[j].structure.y;
                        currMaxX = currRow[j].structure.x + currRow[j].structure.width;
                        currMaxY = currRow[j].structure.y + currRow[j].structure.height;
                    }
                    else {
                        if (currDivX > currRow[j].structure.x) {
                            currDivX = currRow[j].structure.x;
                        }
                        if (currDivY > currRow[j].structure.y) {
                            currDivY = currRow[j].structure.y;
                        }
                        if (currMaxX < currRow[j].structure.x + currRow[j].structure.width) {
                            currMaxX = currRow[j].structure.x + currRow[j].structure.width;
                        }
                        if (currMaxY < currRow[j].structure.y + currRow[j].structure.height) {
                            currMaxY = currRow[j].structure.y + currRow[j].structure.height;
                        }
                    }
                }
                //分行之后进行分列表
                let currWidth = currMaxX - currDivX;
                let currX = currDivX;
                //特征分列
                let item = isLeftImgRightInfo({
                    id: utils_1.uniqueId(),
                    class: 'Row',
                    type: 'Container',
                    name: 'Row',
                    structure: {
                        zIndex,
                        x: currX,
                        y: currDivY,
                        width: currWidth,
                        height: currMaxY - currDivY,
                    },
                    children: currRow,
                    style: {}
                });
                // if (parent && parent.structure.width) {
                //     currWidth = parent.structure.width;
                //     currX = parent.structure.x;
                //     // 处理border的影响
                //     if (parent.border && parent.border.structure.width) {
                //         currWidth = currWidth - parent.border.structure.width * 2;
                //         currX = currX + parent.border.structure.width;
                //     }
                // }
                rowList.push(item);
            }
        }
    }
    // data = [...data,...positionList];
    // data = rowList.sort((a, b) => a.structure.y - b.structure.y);
    data = handleMerge(data);
    //递归处理children
    for (let i = 0; i < data.length; i++) {
        if (Array.isArray(data[i].children) && data[i].children.length > 0) {
            data[i].children = handleRow(data[i].children, data[i]);
        }
    }
    return data;
};
exports.default = handleRow;


/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CLASS_TYPE = void 0;
exports.CLASS_TYPE = {
    "NORMAL": 1,
    "RELY_ON_PARENT": 2,
    "RELY_ON_CHILD_AND_PARENT": 3,
};


/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const styleFix = (dsl) => {
    dsl.map((layer) => {
        var _a;
        // 图片包含子元素的情况
        if (layer.type === 'Image' && ((_a = layer.children) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            layer.type = 'Container';
            layer.style.background = {
                image: {
                    url: layer.value
                },
                size: {
                    width: layer.structure.width,
                    height: layer.structure.height
                }
            };
            delete layer.style.borderRadius;
        }
        if (Array.isArray(layer.children)) {
            layer.children = styleFix(layer.children);
        }
        return layer;
    });
    return dsl;
};
exports.default = styleFix;


/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleOverlap_1 = __webpack_require__(139);
const calculateRow_1 = __webpack_require__(141);
const isBlock_1 = __webpack_require__(142);
const calculateBlock_1 = __webpack_require__(143);
const handleParentIsText_1 = __webpack_require__(151);
const markIsOnlyText_1 = __webpack_require__(152);
const row_1 = __webpack_require__(153);
// 特殊布局识别
const handleTypeLayout_1 = __webpack_require__(33);
const calculateClassName_1 = __webpack_require__(154);
// import * as fs from 'fs';
/**
 * 布局
 * @param {Layer[]} data
 * @param {Layer} parent
 * @returns
 */
const handleLayout = (data, parent) => {
    //使用绝对定位的图层数组
    let dataIsPositionLayout = [];
    //不使用绝对定位的图层数组
    let dataIsNotPositionLayout = [];
    //图层分组
    data.forEach((item) => {
        if (parent && item.isPosition) {
            dataIsPositionLayout.push(item);
        }
        else {
            dataIsNotPositionLayout.push(item);
        }
    });
    data = dataIsNotPositionLayout;
    // 竖向列表
    if (calculateClassName_1.isLeftImgRightInfo(data)) {
        data = calculateClassName_1.calculateLeftImgRightInfo(data);
    }
    if (calculateClassName_1.isVerticalList(data)) {
        data = calculateClassName_1.calculateVerticalList(data);
    }
    else {
        data = calculateClassName_1.handleContinuousListItem(data);
    }
    // fs.writeFileSync('./code_dsl_101.json',JSON.stringify(data,null,2));
    switch (true) {
        case parent === undefined:
            data = calculateRow_1.default(data);
            break;
        case parent && parent.textContainer: //一行文本多个样式不走布局
            break;
        case parent && parent._class == "text": // 父元素是文本，子元素接对定位（目前没有进到这里）
            data = handleParentIsText_1.default(data, parent);
            break;
        case handleTypeLayout_1.isLabelList(data, parent): // 标签列表，目前多段文本会走此处
            data = handleTypeLayout_1.layoutLabelList(data, parent);
            break;
        case isBlock_1.default(data):
            data = calculateBlock_1.default(data, parent);
            break;
        case row_1.isRow(data):
            data = row_1.layoutRow(data, parent);
            break;
        default:
            break;
    }
    if (parent) {
        markIsOnlyText_1.default(data, parent);
    }
    //使用绝对定位的布局
    data = handleOverlap_1.default(dataIsPositionLayout, parent, data);
    // fs.writeFileSync('./code_dsl_102.json',JSON.stringify(data,null,2));
    //递归子集
    if (Array.isArray(data)) {
        for (let i = 0; i < data.length; i++) {
            // 单行文本宽度是否全去掉
            try {
                if (handleTypeLayout_1.isSingleText(data[i])) {
                    delete data[i].style.width;
                    //避免纵向排列的,右对齐的部分，text-align=right 也要去掉
                    if (data.length > 1 && data[i].style.textAlign == 'right' && parent && data[i].structure.width < parent.structure.width * 0.9) {
                        delete data[i].style.textAlign;
                    }
                }
            }
            catch (error) {
                console.log('文本宽度剔除异常' + error);
            }
            if (Array.isArray(data[i].children) && data[i].children.length > 0) {
                data[i].children = handleLayout(data[i].children, data[i]);
            }
        }
    }
    // fs.writeFileSync('./code_dsl_103.json',JSON.stringify(data,null,2));
    return data;
};
exports.default = handleLayout;


/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const getBorderWidth_1 = __webpack_require__(140);
/**
 *处理绝对定位
 *
 * @param {*} dataIsPositionLayout  需要绝对定位的数组
 * @param {*} parent  父图层
 * @param {*} data 通过其他方式布局的数组
 * @returns
 */
const handleOverlap = (dataIsPositionLayout, parent, data) => {
    if (!parent || dataIsPositionLayout.length == 0) {
        return data;
    }
    const { borderTopWidth: parentBorderTopWidth, borderLeftWidth: parentBorderLeftWidth } = getBorderWidth_1.default(parent);
    parent.addClassName = 'clearfloat';
    if (parent._class == 'artboard') {
        parent.style['overflow'] = 'hidden';
    }
    if (!parent.style['position']) {
        parent.style['position'] = 'relative';
    }
    //按照由小到到的顺序排列
    for (let i = 0; i < dataIsPositionLayout.length; i++) {
        dataIsPositionLayout[i].style.position = 'absolute';
        dataIsPositionLayout[i].style['left'] = dataIsPositionLayout[i].structure.x - parent.structure.x - parentBorderLeftWidth;
        dataIsPositionLayout[i].style['top'] = dataIsPositionLayout[i].structure.y - parent.structure.y - parentBorderTopWidth;
        dataIsPositionLayout[i].style['width'] = dataIsPositionLayout[i].structure.width || 'auto';
        dataIsPositionLayout[i].style['height'] = dataIsPositionLayout[i].structure.height;
    }
    data = [...data, ...dataIsPositionLayout];
    parent.children = data;
    data = parent.children;
    return data;
};
exports.default = handleOverlap;


/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 *获取各边宽度
 *
 * @param {*} layer
 * @returns
 * {
    layerBorderTopWidth,
    layerBorderBottomWidth,
    layerBorderLeftWidth,
    layerBorderRightWidth
  }
 */
const getBorderWidth = (layer) => {
    var _a, _b, _c, _d, _e;
    //父元素边框宽度
    const border = ((_a = layer.structure) === null || _a === void 0 ? void 0 : _a.border) || {};
    return {
        borderTopWidth: ((_b = border.top) === null || _b === void 0 ? void 0 : _b.width) || 0,
        borderBottomWidth: ((_c = border.bottom) === null || _c === void 0 ? void 0 : _c.width) || 0,
        borderLeftWidth: ((_d = border.left) === null || _d === void 0 ? void 0 : _d.width) || 0,
        borderRightWidth: ((_e = border.right) === null || _e === void 0 ? void 0 : _e.width) || 0
    };
};
exports.default = getBorderWidth;


/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理最外层布局
 *
 * @param {Array} data 图层Tree
 * @returns
 */
const calculateRow = (data) => {
    //最外层补偿值
    if (!data.length)
        return;
    let minX = data[0].structure.x;
    for (let i = 0; i < data.length; i++) {
        if (minX > data[i].structure.x) {
            minX = data[i].structure.x;
        }
    }
    for (let i = 0; i < data.length; i++) {
        if (data[i]._class == "artboard") {
            data[i].style["width"] = data[i].structure.width;
            data[i].style["margin"] = `0 auto`;
            data[i].style["overflow"] = "hidden";
            if (i > 0) {
                data[i].style.marginTop = 0;
            }
            return [data[i]];
        }
        else {
            data[i].style["width"] = data[i].structure.width;
            data[i].style["margin"] = `0 auto`;
            data[i].style["overflow"] = "hidden";
            if (i > 0) {
                data[i].style.marginTop = 0;
            }
        }
        // 解决margin为负数遮挡问题
        if (data[i].style.marginTop < 0) {
            data[i].style.position = 'relative';
        }
    }
    return data;
};
exports.default = calculateRow;


/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// 判断是横向还是纵向排列
// 只有满足同级下所有的元素都是纵向才认为是纵向排列， 否则都认为是横向排列
const isBlock = (data) => {
    for (var i = 1; i < data.length; i++) {
        //计算的值误差范围
        if (+data[i].structure.x - data[i - 1].structure.width - data[i - 1].structure.x > 0) {
            // 表示的是横向排列的
            return false;
        }
    }
    return true;
};
exports.default = isBlock;


/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleTypeLayout_1 = __webpack_require__(33);
/**
 * 全部为块元素的竖直方向布局
 *
 * @param {*} data
 * @param {*} parent
 * @returns
 */
const calculateBlock = (data, parent) => {
    var _a, _b, _c, _d, _e;
    // data = data.sort((a, b) => a.structure.y - b.structure.y);
    //边框处理
    const pBorderWidth = ((_c = (_b = (_a = parent.structure) === null || _a === void 0 ? void 0 : _a.border) === null || _b === void 0 ? void 0 : _b.top) === null || _c === void 0 ? void 0 : _c.width) || 0;
    for (let i = 0; i < data.length; i++) {
        if (!data[i].style) {
            data[i].style = {};
        }
        data[i].style.width = data[i].structure.width;
        if (handleTypeLayout_1.isCenter(data[i], parent)) {
            data[i].isCenter = true;
        }
        if (handleTypeLayout_1.isSingleText(data[i]) && data[i].style.textAlign === 'left') {
            delete data[i].style.width;
        }
        const marginLeft = data[i].structure.x - parent.structure.x - pBorderWidth;
        if (marginLeft) {
            data[i].style.marginLeft = marginLeft;
        }
        //假设所有单行文本都是填满的
        if (handleTypeLayout_1.isSingleText(data[i]) &&
            Math.abs(parent.structure.x + parent.structure.width * 0.5 - (data[i].structure.x + data[i].structure.width * 0.5)) < 3) {
            data[i].style.textAlign = 'center';
            delete data[i].style.width;
            delete data[i].style.marginLeft;
            //去掉 子元素宽度与父元素相同时情况 
        }
        else if (!handleTypeLayout_1.isSingleText(data[i]) && Math.abs(parent.structure.x + parent.structure.width * 0.5 - (data[i].structure.x + data[i].structure.width * 0.5)) < 3 && parent.structure.width != data[i].structure.width) {
            if (data[i].style.display === 'flex' && data[i].textContainer) { //单行多样式文本的处理
                data[i].style.justifyContent = 'center';
                delete data[i].style.width;
                delete data[i].style.marginLeft;
                delete data[i].style.marginRight;
            }
        }
        if (i > 0) {
            let marginTop = data[i].structure.y - (data[i - 1].structure.y + data[i - 1].structure.height);
            if (marginTop) {
                data[i].style.marginTop = marginTop;
            }
        }
        else {
            let pBorderTop = ((_e = (_d = parent.structure.border) === null || _d === void 0 ? void 0 : _d.top) === null || _e === void 0 ? void 0 : _e.width) || 0;
            let paddingTop = data[i].structure.y - parent.structure.y - pBorderWidth - pBorderTop;
            if (paddingTop) {
                data[i].style.marginTop = paddingTop;
                parent.style.paddingTop = 0.1;
            }
        }
        // 解决margin为负数遮挡问题
        if (data[i].style.marginTop < 0) {
            data[i].style.position = 'relative';
            //     data[i].style.transform ={...data[i].style.transform, translate: {y: data[i].style.marginTop}}
            //     delete data[i].style.marginTop;
        }
    }
    return data;
};
exports.default = calculateBlock;


/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isList = void 0;
/**
 * 判断是否相等
 * @param {*} a
 * @param {*} b
 */
const isEqual = (a, b) => {
    if (Math.abs(a - b) <= 2) {
        return true;
    }
    return false;
};
exports.isList = (data) => {
    let flag = false;
    let flagY = false;
    if (Array.isArray(data) && data.length > 1) {
        let firstItem = data[0];
        flag = true;
        data.forEach(({ structure: { width, height, y } }) => {
            if (!isEqual(width, firstItem.structure.width) || !isEqual(height, firstItem.structure.height)) {
                flag = false;
            }
            if (!isEqual(y, firstItem.structure.y)) {
                flagY = true;
            }
        });
    }
    return flag && flagY;
};


/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.layoutLabelList = exports.isLabelList = void 0;
const utils_1 = __webpack_require__(47);
/**
 * 排序方法
 * @param {Array} data
 */
const sort = (data) => {
    if (!data.length)
        return data;
    let yList = [data[0].structure.y];
    data.map(item => {
        if (yList[0] != item.structure.y && !yList.includes(item.structure.y)) {
            yList.push(item.structure.y);
        }
    });
    yList = yList.sort((a, b) => a - b);
    let result = [];
    for (let i = 0; i < yList.length; i++) {
        let list = [];
        data.map(item => {
            if (item.structure.y == yList[i]) {
                list.push(item);
            }
        });
        list = list.sort((a, b) => a.structure.x - b.structure.x);
        result = [...result, ...list];
    }
    return result;
};
/**
 *  识别标签列表
 *   1. 标签等宽 只包含文字 允许背景不一致  间距
 */
exports.isLabelList = (data, parent) => {
    if (data.length < 3)
        return false;
    let num = 0; // 记录每行有多少元素
    let first = data[0];
    data.map(item => {
        if (item.structure.y == first.structure.y) {
            num++;
        }
    });
    //每行只有一条数据的时候，既纵向排列，不适用于此
    if (num === 1) {
        return false;
    }
    data = sort(data);
    try {
        let count = 0;
        for (let i = 0; i < data.length; i++) {
            if (utils_1.utils.hasTextType(data[i]) &&
                utils_1.utils.isEqualHeight(data) &&
                (utils_1.utils.isSameSpacing(data) || parent.sign == "__list") &&
                (utils_1.utils.hasBackground(data) || utils_1.utils.hasBorder(data))) {
                count++;
            }
        }
        if (count == data.length) { // 父元素宽度扩展
            parent.structure.width += data[1].structure.x - data[0].structure.x - data[0].structure.width;
            parent.style.width += data[1].structure.x - data[0].structure.x - data[0].structure.width;
            if (parent.style.marginLeft && parent.style.marginLeft == parent.style.marginRight) {
                // 如果父元素位置居中的情况下需要计算偏移量
                parent.style.position = 'relative';
                parent.style.left = (data[1].structure.x - data[0].structure.x - data[0].structure.width) / 2;
            }
        }
        return count == data.length;
    }
    catch (error) {
        console.log(error);
    }
};
exports.layoutLabelList = (data, parent) => {
    data = sort(data);
    parent.name = "labelList";
    let first = data[0];
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", "flex-wrap": "wrap", "padding-left": data[0].structure.x - parent.structure.x, "padding-top": data[0].structure.y - parent.structure.y });
    let marginBottom = 0;
    let marginRight = 0;
    marginRight = parent.marginRight || data[1].structure.x - first.structure.x - first.structure.width;
    for (let i = 1; i < data.length; i++) {
        if (first.structure.x == data[i].structure.x) {
            marginBottom = data[i].structure.y - first.structure.y - first.structure.height;
            break;
        }
    }
    for (let item of data) {
        item.style = Object.assign(Object.assign({}, item.style), { display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", marginBottom: `${marginBottom}`, marginRight: `${marginRight}` });
        delete item.style.lineHeight;
        //   item.addClassName = 'item';
        //   item.element = {
        //       tag: "li"
        //   };
    }
    return data;
};


/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isSingleText = void 0;
/**
 * 判断图层是否为单行纯文本
 *
 * @param {Object} layer 图层对象
 */
exports.isSingleText = (layer) => {
    if (layer.type != "Text") {
        return false;
    }
    if (!layer.style) {
        return false;
    }
    if (layer.style['border-radius']
        || layer.style['border']
        || layer.style['background-color']
        || layer.style['background']
        || layer.style['background-image']
        || (layer.structure.height && layer.style['font-size'] && layer.style['font-size'] <= layer.structure.height * 0.5)) {
        return false;
    }
    return true;
};


/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isCenter = void 0;
const isLine_1 = __webpack_require__(48);
/**
 * 判断当前图层是否相对于父元素水平居中
 *
 * @param {*} layer
 * @param {*} parent
 */
exports.isCenter = (layer, parent) => {
    if (parent &&
        parent.structure.width > 750 * 0.7 &&
        layer.structure.width < parent.structure.width * 0.9 &&
        layer.name == 'Row' &&
        layer.children &&
        layer.children.length >= 2 &&
        isLine_1.isLine(layer.children) &&
        Math.abs(layer.structure.x - parent.structure.x - (parent.structure.x + parent.structure.width - layer.structure.x - layer.structure.width)) <= 2) {
        return true;
    }
};


/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isAlignCenter = void 0;
/**
 * 判断是否居中
 */
exports.isAlignCenter = (data, parent) => {
    if (Array.isArray(data) && data.length > 1 && parent) {
        const parentY = parent.structure.y + parent.structure.height / 2;
        for (let i = 0; i < data.length; i++) {
            const itemY = data[i].structure.y + data[i].structure.height / 2;
            if (Math.abs(parentY - itemY) > 1) {
                return false;
            }
        }
        return true;
    }
    return false;
};


/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isOnlyContainer = void 0;
/**
 * 判断图层是否为纯容器
 *
 * @param {Object} layer 图层对象
 */
exports.isOnlyContainer = (layer) => {
    if (layer.type != "Container") {
        return false;
    }
    if (!layer.style) {
        return false;
    }
    if (layer.style['border-radius']
        || layer.style['border']
        || layer.style['background-color']
        || layer.style['background']
        || layer.style['background-image']) {
        return false;
    }
    return true;
};


/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.isVerticalCenter = void 0;
/**
 * 判断是否垂直居中
 * @param {Array} data
 * @param {Object} parent
 */
exports.isVerticalCenter = (data, parent) => {
    if (Array.isArray(data) && data.length > 1 && parent) {
        const parentX = parent.structure.x + parent.structure.width / 2;
        for (let i = 0; i < data.length; i++) {
            const itemX = data[i].structure.x + data[i].structure.width / 2;
            if (Math.abs(parentX - itemX) > 1) {
                return false;
            }
        }
        return true;
    }
    return false;
};


/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 处理父元素是文本的情况， 子元素使用 absoulte 定位
 *
 * @param {*} data
 */
const handleParentIsText = (data, parent) => {
    parent.style['position'] = parent.style['position'] ? parent.style['position'] : 'relative';
    for (let child of data) {
        child.style = Object.assign(Object.assign({}, child.style), {
            'position': 'absolute',
            'left': child.structure.x - parent.structure.x,
            'top': child.structure.y - parent.structure.y
        });
    }
    return data;
};
exports.default = handleParentIsText;


/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// 根据盒子的内容删减没必要的盒子，以适应基本的布局的需要
const markIsOnlyText = (data, parent) => {
    for (var i = 0; i < data.length; i++) {
        if (!data[i].children && parent.children.length == 1) {
            if (data[i].type == 'Text') {
                parent.isOnlyText = true;
            }
        }
        if (data[i].children) {
            markIsOnlyText(data[i].children, data[i]);
        }
    }
    return data;
};
exports.default = markIsOnlyText;


/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.layoutRow = exports.isRow = void 0;
const handleTypeLayout_1 = __webpack_require__(33);
const const_1 = __webpack_require__(49);
// import * as fs from 'fs';
/**
 * 规则
 * 1.父元素width不为auto
 * @param {Array} data
 * @param {Object} parent
 */
const isTowSpan = (data, parent) => {
    // if (data.length == 2 && parent.structure.width != "auto") {
    if (data.length == 2 && parent) {
        let firstItem = data[0];
        let secondItem = data[1];
        if (firstItem.structure.x + firstItem.structure.width / 2 < parent.structure.x + parent.structure.width / 2 &&
            secondItem.structure.x >= parent.structure.x + parent.structure.width / 2 &&
            (secondItem.structure.x - firstItem.structure.x - firstItem.structure.width) * 0.2 >
                parent.structure.width + parent.structure.x - secondItem.structure.x - secondItem.structure.width &&
            parent.structure.width > 750 * 0.7) {
            return true;
        }
    }
};
const layoutTowSpan = (data, parent) => {
    let firstItem = data[0];
    let secondItem = data[1];
    firstItem.class_name = 'left';
    firstItem.class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    secondItem.class_name = 'right';
    secondItem.class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", justifyContent: "space-between", flexDirection: 'row' });
    if (handleTypeLayout_1.utils.isAlignMiddle(data, parent)) {
        if (!handleTypeLayout_1.utils.isSameParentHeight(data, parent)) {
            parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
        }
    }
    else {
        firstItem.style = Object.assign(Object.assign({}, firstItem.style), { marginTop: firstItem.structure.y - parent.structure.y });
        // 解决margin为负数遮挡问题
        if (firstItem.style.marginTop < 0) {
            firstItem.style.position = 'relative';
        }
        secondItem.style = Object.assign(Object.assign({}, secondItem.style), { marginTop: secondItem.structure.y - parent.structure.y });
        // 解决margin为负数遮挡问题
        if (secondItem.style.marginTop < 0) {
            secondItem.style.position = 'relative';
        }
    }
    firstItem.style = Object.assign(Object.assign({}, firstItem.style), { marginLeft: firstItem.structure.x - parent.structure.x });
    if (handleTypeLayout_1.isSingleText(firstItem) || handleTypeLayout_1.isOnlyContainer(firstItem)) {
        delete firstItem.style.width;
    }
    secondItem.style = Object.assign(Object.assign({}, secondItem.style), { marginRight: parent.structure.x + parent.structure.width - secondItem.structure.x - secondItem.structure.width });
    if (handleTypeLayout_1.isSingleText(secondItem) ||
        (handleTypeLayout_1.isOnlyContainer(secondItem) &&
            secondItem.children &&
            secondItem.children.length < 2)) {
        delete secondItem.style.width;
    }
    return data;
};
// 判断是否是图片文案居中的情况
const isimgTextCeneter = (data, parent) => {
    if (data.length !== 2)
        return false; // 只有两个元素的情况
    const isAlignCenter = (data, parent) => {
        // 两个元素组合位于父元素中间
        let firstItem = data[0];
        let secondItem = data[1];
        let leftDis = firstItem.structure.x - parent.structure.x;
        let rightDis = parent.structure.x + parent.structure.width - secondItem.structure.x - secondItem.structure.width;
        return Math.abs(leftDis - rightDis) < 2;
    };
    let existImgLayer = data.find(item => item.type == "Image");
    let existTextLayer = data.find(item => item.type == "Text");
    if (existImgLayer && existTextLayer && isAlignCenter(data, parent)) {
        return true;
    }
    return false;
};
const layoutImgTextCeneter = (data, parent) => {
    let firstItem = data[0];
    let secondItem = data[1];
    if (handleTypeLayout_1.isSingleText(firstItem)) {
        delete firstItem.style.width;
    }
    if (handleTypeLayout_1.isSingleText(secondItem)) {
        delete secondItem.style.width;
    }
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", flexDirection: 'row' });
    if (!handleTypeLayout_1.utils.isHorizontalCloseParent(data, parent)) {
        parent.style = Object.assign(Object.assign({}, parent.style), { justifyContent: "center" });
    }
    if (handleTypeLayout_1.utils.isAlignMiddle(data, parent)) {
        if (!handleTypeLayout_1.utils.isVerticalCloseParent(data, parent)) {
            parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
        }
    }
    else {
        for (let item of data) {
            item.style = Object.assign(Object.assign({}, item.style), { marginTop: item.structure.y - parent.structure.y });
            // 解决margin为负数遮挡问题
            if (item.style.marginTop < 0) {
                item.style.position = 'relative';
            }
        }
    }
    secondItem.style = Object.assign(Object.assign({}, secondItem.style), { marginLeft: secondItem.structure.x - firstItem.structure.x - firstItem.structure.width });
    return data;
};
const isEqualBolck = (data, parent) => {
    if (data.length >= 2 &&
        handleTypeLayout_1.utils.isEqualWidth(data) &&
        handleTypeLayout_1.utils.isEqualHeight(data) &&
        handleTypeLayout_1.utils.isSameSpacing(data) &&
        data[0].structure.x == parent.structure.x &&
        Math.abs(data[data.length - 1].structure.x +
            data[data.length - 1].structure.width -
            parent.structure.x -
            parent.structure.width) < 2) {
        // 至少两个子元素
        return true;
    }
    return false;
};
const layoutEqualBlock = (data, parent) => {
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", justifyContent: "space-between" });
    data = data.map(item => {
        item.class_name = 'li';
        item.class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
        return item;
    });
    return data;
};
const isBetweenItemList = (data, parent) => {
    if (Array.isArray(data) && data.length > 2 && parent) {
        let firstBetween = data[1].structure.x + data[1].structure.width * 0.5 - (data[0].structure.x + data[0].structure.width * 0.5);
        for (let i = 2; i < data.length; i++) {
            const item = data[i];
            if (item.name != "ItemList") {
                return false;
            }
            if (Math.abs(data[i].structure.x + data[i].structure.width * 0.5 - (data[i - 1].structure.x + data[i - 1].structure.width * 0.5) - firstBetween) > 4) {
                return false;
            }
        }
        return true;
    }
    return false;
};
const layoutBetweenItemList = (data, parent) => {
    parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", flexDirection: 'row', justifyContent: "space-between" });
    for (let i = 0; i < data.length; i++) {
        if (!data[i].style) {
            data[i].style = {};
        }
        data[i].class_name = "li";
        data[i].class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
    }
    if (handleTypeLayout_1.isAlignCenter(data, parent)) {
        parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
    }
    else {
        for (let i = 0; i < data.length; i++) {
            data[i].style = Object.assign(Object.assign({}, data[i].style), { marginTop: data[i].structure.y - parent.structure.y });
            // 解决margin为负数遮挡问题
            if (data[i].style.marginTop < 0) {
                data[i].style.position = 'relative';
            }
        }
    }
    //第一个元素
    if (data[0].structure.x != parent.structure.x) {
        parent.style = Object.assign(Object.assign({}, parent.style), { paddingLeft: data[0].structure.x - parent.structure.x });
    }
    //最后一个元素
    if (data[data.length - 1].structure.x + data[data.length - 1].structure.width !=
        parent.structure.x + parent.structure.width) {
        parent.style = Object.assign(Object.assign({}, parent.style), { paddingRight: parent.structure.x
                + parent.structure.width - data[data.length - 1].structure.x
                - data[data.length - 1].structure.width });
    }
    //不设置宽度
    for (let i = 0; i < data.length; i++) {
        delete data[i].style.width;
    }
    return data;
};
/**
 * 行布局
 */
// export const isRow = (data) => {
//     let flag = true;
//     if (Array.isArray(data) && data.length > 1) {
//         data = data.sort((a, b) => a.structure.x - b.structure.x);
//         for (let i = 0; i < data.length; i++) {
//             const item = data[i];
//             flag = false;
//             for (let j = i; j < data.length; j++) {
//                 const itemJ = data[j];
//                 if (
//                     (item.structure.y <= itemJ.structure.y && itemJ.structure.y < item.structure.y + item.structure.width) ||
//                     (itemJ.structure.y <= item.structure.y && item.structure.y < itemJ.structure.y + itemJ.structure.width)
//                 ) {
//                     flag = true;
//                 }
//             }
//         }
//     }
//     return flag;
// }
exports.isRow = (data) => {
    let flag = true;
    if (Array.isArray(data) && data.length > 1) {
        let dataTemp = JSON.parse(JSON.stringify(data));
        dataTemp = dataTemp.sort((a, b) => a.structure.x - b.structure.x);
        for (let i = 0; i < dataTemp.length; i++) {
            const item = dataTemp[i];
            flag = false; // 除非其中有元素跟任何一个都不是一行，否则只要有能拍到一行的元素就都进行行处理
            for (let j = i; j < dataTemp.length; j++) {
                const itemJ = dataTemp[j];
                if ((item.structure.y <= itemJ.structure.y && itemJ.structure.y < item.structure.y + item.structure.height) ||
                    (itemJ.structure.y <= item.structure.y && item.structure.y < itemJ.structure.y + itemJ.structure.height)) {
                    flag = true;
                }
            }
        }
    }
    return flag;
};
exports.layoutRow = (data, parent) => {
    if (Array.isArray(data) && data.length > 1) {
        // data = data.sort((a, b) => a.structure.x - b.structure.x);
        if (parent) {
            if (!parent.style) {
                parent.style = {};
            }
            //两列两边对齐样式
            if (isTowSpan(data, parent)) {
                return layoutTowSpan(data, parent);
            }
            //itemList情况切符合间距相同
            if (isBetweenItemList(data, parent)) {
                return layoutBetweenItemList(data, parent);
            }
            // 多个子元素，宽度一样，第一个和最后一个紧挨父元素情况
            if (isEqualBolck(data, parent)) {
                return layoutEqualBlock(data, parent);
            }
            // 子元素组合位于父元素中间位置， 所有子元素垂直方向上居中
            if (isimgTextCeneter(data, parent)) {
                return layoutImgTextCeneter(data, parent);
            }
            parent.style = Object.assign(Object.assign({}, parent.style), { display: "flex", flexDirection: "row" });
            // 水平居中
            if (parent.isCenter) {
                parent.style = Object.assign(Object.assign({}, parent.style), { width: "auto", justifyContent: "center" });
                delete parent.style.marginLeft;
            }
            // 垂直方向
            if (handleTypeLayout_1.utils.isAlignMiddle(data, parent)) {
                if (!handleTypeLayout_1.utils.isSameParentHeight(data, parent)) {
                    parent.style = Object.assign(Object.assign({}, parent.style), { alignItems: "center" });
                }
            }
            else {
                for (let i = 0; i < data.length; i++) {
                    data[i].style = Object.assign(Object.assign({}, data[i].style), { marginTop: data[i].structure.y - parent.structure.y });
                    // 解决margin为负数遮挡问题
                    if (data[i].style.marginTop < 0) {
                        data[i].style.position = 'relative';
                    }
                }
            }
            for (let i = 0; i < data.length; i++) {
                const item = data[i];
                if (!data[i].style) {
                    data[i].style = {};
                }
                if (i == 0) {
                    data[i].style = Object.assign(Object.assign({}, data[i].style), { marginLeft: item.structure.x - parent.structure.x });
                }
                else {
                    data[i].style = Object.assign(Object.assign({}, data[i].style), { marginLeft: item.structure.x - data[i - 1].structure.x - data[i - 1].structure.width });
                }
            }
            if ((handleTypeLayout_1.isSingleText(data[data.length - 1]) &&
                data[data.length - 1].style.textAlign === "left") ||
                handleTypeLayout_1.isOnlyContainer(data[data.length - 1])) {
                data[data.length - 1].style.width = "auto";
            }
        }
    }
    return data;
};


/***/ }),
/* 154 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.handleContinuousListItem = exports.calculateLeftImgRightInfo = exports.isLeftImgRightInfo = exports.calculateVerticalList = exports.isVerticalList = void 0;
const const_1 = __webpack_require__(49);
/**
 * 判断是否为竖排列表
 * @param {Array} data
 *
 */
exports.isVerticalList = (data) => {
    if (!(Array.isArray(data) && data.length > 1)) {
        return false;
    }
    if (data.findIndex(item => item.sign !== '__li') > -1) {
        return false;
    }
    const firstItem = data[0];
    for (let i = 1; i < data.length; i++) {
        const currItem = data[i];
        if (Math.abs(currItem.structure.width - firstItem.structure.width) > 3) {
            return false;
        }
        if (Math.abs((currItem.structure.x + currItem.structure.width * 0.5) - (firstItem.structure.x + firstItem.structure.width * 0.5)) > 3) {
            return false;
        }
    }
    return true;
};
/**
 * 处理竖排的className
 * @param {Array} data
 * @param {Object} parent
 */
exports.calculateVerticalList = (data) => {
    const firstItem = data[0];
    for (let i = 1; i < data.length; i++) {
        const currItem = data[i];
        if (Math.abs(currItem.structure.height - firstItem.structure.height) > 2) {
            data[i].structure.height = firstItem.structure.height;
        }
    }
    data = data.map(item => {
        item.class_name = 'li';
        item.class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
        return item;
    });
    return data;
};
/**
 * 判断左边图片右边信息的左右布局
 * @param {*} data
 * @param {*} parent
 */
exports.isLeftImgRightInfo = (data) => {
    if (Array.isArray(data) &&
        data.length === 2 &&
        data[0].type === 'Image' &&
        Array.isArray(data[1].children) &&
        data[1].children.length >= 3) {
        return true;
    }
    return false;
};
/**
 * 为左边图片右边信息的结构添加className
 * @param {*} data
 * @param {*} parent
 */
exports.calculateLeftImgRightInfo = (data) => {
    data[0].class_name = 'thumb';
    data[0].class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    data[1].class_name = 'info';
    data[1].class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
    return data;
};
/**
 * 连续的列表项结构
 * @param {*} data
 * @param {*} parent
 */
exports.handleContinuousListItem = (data) => {
    if (!Array.isArray(data) || data.length < 2) {
        return data;
    }
    //列表起始项
    let currStartItem = data[0];
    //列表起始项
    let currStartIndex = 0;
    //列表中项的数量
    let num = 1;
    //列表总数量
    let count = 0;
    for (let i = 1; i < data.length; i++) {
        const currItem = data[i];
        //是否相同
        if (Math.abs(currItem.structure.width - currStartItem.structure.width) < 3 &&
            Math.abs(currItem.structure.height - currStartItem.structure.height) < 3 &&
            Math.abs((currItem.structure.x + currItem.structure.width * 0.5) - (currStartItem.structure.x + currStartItem.structure.width * 0.5)) < 3 &&
            Array.isArray(currItem.children) &&
            Array.isArray(currStartItem.children) &&
            currItem.children.length === currStartItem.children.length) {
            num++;
        }
        else {
            //判断满足条件
            if (num >= 2) {
                count++;
                for (let j = currStartIndex; j < currStartIndex + num; j++) {
                    data[j].class_name = count > 1 ? 'li' + count : 'li';
                    data[j].class_type = const_1.CLASS_TYPE.RELY_ON_PARENT;
                }
            }
            currStartIndex = i;
            currStartItem = data[i];
            num = 1;
        }
    }
    //全量满足条件
    if (num === data.length) {
        data = data.map(item => {
            item.class_name = 'li';
            item.class_type = const_1.CLASS_TYPE.RELY_ON_CHILD_AND_PARENT;
            return item;
        });
    }
    return data;
};


/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.picassoCode = void 0;
const web_1 = __webpack_require__(50);
const weapp_1 = __webpack_require__(56);
const reactnative_1 = __webpack_require__(58);
const src_1 = __webpack_require__(19);
exports.picassoCode = (data, size, // 画板宽度 370px、750px 按照移动端处理
platform = src_1.CodeType.WebPx) => {
    switch (platform) {
        case src_1.CodeType.WebPx:
            return web_1.picassoWebCode(data, size);
        case src_1.CodeType.Weapp:
            return weapp_1.picassoWeappCode(data, size);
        case src_1.CodeType.ReactNative:
            return reactnative_1.picassoRNCode(data, size);
        default:
            break;
    }
};
__exportStar(__webpack_require__(50), exports);
__exportStar(__webpack_require__(56), exports);
__exportStar(__webpack_require__(58), exports);


/***/ }),
/* 156 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleCssOrder_1 = __webpack_require__(51);
/**
 * scss中 px转换为rem方法
 * @param {String} value css值
 * @param {String} platform 平台
 */
const addpxtorem = (value) => {
    if (/px/.test(value)) {
        value = value.replace(/((\.|\d|\e|\-)+)px/g, ($1) => {
            return `pxtorem(${Math.round($1.split('px')[0] * 10) / 10}px)`;
        });
    }
    return value;
};
// scss字符串
let scssStr = '';
const transformScssFormat = (data, layerNumber = 1) => {
    let styleTab = '';
    let classTab = '';
    let count = 0;
    while (count < layerNumber) {
        styleTab += '    ';
        if (count < layerNumber - 1) {
            classTab += '    ';
        }
        count++;
    }
    for (var i = 0; i < data.length; i++) {
        scssStr += layerNumber == 1 ? `.${data[i].className} {\n${styleTab}` : `${classTab}.${data[i].className} {\n${styleTab}`;
        let orderStyle = handleCssOrder_1.default(data[i].style);
        let styleKeyList = Object.keys(orderStyle);
        for (let j = 0; j < styleKeyList.length; j++) {
            const key = styleKeyList[j];
            let value = orderStyle[key];
            //修复undefindpx的bug
            value = addpxtorem(value);
            if (!/undefind/.test(value)) {
                if (j != styleKeyList.length - 1) {
                    scssStr += `${key}: ${value};\n${styleTab}`;
                }
                else {
                    scssStr += `${key}: ${value};\n`;
                }
            }
        }
        if (data[i].children) {
            transformScssFormat(data[i].children, layerNumber + 1);
        }
        scssStr += layerNumber == 1 ? `\}\n` : `${classTab}\}\n`;
    }
    return scssStr;
};
const generaterScss = (data, size) => {
    const draftSize = size / 7.5;
    // scss 基础变量
    let scss = `@function pxtorem($px){
    @return $px/${draftSize}px * 1rem;
}
`;
    // 重新清零，防止不同画板的scss累加
    scssStr = '';
    scss += transformScssFormat(data);
    return scss;
};
exports.default = generaterScss;


/***/ }),
/* 157 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * css顺序数组
 */
const cssList = [
    'position',
    'top',
    'right',
    'bottom',
    'left',
    'z-index',
    'display',
    'float',
    'width',
    'height',
    'max-width',
    'max-height',
    'min-width',
    'min-height',
    'padding',
    'padding-top',
    'padding-right',
    'padding-bottom',
    'padding-left',
    'margin',
    'margin-top',
    'margin-right',
    'margin-bottom',
    'margin-left',
    'margin-collapse',
    'margin-top-collapse',
    'margin-right-collapse',
    'margin-bottom-collapse',
    'margin-left-collapse',
    'overflow',
    'overflow-x',
    'overflow-y',
    'clip',
    'clear',
    'font',
    'font-family',
    'font-size',
    'font-smoothing',
    'osx-font-smoothing',
    'font-style',
    'font-weight',
    'hyphens',
    'src',
    'line-height',
    'letter-spacing',
    'word-spacing',
    'color',
    'text-align',
    'text-decoration',
    'text-indent',
    'text-overflow',
    'text-rendering',
    'text-size-adjust',
    'text-shadow',
    'text-transform',
    'word-break',
    'word-wrap',
    'white-space',
    'vertical-align',
    'list-style',
    'list-style-type',
    'list-style-position',
    'list-style-image',
    'pointer-events',
    'cursor',
    'background',
    'background-attachment',
    'background-color',
    'background-image',
    'background-position',
    'background-repeat',
    'background-size',
    'border',
    'border-collapse',
    'border-top',
    'border-right',
    'border-bottom',
    'border-left',
    'border-color',
    'border-image',
    'border-top-color',
    'border-right-color',
    'border-bottom-color',
    'border-left-color',
    'border-spacing',
    'border-style',
    'border-top-style',
    'border-right-style',
    'border-bottom-style',
    'border-left-style',
    'border-width',
    'border-top-width',
    'border-right-width',
    'border-bottom-width',
    'border-left-width',
    'border-radius',
    'border-top-right-radius',
    'border-bottom-right-radius',
    'border-bottom-left-radius',
    'border-top-left-radius',
    'border-radius-topright',
    'border-radius-bottomright',
    'border-radius-bottomleft',
    'border-radius-topleft',
    'content',
    'quotes',
    'outline',
    'outline-offset',
    'opacity',
    'filter',
    'visibility',
    'size',
    'zoom',
    'transform',
    'box-align',
    'box-flex',
    'box-orient',
    'box-pack',
    'box-shadow',
    'box-sizing',
    'table-layout',
    'animation',
    'animation-delay',
    'animation-duration',
    'animation-iteration-count',
    'animation-name',
    'animation-play-state',
    'animation-timing-function',
    'animation-fill-mode',
    'transition',
    'transition-delay',
    'transition-duration',
    'transition-property',
    'transition-timing-function',
    'background-clip',
    'backface-visibility',
    'resize',
    'appearance',
    'user-select',
    'interpolation-mode',
    'direction',
    'marks',
    'page',
    'set-link-source',
    'unicode-bidi',
    'speak'
];
/**
 * css 排序方法
 */
exports.default = (item) => {
    let itemIndex = cssList.length;
    if (cssList.indexOf(item) > -1) {
        itemIndex = cssList.indexOf(item);
    }
    return itemIndex;
};


/***/ }),
/* 158 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const handleCssOrder_1 = __webpack_require__(51);
/**
 * scss中 px转换为rem方法
 * @param {String} value css值
 * @param {String} platform 平台
 */
const addpxtorem = (value) => {
    if (/px/.test(value)) {
        value = value.replace(/((\.|\d|\e|\-)+)px/g, ($1) => {
            return `pxtorem(${Math.round($1.split('px')[0] * 10) / 10}px)`;
        });
    }
    return value;
};
const pxtorem = (currValue, platform, size) => {
    const draftSize = size / 7.5;
    if (/px/.test(currValue)) {
        currValue = currValue.replace(/((\.|\d|\e|\-)+)px/g, ($1) => {
            return +platform === 2
                ? `${Math.round(($1.split("px")[0] / draftSize) * 1000) / 1000}rem`
                : `${Math.round($1.split("px")[0] * 10) / 10}px`;
        });
    }
    return currValue;
};
// scss字符串
let scssStr = '';
const transformScssFormat = (data, size, platform) => {
    for (var i = 0; i < data.length; i++) {
        scssStr += `.${data[i].className} {\n`;
        let orderStyle = handleCssOrder_1.default(data[i].style);
        let styleKeyList = Object.keys(orderStyle);
        for (let j = 0; j < styleKeyList.length; j++) {
            const key = styleKeyList[j];
            let value = orderStyle[key];
            //修复undefindpx的bug
            value = pxtorem(value, platform, size);
            if (!/undefind/.test(value)) {
                scssStr += `    ${key}: ${value};\n`;
            }
        }
        scssStr += `\}\n`;
        if (data[i].children) {
            transformScssFormat(data[i].children, size, platform);
        }
    }
    return scssStr;
};
const generaterScss = (data, size, platform) => {
    // 清空存储
    scssStr = '';
    return transformScssFormat(data, size, platform);
};
exports.default = generaterScss;


/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const generateBody = (data, tab = '') => {
    var _a, _b;
    let html = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        if (record.type === 'Image' && !(((_a = record.children) === null || _a === void 0 ? void 0 : _a.length) > 0)) {
            html.push(`${tab}<img class="${record.className}" src="${record.value.indexOf('http') === 0 ? record.value : `../images/${record.value}`}"/>`);
        }
        else if (record.type === 'Text' && ((_b = record.children) === null || _b === void 0 ? void 0 : _b.length) > 0) {
            const tag = 'div';
            html.push(`${tab}<${tag} class="${record.className}">`);
            record.children.forEach((layer) => {
                html.push(`${tab}    <span class="${layer.className}">`);
                html.push(`${tab}        ${layer.value || ''}`);
                html.push(`${tab}    </span>`);
            });
            html.push(`${tab}</${tag}>`);
        }
        else {
            // to be done
            const tag = 'div';
            html.push(`${tab}<${tag} class="${record.className}">`);
            if (record.type === 'Text') {
                record.value = record.value.replace(/ /ig, '&nbsp;');
                html.push(`${tab}    ${record.value || ''}`);
            }
            if (Array.isArray(record.children)) {
                html.push(generateBody(record.children, tab + '    '));
            }
            html.push(`${tab}</${tag}>`);
        }
    }
    return html.join('\n');
};
exports.default = generateBody;


/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.formateDslStyle = exports.formatDslRpxStyle = exports.formateDslRemStyle = void 0;
// import * as fs from 'fs'
const utils_1 = __webpack_require__(52);
const dslPxtoRem_1 = __webpack_require__(161);
const dslPxtoRpx_1 = __webpack_require__(162);
const cssOrder_1 = __webpack_require__(53);
// 驼峰改连接符
const toKebabCase = (str) => str.replace(/([A-Z])/g, '-$1').toLowerCase();
const addPx = (val) => {
    if (typeof val == 'number')
        return `${val}px`;
    return val;
};
// 转rem
exports.formateDslRemStyle = (formateDsl, remScale) => {
    // 标注稿以rem形式展示
    if (!remScale || isNaN(Number(remScale)))
        return formateDsl;
    for (let item of formateDsl) {
        let remStyle = {}; // 样式集合
        remStyle = dslPxtoRem_1.dslPxtoRem(item.style, remScale);
        item.style = remStyle;
        if (item.children && item.children.length) {
            exports.formateDslRemStyle(item.children, remScale);
        }
    }
    return formateDsl;
};
//转rpx
exports.formatDslRpxStyle = (formateDsl, size) => {
    for (let item of formateDsl) {
        let rpxStyle = {}; // 样式集合
        rpxStyle = dslPxtoRpx_1.dslPxtoRpx(item.style, size);
        item.style = rpxStyle;
        if (item.children && item.children.length) {
            exports.formatDslRpxStyle(item.children, size);
        }
    }
    return formateDsl;
};
/**
 * DSL=> webStyle 转换方法
 * @param data
 */
exports.formateDslStyle = (data) => {
    //let formateDsl = JSON.parse(JSON.stringify(data))
    for (let i = 0; i < data.length; i++) {
        let style = {}; // 样式集合
        const item = data[i];
        // 处理 structure
        if (item.structure && Object.keys(item.structure).length) {
            for (var key in item.structure) {
                let currValue = item.structure[key];
                // sketch 设计稿解析过来的没有 margin 和 padding
                switch (key) {
                    case 'border':
                        style = Object.assign(Object.assign({}, style), utils_1.generateProperty(currValue));
                        break;
                    case 'width':
                        style[key] = `${Math.round(currValue * 100) / 100}px`;
                        break;
                    case 'height':
                        style[key] = `${Math.round(currValue * 100) / 100}px`;
                        break;
                    case 'x':
                    case 'y':
                        if (style.position) {
                            style[key] = `${Math.round(currValue * 100) / 100}px`;
                        }
                        break;
                    case 'zIndex':
                        if (style.position) {
                            style[toKebabCase(key)] = currValue;
                        }
                        break;
                    default:
                        style[toKebabCase(key)] = utils_1.generateMargin(currValue);
                        break;
                }
            }
        }
        // 处理 style
        if (item.style && Object.keys(item.style).length) {
            for (var key in item.style) {
                if (item.style.hasOwnProperty(key) &&
                    item.style[key] != undefined) {
                    let currValue = item.style[key];
                    switch (key) {
                        case 'textStyle': // text样式直接放在style里
                            for (let textKey of Object.keys(currValue)) {
                                let textVal = currValue[textKey];
                                // 颜色处理
                                if (textKey == 'color') {
                                    textVal = utils_1.generateColor(textVal);
                                }
                                // px处理
                                if (textKey == 'lineHeight' || textKey == 'fontSize' || textKey == 'textIndent' || textKey == 'letterSpacing') {
                                    textVal = `${Math.round(currValue[textKey] * 100) / 100}px`;
                                }
                                // 其他不处理
                                style[toKebabCase(textKey)] = textVal;
                            }
                            break;
                        case 'background': // background样式放到background里
                            let propertyVal;
                            for (let backgroundKey of Object.keys(currValue)) {
                                let backgroundVal = currValue[backgroundKey];
                                if (backgroundKey == 'linearGradient') {
                                    let { gAngle, gList } = backgroundVal;
                                    let list = gList.map((ref) => {
                                        return `${utils_1.generateColor(ref.color)} ${ref.position * 100}%`;
                                    });
                                    list = [...new Set(list)];
                                    style['background'] = `linear-gradient(${Math.round(gAngle * 100) / 100}deg, ${list.join(',')})`;
                                }
                                else if (backgroundKey == 'radialGradient') {
                                    // background-image: radial-gradient(shape size at top left, start-color, ..., last-color);
                                    // background-image: radial-gradient(4.47rem 2rem at 1rem 2rem, red 5%, green 15%, blue 60%)
                                    let { backgroundVal: any, smallRadius, largeRadius, position, gList, } = backgroundVal;
                                    let list = gList.map((ref) => {
                                        return `${utils_1.generateColor(ref.color)} ${ref.position * 100}%`;
                                    });
                                    style['background'] = `radial-gradient(${Math.round(smallRadius * 100) / 100}px ${Math.round(largeRadius * 100) / 100}px at ${Math.round(position.left * 100) / 100}px ${Math.round(-position.top * 100) / 100}px, ${list.join(',')})`;
                                }
                                else if (typeof backgroundVal == 'object') {
                                    if (backgroundKey == 'color') {
                                        propertyVal = utils_1.generateColor(backgroundVal);
                                    }
                                    else if (backgroundKey == 'image' && item.type !== 'Image') {
                                        propertyVal = `url(../images/${backgroundVal.url})`;
                                    }
                                    else { // position、size
                                        let valList = [];
                                        for (let ref of Object.keys(backgroundVal)) {
                                            valList.push(addPx(backgroundVal[ref]));
                                        }
                                        propertyVal = valList.join(' ');
                                    }
                                    style[`background-${backgroundKey}`] = propertyVal;
                                    // 如果为图片，则背景色无效
                                    if (item.type === 'Image') {
                                        delete style['background-color'];
                                    }
                                }
                                else if (backgroundKey == 'repeat') {
                                    // style[`background-${backgroundKey}`] = backgroundVal
                                }
                            }
                            break;
                        case 'textShadow':
                        case 'boxShadow':
                            let shodowList = [];
                            for (let item of currValue) {
                                let { offsetX, offsetY, spread, blurRadius, color, type, } = item;
                                shodowList.push(type
                                    ? `${offsetX}px ${offsetY}px ${blurRadius}px ${spread}px ${utils_1.generateColor(color)} ${type}`
                                    : `${offsetX}px ${offsetY}px ${blurRadius}px ${spread}px ${utils_1.generateColor(color)}`);
                            }
                            if (shodowList.length) {
                                style[toKebabCase(key)] = shodowList.join(', ');
                            }
                            break;
                        case 'transform':
                            let { scale = {}, rotate, translate = {} } = currValue;
                            let transform = [];
                            if (scale.horizontal != undefined &&
                                scale.vertical != undefined) {
                                transform.push(`scale(${scale.horizontal},${scale.vertical})`);
                            }
                            if (rotate != undefined) {
                                transform.push(`rotate(${rotate}deg)`);
                            }
                            if (translate && (translate.x || translate.y)) {
                                transform.push(`translate(${translate.x || 0}px, ${translate.y || 0}px)`);
                            }
                            if (transform && transform.length) {
                                style['transform'] = transform.join(' ');
                            }
                            break;
                        case 'borderRadius':
                            let borderRadius = utils_1.generateBorderRadius(currValue);
                            if (borderRadius) {
                                style['border-radius'] = borderRadius;
                            }
                            break;
                        case 'zIndex':
                        case 'fontWeight':
                            style[key] = currValue;
                            break;
                        case 'lineHeight':
                            style[toKebabCase(key)] = currValue;
                            break;
                        case 'width':
                        case 'height':
                        case 'marginTop':
                        case 'marginRight':
                        case 'marginLeft':
                        case 'marginBottom':
                        case 'paddingTop':
                        case 'paddingRight':
                        case 'paddingLeft':
                        case 'paddingBottom':
                            typeof currValue == 'string'
                                ? (style[toKebabCase(key)] = currValue)
                                : (style[toKebabCase(key)] = `${currValue}px`);
                            break;
                        default:
                            typeof currValue == 'string'
                                ? (style[toKebabCase(key)] = currValue)
                                : (style[toKebabCase(key)] = `${currValue}px`);
                    }
                }
            }
        }
        // fs.writeFileSync(`./test/style_${item.name}.json`, JSON.stringify(style, null,2));
        // css 排序
        data[i].style = cssOrder_1.default(style);
        if (data[i].children && data[i].children.length) {
            data[i].children = exports.formateDslStyle(data[i].children);
        }
    }
    return data;
};


/***/ }),
/* 161 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.dslPxtoRem = void 0;
// 处理text阴影
const formatTextShadowPxToRem = (styleVal, remScale) => {
    let styleValArr = styleVal.split('px');
    const tailArr = styleValArr.splice(4, styleValArr.length - 4);
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
    });
    styleValArr = styleValArr.concat(tailArr);
    return styleValArr.join(' ');
};
// 处理box阴影
const formatBoxShadowPxToRem = (styleVal, remScale) => {
    let styleValArr = styleVal.split(' ');
    styleValArr = styleValArr.map(item => {
        if (item.endsWith('px')) {
            return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
        }
        return item;
    });
    return styleValArr.join(' ');
};
// 处理背景
const formatBGPxToRem = (styleVal, remScale) => {
    let styleValArr = styleVal.split(' ');
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
    });
    return styleValArr.join(' ');
};
// 渐变背景处理
const formatBGradientPxToRem = (styleVal, remScale) => {
    let stylePxArr = styleVal.split(',');
    const tailArr = stylePxArr.splice(1, stylePxArr.length - 1);
    stylePxArr = stylePxArr[0].split('(')[1];
    stylePxArr = stylePxArr.split(' ');
    stylePxArr = stylePxArr.map(item => {
        if (item.includes('px')) {
            return `${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`;
        }
        return item;
    });
    stylePxArr[0] = `radial-gradient(${stylePxArr[0]}`;
    const styleRemArr = [stylePxArr.join(' ')];
    const styleValArr = styleRemArr.concat(tailArr);
    // styleValArr = styleValArr.map(itemFirst => {
    //     if (itemFirst.includes('px')) {
    //         const splitStyle = itemFirst.split(' ');
    //         itemFirst = splitStyle.map(itemSecond => {
    //             if (itemSecond.includes('px')) {
    //                 return `${Math.round(+itemSecond.split('px')[0] * 100 / remScale) /100 }rem`
    //             }
    //             return itemSecond
    //         })
    //     }
    //     return itemFirst
    // })
    return styleValArr.join(',');
};
exports.dslPxtoRem = (styleObj, remScale) => {
    for (let styleKey in styleObj) {
        let styleVal = styleObj[styleKey];
        // if (styleKey !== 'font-weight') {
        //     if (typeof (styleObj[styleKey]) === 'number') {
        //         const styleObjItem = `${Number(styleObj[styleKey]) * this.scaleNum}${this.tag}`;
        //         styleObj[styleKey] = styleObjItem;
        //     }
        // }
        if (typeof styleVal == 'string' && styleVal.includes('px')) {
            // 常规处理
            if (styleKey == 'width' ||
                styleKey == 'height' ||
                styleKey == 'line-height' ||
                styleKey == 'font-size' ||
                styleKey == 'text-indent' ||
                styleKey == 'left' ||
                styleKey == 'right' ||
                styleKey == 'top' ||
                styleKey == 'bottom') {
                styleVal = `${Math.round(+styleVal.split('px')[0] * 100 / remScale) / 100}rem`;
            }
            // margin、padding
            if (styleKey.includes('margin') ||
                styleKey.includes('padding')) {
                const styleValArr = styleVal.split(' ');
                const styleValList = [];
                styleValArr.forEach((item) => {
                    styleValList.push(`${Math.round(+item.split('px')[0] * 100 / remScale) / 100}rem`);
                });
                styleVal = styleValList.join(' ');
            }
            // 边框
            if (styleKey.includes('border')) {
                const styleValArr = styleVal.split(' ');
                styleValArr[0] = `${Math.round(+styleValArr[0].split('px')[0] * 100 / remScale) / 100}rem`;
                styleVal = styleValArr.join(' ');
            }
            // 背景 position、size
            if (styleKey.includes('background-')) {
                styleVal = formatBGPxToRem(styleVal, remScale);
            }
            // 背景 radial-gradient
            if (styleKey == 'background') {
                styleVal = formatBGradientPxToRem(styleVal, remScale);
            }
            // 文字阴影
            if (styleKey.includes('text-shadow')) {
                styleVal = formatTextShadowPxToRem(styleVal, remScale);
            }
            // 边框阴影
            if (styleKey.includes('box-shadow') ||
                styleKey.includes('text-shadow')) {
                styleVal = formatBoxShadowPxToRem(styleVal, remScale);
            }
        }
        styleObj[styleKey] = styleVal;
    }
    return styleObj;
};


/***/ }),
/* 162 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.dslPxtoRpx = void 0;
//处理背景
const formarBGPxToRpx = (styleVal, scale) => {
    // const scale = 750 / size;
    let styleValArr = styleVal.split(' ');
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`;
    });
    return styleValArr.join(' ');
};
//处理径向渐变
const formarBGradientPxToRpx = (styleVal, scale) => {
    // const scale = 750 / size;
    let stylePxArr = styleVal.split(',');
    const tailArr = stylePxArr.splice(1, stylePxArr.length - 1);
    stylePxArr = stylePxArr[0].split('(')[1];
    stylePxArr = stylePxArr.split(' ');
    stylePxArr = stylePxArr.map(item => {
        if (item.includes('px')) {
            return `${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`;
        }
        return item;
    });
    stylePxArr[0] = `radial-gradient(${stylePxArr[0]}`;
    const styleValArr = stylePxArr.concat(tailArr);
    return styleValArr.join(',');
};
//处理阴影
const formatShadowPxToRpx = (styleVal, scale) => {
    // const scale = 750 / size;
    let styleValArr = styleVal.split('px');
    const tailArr = styleValArr.splice(4, styleValArr.length - 4);
    styleValArr = styleValArr.map(item => {
        return `${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`;
    });
    styleValArr = styleValArr.concat(tailArr);
    return styleValArr.join(' ');
};
exports.dslPxtoRpx = (styleObj, scale) => {
    // const scale = 750 / size;
    for (let styleKey in styleObj) {
        let styleVal = styleObj[styleKey];
        if (styleKey !== 'font-weight') {
            if (typeof (styleObj[styleKey]) === 'number') {
                // const styleObjItem = `${Number(styleObj[styleKey]) * this.scaleNum}${this.tag}`;
                const styleObjItem = `${Number(styleObj[styleKey])}`;
                styleObj[styleKey] = styleObjItem;
            }
        }
        if (typeof styleVal == 'string' && styleVal.includes('px')) {
            // 常规处理
            if (styleKey == 'width' ||
                styleKey == 'height' ||
                styleKey == 'line-height' ||
                styleKey == 'font-size' ||
                styleKey == 'text-indent' ||
                styleKey == 'left' ||
                styleKey == 'right' ||
                styleKey == 'top' ||
                styleKey == 'bottom') {
                styleVal = `${Math.round(+styleVal.split('px')[0] * 10 * scale) / 10}rpx`;
            }
            // margin、padding
            if (styleKey.includes('margin') ||
                styleKey.includes('padding')) {
                const styleValArr = styleVal.split(' ');
                const styleValList = [];
                styleValArr.forEach((item) => {
                    styleValList.push(`${Math.round(+item.split('px')[0] * scale * 10) / 10}rpx`);
                });
                styleVal = styleValList.join(' ');
            }
            // 边框
            if (styleKey.includes('border')) {
                const styleValArr = styleVal.split(' ');
                styleValArr[0] = `${Math.round(+styleValArr[0].split('px')[0] * scale * 10) / 10}rpx`;
                styleVal = styleValArr.join(' ');
            }
            // 背景 position、size
            if (styleKey.includes('background-')) {
                styleVal = formarBGPxToRpx(styleVal, scale);
            }
            // 径向渐变 radial-gradient
            if (styleKey == 'background') {
                styleVal = formarBGradientPxToRpx(styleVal, scale);
            }
            // 边框阴影、文字阴影
            if (styleKey.includes('box-shadow') ||
                styleKey.includes('text-shadow')) {
                styleVal = formatShadowPxToRpx(styleVal, scale);
            }
        }
        styleObj[styleKey] = styleVal;
    }
    return styleObj;
};


/***/ }),
/* 163 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transRNStyle = void 0;
/*
 * @Author: iChengbo
 * @Date: 2020-07-08 10:59:55
 * @LastEditors: iChengbo
 * @LastEditTime: 2020-09-08 19:07:57
 * @FilePath: /picasso-core/packages/picasso-trans/src/transRNStyle.ts
 */
const utils_1 = __webpack_require__(52);
const cssOrder_1 = __webpack_require__(53);
// const humpKey2 = key.replace(/-(\w)/g, ($, $1) => $1.toUpperCase());
const toHumpKey = (str) => str.replace(/-(\w)/g, ($, $1) => $1.toUpperCase());
const getValidValue = (object, key) => {
    if (!!object && !!object.key) {
        return object.key;
    }
};
exports.transRNStyle = (data) => {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q;
    for (let item of data) {
        // 样式集合
        let style = {};
        // 布局
        if (item.structure && Object.keys(item.structure).length) {
            for (var key in item.structure) {
                let currValue = item.structure[key];
                // console.log("布局：", key)
                switch (key) {
                    case 'x':
                    case 'y':
                        // case 'zIndex':
                        break;
                    case 'width':
                    case 'height':
                        if (item.type == 'Text') {
                            if (key == 'width') {
                                const _fontSize = (item.style && item.style.textStyle && item.style.textStyle.fontSize) ? item.style.textStyle.fontSize : 28;
                                const dis = parseInt(item.style.width) - _fontSize * item.value.length;
                                if (Math.abs(dis) < 100) {
                                    style['textAlign'] = 'left';
                                }
                                else {
                                    style[key] = parseInt(currValue);
                                }
                            }
                            else {
                                // TODO：文本设高度的话，需处理垂直居中问题
                                style[key] = parseInt(currValue);
                                // style['lineHeight'] = parseInt(currValue) / 2;
                                // style['flexDirection'] = 'row';
                                // style['alignItems'] = 'center';
                                style['textAlignVertical'] = 'center';
                            }
                        }
                        else {
                            style[key] = parseInt(currValue);
                        }
                        break;
                    case 'border':
                        if (!!currValue) {
                            if (currValue.top && currValue.left && currValue.right && currValue.bottom
                                && JSON.stringify(currValue.top) === JSON.stringify(currValue.right)
                                && JSON.stringify(currValue.top) === JSON.stringify(currValue.left)
                                && JSON.stringify(currValue.top) === JSON.stringify(currValue.bottom)) {
                                style['borderStyle'] = (_a = currValue.top) === null || _a === void 0 ? void 0 : _a.style;
                                style['borderWidth'] = (_b = currValue.top) === null || _b === void 0 ? void 0 : _b.width;
                                style['borderColor'] = utils_1.generateColor((_c = currValue.top) === null || _c === void 0 ? void 0 : _c.color);
                            }
                            else {
                                style['borderTopStyle'] = (_d = currValue.top) === null || _d === void 0 ? void 0 : _d.style;
                                style['borderTopWidth'] = (_e = currValue.top) === null || _e === void 0 ? void 0 : _e.width;
                                style['borderTopColor'] = utils_1.generateColor((_f = currValue.top) === null || _f === void 0 ? void 0 : _f.color);
                                style['borderRigthStyle'] = (_g = currValue.right) === null || _g === void 0 ? void 0 : _g.style;
                                style['borderRightWidth'] = (_h = currValue.right) === null || _h === void 0 ? void 0 : _h.width;
                                style['borderRightColor'] = utils_1.generateColor((_j = currValue.right) === null || _j === void 0 ? void 0 : _j.color);
                                style['borderBottomStyle'] = (_k = currValue.bottom) === null || _k === void 0 ? void 0 : _k.style;
                                style['borderBottomWidth'] = (_l = currValue.bottom) === null || _l === void 0 ? void 0 : _l.width;
                                style['borderBottomColor'] = utils_1.generateColor((_m = currValue.bottom) === null || _m === void 0 ? void 0 : _m.color);
                                style['borderLeftStyle'] = (_o = currValue.left) === null || _o === void 0 ? void 0 : _o.style;
                                style['borderLeftWidth'] = (_p = currValue.left) === null || _p === void 0 ? void 0 : _p.width;
                                style['borderLeftColor'] = utils_1.generateColor((_q = currValue.left) === null || _q === void 0 ? void 0 : _q.color);
                            }
                        }
                        break;
                    case 'margin':
                        if (!!currValue) {
                            style['marginTop'] = currValue.top;
                            style['marginBottom'] = currValue.bottom;
                            style['marginLeft'] = currValue.left;
                            style['marginRight'] = currValue.right;
                        }
                        break;
                    case 'padding':
                        if (!!currValue) {
                            style['paddingTop'] = currValue.top;
                            style['paddingBottom'] = currValue.bottom;
                            style['paddingLeft'] = currValue.left;
                            style['paddingRight'] = currValue.right;
                        }
                        break;
                    default:
                        style[key] = currValue;
                        break;
                }
            }
        }
        // 样式
        if (item.style && Object.keys(item.style).length) {
            for (var key in item.style) {
                if (item.style.hasOwnProperty(key) && item.style[key] != undefined) {
                    let currValue = item.style[key];
                    switch (key) {
                        case 'marginTop':
                        case 'marginRight':
                        case 'marginLeft':
                        case 'marginBottom':
                        case 'paddingTop':
                        case 'paddingRight':
                        case 'paddingLeft':
                        case 'paddingBottom':
                            const _currValue = parseInt(currValue);
                            style[key] = !Number.isNaN(_currValue) ? _currValue : 0;
                            // style[key] = parseInt(currValue) / 2;
                            break;
                        case 'borderRadius':
                            if (currValue['topLeft']
                                && currValue['topLeft'] === currValue['topRight']
                                && currValue['topLeft'] === currValue['bottomLeft']
                                && currValue['topLeft'] === currValue['bottomRight']) {
                                style['borderRadius'] = currValue['topLeft'];
                            }
                            else {
                                if (currValue['topLeft']) {
                                    style['borderTopLeftRadius'] = currValue['topLeft'];
                                }
                                if (currValue['topRight']) {
                                    style['borderTopRightRadius'] = currValue['topRight'];
                                }
                                if (currValue['bottomLeft']) {
                                    style['borderBottomLeftRadius'] = currValue['bottomLeft'];
                                }
                                if (currValue['bottomRight']) {
                                    style['borderBottomRightRadius'] = currValue['bottomRight'];
                                }
                            }
                            break;
                        case 'justifyContent':
                        case 'alignItems':
                        case 'flexDirection':
                            style[key] = currValue;
                            break;
                        case 'textStyle':
                            for (let textKey of Object.keys(currValue)) {
                                if (!!currValue && !!currValue[textKey]) {
                                    let textVal = currValue[textKey];
                                    switch (textKey) {
                                        case 'wordBreak':
                                        case 'fontFamily':
                                            break;
                                        case 'fontWeight':
                                            style[textKey] = String(textVal);
                                            break;
                                        case 'lineHeight':
                                            // 确保行高稍大于文字尺寸，避免Android端文本被切头
                                            if (textVal - currValue['fontSize'] > 4) {
                                                style[textKey] = parseInt(textVal);
                                            }
                                            break;
                                        case 'fontSize':
                                            style[textKey] = parseInt(textVal);
                                            break;
                                        case 'color':
                                            textVal = utils_1.generateColor(textVal);
                                            style[textKey] = textVal;
                                            break;
                                        case 'textAlign':
                                            // 布局为主
                                            if (!style['textAlign']) {
                                                style[textKey] = textVal;
                                            }
                                            break;
                                        default:
                                            style[textKey] = textVal;
                                            break;
                                    }
                                }
                            }
                            break;
                        case 'textShadow':
                            // TODO
                            break;
                        case 'background':
                            // console.log("背景样式", currValue)
                            for (let bgKey of Object.keys(currValue)) {
                                let bgVal = currValue[bgKey];
                                switch (bgKey) {
                                    case 'position':
                                        style['position'] = 'absolute';
                                        break;
                                    case 'color':
                                        bgVal = utils_1.generateColor(bgVal);
                                        style['backgroundColor'] = bgVal;
                                        break;
                                    case 'image':
                                        // 背景图特殊处理，最终生成样式时需删除此属性
                                        style['backgroundImage'] = bgVal.url;
                                        break;
                                    case 'linearGradient':
                                        // 渐变特殊处理，最终生成样式时需删除此属性
                                        style['linearGradient'] = bgVal;
                                        break;
                                    case 'size':
                                        style['backgroundSize'] = bgVal;
                                        break;
                                    default:
                                        break;
                                }
                            }
                            break;
                        case 'boxShadow':
                            if (!!currValue && currValue.length > 0 && !!currValue[0].color && item.type == 'Container') {
                                style = Object.assign(Object.assign({}, style), { elevation: currValue[0].offsetY, 
                                    // 以下属性，仅 IOS 可用
                                    shadowColor: utils_1.generateColor(currValue[0].color), shadowOffset: {
                                        width: currValue[0].offsetX,
                                        height: currValue[0].offsetY,
                                    }, shadowRadius: currValue[0].blurRadius, shadowOpacity: 1 });
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        // css 排序
        item.style = cssOrder_1.default(style);
        if (item.children && item.children.length) {
            exports.transRNStyle(item.children);
        }
    }
    return data;
};


/***/ }),
/* 164 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transAndroidCode = void 0;
const colorTrans_1 = __webpack_require__(54);
const _getAndroidWithHeight = (panel) => "android:layout_width=\"" + panel.properties.size.width + "\"\r\n" + "android:layout_height=\"" + panel.properties.size.height + "\"\r\n";
const _getAndroidShapeBackground = (panel) => {
    const pureColorFill = panel.fills.find(item => item.type === 0);
    if (pureColorFill) {
        return "android:background=\"" + colorTrans_1.color2AHEX(pureColorFill.color) + "\"\r\n";
    }
    return '';
};
exports.transAndroidCode = (data) => {
    for (let i = 0; i < data.length; i++) {
        const { panelData: panel } = data[i];
        const androidCode = [];
        if (data[i].type === "Text") {
            androidCode.push("<TextView\r\n" + _getAndroidWithHeight(panel)
                + "android:text=\"" + data[i].value + "\"\r\n" + "android:textColor=\"" + colorTrans_1.color2AHEX(panel.typefaces[0].color) + "\"\r\n"
                + "android:textSize=\"" + panel.typefaces[0].fontSize.replace('dp', 'sp') + "\"\r\n" + "/>" + '</textarea></label>');
        }
        else if (data[i].type === "Container") {
            androidCode.push("<View\r\n" + _getAndroidWithHeight(panel)
                + _getAndroidShapeBackground(panel)
                + "/>");
        }
        data[i].panelData.code = androidCode.join('');
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            data[i].children = exports.transAndroidCode(data[i].children);
        }
    }
    return data;
};


/***/ }),
/* 165 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transIOSCode = void 0;
exports.transIOSCode = (data) => {
    for (let i = 0; i < data.length; i++) {
        const { panelData: panel } = data[i];
        const iosCode = [];
        if (data[i].type === "Text") {
            iosCode.push("UILabel *label = [[UILabel alloc] init];\r\n"
                + "label.frame = CGRectMake(" + panel.properties.position.x + "\, " + panel.properties.position.y + "\, "
                + panel.properties.size.width + "\, " + panel.properties.size.height + ");\r\n"
                + "label.text = \@\"" + data[i].value + "\";\r\n"
                + "label.font = [UIFont fontWithName:\@\"" + panel.typefaces[0].fontFamily + "\" size:" + panel.typefaces[0].fontSize + "];\r\n"
                + "label.textColor = [UIColor colorWithRed:" + panel.typefaces[0].color.red + "/255.0 green:" + panel.typefaces[0].color.red + "/255.0 blue:" + panel.typefaces[0].color.blue + "/255.0 alpha:" + panel.typefaces[0].color.alpha + "/1.0];\r\n");
        }
        else if (data[i].type === "Container") {
            let bgColorCode = '';
            const pureColorFill = panel.fills.find(item => item.type === 0);
            if (pureColorFill) {
                bgColorCode = "view.backgroundColor = [UIColor colorWithRed:" + pureColorFill.color.red + "/255.0 green:" + pureColorFill.color.green + "/255.0 blue:" + pureColorFill.color.blue + "/255.0 alpha:" + pureColorFill.color.alpha + "/1.0]\;\r\n";
            }
            iosCode.push("UIView *view = [[UIView alloc] init];\r\n"
                + "view.frame = CGRectMake(" + panel.properties.position.x + "\, " + panel.properties.position.y + "\, "
                + panel.properties.size.width + "\, " + panel.properties.size.height + ");\r\n"
                + bgColorCode);
        }
        data[i].panelData.code = iosCode.join('');
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            data[i].children = exports.transIOSCode(data[i].children);
        }
    }
    return data;
};


/***/ }),
/* 166 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transWebCode = void 0;
exports.transWebCode = (data, codeData) => {
    for (let i = 0; i < data.length; i++) {
        // let code = '';
        // Object.keys(codeData[i].style).forEach(item=> {
        //     code += `${item}: ${codeData[i].style[item]};\r\n`;
        // })
        if (!data[i].panelData) {
            data[i].panelData = {};
        }
        // 属性面板兼容
        data[i].panelData.code = codeData[i].style;
        // 样式复值
        data[i].style = codeData[i].style;
        if (Array.isArray(data[i].children)) {
            exports.transWebCode(data[i].children, codeData[i].children);
        }
    }
    return data;
};


/***/ }),
/* 167 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transPanel = void 0;
const common_1 = __webpack_require__(55);
// 转换 Radius
const transRadius = (radius, scale, unit) => {
    // 值相同
    if (new Set(radius).size === 1) {
        // 值等于0
        if (radius[0] === 0) {
            return '';
        }
        // 值不等于0
        return `${common_1._scale(radius[0], scale)}${unit}`;
    }
    // 值不同
    return radius.map((item) => `${common_1._scale(item, scale)}${unit}`).join(' ');
};
exports.transPanel = (data, options) => {
    const { scale, unit } = options;
    for (let i = 0; i < data.length; i++) {
        const { panel } = data[i];
        if (panel) {
            const { properties, fills, typefaces, borders, shadows, code } = panel;
            // panel转换
            data[i].panelData = {
                properties: {
                    name: properties.name,
                    position: {
                        x: `${common_1._scale(properties.position.x, scale)}${unit}`,
                        y: `${common_1._scale(properties.position.y, scale)}${unit}`,
                    },
                    size: {
                        width: `${common_1._scale(properties.size.width, scale)}${unit}`,
                        height: `${common_1._scale(properties.size.height, scale)}${unit}`
                    },
                    opacity: properties.opacity ? `${properties.opacity * 100}%` : '',
                    radius: Array.isArray(properties.radius) ? transRadius(properties.radius, scale, unit) : (properties.radius ? `${common_1._scale(properties.radius, scale)}${unit}` : ''),
                    symbolName: properties.symbolName,
                    sharedLayerStyleName: properties.sharedLayerStyleName,
                    sharedTextStyleName: properties.sharedTextStyleName // 共享文本样式名称
                },
                fills,
                typefaces: typefaces.map(typeface => {
                    const { fontSize, letterSpacing, lineHeight, paragraphSpacing } = typeface;
                    return Object.assign(Object.assign({}, typeface), { fontSize: `${common_1._scale(fontSize, scale)}${unit}`, letterSpacing: `${common_1._scale(letterSpacing, scale)}${unit}`, lineHeight: `${common_1._scale(lineHeight, scale)}${unit}`, paragraphSpacing: `${common_1._scale(paragraphSpacing, scale)}${unit}` });
                }),
                borders: borders.map(border => {
                    const { thickness } = border;
                    return Object.assign(Object.assign({}, border), { thickness: `${common_1._scale(thickness, scale)}${unit}` });
                }),
                shadows: shadows.map((shadow) => {
                    const { offsetX, offsetY, blurRadius, spread } = shadow;
                    return Object.assign(Object.assign({}, shadow), { offsetX: `${common_1._scale(offsetX, scale)}${unit}`, offsetY: `${common_1._scale(offsetY, scale)}${unit}`, blurRadius: `${common_1._scale(blurRadius, scale)}${unit}`, spread: `${common_1._scale(spread, scale)}${unit}` });
                }),
                code
            };
        }
        if (data[i].type !== 'Text' && Array.isArray(data[i].children)) {
            data[i].children = exports.transPanel(data[i].children, options);
        }
    }
    return data;
};


/***/ }),
/* 168 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.transScale = void 0;
const common_1 = __webpack_require__(55);
exports.transScale = (data, options) => {
    var _a;
    const { scale } = options;
    const scaleData = JSON.parse(JSON.stringify(data));
    for (let i = 0; i < scaleData.length; i++) {
        const { structure } = scaleData[i];
        scaleData[i].structure = Object.assign(Object.assign({}, scaleData[i].structure), { x: common_1._scale(structure.x, scale), y: common_1._scale(structure.y, scale), width: common_1._scale(structure.width, scale), height: common_1._scale(structure.height, scale) });
        if (scaleData[i].structure.border) {
            scaleData[i].structure.border = {
                top: Object.assign(Object.assign({}, scaleData[i].structure.border.top), { width: common_1._scale(scaleData[i].structure.border.top.width, scale) }),
                right: Object.assign(Object.assign({}, scaleData[i].structure.border.right), { width: common_1._scale(scaleData[i].structure.border.right.width, scale) }),
                bottom: Object.assign(Object.assign({}, scaleData[i].structure.border.bottom), { width: common_1._scale(scaleData[i].structure.border.bottom.width, scale) }),
                left: Object.assign(Object.assign({}, scaleData[i].structure.border.left), { width: common_1._scale(scaleData[i].structure.border.left.width, scale) })
            };
        }
        if (scaleData[i].style.width) {
            scaleData[i].style.width = common_1._scale(scaleData[i].style.width, scale);
        }
        if (scaleData[i].style.height) {
            scaleData[i].style.height = common_1._scale(scaleData[i].style.height, scale);
        }
        if (scaleData[i].style.textStyle) {
            if (scaleData[i].style.textStyle.fontSize) {
                scaleData[i].style.textStyle.fontSize = common_1._scale(scaleData[i].style.textStyle.fontSize, scale);
            }
            if (scaleData[i].style.textStyle.letterSpacing) {
                scaleData[i].style.textStyle.letterSpacing = common_1._scale(scaleData[i].style.textStyle.letterSpacing, scale);
            }
            if (scaleData[i].style.textStyle.lineHeight) {
                scaleData[i].style.textStyle.lineHeight = common_1._scale(scaleData[i].style.textStyle.lineHeight, scale);
            }
        }
        if (scaleData[i].style.lineHeight) {
            scaleData[i].style.lineHeight = common_1._scale(scaleData[i].style.lineHeight, scale);
        }
        if (scaleData[i].style.boxShadow) {
            scaleData[i].style.boxShadow = scaleData[i].style.boxShadow.map(shadow => (Object.assign(Object.assign({}, shadow), { offsetX: common_1._scale(shadow.offsetX, scale), offsetY: common_1._scale(shadow.offsetY, scale), spread: common_1._scale(shadow.spread, scale), blurRadius: common_1._scale(shadow.blurRadius, scale) })));
        }
        if (scaleData[i].style.textShadow) {
            scaleData[i].style.textShadow = scaleData[i].style.textShadow.map(shadow => (Object.assign(Object.assign({}, shadow), { offsetX: common_1._scale(shadow.offsetX, scale), offsetY: common_1._scale(shadow.offsetY, scale), spread: common_1._scale(shadow.spread, scale), blurRadius: common_1._scale(shadow.blurRadius, scale) })));
        }
        if (scaleData[i].style.borderRadius) {
            const { bottomLeft, bottomRight, topLeft, topRight } = scaleData[i].style.borderRadius;
            scaleData[i].style.borderRadius = {
                bottomLeft: common_1._scale(bottomLeft, scale),
                bottomRight: common_1._scale(bottomRight, scale),
                topLeft: common_1._scale(topLeft, scale),
                topRight: common_1._scale(topRight, scale),
            };
        }
        if ((_a = scaleData[i].style.background) === null || _a === void 0 ? void 0 : _a.radialGradient) {
            const { smallRadius, largeRadius, position } = scaleData[i].style.background.radialGradient;
            scaleData[i].style.background.radialGradient = Object.assign(Object.assign({}, scaleData[i].style.background.radialGradient), { smallRadius: common_1._scale(smallRadius, scale), largeRadius: common_1._scale(largeRadius, scale), position: {
                    left: common_1._scale(position.left, scale),
                    top: common_1._scale(position.top, scale),
                } });
        }
        if (Array.isArray(scaleData[i].children)) {
            scaleData[i].children = exports.transScale(scaleData[i].children, options);
        }
    }
    return scaleData;
};


/***/ }),
/* 169 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(19), exports);
__exportStar(__webpack_require__(183), exports);


/***/ }),
/* 170 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 171 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 173 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
// 类型导出
__exportStar(__webpack_require__(174), exports);
__exportStar(__webpack_require__(175), exports);
__exportStar(__webpack_require__(176), exports);
__exportStar(__webpack_require__(177), exports);
__exportStar(__webpack_require__(178), exports);


/***/ }),
/* 174 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description Sketch 边框位置
 * @enum {number}
 */
var SKBorderPosition;
(function (SKBorderPosition) {
    SKBorderPosition[SKBorderPosition["Inside"] = 0] = "Inside";
    SKBorderPosition[SKBorderPosition["Center"] = 1] = "Center";
    SKBorderPosition[SKBorderPosition["Outside"] = 2] = "Outside"; // 外边框
})(SKBorderPosition || (SKBorderPosition = {}));


/***/ }),
/* 175 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 176 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description 渐变类型
 * @enum {number}
 */
var SKGradientType;
(function (SKGradientType) {
    SKGradientType[SKGradientType["Linear"] = 0] = "Linear";
    SKGradientType[SKGradientType["Radial"] = 1] = "Radial";
    SKGradientType[SKGradientType["Angular"] = 2] = "Angular"; // 环形渐变
})(SKGradientType || (SKGradientType = {}));
/**
 * @description 填充类型
 * @enum {number}
 */
var SKFillType;
(function (SKFillType) {
    SKFillType[SKFillType["Color"] = 0] = "Color";
    SKFillType[SKFillType["Gradient"] = 1] = "Gradient";
    SKFillType[SKFillType["Image"] = 4] = "Image";
    SKFillType[SKFillType["Texture"] = 5] = "Texture"; // 纹理效果填充
})(SKFillType || (SKFillType = {}));
/**
 * @description 图片填充模式类型
 * @enum {number}
 */
var SKPatternFillType;
(function (SKPatternFillType) {
    SKPatternFillType[SKPatternFillType["Mask_Tile"] = 0] = "Mask_Tile";
    SKPatternFillType[SKPatternFillType["Mask_Fill"] = 1] = "Mask_Fill";
    SKPatternFillType[SKPatternFillType["Mask_Stretch"] = 2] = "Mask_Stretch";
    SKPatternFillType[SKPatternFillType["Mask_Fit"] = 3] = "Mask_Fit"; // 包含(contain)
})(SKPatternFillType || (SKPatternFillType = {}));


/***/ }),
/* 177 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 178 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * @description 段落文本分布方式
 * @enum {number}
 */
var SKAlignment;
(function (SKAlignment) {
    SKAlignment[SKAlignment["Left"] = 0] = "Left";
    SKAlignment[SKAlignment["Right"] = 1] = "Right";
    SKAlignment[SKAlignment["Center"] = 2] = "Center";
    SKAlignment[SKAlignment["Justify"] = 3] = "Justify";
})(SKAlignment || (SKAlignment = {}));
var SKTextTransformAttribute;
(function (SKTextTransformAttribute) {
    SKTextTransformAttribute[SKTextTransformAttribute["Normal"] = 0] = "Normal";
    SKTextTransformAttribute[SKTextTransformAttribute["LowerCase"] = 1] = "LowerCase";
    SKTextTransformAttribute[SKTextTransformAttribute["UpperCase"] = 2] = "UpperCase"; // 转成小写
})(SKTextTransformAttribute || (SKTextTransformAttribute = {}));


/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Alignment;
(function (Alignment) {
    Alignment[Alignment["Left"] = 0] = "Left";
    Alignment[Alignment["Right"] = 1] = "Right";
    Alignment[Alignment["Center"] = 2] = "Center";
    Alignment[Alignment["Justify"] = 3] = "Justify"; // 水平两边对齐
})(Alignment || (Alignment = {}));
var VerticalAlignment;
(function (VerticalAlignment) {
    VerticalAlignment[VerticalAlignment["Top"] = 0] = "Top";
    VerticalAlignment[VerticalAlignment["Center"] = 1] = "Center";
    VerticalAlignment[VerticalAlignment["Bottom"] = 2] = "Bottom";
})(VerticalAlignment || (VerticalAlignment = {}));
var FillType;
(function (FillType) {
    FillType[FillType["PureColor"] = 0] = "PureColor";
    FillType[FillType["linearGradient"] = 1] = "linearGradient";
    FillType[FillType["radialGradient"] = 2] = "radialGradient";
    FillType[FillType["angularGradient"] = 3] = "angularGradient";
})(FillType || (FillType = {}));
/**
 * 边框位置
 */
var BorderPosition;
(function (BorderPosition) {
    BorderPosition[BorderPosition["Center"] = 0] = "Center";
    BorderPosition[BorderPosition["Inside"] = 1] = "Inside";
    BorderPosition[BorderPosition["Outside"] = 2] = "Outside";
})(BorderPosition || (BorderPosition = {}));
/**
 * 阴影类型
 */
var ShadowType;
(function (ShadowType) {
    ShadowType[ShadowType["Inner"] = 0] = "Inner";
    ShadowType[ShadowType["Normal"] = 1] = "Normal";
})(ShadowType || (ShadowType = {}));


/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CodeType = exports.ColorFormat = exports.Unit = exports.AndroidScale = exports.IOSScale = exports.WebScale = void 0;
var WebScale;
(function (WebScale) {
    WebScale[WebScale["Points"] = 1] = "Points";
    WebScale[WebScale["Retina"] = 2] = "Retina";
})(WebScale = exports.WebScale || (exports.WebScale = {}));
var IOSScale;
(function (IOSScale) {
    IOSScale[IOSScale["Points"] = 1] = "Points";
    IOSScale[IOSScale["Retina"] = 2] = "Retina";
    IOSScale[IOSScale["RetinaHD"] = 3] = "RetinaHD";
})(IOSScale = exports.IOSScale || (exports.IOSScale = {}));
var AndroidScale;
(function (AndroidScale) {
    AndroidScale[AndroidScale["MDPI"] = 1] = "MDPI";
    AndroidScale[AndroidScale["HDPI"] = 1.5] = "HDPI";
    AndroidScale[AndroidScale["XHDPI"] = 2] = "XHDPI";
    AndroidScale[AndroidScale["XXHDPI"] = 3] = "XXHDPI";
    AndroidScale[AndroidScale["XXXHDPI"] = 4] = "XXXHDPI";
})(AndroidScale = exports.AndroidScale || (exports.AndroidScale = {}));
var Unit;
(function (Unit) {
    Unit["IOS"] = "pt";
    Unit["Android"] = "dp";
    Unit["WebPx"] = "px";
    Unit["WebRem"] = "rem";
    Unit["Weapp"] = "rpx";
    Unit["ReactNative"] = "";
})(Unit = exports.Unit || (exports.Unit = {}));
var ColorFormat;
(function (ColorFormat) {
    ColorFormat["HEX"] = "hex";
    ColorFormat["AHEX"] = "ahex";
    ColorFormat["HEXA"] = "hexa";
    ColorFormat["RGBA"] = "rgba";
    ColorFormat["HSLA"] = "hsla";
})(ColorFormat = exports.ColorFormat || (exports.ColorFormat = {}));
var CodeType;
(function (CodeType) {
    CodeType["IOS"] = "ios";
    CodeType["Android"] = "android";
    CodeType["WebPx"] = "webpx";
    CodeType["WebRem"] = "webrem";
    CodeType["Weapp"] = "weapp";
    CodeType["ReactNative"] = "reactnative";
})(CodeType = exports.CodeType || (exports.CodeType = {}));


/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(184), exports);
__exportStar(__webpack_require__(191), exports);
__exportStar(__webpack_require__(195), exports);
__exportStar(__webpack_require__(202), exports);


/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(185), exports);
__exportStar(__webpack_require__(186), exports);
__exportStar(__webpack_require__(187), exports);
__exportStar(__webpack_require__(188), exports);
__exportStar(__webpack_require__(189), exports);
__exportStar(__webpack_require__(190), exports);


/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 186 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 187 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 188 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 189 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 190 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 191 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(192), exports);
__exportStar(__webpack_require__(193), exports);
__exportStar(__webpack_require__(194), exports);


/***/ }),
/* 192 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 边框类型
 */
var borderStyleType;
(function (borderStyleType) {
    borderStyleType["Dotted"] = "dotted";
    borderStyleType["Solid"] = "solid";
    borderStyleType["Double"] = "double";
    borderStyleType["Dashed"] = "dashed";
})(borderStyleType || (borderStyleType = {}));


/***/ }),
/* 193 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 194 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 195 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
__exportStar(__webpack_require__(196), exports);
__exportStar(__webpack_require__(197), exports);
__exportStar(__webpack_require__(198), exports);
__exportStar(__webpack_require__(199), exports);
__exportStar(__webpack_require__(200), exports);
__exportStar(__webpack_require__(201), exports);


/***/ }),
/* 196 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 197 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.BackgroundRepeat = void 0;
/**
 *
 */
var BackgroundRepeat;
(function (BackgroundRepeat) {
    BackgroundRepeat[BackgroundRepeat["repeat"] = 0] = "repeat";
    BackgroundRepeat[BackgroundRepeat["repeat-x"] = 1] = "repeat-x";
    BackgroundRepeat[BackgroundRepeat["no-repeat"] = 2] = "no-repeat";
    BackgroundRepeat[BackgroundRepeat["repeat-y"] = 3] = "repeat-y";
})(BackgroundRepeat = exports.BackgroundRepeat || (exports.BackgroundRepeat = {}));


/***/ }),
/* 198 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 199 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 200 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 201 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 202 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });


/***/ }),
/* 203 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.decodeCodeTrans = exports.decodeMeatureTrans = exports.encodeTrans = void 0;
/**
 * Base64 加密、解密算法封装：
 */
function Base64() {
    // private property
    let _keyStr = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    // private method for UTF-8 encoding
    function _utf8_encode(string) {
        string = string.replace(/\r\n/g, '\n');
        let utftext = '';
        for (let n = 0; n < string.length; n++) {
            let c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }
        }
        return utftext;
    }
    // private method for UTF-8 decoding
    function _utf8_decode(utftext) {
        let string = '';
        let i = 0;
        let c2, c1, c3;
        let c = c1 = c2 = 0;
        while (i < utftext.length) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
    // public method for encoding
    this.encode = function (input) {
        let output = '';
        let chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        let i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            }
            else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
                _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
                _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    };
    // public method for decoding
    this.decode = function (input) {
        let output = '';
        let chr1, chr2, chr3;
        let enc1, enc2, enc3, enc4;
        let i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, '');
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    };
}
const base64Instance = new Base64();
// 编码
exports.encodeTrans = base64Instance.encode;
// 解码标注数据
exports.decodeMeatureTrans = (data) => {
    try {
        // base64解码
        let dsl = base64Instance.decode(data);
        dsl = dsl ? JSON.parse(dsl) : [];
        // 数据结构调整
        return [Object.assign(Object.assign({}, dsl), { children: [] }), ...(Array.isArray(dsl.children) ? dsl.children : [])];
    }
    catch (error) {
        console.log(error);
        return [];
    }
};
// 解码代码数据
exports.decodeCodeTrans = (data) => {
    // base64解码
    let dsl = base64Instance.decode(data);
    dsl = dsl ? JSON.parse(dsl) : dsl;
    // 数据结构调整
    return dsl;
};


/***/ }),
/* 204 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const classNameList = [
    'rat',
    'valley',
    'pence',
    'unconditional',
    'feather',
    'zoo',
    'build',
    'field',
    'nationality',
    'salad',
    'ferry',
    'building',
    'limit',
    'stewardess',
    'water',
    'manage',
    'path',
    'example',
    'purple',
    'valid',
    'hurry',
    'argue',
    'accommodation',
    'mixture',
    'time',
    'picnic',
    'consensus',
    'smoke',
    'protection',
    'conscience',
    'sense',
    'owe',
    'chant',
    'term',
    'urban',
    'considerate',
    'afraid',
    'bandage',
    'table',
    'tennis',
    'candidate',
    'combine',
    'hurricane',
    'independent',
    'cancer',
    'choose',
    'town',
    'desire',
    'visual',
    'life',
    'submit',
    'physics',
    'meaning',
    'country',
    'half',
    'joy',
    'adult',
    'servant',
    'care',
    'search',
    'same',
    'furniture',
    'agree',
    'heart',
    'unemployment',
    'nearly',
    'bond',
    'master',
    'rise',
    'punish',
    'monument',
    'stick',
    'tax',
    'personnel',
    'fact',
    'therefore',
    'ox',
    'ocean',
    'eagle',
    'cloud',
    'fibre',
    'fiber',
    'bingo',
    'fortunate',
    'mommy',
    'wage',
    'along',
    'surplus',
    'add',
    'outdoors',
    'paper',
    'fetch',
    'church',
    'edition',
    'weather',
    'opera',
    'dot',
    'service',
    'disease',
    'symphony',
    'survival',
    'thus',
    'satisfy',
    'arise',
    'sorry',
    'dinosaur',
    'properly',
    'story',
    'appetite',
    'pronounce',
    'socialist',
    'certain',
    'pea',
    'bacterium',
    'contrary',
    'roof',
    'carve',
    'essay',
    'reward',
    'convenience',
    'export',
    'fit',
    'racial',
    'herself',
    'bid',
    'novelist',
    'safety',
    'off',
    'east',
    'misunderstand',
    'razor',
    'waiting',
    'room',
    'short',
    'surprise',
    'pleasure',
    'tidy',
    'garage',
    'analyse',
    'Am',
    'analyze',
    'notice',
    'violinist',
    'ice',
    'deliberately',
    'alike',
    'perfect',
    'broom',
    'welfare',
    'keyboard',
    'dad',
    'daddy',
    'approximately',
    'hopeful',
    'habit',
    'confidential',
    'complex',
    'recreation',
    'data',
    'kindergarten',
    'sniff',
    'we',
    'studio',
    'overlook',
    'barbershop',
    'minority',
    'escape',
    'jeans',
    'videophone',
    'adapt',
    'report',
    'recorder',
    'betray',
    'vast',
    'arrow',
    'usual',
    'eat',
    'spread',
    'agent',
    'spare',
    'conclusion',
    'rock',
    'hometown',
    'bakery',
    'conclude',
    'worry',
    'operate',
    'floor',
    'area',
    'noise',
    'chairwoman',
    'classroom',
    'communicate',
    'attack',
    'event',
    'dream',
    'criminal',
    'authentic',
    'scarf',
    'senior',
    'OK',
    'okay',
    'description',
    'representative',
    'carriage',
    'sacred',
    'run',
    'software',
    'diet',
    'copy',
    'eastern',
    'carbon',
    'sow',
    'universe',
    'folk',
    'tendency',
    'camp',
    'likely',
    'alive',
    'harvest',
    'devote',
    'marathon',
    'Christian',
    'government',
    'Franc',
    'seminar',
    'departure',
    'forward',
    'person',
    'violence',
    'basketball',
    'gas',
    'fox',
    'advance',
    'majority',
    'credit',
    'relief',
    'prefer',
    'qualification',
    'sand',
    'lift',
    'attain',
    'fantasy',
    'trap',
    'interesting',
    'nothing',
    'civilian',
    'besides',
    'homework',
    'container',
    'fireworks',
    'toy',
    'focus',
    'decide',
    'frighten',
    'cleaner',
    'autumn',
    'beneath',
    'hostess',
    'climb',
    'expert',
    'super',
    'significance',
    'hair',
    'phrase',
    'authority',
    'agricultural',
    'explore',
    'framework',
    'caf',
    'consequence',
    'geography',
    'your',
    'match',
    'hall',
    'ship',
    'suppose',
    'signature',
    'borrow',
    'create',
    'companion',
    'direction',
    'except',
    'big',
    'nutrition',
    'anecdote',
    'string',
    'breast',
    'flashlight',
    'unconscious',
    'champion',
    'funeral',
    'since',
    'how',
    'jacket',
    'robot',
    'like',
    'pleasant',
    'airport',
    'compensate',
    'more',
    'sandwich',
    'boring',
    'seldom',
    'jazz',
    'mile',
    'apologize',
    'shout',
    'commit',
    'can',
    'institution',
    'upstairs',
    'abortion',
    'storage',
    'bravery',
    'envelope',
    'amazing',
    'disappoint',
    'advantage',
    'lab',
    'laboratory',
    'foreign',
    'conduct',
    'prison',
    'agreement',
    'botany',
    'famous',
    'mix',
    'level',
    'go',
    'urgent',
    'scholar',
    'jet',
    'cottage',
    'sigh',
    'maid',
    'pop',
    'popular',
    'advertisement',
    'western',
    'course',
    'wound',
    'together',
    'reservation',
    'because',
    'realise',
    'grateful',
    'huge',
    'turn',
    'knowledge',
    'arrive',
    'seaside',
    'assessment',
    'kilometre',
    'plug',
    'impress',
    'else',
    'fail',
    'discuss',
    'temporary',
    'volcano',
    'call',
    'asleep',
    'amateur',
    'material',
    'fragrant',
    'slave',
    'itself',
    'stupid',
    'central',
    'evening',
    'collision',
    'highway',
    'staff',
    'Asia',
    'medicine',
    'shop',
    'pump',
    'discourage',
    'political',
    'continent',
    'bless',
    'jeep',
    'account',
    'zoom',
    'content',
    'trousers',
    'tonight',
    'spend',
    'astronaut',
    'belt',
    'yet',
    'result',
    'gravity',
    'worth',
    'prize',
    'up',
    'quarrel',
    'born',
    'ring',
    'guard',
    'driver',
    'otherwise',
    'repair',
    'back',
    'reasonable',
    'could',
    'disappear',
    'shy',
    'questionnaire',
    'cheers',
    'interview',
    'kindness',
    'gold',
    'gradual',
    'quit',
    'medical',
    'waste',
    'airmail',
    'expensive',
    'wisdom',
    'favourite',
    'attitude',
    'touch',
    'soil',
    'especially',
    'who',
    'suck',
    'breath',
    'rice',
    'stout',
    'version',
    'oxygen',
    'grey',
    'humorous',
    'burn',
    'regard',
    'seaweed',
    'tremble',
    'pillow',
    'garlic',
    'straw',
    'pineapple',
    'hot',
    'tradition',
    'rescue',
    'again',
    'violent',
    'as',
    'terror',
    'fortune',
    'until',
    'pride',
    'foster',
    'home',
    'peace',
    'shorts',
    'vertical',
    'jam',
    'hatch',
    'atmosphere',
    'stadium',
    'main',
    'people',
    'light',
    'injure',
    'witness',
    'component',
    'weekly',
    'right',
    'dialogue',
    'audience',
    'acquire',
    'store',
    'decline',
    'very',
    'user',
    'spit',
    'undertake',
    'terrible',
    'vacation',
    'much',
    'handbag',
    'saucer',
    'officer',
    'whisper',
    'pleased',
    'greedy',
    'horse',
    'little',
    'cloudy',
    'mainland',
    'fee',
    'taste',
    'alternative',
    'opening',
    'toothache',
    'universal',
    'cow',
    'wheel',
    'pipe',
    'profession',
    'dig',
    'conversation',
    'gain',
    'subjective',
    'thunder',
    'clay',
    'hill',
    'give',
    'budget',
    'against',
    'cage',
    'on',
    'unfit',
    'scene',
    'pint',
    'freezing',
    'oilfield',
    'onion',
    'seed',
    'outstanding',
    'wool',
    'crazy',
    'sew',
    'shelf',
    'freeze',
    'speed',
    'behaviour',
    'behavior',
    'TV',
    'television',
    'chest',
    'knock',
    'something',
    'directory',
    'platform',
    'sightseeing',
    'bay',
    'foreigner',
    'another',
    'oh',
    'zero',
    'boy',
    'handsome',
    'rest',
    'study',
    'front',
    'rely',
    'aside',
    'appeal',
    'competence',
    'fresh',
    'question',
    'south',
    'annoy',
    'pretty',
    'conference',
    'communist',
    'sunlight',
    'cure',
    'slide',
    'glance',
    'paint',
    'wine',
    'dive',
    'admire',
    'existence',
    'bureaucratic',
    'price',
    'skill',
    'nor',
    'enthusiastic',
    'volleyball',
    'dam',
    'delicate',
    'someone',
    'post',
    'father',
    'disgusting',
    'radioactive',
    'offense',
    'passer',
    'by',
    'what',
    'human',
    'guarantee',
    'husband',
    'island',
    'painting',
    'nowadays',
    'hardship',
    'counter',
    'collar',
    'appropriate',
    'thriller',
    'repeat',
    'perform',
    'unbelievable',
    'dozen',
    'Easter',
    'noisy',
    'see',
    'idea',
    'uncomfortable',
    'load',
    'reception',
    'look',
    'value',
    'chess',
    'thunderstorm',
    'convenient',
    'kilo',
    'cassette',
    'toward',
    's',
    'wood',
    'theft',
    'chef',
    'businessman',
    'silly',
    'tomato',
    'brunch',
    'laugh',
    'suitcase',
    'coin',
    'spade',
    'mental',
    'comfort',
    'receiver',
    'Africa',
    'percentage',
    'wrong',
    'correspond',
    'reflect',
    'spy',
    'somebody',
    'religious',
    'last',
    'shade',
    'perfume',
    'pity',
    'trouble',
    'necklace',
    'pancake',
    'interest',
    'hen',
    'dynasty',
    'single',
    'puzzle',
    'head',
    'mean',
    'break',
    'among',
    'certificate',
    'crowd',
    'wander',
    'box',
    'fix',
    'clinic',
    'grammar',
    'ball',
    'translate',
    'delete',
    'cheat',
    'adjust',
    'ill',
    'swing',
    'privilege',
    'quarter',
    'brain',
    'orbit',
    'attach',
    'blind',
    'wild',
    'plastic',
    'adaption',
    'lively',
    'reply',
    'yours',
    'assume',
    'saying',
    'composition',
    'sunshine',
    'union',
    'angle',
    'legal',
    'death',
    'observe',
    'splendid',
    'scar',
    'buy',
    'kill',
    'rent',
    'distinguish',
    'lead',
    'vest',
    'effect',
    'mud',
    'refer',
    'globe',
    'zip',
    'power',
    'marriage',
    'brilliant',
    'pick',
    'speech',
    'ancient',
    'director',
    'replace',
    'pig',
    'autonomous',
    'red',
    'output',
    'die',
    'gifted',
    'station',
    'apple',
    'teamwork',
    'revision',
    'revolution',
    'surgeon',
    'link',
    'average',
    'section',
    'fluency',
    'underground',
    'number',
    'amusement',
    'develop',
    'sword',
    'star',
    'greengrocer',
    'lucky',
    'eraser',
    'rainbow',
    'anxious',
    'beyond',
    'news',
    'waitress',
    'reference',
    'switch',
    'caption',
    'rough',
    'rail',
    'photo',
    'photograph',
    'parrot',
    'must',
    'instant',
    'centre',
    'determine',
    'street',
    'voyage',
    'Ms',
    'patient',
    'wake',
    'worker',
    'Internet',
    'coast',
    'benefit',
    'with',
    'already',
    'face',
    'none',
    'broad',
    'feed',
    'shoot',
    'across',
    'male',
    'Antarctic',
    'zone',
    'continue',
    'blackboard',
    'join',
    'defend',
    'tentative',
    'channel',
    'technical',
    'snow',
    'difficult',
    'bird',
    'widespread',
    'war',
    'pear',
    'lot',
    'excuse',
    'actress',
    'tablet',
    'score',
    'pronunciation',
    'such',
    'accent',
    'chat',
    'deer',
    'memorial',
    'within',
    'tent',
    'microwave',
    'success',
    'luggage',
    'ending',
    'noodle',
    'vain',
    'dentist',
    'district',
    'control',
    'bill',
    'professor',
    'indicate',
    'gentle',
    'helicopter',
    'airplane',
    'please',
    'allowance',
    'forehead',
    'stable',
    'fast',
    'lake',
    'quilt',
    'agenda',
    'command',
    'photographer',
    'monitor',
    'gift',
    'middle',
    'means',
    'glare',
    'breakfast',
    'mad',
    'currency',
    'detective',
    'VCD',
    'visual',
    'compact',
    'disk',
    'prisoner',
    'dinner',
    'helmet',
    'handwriting',
    'thankful',
    'enough',
    'psychology',
    'skin',
    'amuse',
    'cut',
    'poisonous',
    'hearing',
    'praise',
    'flight',
    'ash',
    'crime',
    'troublesome',
    'coke',
    'circulate',
    'address',
    'numb',
    'drunk',
    'resign',
    'menu',
    'congratulate',
    'gay',
    'plain',
    'affair',
    'chicken',
    'deed',
    'pure',
    'cover',
    'error',
    'relationship',
    'snowy',
    'ticket',
    'subject',
    'throughout',
    'applicant',
    'ceiling',
    'manner',
    'type',
    'remark',
    'mop',
    'smog',
    'lid',
    'topic',
    'literature',
    'garment',
    'squirrel',
    'aloud',
    'next',
    'barrier',
    'sharp',
    'declare',
    'headline',
    'appreciation',
    'vivid',
    'well',
    'a',
    'm',
    'am',
    'A',
    'M',
    'AM',
    'thief',
    'skirt',
    'wildlife',
    'cater',
    'tissue',
    'leader',
    'hide',
    'bit',
    'pioneer',
    'nation',
    'disagree',
    'relevant',
    'drawer',
    'dip',
    'treatment',
    'regular',
    'duty',
    'metre',
    'download',
    'canal',
    'vague',
    'foot',
    'letter',
    'sadness',
    'skate',
    'motherland',
    'dress',
    'some',
    'major',
    'lie',
    'tractor',
    'plus',
    'honour',
    'bow',
    'public',
    'reform',
    'fill',
    'mathematics',
    'math',
    'maths',
    'admission',
    'throat',
    'civil',
    'goat',
    'watch',
    'environment',
    'taxpayer',
    'whether',
    'anxiety',
    'carrier',
    'captain',
    'apology',
    'broadcast',
    'compete',
    'matter',
    'decision',
    'unwilling',
    'Europe',
    'coincidence',
    'circle',
    'oppose',
    'forty',
    'arrest',
    'shore',
    'unit',
    'origin',
    'use',
    'inn',
    'electronic',
    'volunteer',
    'team',
    'burst',
    'thread',
    'innocent',
    'skyscraper',
    'hero',
    'twin',
    'tiny',
    'expense',
    'surface',
    'swift',
    'thermos',
    'tutor',
    'dimension',
    'god',
    'behave',
    'jog',
    'wax',
    'bad',
    'outside',
    'vital',
    'leaf',
    'Asian',
    'pet',
    'each',
    'no',
    'theater',
    'think',
    'storm',
    'neighbourhood',
    'clock',
    'dare',
    'explode',
    'peaceful',
    'pale',
    'assumption',
    'typewriter',
    'concentrate',
    'several',
    'bell',
    'bitter',
    'reason',
    'dance',
    'pest',
    'shame',
    'bored',
    'point',
    'analysis',
    'bus',
    'identification',
    'need',
    'spoon',
    'nephew',
    'physician',
    'judgment',
    'gallon',
    'meeting',
    'tobacco',
    'wash',
    'relation',
    'breathe',
    'clean',
    'chart',
    'faith',
    'hook',
    'percent',
    'instruction',
    'daughter',
    'intention',
    'yourself',
    'booth',
    'secure',
    'semicircle',
    'voice',
    'food',
    'strait',
    'addicted',
    'cartoon',
    'prepare',
    'shave',
    'fight',
    'apparent',
    'metal',
    'pink',
    'passive',
    'lovely',
    'transparent',
    'click',
    'outward',
    's',
    'adolescent',
    'than',
    'fire',
    'sick',
    'grasp',
    'ashamed',
    'black',
    'interpreter',
    'weed',
    'from',
    'beauty',
    'schoolboy',
    'towel',
    'beg',
    'biochemistry',
    'into',
    'symptom',
    'subscribe',
    'shrink',
    'allow',
    'accountant',
    'disturb',
    'avenue',
    'meet',
    'message',
    'bread',
    'sheet',
    'secret',
    'whenever',
    'pardon',
    'physical',
    'athlete',
    'requirement',
    'glory',
    'surround',
    'violin',
    'aluminium',
    'birthplace',
    'nuclear',
    'equal',
    'most',
    'often',
    'soup',
    'rigid',
    'adjustment',
    'blue',
    'abstract',
    'steady',
    'rope',
    'sink',
    'goose',
    'place',
    'truck',
    'job',
    'wide',
    'compromise',
    'arrival',
    'rooster',
    'tick',
    'intelligence',
    'theme',
    'wait',
    'postpone',
    'hole',
    'deserve',
    'institute',
    'surrounding',
    'twice',
    'coal',
    'draw',
    'yard',
    'destroy',
    'rag',
    'correction',
    'ownership',
    'predict',
    'agency',
    'I',
    'automatic',
    'guess',
    'lunch',
    'rugby',
    'burden',
    'enter',
    'discussion',
    'struggle',
    'editor',
    'reduce',
    'prohibit',
    'persuade',
    'day',
    'sharpener',
    'research',
    'greet',
    'educator',
    'penny',
    'get',
    'cheap',
    'lose',
    'customs',
    'salty',
    'height',
    'find',
    'above',
    'aid',
    'Arctic',
    'fuel',
    'socialism',
    'bend',
    'terminal',
    'compulsory',
    'winner',
    'grass',
    'sweet',
    'stream',
    'irrigation',
    'busy',
    'low',
    'swap',
    'musician',
    'cuisine',
    'sacrifice',
    'recommend',
    'soldier',
    'ruin',
    'possible',
    'anyway',
    'judge',
    'triangle',
    'mother',
    'attraction',
    'pool',
    'birthday',
    'brown',
    'howl',
    'personally',
    'offshore',
    'application',
    'dioxide',
    'suite',
    'obvious',
    'wife',
    'ham',
    'speaker',
    'mistake',
    'least',
    'game',
    'sympathy',
    'league',
    'clumsy',
    'millionaire',
    'tournament',
    'nod',
    'socket',
    'willing',
    'blame',
    'status',
    'sincerely',
    'emergency',
    'nature',
    'seal',
    'pollute',
    'sometimes',
    'contribute',
    'poster',
    'postage',
    'routine',
    'kettle',
    'piece',
    'listen',
    'lesson',
    'painter',
    'neither',
    'postcode',
    'electric',
    'competition',
    'leather',
    'seem',
    'sausage',
    'format',
    'bamboo',
    'expose',
    'protect',
    'accident',
    'cubic',
    'yoghurt',
    'dictation',
    'plate',
    'inspire',
    'grandson',
    'stop',
    'anyhow',
    'merciful',
    'bathroom',
    'journey',
    'patience',
    'cinema',
    'chair',
    'survive',
    'change',
    'litre',
    'onto',
    'dirty',
    'mineral',
    'gather',
    'milk',
    'grill',
    'wall',
    'object',
    'spot',
    'ready',
    'patent',
    'land',
    'policewoman',
    'media',
    'tale',
    'guest',
    'positive',
    'precise',
    'march',
    'speed',
    'o',
    'clock',
    'donate',
    'want',
    'polite',
    'troop',
    'hotel',
    'classify',
    'fingernail',
    'facial',
    'classmate',
    'graduation',
    'pattern',
    'card',
    'powerful',
    'brewery',
    'homeland',
    'distant',
    'trust',
    'stage',
    'is',
    'sell',
    'import',
    'convince',
    'suffering',
    'pork',
    'grocer',
    'satellite',
    'statistics',
    'himself',
    'defence',
    'rate',
    'tense',
    'army',
    'factory',
    'necessary',
    'agriculture',
    'impression',
    'accustomed',
    'few',
    'flow',
    'hold',
    'moustache',
    'corrupt',
    'tasty',
    'swear',
    'condition',
    'steep',
    'courage',
    'marry',
    'extreme',
    'those',
    'that',
    'tourism',
    'ground',
    'glove',
    'contain',
    'chain',
    'midnight',
    'obtain',
    'will',
    'acid',
    'stair',
    'update',
    'pay',
    'evidence',
    'carpet',
    'advocate',
    'cheer',
    'blow',
    'reject',
    'comprehension',
    'bathe',
    'dumpling',
    'high',
    'my',
    'airspace',
    'promise',
    'athletic',
    'headmistress',
    'slim',
    'after',
    'afterward',
    's',
    'refuse',
    'organ',
    'cautious',
    'advise',
    'fountain',
    'wet',
    'PE',
    'physical',
    'education',
    'remind',
    'whole',
    'down',
    'weekend',
    'punctuation',
    'shopping',
    'flag',
    'violate',
    'premier',
    'slice',
    'hunt',
    'healthy',
    'respond',
    'approve',
    'peach',
    'avoid',
    'sort',
    'daily',
    'trick',
    'bean',
    'curd',
    'many',
    'approach',
    'enquiry',
    'rude',
    'slow',
    'cab',
    'band',
    'transform',
    'paragraph',
    'freeway',
    'production',
    'international',
    'invent',
    'security',
    'rectangle',
    'his',
    'treasure',
    'govern',
    'discount',
    'fantastic',
    'sight',
    'delay',
    'restaurant',
    'independence',
    'spoken',
    'might',
    'which',
    'accept',
    'read',
    'every',
    'scientist',
    'so',
    'fever',
    'acre',
    'argument',
    'holy',
    'crew',
    'door',
    'today',
    'meal',
    'walk',
    'scenery',
    'found',
    'gesture',
    'come',
    'ample',
    'due',
    'tree',
    'meanwhile',
    'try',
    'construction',
    'intend',
    'nervous',
    'here',
    'divide',
    'page',
    'movement',
    'decrease',
    'raise',
    'bench',
    'fence',
    'manager',
    'interval',
    'bowl',
    'heel',
    'disability',
    'case',
    'sweat',
    'link',
    'exist',
    'mourn',
    'performance',
    'glad',
    'ancestor',
    'gun',
    'recognise',
    'different',
    'toast',
    'civilization',
    'language',
    'flee',
    'zebra',
    'select',
    'never',
    'broken',
    'mutton',
    'video',
    'twist',
    'shadow',
    'stocking',
    'algebra',
    'help',
    'cookie',
    'elegant',
    'endless',
    'centigrade',
    'glue',
    'concern',
    'basic',
    'wallet',
    'wave',
    'dish',
    'spelling',
    'know',
    'goods',
    'practise',
    'clothes',
    'scientific',
    'instead',
    'teenager',
    'welcome',
    'careless',
    'weigh',
    'parking',
    'human',
    'being',
    'used',
    'north',
    'chopsticks',
    'principle',
    'loud',
    'African',
    'size',
    'strike',
    'biology',
    'absence',
    'deaf',
    'rare',
    'unrest',
    'saleswoman',
    'royal',
    'below',
    'movie',
    'bowling',
    'resist',
    'kingdom',
    'powder',
    'condemn',
    'capsule',
    'let',
    'practical',
    'paddle',
    'temperature',
    'apart',
    'butterfly',
    'stand',
    'concert',
    'maximum',
    'simplify',
    'sleep',
    'spring',
    'tooth',
    'exercise',
    'reach',
    'overhead',
    'heaven',
    'dignity',
    'believe',
    'commitment',
    'parent',
    'tired',
    'tennis',
    'flesh',
    'ping',
    'pong',
    'circuit',
    'decoration',
    'review',
    'courtyard',
    'potato',
    'various',
    'destination',
    'appoint',
    'affection',
    'severe',
    'bush',
    'conductor',
    'sceptical',
    'mask',
    'why',
    'poor',
    'great',
    'solid',
    'permanent',
    'nest',
    'dust',
    'assess',
    'impossible',
    'would',
    'fat',
    'rapid',
    'northeast',
    'oral',
    'typical',
    'harmful',
    'darkness',
    'defeat',
    'spokeswoman',
    'beneficial',
    'wherever',
    'skip',
    'but',
    'Olympic',
    'confuse',
    'preference',
    'artificial',
    'expression',
    'drink',
    'check',
    'ban',
    'interrupt',
    'divorce',
    'variety',
    'altogether',
    'anniversary',
    'herb',
    'jump',
    'foolish',
    'quick',
    'he',
    'deposit',
    'at',
    'train',
    'shabby',
    'ripen',
    'worldwide',
    'computer',
    'sob',
    'kick',
    'thirst',
    'partly',
    'upset',
    'chalk',
    'diagram',
    'appear',
    'lamp',
    'if',
    'lorry',
    'congratulation',
    'forgetful',
    'castle',
    'skatebroad',
    'toothpaste',
    'ordinary',
    'piano',
    'collection',
    'emperor',
    'remove',
    'unlike',
    'encouragement',
    'bungalow',
    'lazy',
    'measure',
    'perhaps',
    'native',
    'ought',
    'wag',
    'become',
    'astronomer',
    'contemporary',
    'villager',
    'rewind',
    'when',
    'receive',
    'other',
    'salary',
    'potential',
    'compass',
    'animal',
    'ear',
    'pension',
    'annual',
    'salesman',
    'month',
    'behind',
    'drug',
    'creature',
    'hire',
    'respect',
    'granddaughter',
    'partner',
    'jaw',
    'mind',
    'total',
    'alarm',
    'aggressive',
    'mobile',
    'attention',
    'require',
    'air',
    'basement',
    'belong',
    'equipment',
    'recite',
    'standard',
    'straight',
    'chief',
    'decade',
    'shot',
    'earthquake',
    'scare',
    'PC',
    'personal',
    'computer',
    'access',
    'inform',
    'rain',
    'envy',
    'feeling',
    'keep',
    'flour',
    'yell',
    'rid',
    'badminton',
    'newspaper',
    'aim',
    'disadvantage',
    'admirable',
    'stress',
    'unable',
    'occupy',
    'laughter',
    'referee',
    'part',
    'introduce',
    'time',
    'pulse',
    'information',
    'soon',
    'theoretical',
    'junior',
    'journalist',
    'chemist',
    'pace',
    'frequent',
    'explicit',
    'bounce',
    'cat',
    'happen',
    'chemistry',
    'sharpen',
    'safe',
    'form',
    'steal',
    'toilet',
    'clothing',
    'prescription',
    'spell',
    'advice',
    'belief',
    'differ',
    'graduate',
    'seek',
    'spirit',
    'nail',
    'female',
    'development',
    'bottle',
    'blank',
    'round',
    'host',
    'cattle',
    'barber',
    'basis',
    'bite',
    'phone',
    'telephone',
    'parallel',
    'friend',
    'gym',
    'gymnasium',
    'equip',
    'way',
    'occupation',
    'appearance',
    'health',
    'bomb',
    'tour',
    'print',
    'addition',
    'apartment',
    'shut',
    'supper',
    'play',
    'guilty',
    'beast',
    'diary',
    'local',
    'dog',
    'progress',
    'boxing',
    'line',
    'diverse',
    'breakthrough',
    'dictionary',
    'supermarket',
    'shower',
    'wise',
    'controversial',
    'background',
    'spiritual',
    'handle',
    'bridge',
    'succeed',
    'calculate',
    'private',
    'reality',
    'accuracy',
    'smart',
    'sad',
    'butter',
    'contradictory',
    'passenger',
    'contribution',
    'beautiful',
    'sideway',
    'brand',
    'maybe',
    'easy',
    'close',
    'bunch',
    'actual',
    'statesman',
    'province',
    'fierce',
    'Mrs',
    'net',
    'age',
    'owner',
    'silver',
    'per',
    'deep',
    'summary',
    'flash',
    'citizen',
    'Christmas',
    'opposite',
    'blanket',
    'pregnant',
    'one',
    'anchor',
    'root',
    'wear',
    'participate',
    'firm',
    'neck',
    'request',
    'refrigerator',
    'pile',
    'changeable',
    'brave',
    'technology',
    'magazine',
    'the',
    'sparrow',
    'cook',
    'evaluate',
    'traditional',
    'man',
    'profit',
    'random',
    'bean',
    'botanical',
    'natural',
    'night',
    'double',
    'shortly',
    'lounge',
    'teapot',
    'scholarship',
    'tease',
    'warehouse',
    'quiet',
    'bag',
    'side',
    'uniform',
    'pray',
    'just',
    'pupil',
    'whale',
    'helpful',
    'tall',
    'hers',
    'outcome',
    'eager',
    'title',
    'northern',
    'bother',
    'silence',
    'sensitive',
    'scissors',
    'oneself',
    'sail',
    'arrange',
    'postcard',
    'ray',
    'clear',
    'kilogram',
    'typhoon',
    'dismiss',
    'law',
    'disappointed',
    'failure',
    'contradict',
    'primitive',
    'artist',
    'boss',
    'Catholic',
    'chemical',
    'aunt',
    'science',
    'operator',
    'outer',
    'dangerous',
    'birth',
    'arm',
    'improve',
    'separate',
    'expand',
    'America',
    'rubber',
    'police',
    'wire',
    'hurt',
    'virus',
    'textbook',
    'away',
    'winter',
    'carry',
    'acknowledge',
    'block',
    'cycle',
    'fisherman',
    'housework',
    'freedom',
    'discrimination',
    'normal',
    'official',
    'reserve',
    'refresh',
    'accurate',
    'finance',
    'cross',
    'everybody',
    'enjoyable',
    'visit',
    'modem',
    'word',
    'raincoat',
    'nationwide',
    'learn',
    'injury',
    'brother',
    'garbage',
    'tomb',
    'unfair',
    'insect',
    'her',
    'jar',
    'vegetable',
    'she',
    'silent',
    'pack',
    'clap',
    'pain',
    'able',
    'remote',
    'heat',
    'dormitory',
    'worthy',
    'choke',
    'send',
    'both',
    'industry',
    'fall',
    'fragile',
    'maple',
    'bank',
    'suspension',
    'minus',
    'mouse',
    'seize',
    'fax',
    'sing',
    'smell',
    'foggy',
    'occur',
    'pie',
    'cushion',
    'absurd',
    'examine',
    'thin',
    'yellow',
    'salt',
    'sea',
    'free',
    'cream',
    'hungry',
    'elect',
    'policeman',
    'confident',
    'drive',
    'room',
    'nobody',
    'board',
    'cash',
    'important',
    'blouse',
    'name',
    'acquisition',
    'write',
    'article',
    'sheep',
    'marble',
    'self',
    'lung',
    'incident',
    'juice',
    'vinegar',
    'overcoat',
    'tea',
    'simple',
    'snake',
    'concrete',
    'wealth',
    'hand',
    'encourage',
    'swell',
    'good',
    'record',
    'pair',
    'package',
    'entry',
    'extraordinary',
    'harmony',
    'ton',
    'him',
    'quite',
    'attract',
    'publish',
    'uncertain',
    'invitation',
    'whose',
    'enjoy',
    'conservative',
    'stare',
    'spray',
    'money',
    'garden',
    'either',
    'map',
    'e',
    'mail',
    'email',
    'theory',
    'noble',
    'nowhere',
    'produce',
    'sunburnt',
    'shape',
    'too',
    'receipt',
    'me',
    'ski',
    'son',
    'fur',
    'date',
    'optimistic',
    'toothbrush',
    'cap',
    'vote',
    'mirror',
    'shoe',
    'butcher',
    'specialist',
    'cake',
    'bachelor',
    'fruit',
    'tongue',
    'pyramid',
    'kite',
    'carpenter',
    'supreme',
    'cousin',
    'special',
    'somehow',
    'honest',
    'generation',
    'figure',
    'capital',
    'friendship',
    'pencil',
    'lantern',
    'social',
    'lame',
    'drop',
    'finger',
    'allocate',
    'boat',
    'farmer',
    'turning',
    'brochure',
    'possess',
    'pull',
    'magic',
    'save',
    'goal',
    'schoolmate',
    'period',
    'smooth',
    'wealthy',
    'merely',
    'serious',
    'dawn',
    'cup',
    'consume',
    'pond',
    'kind',
    'cough',
    'somewhere',
    'mine',
    'soccer',
    'politician',
    'anywhere',
    'second',
    'alphabet',
    'ripe',
    'hopeless',
    'performer',
    'steam',
    'digital',
    'biography',
    'abundant',
    'canteen',
    'introduction',
    'past',
    'mature',
    'quiz',
    'planet',
    'ourselves',
    'start',
    'seashell',
    'insurance',
    'adventure',
    'enemy',
    'appendix',
    'cancel',
    'unite',
    'damage',
    'rob',
    'method',
    'immediately',
    'fun',
    'brief',
    'electricity',
    'football',
    'exit',
    'morning',
    'liberty',
    'swim',
    'assistant',
    'moral',
    'book',
    'umbrella',
    'operation',
    'however',
    'hunger',
    'order',
    'consult',
    'unusual',
    'preserve',
    'headache',
    'teach',
    'palace',
    'desperate',
    'accessible',
    'lay',
    'am',
    'cause',
    'lemon',
    'motto',
    'stainless',
    'slip',
    'mosquito',
    'small',
    'understand',
    'talent',
    'activity',
    'astonish',
    'regardless',
    'training',
    'season',
    'although',
    'fiction',
    'take',
    'key',
    'bonus',
    'hard',
    'republic',
    'railway',
    'early',
    'final',
    'sit',
    'adequate',
    'accelerate',
    'education',
    'voluntary',
    'desert',
    'pollution',
    'pianist',
    'via',
    'settlement',
    'receptionist',
    'alongside',
    'out',
    'arithmetic',
    'foresee',
    'dilemma',
    'madam',
    'madame',
    'purse',
    'exhibition',
    'popular',
    'year',
    'dynamic',
    'CD',
    'compact',
    'disk',
    'awkward',
    'cabbage',
    'conservation',
    'by',
    'leak',
    'note',
    'strange',
    'inspect',
    'tube',
    'symbol',
    'sleepy',
    'acquaintance',
    'slight',
    'scan',
    'national',
    'shopkeeper',
    'sky',
    'behalf',
    'engine',
    'recover',
    'yes',
    'fine',
    'teacher',
    'accomplish',
    'explain',
    'tram',
    'company',
    'transport',
    'fellow',
    'attend',
    'colour',
    'bury',
    'purchase',
    'quake',
    'act',
    'follow',
    'grocery',
    'crash',
    'plane',
    'systematic',
    'network',
    'fundamental',
    'trade',
    'superior',
    'hotdog',
    'dial',
    'complete',
    'cheerful',
    'frontier',
    'battle',
    'pause',
    'warmth',
    'ruler',
    'mild',
    'explanation',
    'drawback',
    'proud',
    'cigarette',
    'strong',
    'tune',
    'offer',
    'long',
    'thought',
    'absorb',
    'mend',
    'invention',
    'victim',
    'responsibility',
    'minister',
    'tell',
    'sun',
    'rot',
    'beside',
    'approval',
    'radium',
    'pressure',
    'sorrow',
    'consider',
    'diamond',
    'drag',
    'apply',
    'useless',
    'register',
    'depth',
    'difference',
    'X',
    'ray',
    'X',
    'lack',
    'sentence',
    'tend',
    'announce',
    'division',
    'initial',
    'income',
    'all',
    'fist',
    'abolish',
    'them',
    'they',
    'grandma',
    'grandmother',
    'stand',
    'bicycle',
    'fear',
    'engineer',
    'arbitrary',
    'spoonful',
    'hang',
    'tape',
    'particular',
    'assistance',
    'mail',
    'hi',
    'settle',
    'forecast',
    'comment',
    'lady',
    'nursery',
    'radiation',
    'passport',
    'prove',
    'road',
    'house',
    'while',
    'row',
    'precious',
    'arch',
    'mass',
    'grape',
    'poison',
    'statement',
    'mouth',
    'merchant',
    'European',
    'roundabout',
    'wish',
    'enlarge',
    'AIDS',
    'abuse',
    'narrow',
    'grandparents',
    'action',
    'quality',
    'beach',
    'acute',
    'yesterday',
    'general',
    'far',
    'celebration',
    'react',
    'elder',
    'doctor',
    'stone',
    'loss',
    'playground',
    'cheque',
    'sneeze',
    'distinction',
    'gymnastics',
    'concept',
    'excellent',
    'common',
    'commercial',
    'demand',
    'presentation',
    'choir',
    'white',
    'stateswoman',
    'southern',
    'crossroads',
    'kitchen',
    'hobby',
    'preview',
    'win',
    'west',
    'hour',
    'haircut',
    'relay',
    'humour',
    'text',
    'possibility',
    'literary',
    'effort',
    'sir',
    'shark',
    'T',
    'shirt',
    'T',
    'art',
    'grow',
    'forever',
    'banana',
    'opinion',
    'awake',
    'invite',
    'administration',
    'slavery',
    'bishop',
    'diploma',
    'attractive',
    'between',
    'watermelon',
    'deadline',
    'car',
    'elephant',
    'minimum',
    'hammer',
    'baby',
    'exchange',
    'kangaroo',
    'crossing',
    'do',
    'work',
    'ambition',
    'base',
    'loaf',
    'president',
    'businesswoman',
    'merry',
    'minibus',
    'insure',
    'drum',
    'dark',
    'mistaken',
    'Moslem',
    'Muslim',
    'weak',
    'hunter',
    'rainy',
    'degree',
    'club',
    'scold',
    'session',
    'whom',
    'tomorrow',
    'cooker',
    'process',
    'library',
    'beat',
    'neighbour',
    'truth',
    'recent',
    'author',
    'dollar',
    'abandon',
    'beard',
    'silk',
    'BC',
    'tight',
    'bat',
    'victory',
    'honey',
    'substitute',
    'themselves',
    'zipper',
    'licence',
    'chapter',
    'unique',
    'hardly',
    'nut',
    'lawyer',
    'aware',
    'being',
    'alcoholic',
    'vehicle',
    'campaign',
    'upper',
    'lamb',
    'track',
    'branch',
    'large',
    'optional',
    'bacon',
    'whichever',
    'fasten',
    'convey',
    'problem',
    'pilot',
    'sickness',
    'hardworking',
    'atom',
    'eggplant',
    'lip',
    'rubbish',
    'hope',
    'embassy',
    'tin',
    'cost',
    'pin',
    'favour',
    'walnut',
    'entire',
    'mom',
    'mum',
    'share',
    'experiment',
    'leave',
    'sugar',
    'bent',
    'serve',
    'permit',
    'missile',
    'pill',
    'earth',
    'upward',
    's',
    'golf',
    'sculpture',
    'fortnight',
    'lend',
    'fish',
    'near',
    'sound',
    'feel',
    'successful',
    'dry',
    'return',
    'only',
    'waist',
    'trial',
    'ride',
    'put',
    'thorough',
    'and',
    'green',
    'sideroad',
    'rebuild',
    'around',
    'bathtub',
    'conventional',
    'discovery',
    'communication',
    'illegal',
    'now',
    'wrist',
    'museum',
    'guidance',
    'rainfall',
    'awful',
    'cosy',
    'tolerate',
    'rank',
    'throw',
    'category',
    'illness',
    'everywhere',
    'retell',
    'member',
    'petrol',
    'bedroom',
    'ceremony',
    'balance',
    'mustard',
    'polish',
    'constant',
    'uncle',
    'tiresome',
    'tailor',
    'disturbing',
    'moment',
    'statue',
    'moon',
    'system',
    'bargain',
    'energetic',
    'alcohol',
    'expectation',
    'instrument',
    'reliable',
    'equality',
    'greeting',
    'generous',
    'shuttle',
    'or',
    'handkerchief',
    'to',
    'fog',
    'everyone',
    'enterprise',
    'trunk',
    'soft',
    'comb',
    'useful',
    'bride',
    'oil',
    'sudden',
    'before',
    'sponsor',
    'always',
    'candy',
    'pavement',
    'hit',
    'biscuit',
    'table',
    'of',
    'modern',
    'kiss',
    'instruct',
    'without',
    'weight',
    'starvation',
    'city',
    'you',
    'consistent',
    'orange',
    'scream',
    'Oceania',
    'shelter',
    'characteristic',
    'evident',
    'inside',
    'trend',
    'appreciate',
    'fan',
    'attempt',
    'ankle',
    'spaceship',
    'indeed',
    'carrot',
    'abrupt',
    'curriculum',
    'depend',
    'plan',
    'market',
    'eventually',
    'schedule',
    'cool',
    'yummy',
    'strength',
    'fluent',
    'pedestrian',
    'claw',
    'suit',
    'party',
    'set',
    'task',
    'seat',
    'school',
    'applaud',
    'world',
    'furnished',
    'anger',
    'seagull',
    'department',
    'bring',
    'cheese',
    'press',
    'sweep',
    'panic',
    'pub',
    'suspect',
    'prevent',
    'challenging',
    'live',
    'bar',
    'pan',
    'corner',
    'temple',
    'pass',
    'real',
    'frost',
    'trip',
    'character',
    'tyre',
    'race',
    'through',
    'aspect',
    'novel',
    'permission',
    'wonder',
    'false',
    'our',
    'energy',
    'microscope',
    'grandchild',
    'exam',
    'examination',
    'climate',
    'suggestion',
    'consultant',
    'college',
    'Pacific',
    'shirt',
    'phenomenon',
    'cotton',
    'organization',
    'vase',
    'bleed',
    'cruel',
    'smoker',
    'terrify',
    'consist',
    'latter',
    'advertise',
    'harbour',
    'mark',
    'proper',
    'empty',
    'curtain',
    'style',
    'restriction',
    'upon',
    'camera',
    'loose',
    'university',
    'boot',
    'melon',
    'sour',
    'border',
    'coat',
    'hear',
    'consideration',
    'open',
    'anyone',
    'rocket',
    'ours',
    'notebook',
    'ambassadress',
    'skillful',
    'sale',
    'beer',
    'criterion',
    'translation',
    'weep',
    'tiger',
    'woollen',
    'have',
    'hesitate',
    'weakness',
    'balcony',
    'armchair',
    'extension',
    'southwest',
    'function',
    'reading',
    'business',
    'ugly',
    'connect',
    'cigar',
    'aboard',
    'grandpa',
    'grandfather',
    'justice',
    'debt',
    'begin',
    'raw',
    'countryside',
    'fry',
    'wipe',
    'smile',
    'fool',
    'everyday',
    'boom',
    'shaver',
    'erupt',
    'brush',
    'frog',
    'this',
    'court',
    'evolution',
    'insist',
    'grand',
    'week',
    'admit',
    'split',
    'forbid',
    'disaster',
    'society',
    'awesome',
    'embarrass',
    'provide',
    'vice',
    'muddy',
    'couple',
    'ant',
    'relax',
    'pocket',
    'cheek',
    'selfish',
    'forget',
    'balloon',
    'memory',
    'p',
    'm',
    'pm',
    'P',
    'M',
    'PM',
    'dead',
    'chocolate',
    'superb',
    'bee',
    'ad',
    'advertisement',
    'truly',
    'valuable',
    'draft',
    'scratch',
    'procedure',
    'be',
    'should',
    'soap',
    'alley',
    'religion',
    'primary',
    'No',
    'number',
    'punishment',
    'granny',
    'mat',
    'waiter',
    'include',
    'oval',
    'finish',
    'flexible',
    'dustbin',
    'any',
    'top',
    'stay',
    'souvenir',
    'left',
    'bone',
    'ability',
    'stomach',
    'basket',
    'available',
    'regret',
    'ever',
    'anything',
    'ago',
    'previous',
    'window',
    'thrill',
    'federal',
    'bottom',
    'physicist',
    'accompany',
    'increase',
    'murder',
    'accumulate',
    'for',
    'excite',
    'bath',
    'traffic',
    'classic',
    'festival',
    'rather',
    'drill',
    'allergic',
    'insert',
    'fare',
    'spear',
    'theirs',
    'conflict',
    'lecture',
    'even',
    'chaos',
    'youth',
    'fault',
    'desk',
    'list',
    'porridge',
    'tasteless',
    'backward',
    's',
    'suggest',
    'influence',
    'disagreement',
    'virtue',
    'personal',
    'guide',
    'damp',
    'future',
    'cent',
    'fold',
    'over',
    'golden',
    'translator',
    'queen',
    'queue',
    'librarian',
    'communism',
    'signal',
    'outgoing',
    'burglar',
    'deal',
    'motor',
    'growth',
    'state',
    'glass',
    'presence',
    'database',
    'office',
    'family',
    'motorcycle',
    'ridiculous',
    'duck',
    'overcome',
    'cafeteria',
    'motivation',
    'culture',
    'poet',
    'preparation',
    'centimetre',
    'gate',
    'tortoise',
    'hospital',
    'they',
    'architect',
    'heavy',
    'chance',
    'messy',
    'solar',
    'multiply',
    'plant',
    'film',
    'guitar',
    'then',
    'sister',
    'count',
    'experience',
    'once',
    'poem',
    'choice',
    'quantity',
    'immigration',
    'inch',
    'also',
    'similar',
    'outline',
    'ministry',
    'remain',
    'grain',
    'baggage',
    'clerk',
    'withdraw',
    'idiom',
    'architecture',
    'alone',
    'ward',
    'flame',
    'thinking',
    'pot',
    'mailbox',
    'academic',
    'bed',
    'hat',
    'caution',
    'pepper',
    'afford',
    'bound',
    'jewellery',
    'dash',
    'lightning',
    'stranger',
    'port',
    'nose',
    'customer',
    'practice',
    'turkey',
    'meat',
    'tail',
    'situation',
    'position',
    'construct',
    'push',
    'secretary',
    'stain',
    'tension',
    'schoolgirl',
    'risk',
    'late',
    'stamp',
    'absent',
    'challenge',
    'shine',
    'cell',
    'grade',
    'full',
    'collect',
    'minute',
    'catalogue',
    'clarify',
    'fade',
    'sunny',
    'worn',
    'roast',
    'picture',
    'horrible',
    'population',
    'nice',
    'AD',
    'colleague',
    'speak',
    'love',
    'child',
    'achieve',
    'discover',
    'spin',
    'adolescence',
    'nurse',
    'active',
    'panda',
    'adore',
    'forgive',
    'tire',
    'cold',
    'earn',
    'travel',
    'distribute',
    'jungle',
    'dull',
    'clever',
    'dislike',
    'pole',
    'radio',
    'former',
    'careful',
    'employ',
    'whistle',
    'separation',
    'happiness',
    'prayer',
    'underwear',
    'pine',
    'downstairs',
    'dizzy',
    'space',
    'cocoa',
    'abnormal',
    'young',
    'passage',
    'sideways',
    'cube',
    'extra',
    'tool',
    'show',
    'plot',
    'express',
    'southeast',
    'girl',
    'cave',
    'ache',
    'monkey',
    'target',
    'Mr',
    'ambulance',
    'unless',
    'noon',
    'range',
    'shake',
    'vocabulary',
    'miss',
    'dessert',
    'painful',
    'connection',
    'true',
    'casual',
    'strengthen',
    'circumstance',
    'knee',
    'tank',
    'handful',
    'gram',
    'during',
    'correct',
    'importance',
    'wheat',
    'ahead',
    'joke',
    'coffee',
    'shock',
    'punctual',
    'leg',
    'ink',
    'brake',
    'its',
    'anybody',
    'washroom',
    'sex',
    'holiday',
    'downtown',
    'mountainous',
    'organise',
    'strawberry',
    'starve',
    'expect',
    'worthwhile',
    'candle',
    'obey',
    'geometry',
    'doubt',
    'DVD',
    'digital',
    'video',
    'disk',
    'ballet',
    'web',
    'housewife',
    'role',
    'roll',
    'wrinkle',
    'tap',
    'make',
    'eye',
    'traveller',
    'neat',
    'where',
    'almost',
    'ask',
    'laundry',
    'move',
    'labour',
    'a',
    'feast',
    'swallow',
    'pen',
    'award',
    'handy',
    'reporter',
    'relate',
    'stubborn',
    'identify',
    'entrance',
    'forest',
    'that',
    'ice',
    'cream',
    'remember',
    'lemonade',
    'dusty',
    'delight',
    'westward',
    's',
    'litter',
    'imagine',
    'support',
    'machine',
    'charge',
    'fancy',
    'end',
    'disabled',
    'associate',
    'entertainment',
    'fond',
    'porter',
    'hate',
    'appointment',
    'woman',
    'class',
    'album',
    'delighted',
    'fork',
    'promote',
    'doll',
    'cry',
    'bright',
    'deliver',
    'catastrophe',
    'comfortable',
    'portable',
    'not',
    'retire',
    'visitor',
    'ecology',
    'own',
    'recipe',
    'history',
    'luck',
    'visa',
    'unfortunate',
    'achievement',
    'rabbit',
    'programme',
    'sofa',
    'battery',
    'postman',
    'electrical',
    'talk',
    'mercy',
    'iron',
    'present',
    'baseball',
    'strict',
    'bare',
    'airline',
    'comedy',
    'century',
    'dear',
    'apron',
    'flat',
    'assist',
    'sport',
    'politics',
    'fly',
    'actor',
    'farm',
    'song',
    'outing',
    'belly',
    'typist',
    'policy',
    'float',
    'buffet',
    'settler',
    'headmaster',
    'happy',
    'catch',
    'medium',
    'steward',
    'riddle',
    'bear',
    'nearby',
    'mess',
    'paperwork',
    'flu',
    'supply',
    'model',
    'mist',
    'Dr',
    'doctor',
    'popcorn',
    'corn',
    'old',
    'chew',
    'exact',
    'aircraft',
    'view',
    'bike',
    'bicycle',
    'hydrogen',
    'astronomy',
    'cupboard',
    'rule',
    'flower',
    'project',
    'test',
    'represent',
    'shallow',
    'weekday',
    'document',
    'thank',
    'purpose',
    'step',
    'bark',
    'overweight',
    'tower',
    'direct',
    'liquid',
    'worm',
    'hello',
    'hamburger',
    'chorus',
    'stove',
    'reputation',
    'sweater',
    'affect',
    'windy',
    'may',
    'niece',
    'regulation',
    'soul',
    'eyesight',
    'brick',
    'till',
    'harm',
    'ambassador',
    'sailor',
    'egg',
    'wind',
    'tourist',
    'mountain',
    'gallery',
    'clone',
    'mushroom',
    'northwest',
    'needle',
    'tie',
    'trolleybus',
    'committee',
    'in',
    'lap',
    'everything',
    'warm',
    'cyclist',
    'widow',
    'shall',
    'yawn',
    'afternoon',
    'Buddhism',
    'timetable',
    'chairman',
    'are',
    'funny',
    'decorate',
    'edge',
    'file',
    'boycott',
    'underline',
    'technique',
    'childhood',
    'blood',
    'pound',
    'crop',
    'celebrate',
    'absolute',
    'describe',
    'sock',
    'breathless',
    'liberation',
    'knife',
    'rose',
    'custom',
    'resemble',
    'bye',
    'graph',
    'worried',
    'salute',
    'amount',
    'ignore',
    'whoever',
    'barbecue',
    'delicious',
    'summer',
    'rich',
    'telescope',
    'abroad',
    'beef',
    'accuse',
    'sleeve',
    'mm',
    'millimetre',
    'body',
    'navy',
    'basin',
    'say',
    'dusk',
    'these',
    'this',
    'student',
    'steel',
    'friendly',
    'music',
    'altitude',
    'sure',
    'wrestle',
    'it',
    'treat',
    'wonderful',
    'probably',
    'button',
    'force',
    'ambiguous',
    'bridegroom',
    'really',
    'gentleman',
    'giraffe',
    'possession',
    'boil',
    'telephone',
    'recycle',
    'cloth',
    'shoulder',
    'park',
    'confirm',
    'compare',
    'answer',
    'mankind',
    'wolf',
    'danger',
    'hug',
    'camel',
    'shortcoming',
    'river',
    'about',
    'tear',
    'antique',
    'thing',
    'unbearable',
    'sneaker',
    'circus',
    'familiar',
    'still',
    'pretend',
    'beddings',
    'whatever',
    'amaze',
    'vacant',
    'suffer',
    'Atlantic',
    'flood',
    'devotion',
    'wedding',
    'rush',
    'difficulty',
    'friction',
    'king',
    'schoolbag',
    'urge',
    'screen',
    'cast',
    'steak',
    'parcel',
    'square',
    'warn',
    'lock',
    'under',
    'debate',
    'tough',
    'design',
    'corporation',
    'negotiate',
    'new',
    'tip',
    'modest',
    'association',
    'adopt',
    'constitution',
    'curious',
    'medal',
    'taxi',
    'arrangement',
    'packet',
    'pour',
    'group',
    'crayon',
    'musical',
    'angry',
    'boundary',
    'spokesman',
    'lonely',
    'though',
    'academy',
    'their',
    'outspoken',
    'length',
    'thick',
    'wing',
    'myself',
    'digest',
    'plenty',
    'fair',
    'squeeze',
    'product',
    'mention',
    'coach',
    'suitable',
    'kid',
    'lion',
    'straight',
    'forward',
    'there',
    'educate',
    'disk',
    'disc',
    'calm',
    'fridge',
    'refrigerator',
    'distance',
    'relative',
    'satisfaction',
    'village',
    'television',
];
exports.default = classNameList;


/***/ }),
/* 205 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
const generateWXML = (data) => {
    let wxml = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        if (record.type === 'Image') {
            wxml.push(`<image class="${record.className}" src="./images/${record.value}"/>`);
        }
        else {
            if (record.type === 'Text') {
                wxml.push(`<view class="${record.className}">`);
                record.value = record.value.replace(/\n/g, '\\n') || '';
                wxml.push(record.value || '');
            }
            else {
                wxml.push(`<view class="${record.className}" >`);
            }
            if (Array.isArray(record.children)) {
                wxml.push(generateWXML(record.children));
            }
            if (record.type === 'Text') {
                wxml.push(`</view>`);
            }
            else {
                wxml.push(`</view>`);
            }
        }
    }
    return wxml.join('\n');
};
exports.default = generateWXML;


/***/ }),
/* 206 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/**
 *  px转换为rpx
 *
 */
const pxtorpx = (value, size) => {
    const scale = 750 / size;
    if (/px/.test(value)) {
        value = value.replace(/((\.|\d|\e|\-)+)px/g, ($1, $2) => {
            return `${Math.round($1.split('px')[0] * 10 * scale) / 10}rpx`;
        });
    }
    return value;
};
const generateWeappStyle = (data, size) => {
    let style = [];
    if (data.style && Object.keys(data.style).length) {
        for (var key in data.style) {
            if (data.style.hasOwnProperty(key) &&
                data.style[key] != undefined) {
                let currValue = data.style[key];
                currValue = pxtorpx(currValue, size);
                style.push(`${key}: ${currValue};`);
            }
        }
    }
    return style.join('\n');
};
const generateWXSS = (data, size, parentNodeName = '') => {
    let wxss = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        let nodeName = parentNodeName
            ? parentNodeName + ' .' + record.className
            : '.' + record.className;
        wxss.push(nodeName + '{');
        wxss.push(generateWeappStyle(record, size));
        wxss.push('}');
        if (record.children) {
            wxss.push(generateWXSS(record.children, size, nodeName));
        }
    }
    return wxss.join('\n');
};
exports.default = generateWXSS;


/***/ }),
/* 207 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: iChengbo
 * @Date: 2020-09-02 11:41:52
 * @LastEditors: iChengbo
 * @LastEditTime: 2021-02-03 15:45:08
 * @FilePath: /Picasso/picasso-package/packages/picasso-code-browser/src/reactnative/generateJSX.ts
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRNJSX = void 0;
const RN = {
    Container: 'View',
    Image: 'ImageBackground',
    Text: 'Text',
    Link: 'Text',
};
/**
 *
 *
 * @param {Array} data layoutDSL
 * @returns React代码
 */
function _generateRNJSX(data) {
    let html = [];
    for (let i = 0; i < data.length; i++) {
        let record = data[i];
        if (record.type == 'Image' && ((record.children && record.children.length == 0) || !record.children)) {
            const source = formatImageSource(record.value);
            html.push(`<Image style=${record.addClassName
                ? `{StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])}`
                : `{styles.${record.className}}`} source={${source}} resizeMode={"stretch"} />`);
        }
        else {
            let tag = RN[record.type];
            if (record.type == 'Image') {
                // console.log("图片样式：", record.style)
                // 背景图片
                if (!!record.style.backgroundImage) {
                    const bgSource = formatImageSource(record.style.backgroundImage);
                    html.push(`<${tag} style={${record.addClassName ?
                        `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])`
                        : `styles.${record.className}`}}
                            source={${bgSource}}
                        >`);
                }
                else if (!!record.style.linearGradient) {
                    // 渐变的处理
                    tag = 'LinearGradient';
                    const { gAngle, gList } = record.style.linearGradient;
                    const _gList = gList.map(item => {
                        // return generateColor(item.color);
                    });
                    const { width, height } = record.style.backgroundSize;
                    html.push(`<LinearGradient useAngle={true} angle={${+gAngle}} colors={${JSON.stringify(_gList)}} style={{width: scaleSize(${width / 2}), height: scaleSize(${height / 2})}}>`);
                }
                else {
                    tag = 'View';
                    html.push('<View>');
                }
            }
            else if (record.type == 'Text') {
                // 文本特殊处理：包一层View设置高度，并将文本垂直居中
                // 方案一：会导致一些其他的问题
                // tag = 'View';
                // html.push(`<${tag} style={{ height: styles.${record.className}.height, flexDirection: 'row', alignItems: 'center'  }}>`)
                // // html.push(`<${tag} style={${record.addClassName ?
                // //     `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}, { flexDirection: 'row', alignItems: 'center' }])`
                // //     : `[styles.${record.className}, { flexDirection: 'row', alignItems: 'center' }]`}}>`);
                // html.push(`<Text style={${record.addClassName ?
                //     `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}, { height: undefined, lineHeight: undefined }])`
                //     : `[styles.${record.className}, { height: undefined, lineHeight: undefined }]`}}>`
                // );
                // html.push(record.value.replace(/\n/g, `{"\\n"}`) || '');
                // html.push('</Text>');
                // 方案二：将高度及行高均置为 undefined，但会影响上下间距布局
                html.push(`<${tag} style={${record.addClassName ?
                    `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])`
                    : `[styles.${record.className}, { height: undefined, lineHeight: undefined }]`}}>`);
            }
            else {
                html.push(`<${tag} style={${record.addClassName ?
                    `StyleSheet.flatten([styles.${record.addClassName}, styles.${record.className}])`
                    : `styles.${record.className}`}}>`);
            }
            if (record.children && record.type != 'Text') {
                // 递归 子 children
                html.push(exports.generateRNJSX(record.children));
            }
            // else if (record.children && record.type == 'Text' && !record.isMerged) {
            //     // TODO：此处是干啥的
            //     html.push(record.value || '');
            //     html.push(generateRNJSX(record.children));
            // } 
            else {
                if (record.type == 'Text') {
                    html.push(record.value.replace(/\n/g, `{"\\n"}`) || '');
                }
            }
            html.push(`</${tag}>`);
        }
    }
    return html.join('\n');
}
exports.generateRNJSX = (data) => {
    let JSXCode = _generateRNJSX(data);
    return JSXCode;
    // return beautifyHtml(JSXCode, { indent_size: 2 })
};
/**
 * 根据图片名称，格式化为 RN Image 标签 source 属性
 * @param imageName 图片名称
 */
function formatImageSource(imageName) {
    let imageSource = '';
    if (/^http/.test(imageName)) {
        imageSource = `{uri: "${imageName}"}`;
    }
    else {
        imageSource = `require('./images/${imageName}')`.replace(/\@\d+x/, '');
    }
    return imageSource;
}


/***/ }),
/* 208 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.generateRNStyle = void 0;
/*
 * @Author: iChengbo
 * @Date: 2020-09-02 11:44:55
 * @LastEditors: iChengbo
 * @LastEditTime: 2020-12-24 15:17:23
 * @FilePath: /Picasso/picasso-package/packages/picasso-code-browser/src/reactnative/generateStyle.ts
 */
let styles = {};
exports.generateRNStyle = (data) => {
    if (Array.isArray(data)) {
        data.forEach(item => {
            // 删除特殊处理的属性
            delete item.style.backgroundImage;
            delete item.style.linearGradient;
            delete item.style.backgroundSize;
            styles[item.className] = item.style;
            if (Array.isArray(item.children)) {
                exports.generateRNStyle(item.children);
            }
        });
    }
    let result = JSON.stringify(styles, null, 2).replace(/"width": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"width": scaleSize(${$1})`;
    });
    result = result.replace(/"height": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"height": scaleSize(${$1})`;
    });
    result = result.replace(/"lineHeight": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"lineHeight": scaleSize(${$1})`;
    });
    result = result.replace(/"marginLeft": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"marginLeft": scaleSize(${$1})`;
    });
    result = result.replace(/"marginTop": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"marginTop": scaleSize(${$1})`;
    });
    result = result.replace(/"fontSize": ((\.|\d|\e|\-)+)/g, ($, $1) => {
        return `"fontSize": scaleSize(${$1})`;
    });
    return result;
};


/***/ })
/******/ ]);
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['openOfficialWebsite'] = __skpm_run.bind(this, 'openOfficialWebsite');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['getCompData'] = __skpm_run.bind(this, 'getCompData')
